"""Прибыль магазина «по-честному»: завершённые заказы Kaspi минус себестоимость, комиссия Kaspi, доставка, налог.
Только чтение. Завершённые заказы не меняются, поэтому их позиции кэшируются в data/profit_cache.json."""
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from core import kaspi_store as ks
from core import order_flow as of
from core import orders_screen as osr

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_CACHE = os.path.join(ROOT, "data", "profit_cache.json")
_LOCK = threading.Lock()


def _cache_load():
    try:
        with open(_CACHE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _entries_priced(order_id):
    try:
        d = osr._get(f"https://kaspi.kz/shop/api/v2/orders/{order_id}/entries?include=product")
    except Exception:
        return None
    out = []
    for e in d.get("data", []):
        a = e.get("attributes", {})
        off = a.get("offer") or {}
        qty = int(a.get("quantity") or 1)
        unit = a.get("basePrice")
        if unit is None and a.get("totalPrice") is not None:
            unit = float(a["totalPrice"]) / max(qty, 1)
        out.append({"sku": off.get("code"), "name": off.get("name"), "qty": qty, "unit": float(unit or 0)})
    return out


def _costs():
    """sku -> себестоимость: ваша правка > файл себестоимостей > черновик карточки > оценка магазина."""
    out = {}
    # оценки магазина (default_cost) не используем: закупка только введённая или из черновика
    try:
        with open(os.path.join(ROOT, "data", "kaspi_card_drafts.json"), encoding="utf-8") as f:
            for d in json.load(f):
                if d.get("sku") and (d.get("cost") or 0) > 0:
                    out[str(d["sku"])] = float(d["cost"])
    except Exception:
        pass
    try:
        with open(os.path.join(ROOT, "data", "my_store_costs.json"), encoding="utf-8") as f:
            for k, v in json.load(f).items():
                if float(v or 0) > 0:
                    out[str(k)] = float(v)
    except Exception:
        pass
    try:
        for k, v in ks.load_overrides().items():
            if float(v.get("cost_price") or 0) > 0:
                out[str(k)] = float(v["cost_price"])
    except Exception:
        pass
    return out


def _econ_params():
    """Те же настройки доставки, упаковки и НДС, что в «Мой магазин», чтобы прибыль на Главной совпадала с таблицей магазина."""
    mode = ks._config_value("kaspi_delivery_mode", "official_kz")
    kw = {"pack_kzt": float(ks._config_value("packaging_cost_kzt", 150) or 150),
          "delivery_scope": "city" if mode == "official_city" else "kz",
          "include_vat": ks._config_value("kaspi_delivery_vat", True)}
    if mode == "custom":
        try:
            kw["delivery_kzt"] = float(ks._config_value("kaspi_delivery_cost_kzt", 1299))
        except (TypeError, ValueError):
            pass
    return kw


def _comm_by_sku():
    """sku -> комиссия Kaspi по категории товара (как в таблице магазина)."""
    out = {}
    try:
        for p in ks.load_live_products():
            if p.get("sku"):
                out[str(p["sku"])] = ks.category_commission(p.get("category"), p.get("commission_rate", 12.5))
    except Exception:
        pass
    return out


_FIN = os.path.join(ROOT, "data", "finance.json")


def load_expenses():
    """Ваши расходы в месяц: [{"name": "Реклама", "month": 30000}, ...]. Вводятся вручную, Kaspi их не знает."""
    try:
        with open(_FIN, encoding="utf-8") as f:
            raw = json.load(f).get("expenses") or []
    except (OSError, ValueError, AttributeError):
        return []
    out = []
    for e in raw[:10]:
        try:
            m = float(e.get("month") or 0)
        except (TypeError, ValueError):
            continue
        if m > 0:
            out.append({"name": str(e.get("name") or "Расход")[:40], "month": round(m)})
    return out


def save_expenses(items):
    clean = []
    for e in (items or [])[:10]:
        try:
            m = float(e.get("month") or 0)
        except (TypeError, ValueError, AttributeError):
            continue
        if 0 < m <= 100_000_000:
            clean.append({"name": str(e.get("name") or "Расход").strip()[:40] or "Расход", "month": round(m)})
    os.makedirs(os.path.dirname(_FIN), exist_ok=True)
    ks._atomic_json_write(_FIN, {"expenses": clean})
    return clean


def _is_return(o):
    a = o.get("attributes") or {}
    kd = a.get("kaspiDelivery") or {}
    st = a.get("status")
    return st in of.RETURN_STATUSES or (st == "CANCELLED" and bool(kd.get("courierTransmissionDate")))


def _return_loss(total, ek):
    """Потеря на одном возврате: доставка Kaspi и упаковка (товар возвращается на склад). Та же логика, что в калькуляторе маржи."""
    if ek.get("delivery_kzt") is not None:
        fee = float(ek["delivery_kzt"])
    else:
        try:
            fee = float(ks.get_kaspi_delivery_details(float(total or 0), scope=ek.get("delivery_scope", "kz"),
                                                      include_vat=ek.get("include_vat", True)).get("fee") or 0)
        except Exception:
            fee = 0.0
    return fee + float(ek.get("pack_kzt") or 0)


def _structure(T, period):
    """Куда уходит выручка (по заказам с известной закупкой) + возвраты и ваши расходы за тот же период."""
    if T["rev"] <= 0:
        return None
    rows = [("Выручка (заказы с закупкой)", T["rev"]), ("Закупка товара", -T["cogs"]),
            ("Комиссия Kaspi и Kaspi Pay", -T["kaspi"]), ("Доставка Kaspi", -T["delivery"]),
            ("Упаковка", -T["pack"]), ("Налог", -T["tax"])]
    out = [{"name": n, "sum": round(v)} for n, v in rows]
    out.append({"name": "Прибыль с продаж", "sum": round(T["profit"]), "total": True})
    out.append({"name": "Возвраты и отмены", "sum": -period["ret_loss"]})
    out.append({"name": "Ваши расходы", "sum": -period["expenses"]})
    out.append({"name": "Чистыми", "sum": period["net"], "total": True})
    return out


def _forecast(period, days):
    """Оценка «за 30 дней при таком темпе». Только если заказов достаточно, чтобы не гадать по паре штук."""
    if days < 7 or period["orders"] < 5:
        return None
    return round(period["net"] / days * 30)


def to_csv(kind, rep):
    """CSV для Excel: разделитель «;», кодировка UTF-8 с BOM. kind: products | days."""
    import csv
    import io as _io
    buf = _io.StringIO()
    w = csv.writer(buf, delimiter=";")
    if kind == "days":
        w.writerow(["Дата", "Заказов", "Выручка, ₸", "Прибыль с продаж, ₸", "Потери на возвратах, ₸"])
        for d in sorted(rep.get("days") or [], key=lambda x: x["date"]):
            w.writerow([d["date"], d["orders"], d["revenue"], d["profit"], d.get("ret_loss", 0)])
    else:
        w.writerow(["Артикул", "Товар", "Продано, шт", "Выручка, ₸", "Прибыль, ₸", "Маржа, %", "Закупка указана"])
        for p in rep.get("products") or []:
            w.writerow([p.get("sku"), p.get("name"), p.get("qty"), p.get("revenue"), p.get("profit") if p.get("known") else "",
                        p.get("margin_pct") if p.get("margin_pct") is not None else "", "да" if p.get("known") else "нет"])
    return "\ufeff" + buf.getvalue()


def _cheaper(prods, costs, days):
    """Товары, где «🔍 дешевле» нашёл закупку ниже вашей, и сколько это стоит в месяц при текущем темпе продаж."""
    try:
        from core import sourcing
        best = sourcing.best_summary()
    except Exception:
        return None
    rows = []
    for p in prods:
        sku = str(p["sku"])
        cost = costs.get(sku)
        b = (best.get(sku) or {}).get("best")
        if not cost or not b or not b.get("price") or p["qty"] <= 0:
            continue
        diff = cost - float(b["price"])
        if diff <= 1:
            continue
        qty_m = p["qty"] / max(days, 1) * 30
        rows.append({"sku": sku, "name": p["name"], "market": b.get("market"), "price": round(b["price"]), "cost": round(cost),
                     "diff": round(diff), "qty_month": round(qty_m, 1), "loss_month": round(diff * qty_m), "url": b.get("url")})
    rows.sort(key=lambda r: r["loss_month"], reverse=True)
    return {"total_month": sum(r["loss_month"] for r in rows), "count": len(rows), "items": rows[:10]}


def frozen(products):
    """Деньги в товаре: закупка × остаток. Считаются только карточки с известным остатком и введённой закупкой."""
    total = units = with_cost = no_cost = est = 0
    rows = []
    for p in products or []:
        if p.get("delivery_type") == "archive":
            continue
        if p.get("stock_est"):
            est += 1
            continue
        try:
            stock = int(float(p.get("stock") or 0))
        except (TypeError, ValueError):
            continue
        if stock <= 0:
            continue
        try:
            cost = float(p.get("cost_price") or 0)
        except (TypeError, ValueError):
            cost = 0.0
        if cost <= 0:
            no_cost += 1
            continue
        with_cost += 1
        units += stock
        total += cost * stock
        rows.append({"sku": p.get("sku"), "name": (p.get("title") or "")[:60], "stock": stock, "cost": round(cost), "sum": round(cost * stock)})
    rows.sort(key=lambda r: r["sum"], reverse=True)
    return {"total": round(total), "units": units, "count": with_cost, "no_cost": no_cost, "stock_unknown": est, "top": rows[:5]}


def report(days=28):
    windows = max(1, min(4, -(-days // 14)))
    archive = of._scan(["ARCHIVE"], windows=windows)
    cutoff = int(time.time() * 1000) - days * 86400000
    orders = [o for o in archive if o["attributes"].get("status") == "COMPLETED"]
    orders = [o for o in orders if (o["attributes"].get("completionDate") or 0) >= cutoff]
    rets = [o for o in archive if _is_return(o)
            and ((o["attributes"].get("completionDate") or o["attributes"].get("creationDate") or 0) >= cutoff)]
    with _LOCK:
        cache = _cache_load()
        todo = [o for o in orders if o["id"] not in cache]
        if todo:
            with ThreadPoolExecutor(6) as ex:
                got = list(ex.map(lambda o: _entries_priced(o["id"]), todo))
            for o, g in zip(todo, got):
                if g is not None:
                    cache[o["id"]] = g
            os.makedirs(os.path.dirname(_CACHE), exist_ok=True)
            ks._atomic_json_write(_CACHE, cache)
    costs = _costs()
    ek, comm = _econ_params(), _comm_by_sku()
    by_day, by_prod = {}, {}
    T = {"rev": 0.0, "cogs": 0.0, "kaspi": 0.0, "delivery": 0.0, "pack": 0.0, "tax": 0.0, "profit": 0.0}
    no_cost_orders = 0
    for o in orders:
        a = o["attributes"]
        items = cache.get(o["id"])
        if not items:
            continue
        day = time.strftime("%Y-%m-%d", time.localtime((a.get("completionDate") or 0) / 1000))
        d = by_day.setdefault(day, {"date": day, "orders": 0, "revenue": 0.0, "profit": 0.0, "known_rev": 0.0, "ret_n": 0, "ret_loss": 0.0})
        d["orders"] += 1
        unknown = False
        for it in items:
            rev = it["unit"] * it["qty"]
            cost = costs.get(str(it["sku"]))
            p = by_prod.setdefault(str(it["sku"]), {"sku": it["sku"], "name": it["name"], "qty": 0, "revenue": 0.0,
                                                    "profit": 0.0, "known": True})
            p["qty"] += it["qty"]
            p["revenue"] += rev
            d["revenue"] += rev
            if cost:
                econ = ks.calculate_product_economics(it["unit"], cost, comm_rate=comm.get(str(it["sku"]), 12.5), **ek)
                d["known_rev"] += rev
                q = it["qty"]
                T["rev"] += rev
                T["cogs"] += cost * q
                T["kaspi"] += (econ.get("comm_kzt") + econ.get("pay_kzt")) * q
                T["delivery"] += econ.get("delivery_kzt") * q
                T["pack"] += econ.get("pack_kzt") * q
                T["tax"] += econ.get("tax_kzt") * q
                pr = float(econ.get("net_profit") or 0) * it["qty"]
                p["profit"] += pr
                d["profit"] += pr
                T["profit"] += pr
            else:
                p["known"] = False
                unknown = True
        no_cost_orders += 1 if unknown else 0
    for o in rets:
        a = o["attributes"]
        day = time.strftime("%Y-%m-%d", time.localtime((a.get("completionDate") or a.get("creationDate") or 0) / 1000))
        d = by_day.setdefault(day, {"date": day, "orders": 0, "revenue": 0.0, "profit": 0.0, "known_rev": 0.0, "ret_n": 0, "ret_loss": 0.0})
        d["ret_n"] += 1
        d["ret_loss"] += _return_loss(a.get("totalPrice"), ek)
    days_list = sorted(by_day.values(), key=lambda x: x["date"], reverse=True)
    today = time.strftime("%Y-%m-%d")
    week_from = time.strftime("%Y-%m-%d", time.localtime(time.time() - 6 * 86400))
    exp_list = load_expenses()
    exp_month = sum(e["month"] for e in exp_list)

    def agg(f, span):
        sel = [d for d in days_list if f(d["date"])]
        kr = sum(d["known_rev"] for d in sel)
        pr = sum(d["profit"] for d in sel)
        rl = sum(d["ret_loss"] for d in sel)
        ex = exp_month * span / 30.0
        return {"orders": sum(d["orders"] for d in sel), "revenue": round(sum(d["revenue"] for d in sel)),
                "profit": round(pr), "known_revenue": round(kr), "margin_pct": round(pr / kr * 100, 1) if kr > 0 else None,
                "ret_count": sum(d["ret_n"] for d in sel), "ret_loss": round(rl), "expenses": round(ex),
                "net": round(pr - rl - ex)}
    prev_from = time.strftime("%Y-%m-%d", time.localtime(time.time() - 13 * 86400))
    prods = sorted(by_prod.values(), key=lambda p: -p["profit"])
    for p in prods:
        p["revenue"], p["profit"] = round(p["revenue"]), round(p["profit"])
    for p in prods:
        p["margin_pct"] = round(p["profit"] / p["revenue"] * 100, 1) if p["known"] and p["revenue"] > 0 else None
    losers = [p for p in prods if p["known"] and p["profit"] < 0]
    return {"today": agg(lambda d: d == today, 1), "week": agg(lambda d: d >= week_from, 7), "period": agg(lambda d: True, days),
            "prev_week": agg(lambda d: prev_from <= d < week_from, 7) if days >= 14 else None,
            "expenses": exp_list, "expenses_month": exp_month,
            "structure": _structure(T, agg(lambda d: True, days)),
            "forecast_30": _forecast(agg(lambda d: True, days), days),
            "products": prods[:300],
            "cheaper": _cheaper(prods, costs, days),
            "days": [dict(d, revenue=round(d["revenue"]), profit=round(d["profit"]), known_rev=round(d["known_rev"]), ret_loss=round(d["ret_loss"])) for d in days_list[:30]],
            "top": [p for p in prods if p["known"]][:8], "losers": losers[:8], "no_cost_orders": no_cost_orders, "period_days": days}
