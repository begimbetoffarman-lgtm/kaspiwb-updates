"""«Где закупить дешевле»: ищет товар вашей карточки Kaspi на Wildberries по фото (поиск по картинке на сайте WB
через браузер ego) и считает чистую маржу при вашей текущей цене. Ничего не записывает в закупку само:
«взять как закупку» делает только владелец кнопкой."""
import json
import os
import re
import time

from core import ego_bridge, imghash
from core import kaspi_store as ks

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_FILE = os.path.join(BASE_DIR, "data", "sourcing.json")
CACHE_TTL = 6 * 3600        # повторный поиск по той же карточке в течение 6 часов берёт сохранённый результат
MAX_ITEMS = 5               # в окне показываем не больше пяти вариантов
SANE_MIN_RATIO = 0.04       # цена WB меньше 4% от вашей — почти наверняка не тот товар (запчасть, чехол)

_EXTRACT = r"""
(() => {
  const out = [];
  const onRes = /\/search\/image|image-search|searchByImage/i.test(location.href);
  const empty = /Не нашлось подходящих/i.test(document.body ? document.body.innerText : '');
  // блок «Вы недавно смотрели» идёт после результатов и тоже состоит из карточек: его не берём
  let mark = null;
  document.querySelectorAll('h1,h2,h3,h4,span,p,div').forEach(e => { if (!mark && e.children.length === 0 && /^Вы недавно смотрели/i.test((e.textContent || '').trim())) mark = e; });
  if (onRes && !empty) document.querySelectorAll('[data-nm-id]').forEach(c => {
    if (mark && (mark.compareDocumentPosition(c) & Node.DOCUMENT_POSITION_FOLLOWING)) return;
    const id = c.getAttribute('data-nm-id');
    if (!id || out.some(o => o.id == id)) return;
    const link = c.querySelector('a[aria-label]');
    const name = (link && link.getAttribute('aria-label') || '').trim();
    const txt = (c.innerText || '').replace(/ /g, ' ');
    const ins = c.querySelector('ins');
    let price = ins ? parseInt((ins.textContent || '').replace(/[^0-9]/g, ''), 10) : 0;
    if (!price) { const m = txt.match(/(\d[\d ]{2,9})\s*[₸₽]/); price = m ? parseInt(m[1].replace(/\D/g, ''), 10) : 0; }
    const rm = txt.match(/(\d[,.]\d)\s*[·•]\s*([\d ]+)\s*оцен/);
    const img = c.querySelector('img');
    out.push({id: parseInt(id, 10), name, price, rating: rm ? parseFloat(rm[1].replace(',', '.')) : 0,
              feedbacks: rm ? parseInt(rm[2].replace(/\D/g, ''), 10) : 0, img: img ? (img.currentSrc || img.src) : ''});
  });
  return JSON.stringify({count: out.length, items: out, empty: onRes && empty, onRes: onRes, url: location.href});
})()
"""

def _stable(extract_expr, with_empty):
    """Выражение для ожидания готовой выдачи: число карточек одинаково на трёх проверках подряд (WB сначала показывает заглушки)."""
    empty = "if(d.empty)return {done:true,value:0};" if with_empty else ""
    return ("(()=>{const d=JSON.parse(%s);" % extract_expr.strip() + empty +
            "const w=window.__sc||(window.__sc={n:-1,k:0});"
            "if(d.count>=1&&d.count===w.n){w.k++;}else{w.k=0;}w.n=d.count;"
            "return w.k>=2?{done:true,value:d.count}:{done:false};})()")


def _present(selector):
    return "(()=>document.querySelector(%s)?{done:true,value:1}:{done:false})()" % json.dumps(selector)


_WAIT = "(()=>{const d=JSON.parse(%s);return (d.count>=1||d.empty)?{done:true,value:d.count}:{done:false};})()" % _EXTRACT.strip()


def _words(text):
    """Значимые слова названия (первые 5 букв: «зубьев» и «зуб.» считаются одним словом); артикулы-номера и мелочь не берём."""
    out = set()
    for w in re.findall(r"[a-zA-Zа-яА-ЯёЁ0-9\-]+", (text or "").lower()):
        if len(w) < 3 or w.isdigit():
            continue
        out.add(w[:5])
    return out


def _overlap(title, name):
    tw = _words(title)
    return (len(tw & _words(name)) / len(tw)) if tw else 0.0


def _fetch_source(wid):
    """Цена и наличие исходного товара WB. Короткий вариант wb_tracker.fetch_wb: ждём страницу не больше 25 секунд (там было до 90)."""
    from core import wb_tracker
    wait = "(document.body&&document.body.innerText.match(/[₽₸]/))?{done:true,value:1}:{done:false}"
    steps = [{"t": "goto", "url": "https://www.wildberries.ru/catalog/%d/detail.aspx" % wid, "soft": True},
             {"t": "poll", "expr": wait, "every": 1000, "timeout": 25000, "key": "w", "required": False},
             {"t": "eval", "expr": wb_tracker._JS % (json.dumps([wid]), json.dumps(str(wb_tracker._cfg("wb_dest", "269")))), "key": "d"}]
    res = ego_bridge.run(steps, space="kaspi-wb", timeout=90)
    data = json.loads((res.get("values") or {}).get("d") or "{}")
    return (data.get("items") or {}).get(str(wid)) or {}


def _source_item(sku, sell_price, ref_hash):
    """Карточка создана из WB (артикул ARM + номер): сразу смотрим сам исходный товар, даже если фото-поиск его не показал."""
    m = re.match(r"^ARM(\d{5,12})$", str(sku or ""))
    if not m:
        return None
    wid = int(m.group(1))
    try:
        from core import wb_tracker, wb_parser
        info = _fetch_source(wid)
        price = int(info.get("price") or 0)
        if price <= 0 or int(info.get("qty") or 1) <= 0:
            return None
        imgs = []
        try:
            imgs = wb_parser.get_wb_images(wid, 1)
        except Exception:
            pass
        return {"id": wid, "name": info.get("name") or "Исходный товар на WB", "price": price, "rating": 0, "feedbacks": 0,
                "img": imgs[0] if imgs else ""}
    except Exception:
        return None


BEST_FILE = os.path.join(BASE_DIR, "data", "sourcing_best.json")
RELIABLE = ("source", "same", "name")        # только уверенные совпадения попадают в метку «есть дешевле»


def _load_best():
    try:
        with open(BEST_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _remember_best(sku, markets, items, sell_price):
    """Лучшая уверенная находка по каждому сайту. Хранится без срока: нужна, чтобы отметить карточки «есть дешевле» в Моём магазине."""
    if not sku:
        return
    data = _load_best()
    cur = data.get(str(sku)) or {}
    for m in markets:
        cand = [i for i in items if i.get("market") == m and i.get("label") in RELIABLE and not i.get("need_weight")]
        cand.sort(key=lambda i: i["price"])
        if cand:
            b = cand[0]
            cur[m] = {"ts": time.time(), "sell_price": int(sell_price), "price": b["price"], "net_profit": b.get("net_profit"),
                      "margin_pct": b.get("margin_pct"), "label": b["label"], "url": b.get("url"), "name": (b.get("name") or "")[:80]}
        else:
            cur[m] = {"ts": time.time(), "sell_price": int(sell_price), "price": None}
    data[str(sku)] = cur
    try:
        os.makedirs(os.path.dirname(BEST_FILE), exist_ok=True)
        with open(BEST_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except OSError:
        pass


def best_summary():
    """sku -> {best: {market, price, ...} | None, checked: время последней проверки}."""
    out = {}
    for sku, per in _load_best().items():
        entries = [dict(v, market=m) for m, v in (per or {}).items() if isinstance(v, dict)]
        found = [e for e in entries if e.get("price")]
        found.sort(key=lambda e: e["price"])
        out[sku] = {"best": found[0] if found else None, "checked": max((e.get("ts") or 0) for e in entries) if entries else 0}
    return out


def _load_cache():
    try:
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_cache(data):
    try:
        os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except OSError:
        pass


def _photo_for(card_code, img_url):
    """Фото карточки Kaspi (байты, ссылка): сначала то, что передал экран, потом публичный поиск Kaspi по коду."""
    candidates = []
    if img_url and str(img_url).startswith("https://resources.cdn-kaspi.kz/"):
        candidates.append(str(img_url))
    if card_code:
        try:
            u = ks._fetch_card_image(card_code)
            if u and u not in candidates:
                candidates.append(u)
        except Exception:
            pass
    for u in candidates:
        # маленькие превью WB может не принять — просим версию побольше, если она есть
        for v in (u.replace("/medium/", "/large/"), u):
            data = imghash.fetch(v, timeout=10)
            if data and len(data) > 3000:
                return data, v
    return None, ""


def _wb_photo_search(path):
    """Поиск по картинке на сайте WB. Возвращает (список вариантов, сообщение об ошибке)."""
    steps = [
        {"t": "goto", "url": "https://www.wildberries.ru/", "soft": True},
        {"t": "poll", "expr": _present("#searchByImageFormAbNew"), "every": 400, "timeout": 25000, "key": "a"},
        {"t": "click", "selector": "#searchByImageFormAbNew"},
        {"t": "poll", "expr": _present("#uploadLink"), "every": 300, "timeout": 10000, "key": "b"},
        {"t": "upload", "selector": "#uploadLink", "files": [path]},
        {"t": "poll", "expr": _present('button[aria-label="Найти товар"]'), "every": 500, "timeout": 25000, "key": "c", "required": False},
        {"t": "sleep", "ms": 600},
        {"t": "click", "selector": 'button[aria-label="Найти товар"]', "soft": True},
        {"t": "sleep", "ms": 3000},                      # сразу после клика WB показывает заглушки
        {"t": "poll", "expr": _stable(_EXTRACT, True), "every": 1200, "timeout": 40000, "key": "w", "required": False},
        {"t": "eval", "expr": _EXTRACT.strip(), "key": "p"},
    ]
    res, last = None, ""
    for attempt in range(2):                      # окно выбора файла иногда обрывается: одна повторная попытка
        try:
            res = ego_bridge.run(steps, space="kaspi-wb", timeout=150)
            break
        except ego_bridge.EgoError as e:
            last = str(e)
            time.sleep(5)
    if res is None:
        return [], last
    try:
        data = json.loads((res.get("values") or {}).get("p") or "{}")
    except ValueError:
        data = {}
    if data.get("items"):
        return data["items"], ""
    if data.get("empty"):
        return [], ""
    return [], "WB не показал результат поиска по фото. Откройте WB в браузере ego и повторите."


_OZ_EXTRACT = r"""
(() => {
  const onRes = /search-by-image/i.test(location.href);
  const byId = {};
  if (onRes) document.querySelectorAll('a[href*="/product/"]').forEach(a => {
    const href = a.getAttribute('href').split('?')[0];
    const m = href.match(/-(\d{6,})\/?$/);
    if (!m) return;
    const id = m[1];
    let t = a;
    for (let i = 0; i < 8 && t.parentElement; i++) { t = t.parentElement; if (/₸/.test(t.innerText || '') && (t.innerText || '').length < 700 && t.querySelectorAll('a[href*="/product/"]').length <= 3) break; }
    const rec = byId[id] || (byId[id] = {id: id, url: 'https://ozon.kz' + href, name: '', price: 0, img: '', tile: t});
    const txt = (a.innerText || '').trim();
    if (txt.length > rec.name.length) rec.name = txt;
    const im = a.querySelector('img');
    if (im && !rec.img) rec.img = im.currentSrc || im.src || '';
    rec.tile = t;
  });
  const out = Object.values(byId).map(r => {
    const txt = (r.tile.innerText || '').replace(/[\s\u00a0\u2009\u202f]+/g, ' ');
    let m = txt.match(/×\s*\d+\s*мес\s*([\d ]{3,9})\s*₸/);
    let price = m ? parseInt(m[1].replace(/\D/g, ''), 10) : 0;
    if (!price) { m = txt.match(/([\d ]{3,9})\s*₸/); price = m ? parseInt(m[1].replace(/\D/g, ''), 10) : 0; }
    const rm = txt.match(/(\d[.,]\d)\s*(?:\n|\s)*(\d[\d ]*)\s*отзыв/);
    let nm = r.name;
    if (nm.length < 25 || /^(Распродажа|Вау-цены|Стало дешевле|рейтинг)/i.test(nm)) {
      const mm = txt.match(/(?:осталось|₸ −?\d+%|₸)\s+([^₸]{12,200}?)\s+\d[.,]\d\s+\d[\d ]*\s*отзыв/) || txt.match(/(?:осталось|%)\s+([^₸%]{12,200}?)\s+рейтинг магазина/);
      if (mm) nm = mm[1].trim();
    }
    nm = nm.replace(/^(Стало дешевле|Распродажа|Вау-цены)\s+/i, '').replace(/^\d+\s*ед осталось\s+/i, '').replace(/\s+\d[.,]\d$/, '');
    const img = r.tile.querySelector('img');
    return {id: r.id, url: r.url, name: nm, price: price, rating: rm ? parseFloat(rm[1].replace(',', '.')) : 0,
            feedbacks: rm ? parseInt(rm[2].replace(/\D/g, ''), 10) : 0, img: r.img || (img ? (img.currentSrc || img.src) : '')};
  }).filter(x => x.name && x.price > 0);
  return JSON.stringify({count: out.length, items: out, onRes: onRes});
})()
"""

_OZ_WAIT = "(()=>{const d=JSON.parse(%s);return d.count>=1?{done:true,value:d.count}:{done:false};})()" % _OZ_EXTRACT.strip()
_OZ_PASS = "(()=>document.title.indexOf('Antibot')<0&&!!document.querySelector('input[placeholder]')?{done:true,value:1}:{done:false})()"
_OZ_CAMERA = r"""(()=>{
  [...document.querySelectorAll('button')].filter(x=>/^(Не сейчас|ОК)$/.test((x.innerText||'').trim())).forEach(x=>x.click());
  const inp=document.querySelector('input[placeholder*="Ozon"]'); if(!inp) return {done:false};
  let box=inp.parentElement; for(let i=0;i<6&&box;i++){ if(box.querySelectorAll('button').length>=2) break; box=box.parentElement; }
  const b=[...(box?box.querySelectorAll('button'):[])].filter(x=>!(x.innerText||'').trim());
  if(document.querySelector('input[type=file][accept*="image"]')) return {done:true,value:1};
  if(!b.length) return {done:false}; b[0].click(); return {done:false};
})()"""
_OZ_FIND = "(()=>{const b=[...document.querySelectorAll('button')].find(x=>(x.innerText||'').trim()==='Найти'); if(b){b.click();return 'ok';} return 'no';})()"


def _ozon_photo_search(path):
    """Поиск по картинке на Ozon (ozon.kz). Возвращает (список вариантов, сообщение об ошибке)."""
    steps = [
        {"t": "goto", "url": "https://ozon.kz/", "soft": True},
        {"t": "poll", "expr": _OZ_PASS, "every": 1500, "timeout": 40000, "key": "pass", "required": False},
        {"t": "sleep", "ms": 1200},
        {"t": "poll", "expr": _OZ_CAMERA, "every": 1500, "timeout": 25000, "key": "cam", "required": False},
        {"t": "files", "selector": 'input[type=file][accept*="image"]', "files": [path]},
        {"t": "poll", "expr": "(()=>[...document.querySelectorAll('button')].some(x=>(x.innerText||'').trim()==='Найти')?{done:true,value:1}:{done:false})()", "every": 500, "timeout": 20000, "key": "f", "required": False},
        {"t": "sleep", "ms": 500},
        {"t": "eval", "expr": _OZ_FIND, "key": "go"},
        {"t": "sleep", "ms": 3000},
        {"t": "poll", "expr": _stable(_OZ_EXTRACT, False), "every": 1200, "timeout": 30000, "key": "w", "required": False},
        {"t": "eval", "expr": _OZ_EXTRACT.strip(), "key": "p"},
    ]
    res, last = None, ""
    for attempt in range(2):
        try:
            res = ego_bridge.run(steps, space="kaspi-wb", timeout=170)
            break
        except ego_bridge.EgoError as e:
            last = str(e)
            time.sleep(5)
    if res is None:
        return [], last
    try:
        data = json.loads((res.get("values") or {}).get("p") or "{}")
    except ValueError:
        data = {}
    if data.get("items"):
        return data["items"], ""
    return [], "" if data.get("onRes") else "Ozon не показал результат поиска по фото."


def _1688_photo_search(path, data=None):
    """Поиск по фото на 1688 готовым поиском программы (core/suppliers.photo_search). Возвращает (варианты, сообщение)."""
    import io as _io
    from core import suppliers
    res, last = None, ""
    for attempt in range(2):                      # вкладка 1688 после прошлого поиска иногда зависает: одна повторная попытка
        try:
            res = suppliers.photo_search(None, _io.BytesIO(data))
            break
        except Exception as e:
            last = str(e)[:200]
            time.sleep(4)
    if res is None:
        return [], last
    items = []
    for it in res.get("items") or []:
        try:
            cny = float(it.get("price"))
        except (TypeError, ValueError):
            continue
        if cny <= 0:
            continue
        items.append({"id": str(it.get("id") or it.get("url") or ""), "name": it.get("name") or "", "cny": cny,
                      "img": it.get("image") or "", "url": it.get("url") or "", "rating": 0, "feedbacks": 0})
    if items:
        return items, ""
    if res.get("needs_login") or res.get("blocked"):
        return [], "1688 просит вход или проверку. Откройте 1688 в ego, войдите один раз и повторите."
    return [], ""


def landed_cost(cny_price, calc, weight_kg, qty):
    """Закупка одной штуки с 1688 по формулам калькулятора маржи (static/margin.js unitCost): товар + карго с учётом брака."""
    cny = float(calc.get("cny") or 0)
    if cny <= 0 or not weight_kg or weight_kg <= 0:
        return None
    qty = max(1, int(qty or 1))
    total = weight_kg * qty
    hi, lo = float(calc.get("cargo_hi") or 0), float(calc.get("cargo_lo") or 0) or float(calc.get("cargo_hi") or 0)
    rate = hi if total >= float(calc.get("thr") or 30) else lo
    k = 1 / (1 - min(0.9, float(calc.get("loss") or 0) / 100))
    return (cny_price * cny) * k + weight_kg * rate * k


def find_cheaper(sku, card_code, title, sell_price, img_url="", comm_rate=12.5, cost_now=0, econ_kwargs=None, force=False, markets=("wb", "ozon"), calc=None, weight_kg=0, qty=10):
    """Главная функция: результат для одной карточки. Всегда возвращает словарь с ключами ok, items, error, cached."""
    try:
        sell_price = float(sell_price or 0)
    except (TypeError, ValueError):
        sell_price = 0.0
    markets = tuple(m for m in markets if m in ("wb", "ozon", "1688")) or ("wb",)
    key = str(sku or card_code or title) + "|" + "+".join(markets) + ("|%s|%s" % (weight_kg, qty) if "1688" in markets else "")
    cache = _load_cache()
    hit = cache.get(key)
    if hit and not force and time.time() - hit.get("ts", 0) < CACHE_TTL and hit.get("sell_price") == int(sell_price):
        return dict(hit, cached=True, ok=True)
    if sell_price <= 0:
        return {"ok": False, "error": "У карточки нет цены на Kaspi, считать маржу не от чего.", "items": []}
    if not ego_bridge.available():
        return {"ok": False, "error": "Для поиска по фото нужен браузер ego. Он не найден на этом компьютере.", "items": []}
    data, photo_url = _photo_for(card_code, img_url)
    if not data:
        # у карточки нет публичного фото на Kaspi: берём фото исходного товара WB (артикул ARM + номер)
        m = re.match(r"^ARM(\d{5,12})$", str(sku or ""))
        if m:
            try:
                from core import wb_parser
                for u in wb_parser.get_wb_images(int(m.group(1)), 1):
                    data = imghash.fetch(u, timeout=10)
                    if data and len(data) > 3000:
                        break
                    data = None
            except Exception:
                data = None
    if not data:
        return {"ok": False, "error": "Не удалось получить фото карточки: на Kaspi его не видно, а исходного товара WB у неё нет.", "items": []}
    os.makedirs(os.path.join(BASE_DIR, "data", "ego"), exist_ok=True)
    path = os.path.join(BASE_DIR, "data", "ego", "src_%s.jpg" % re.sub(r"\W", "", key)[:40])
    with open(path, "wb") as f:
        f.write(data)
    searches = {"wb": _wb_photo_search, "ozon": _ozon_photo_search, "1688": lambda pth: _1688_photo_search(pth, data)}
    found_by, errors = {}, {}
    try:
        for m in markets:
            found_by[m], errors[m] = searches[m](path)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if all(errors.get(m) for m in markets):
        return {"ok": False, "error": " ".join("%s: %s" % ({"wb": "WB", "ozon": "Ozon", "1688": "1688"}[m], errors[m]) for m in markets), "items": []}

    ref = imghash.dhash_bytes(data)
    m_src = re.match(r"^ARM(\d{5,12})$", str(sku or ""))
    src_id = int(m_src.group(1)) if (m_src and "wb" in markets) else None
    pool = []
    for m in markets:
        for it in (found_by.get(m) or [])[:40]:
            pool.append(dict(it, market=m))
    if src_id and not any(x["market"] == "wb" and str(x["id"]) == str(src_id) for x in pool):
        src = _source_item(sku, sell_price, ref)         # отдельный заход в WB только если поиск по фото исходный товар не показал
        if src:
            pool.insert(0, dict(src, market="wb"))
    items = []
    for it in pool:
        cny = it.get("cny")
        if it["market"] == "1688":
            lc = landed_cost(cny, calc or {}, weight_kg, qty)
            goods = int(round(cny * float((calc or {}).get("cny") or 0)))
            price = int(round(lc)) if lc else goods          # без веса показываем только цену товара: доставку не выдумываем
            if price <= 0 or price >= sell_price:
                continue
        else:
            lc = None
            price = int(it.get("price") or 0)
            if price <= 0 or price < sell_price * SANE_MIN_RATIO or price >= sell_price:
                continue                                 # дороже вашей цены — выгоды нет, слишком дёшево — другой товар
        h = imghash.hash_url(it.get("img"))
        dist = imghash.same_photo(h, [ref]) if ref is not None else None
        ov = _overlap(title, it.get("name")) if it["market"] != "1688" else 0.0
        if it["market"] == "1688":
            if dist is None or dist > 22:
                continue                                 # у 1688 названия китайские: верим только фото
            label = "same" if dist <= imghash.SAME_MAX_DIST else "similar"
        elif it["market"] == "wb" and src_id and str(it["id"]) == str(src_id):
            label = "source"
        elif dist is not None and dist <= imghash.SAME_MAX_DIST:
            label = "same"
        elif ov >= 0.5 and (dist is None or dist <= (33 if len(_words(title)) > 3 else 20)):
            label = "name"                               # у короткого названия («Рюкзак экокожа черный») одних слов мало: нужно и близкое фото
        elif ov >= 0.3 or (dist is not None and dist <= 20):
            label = "similar"
        else:
            continue                                     # ни фото, ни название не совпали: шум
        kw = dict(econ_kwargs or {})
        need_weight = it["market"] == "1688" and not lc
        econ = {} if need_weight else ks.calculate_product_economics(sell_price, price, comm_rate=comm_rate, **kw)
        url = it.get("url") or "https://www.wildberries.ru/catalog/%s/detail.aspx" % it["id"]
        items.append({
            "market": it["market"], "id": it["id"], "name": it.get("name") or "", "price": price, "rating": it.get("rating") or 0,
            "feedbacks": it.get("feedbacks") or 0, "img": it.get("img") or "", "url": url,
            "label": label, "dist": dist, "overlap": round(ov, 2),
            "net_profit": econ.get("net_profit"), "margin_pct": econ.get("margin_pct"),
            "saving": int(cost_now - price) if cost_now and cost_now > price and not need_weight else 0,
            "cny": cny, "need_weight": need_weight, "goods_kzt": price if need_weight else None,
        })
    total = sum(len(v or []) for v in found_by.values())
    rank = {"source": 0, "same": 1, "name": 2, "similar": 3}
    items.sort(key=lambda x: (rank.get(x["label"], 9), x["price"]))
    result = {"ok": True, "items": items[:MAX_ITEMS], "ts": time.time(), "sell_price": int(sell_price),
              "total_found": total, "empty": total == 0, "cached": False, "errors": {m: e for m, e in errors.items() if e}}
    cache[key] = result
    _save_cache(cache)
    _remember_best(sku, markets, items, sell_price)
    return result
