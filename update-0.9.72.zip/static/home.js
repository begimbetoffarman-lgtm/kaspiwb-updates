// Главная: дашборд (сводка, график прибыли по дням, сроки, товары, слежение за WB, отказы Kaspi). Плюс резервная копия в настройках.
(function () {
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const num = n => (Number(n) || 0).toLocaleString('ru-RU');
  const money = n => num(Math.round(Number(n) || 0)) + ' ₸';
  let loadedAt = 0;

  // число плавно «набегает» от нуля
  function countUp(el, to, fmt) {
    if (!el) return;
    const end = Number(to) || 0, t0 = performance.now(), dur = 700;
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = fmt(end); return; }
    (function step(now) {
      const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      el.textContent = fmt(Math.round(end * e));
      if (k < 1) requestAnimationFrame(step);
    })(t0);
  }
  function kpi(cls, icon, id, label, sub) {
    return `<div class="kpi ${cls}"><div class="kpi-ico">${icon}</div><div><b id="${id}">0</b><span>${label}</span>${sub ? `<em>${sub}</em>` : ''}</div></div>`;
  }

  // столбики прибыли по дням (SVG, без библиотек)
  function chart(days) {
    const d = (days || []).slice().sort((a, b) => a.date < b.date ? -1 : 1);
    if (!d.length) return '<div class="dash-empty">За этот период нет завершённых заказов.</div>';
    const W = 640, H = 150, pad = 4, gap = 4;
    const max = Math.max(1, ...d.map(x => Math.abs(x.profit)));
    const zero = H * (d.some(x => x.profit < 0) ? 0.72 : 0.94);
    const bw = Math.max(6, (W - pad * 2 - gap * (d.length - 1)) / d.length);
    const bars = d.map((x, i) => {
      const h = Math.max(2, Math.abs(x.profit) / max * (x.profit >= 0 ? zero - 8 : H - zero - 6));
      const y = x.profit >= 0 ? zero - h : zero;
      const xx = pad + i * (bw + gap);
      return `<rect class="bar ${x.profit >= 0 ? 'up' : 'down'}" x="${xx.toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="3" style="animation-delay:${i * 25}ms"><title>${esc(x.date)}: ${money(x.profit)} (заказов ${x.orders})</title></rect>`;
    }).join('');
    return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Прибыль по дням"><line x1="0" x2="${W}" y1="${zero}" y2="${zero}" class="zero"/>${bars}</svg>` +
      `<div class="axis"><span>${esc(d[0].date)}</span><span>${esc(d[d.length - 1].date)}</span></div>`;
  }
  const prods = (list, cls, empty) => (list && list.length)
    ? list.map(p => `<div class="prod"><div class="prod-n"><b>${esc(p.sku)}</b><span>${esc((p.name || '').slice(0, 54))}</span></div><div class="prod-v ${cls}">${p.profit > 0 ? '+' : ''}${money(p.profit)}</div></div>`).join('')
    : `<div class="dash-empty">${empty}</div>`;

  // «Следующий шаг»: одна подсказка по состоянию магазина (данные уже есть в других запросах)
  const S = { d: undefined, drafts: undefined };
  function renderNext() {
    const el = $('homeNext'); if (!el || S.d === undefined) return;
    let t = null;
    if (!S.d) t = ['Подключите магазин Kaspi', 'Без этого программа не видит заказы и карточки. Это три шага в мастере.', 'Подключить Kaspi', 'tab-setup'];
    else if (S.d.to_collect > 0) t = ['Соберите заказы: ' + S.d.to_collect, 'Эти заказы ждут сборки и передачи курьеру.', 'Открыть заказы', 'tab-orders'];
    else if (S.drafts === undefined) { el.innerHTML = ''; return; }
    else if (S.drafts > 0) t = ['Проверьте черновики: ' + S.drafts, 'Проверьте название, цену и категорию и отправьте в Kaspi. Пока вы не нажмёте «Отправить в Kaspi», ничего не уходит.', 'Открыть карточки', 'tab-cards'];
    else if (S.drafts === 0) t = ['Найдите первый товар для продажи', 'Откройте поиск на Wildberries, выберите хит и создайте черновик карточки.', 'Перейти к поиску WB', 'tab-radar'];
    el.innerHTML = t ? '<div class="dash-card" style="margin-bottom:14px"><div class="dash-head"><h4>Следующий шаг</h4></div><div style="font-size:17px;font-weight:700;margin:4px 0">' + esc(t[0]) + '</div><div class="dash-sub" style="margin-bottom:10px">' + esc(t[1]) + '</div><button type="button" class="btn btn-primary wz-go" data-go="' + t[3] + '">' + esc(t[2]) + '</button></div>' : '';
  }

  // ---- тренд, строка «Чистыми после возвратов и расходов», редактор расходов
  function trend(cur, prev) {
    if (!prev || !(Math.abs(prev.profit) > 0)) return '';
    const pct = Math.round((cur - prev.profit) / Math.abs(prev.profit) * 100);
    if (pct === 0) return '<em class="tr flat">как неделей ранее</em>';
    return '<em class="tr ' + (pct > 0 ? 'up' : 'down') + '">' + (pct > 0 ? '▲ +' : '▼ ') + pct + '% к прошлой неделе</em>';
  }
  function netLine(d) {
    const w = d.week, p = d.period;
    if (!(p.ret_count > 0 || p.expenses > 0)) {
      return '<span class="net-hint">Возвраты и свои расходы пока не учтены. Добавьте расходы ниже, и здесь появится «чистыми».</span>';
    }
    const part = x => 'возвраты ' + x.ret_count + ' шт −' + money(x.ret_loss) + (x.expenses > 0 ? ', расходы −' + money(x.expenses) : '');
    return '<div><b class="' + (w.net < 0 ? 'neg' : '') + '">' + money(w.net) + '</b> чистыми за 7 дней <span>(' + part(w) + ')</span></div>' +
      '<div><b class="' + (p.net < 0 ? 'neg' : '') + '">' + money(p.net) + '</b> чистыми за 28 дней <span>(' + part(p) + ')</span></div>';
  }
  function renderExp(list) {
    const box = $('homeExpBody');
    if (!box) return;
    const row = (e, i) => '<div class="exp-row"><input type="text" maxlength="40" placeholder="Что (например, реклама)" value="' + esc(e.name || '') + '" data-exp-name>' +
      '<input type="number" min="0" step="100" placeholder="₸ в месяц" value="' + esc(e.month || '') + '" data-exp-month><button type="button" class="exp-del" data-exp-del title="Убрать" aria-label="Убрать">×</button></div>';
    const rows = (list.length ? list : [{}]).map(row).join('');
    box.innerHTML = '<p class="exp-help">Суммы, которые вы тратите в месяц вне заказов. Программа вычтет их по дням (сумма ÷ 30) и покажет «чистыми». Данные только на этом компьютере.</p>' +
      '<div id="expRows">' + rows + '</div><div class="exp-act"><button type="button" class="btn btn-sm btn-secondary" id="expAdd">+ расход</button> ' +
      '<button type="button" class="btn btn-sm btn-primary" id="expSave">Сохранить</button> <span id="expMsg" class="dash-sub"></span></div>';
  }
  document.addEventListener('click', async e => {
    const t = e.target;
    if (!t || !t.closest || !t.closest('#homeExp')) return;
    if (t.id === 'expAdd') {
      const rowsEl = $('expRows');
      if (rowsEl && rowsEl.children.length < 10) rowsEl.insertAdjacentHTML('beforeend', '<div class="exp-row"><input type="text" maxlength="40" placeholder="Что" data-exp-name><input type="number" min="0" step="100" placeholder="₸ в месяц" data-exp-month><button type="button" class="exp-del" data-exp-del aria-label="Убрать">×</button></div>');
    } else if (t.hasAttribute('data-exp-del')) {
      const row = t.closest('.exp-row'); if (row) row.remove();
    } else if (t.id === 'expSave') {
      const items = [...document.querySelectorAll('#expRows .exp-row')].map(r => ({ name: r.querySelector('[data-exp-name]').value, month: parseFloat(r.querySelector('[data-exp-month]').value) || 0 })).filter(x => x.month > 0);
      const msg = $('expMsg'); msg.textContent = 'Сохраняю…';
      try {
        const res = await fetch('/api/finance/expenses', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ expenses: items }) });
        const j = await res.json();
        msg.textContent = j.success ? 'Сохранено, пересчитываю…' : (j.error || 'Не удалось сохранить.');
        if (j.success) await loadProfit();
        const m2 = $('expMsg'); if (m2 && j.success) m2.textContent = 'Сохранено. Чистая прибыль пересчитана.';
      } catch (err) { msg.textContent = 'Нет связи с программой.'; }
    }
  });

  // ---- «Можно закупить дешевле» и «Деньги в товаре»
  const MKT = { wb: 'WB', ozon: 'Ozon', '1688': '1688' };
  const safeHref = u => /^https?:\/\//i.test(u || '') ? u : '';
  function renderSave(c) {
    const box = $('homeSave'); if (!box) return;
    if (!c || !c.count) {
      box.innerHTML = '<h5>Можно закупить дешевле</h5><div class="box-sub">Пока ничего не найдено. Нажимайте «🔍 дешевле» у карточек в «Моём магазине»: сюда попадут товары, которые нашлись дешевле вашей закупки.</div>';
      return;
    }
    box.innerHTML = '<h5>Можно закупить дешевле</h5><div class="box-big"><b class="neg">−' + money(c.total_month) + '</b> в месяц<span> теряете, если закупать по-старому (при текущем темпе продаж, ' + c.count + ' тов.)</span></div>' +
      '<table class="box-t">' + c.items.slice(0, 5).map(r => {
        const h = safeHref(r.url);
        return '<tr><td><b>' + esc(r.sku) + '</b><span>' + esc((r.name || '').slice(0, 50)) + '</span></td><td>вы платите ' + money(r.cost) + '</td><td>нашли ' + (h ? '<a href="' + esc(h) + '" target="_blank" rel="noopener">' + money(r.price) + '</a>' : money(r.price)) + ' · ' + esc(MKT[r.market] || '') + '</td><td><b>−' + money(r.loss_month) + '</b><span>' + r.qty_month + ' шт/мес</span></td></tr>';
      }).join('') + '</table><div class="box-sub">Цена найдена поиском по фото. Перед закупкой проверьте, что это тот же товар.</div>';
  }
  function renderFrozen(f) {
    const box = $('homeFrozen'); if (!box) return;
    if (!f) { box.innerHTML = ''; return; }
    let h = '<h5>Деньги в товаре</h5>';
    if (!f.count) {
      h += '<div class="box-sub">' + (f.stock_unknown
        ? 'Kaspi не отдаёт остатки по заказам, поэтому у ' + f.stock_unknown + ' товаров остаток неизвестен. Загрузите прайс-лист с остатками на вкладке «Мой магазин», и здесь появится сумма.'
        : (f.no_cost ? 'Остатки есть, но у ' + f.no_cost + ' товаров не указана закупка. <a href="#" class="wz-go" data-go="tab-my-store">Указать закупку</a>.' : 'Нет товаров с остатком.')) + '</div>';
    } else {
      h += '<div class="box-big"><b>' + money(f.total) + '</b><span> лежит в остатках: ' + f.units + ' шт, ' + f.count + ' тов. (закупка × остаток)</span></div>';
      h += '<table class="box-t">' + f.top.map(r => '<tr><td><b>' + esc(r.sku) + '</b><span>' + esc(r.name) + '</span></td><td>' + r.stock + ' шт × ' + money(r.cost) + '</td><td><b>' + money(r.sum) + '</b></td></tr>').join('') + '</table>';
      const notes = [];
      if (f.no_cost) notes.push(f.no_cost + ' тов. без закупки не учтены');
      if (f.stock_unknown) notes.push('у ' + f.stock_unknown + ' тов. остаток неизвестен');
      if (notes.length) h += '<div class="box-sub">' + notes.join('; ') + '. Товар в пути не считается.</div>';
      else h += '<div class="box-sub">Товар в пути не считается.</div>';
    }
    box.innerHTML = h;
  }
  function loadFrozen() {
    return apiGet('/api/finance/frozen').then(r => { renderFrozen(r.ok ? r.data.frozen : null); }).catch(() => { });
  }

  function loadProfit() {
    return apiGet('/api/profit?days=28').then(r => {
      if (!r.ok) { $('homeChart').textContent = 'Данные появятся после подключения Kaspi («Подключение магазина»). ' + (r.error || ''); $('homeTop').textContent = ''; $('homeLosers').textContent = ''; return; }
      const d = r.data;
      window.__homeWeek = d.week.profit;
      if ($('kpiProfit')) countUp($('kpiProfit'), d.week.profit, money);
      $('homeProfitNums').innerHTML =
        `<div><b class="${d.today.profit < 0 ? 'neg' : ''}">${money(d.today.profit)}</b><span>сегодня · заказов ${d.today.orders}</span></div>` +
        `<div><b class="${d.week.profit < 0 ? 'neg' : ''}">${money(d.week.profit)}</b><span>7 дней · заказов ${d.week.orders}${d.week.margin_pct != null ? ' · маржа ' + d.week.margin_pct + '%' : ''}</span>${trend(d.week.profit, d.prev_week)}</div>` +
        `<div><b class="${d.period.profit < 0 ? 'neg' : ''}">${money(d.period.profit)}</b><span>28 дней · выручка ${money(d.period.revenue)}${d.period.margin_pct != null ? ' · маржа ' + d.period.margin_pct + '%' : ''}</span></div>`;
      $('homeChart').innerHTML = chart(d.days);
      $('homeNet').innerHTML = netLine(d);
      renderExp(d.expenses || []);
      renderSave(d.cheaper);
      loadFrozen();
      $('homeProfitNote').innerHTML = (d.no_cost_orders ? 'Для ' + d.no_cost_orders + ' заказов не указана закупка, прибыль по ним не посчитана, маржа считается только по остальным. <a href="#" class="wz-go" data-go="tab-my-store">Указать закупку</a>. ' : '') +
        '<a href="#" class="wz-go" data-go="tab-finance">Подробные финансы</a>. Прибыль с продаж = цена минус закупка, комиссия Kaspi по категории, доставка, упаковка и налог (как в «Мой магазин»). Возвраты и ваши расходы вычитаются в строке «Чистыми» выше.';
      $('homeTop').innerHTML = prods((d.top || []).slice(0, 5), 'plus', 'Пока нет данных.');
      $('homeLosers').innerHTML = prods((d.losers || []).slice(0, 5), 'minus', 'Товаров в минусе нет 🎉');
    });
  }

  async function loadHome() {
    if (!$('homeBox')) return;
    if (Date.now() - loadedAt < 20000) return;          // не дёргаем Kaspi при каждом переключении вкладок
    loadedAt = Date.now();
    apiGet('/api/orders/digest').then(r => {
      const d = r.ok ? r.data : null;
      S.d = d; renderNext();
      if (!d) { $('homeDigest').innerHTML = '<div class="dash-empty" style="grid-column:1/-1">Здесь появятся заказы, прибыль и сроки после подключения Kaspi.</div>'; return; }
      $('homeDigest').innerHTML =
        kpi(d.to_collect > 0 ? 'k-red' : 'k-green', `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/></svg>`, 'kpiCollect', 'собрать сейчас') +
        kpi('k-blue', `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 6h13v10H1z"/><path d="M14 9h4l3 3v4h-7"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/></svg>`, 'kpiTransit', 'в пути к покупателю') +
        kpi(d.returns_open > 0 ? 'k-amber' : 'k-green', `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg>`, 'kpiReturns', 'возвратов не забрано', d.returns_open_sum > 0 ? money(d.returns_open_sum) : '') +
        kpi('k-violet', `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M14.5 9.2c-.5-.8-1.4-1.2-2.5-1.2-1.4 0-2.5.8-2.5 2s1 1.7 2.5 2 2.5.8 2.5 2-1.1 2-2.5 2c-1.1 0-2-.4-2.5-1.2M12 6v2M12 16v2"/></svg>`, 'kpiProfit', 'чистая прибыль за 7 дней');
      countUp($('kpiCollect'), d.to_collect, String);
      countUp($('kpiTransit'), d.in_transit, String);
      countUp($('kpiReturns'), d.returns_open, String);
      if (window.__homeWeek != null) countUp($('kpiProfit'), window.__homeWeek, money);
    });
    apiGet('/api/cards').then(r => {
      const dr = r.ok && r.data && Array.isArray(r.data.drafts) ? r.data.drafts : null;
      S.drafts = dr ? dr.filter(x => !['sent', 'accepted', 'selling', 'on_sale'].includes(x.status)).length : undefined;
      if (dr && !dr.length) S.drafts = 0;
      renderNext();
    });
    apiGet('/api/home/deadlines').then(r => {
      const it = r.ok ? r.data.items : [];
      $('homeDeadlines').innerHTML = it.length
        ? it.slice(0, 6).map(x => `<div class="dl ${esc(x.level)}"><i></i><span>${esc(x.text)}</span></div>`).join('')
        : `<div class="dash-empty">${r.ok ? 'Срочных дел нет. Можно выдохнуть 🙂' : 'Появятся после подключения Kaspi.'}</div>`;
    });
    loadProfit();
    apiGet('/api/home/tracker').then(r => {
      if (!r.ok) { $('homeTracker').textContent = r.error; return; }
      const d = r.data;
      $('homeTracker').innerHTML = d.tracked
        ? `<div class="chip-line"><span class="chip ok">Слежу за ${d.tracked} товарами</span><span class="dash-sub">проверка: ${esc(d.last_run || '—')}</span></div>` +
          (d.problems.length ? d.problems.map(p => `<div class="dl late"><i></i><span>${esc(p.sku)}: ${esc(p.action)}</span></div>`).join('') : '<div class="dash-empty">Всё в порядке ✅</div>')
        : '<div class="dash-empty">Слежение начнётся после первой продажи товара, выставленного из WB.</div>';
    });
    apiGet('/api/home/rejects').then(r => {
      const it = r.ok ? r.data.items : [];
      $('homeRejects').innerHTML = it.length
        ? it.slice(0, 4).map(x => `<div class="dl soon"><i></i><span>${esc(x.example)} · ${x.count} раз, исправлено ${x.fixed}</span></div>`).join('')
        : '<div class="dash-empty">Отказов Kaspi пока не было ✅</div>';
    });
  }
  window.loadHome = loadHome;

  // ---- резервная копия
  if ($('bkImport')) {
    $('bkImport').addEventListener('change', async e => {
      const f = e.target.files[0]; if (!f) return;
      if (!confirm('Восстановить данные из файла «' + f.name + '»? Текущие файлы будут заменены (старые сохранятся рядом с пометкой .before-restore).')) { e.target.value = ''; return; }
      $('bkStatus').textContent = 'Восстанавливаю…';
      try {
        const r = await fetch('/api/backup/import', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: await f.arrayBuffer() });
        const j = await r.json();
        $('bkStatus').textContent = j.success ? 'Восстановлено файлов: ' + j.restored.length + '. Перезапустите программу.' : (j.error || 'Не удалось восстановить.');
      } catch (err) { $('bkStatus').textContent = 'Ошибка: ' + err.message; }
      e.target.value = '';
    });
  }

  // главная открывается первой
  setTimeout(() => { const a = document.querySelector('.nav-item.active'); if (a && a.dataset.tab === 'tab-home') loadHome(); }, 600);
})();

  // «Как добавить в предзаказ»: открыт при первом запуске, потом свёрнут
  (function () {
    const d = document.getElementById('radarHowto'); if (!d) return;
    try { if (localStorage.getItem('howtoSeen')) d.open = false; } catch (e) {}
    d.addEventListener('toggle', () => { try { localStorage.setItem('howtoSeen', '1'); } catch (e) {} });
  })();
