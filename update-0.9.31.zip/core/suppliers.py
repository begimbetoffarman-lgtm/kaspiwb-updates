"""Read-only supplier search in the installed browser; no Kaspi operations."""
import datetime
import json
import math
import os
import re
import threading
import time
import urllib.parse
import uuid
import io

from core import wb_browser

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LOCK = threading.Lock()
_TABS = {}
_LAST_READ = 0.0
_PRODUCTS = {}
_CATALOG_LOCK = threading.Lock()
_CN = [('обув', '鞋子收纳盒'), ('органайзер', '收纳盒'), ('полка', '置物架'),
       ('кухн', '厨房'), ('держатель', '支架'), ('лампа', '台灯'), ('сумка', '包'), ('рюкзак', '双肩包')]


class SupplierError(RuntimeError):
    """Only deliberate, safe messages for the seller; no raw browser exceptions."""


class _SupplierWS(wb_browser._WS):
    """Bound total command time, including a stream of browser events."""
    def call(self, method, params=None, timeout=8):
        self._id += 1
        mid = self._id
        self._send(json.dumps({'id': mid, 'method': method, 'params': params or {}}))
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Supplier browser command timed out')
            self.sock.settimeout(remaining)
            msg = json.loads(self._recv())
            if msg.get('id') == mid:
                if 'error' in msg:
                    raise RuntimeError('Supplier browser command failed')
                return msg.get('result', {})

    def eval(self, expr, timeout=8):
        return super().eval(expr, timeout=timeout)


def source_name(source):
    if source not in ('1688', 'ozon'):
        raise ValueError('Выберите 1688 или Ozon.')
    return source


def product_url(source, value):
    source_name(source)
    try:
        u = urllib.parse.urlsplit(str(value).strip())
        hosts = ('detail.1688.com',) if source == '1688' else ('ozon.kz', 'www.ozon.kz', 'ozon.ru', 'www.ozon.ru')
        pattern = r'/offer/\d{5,20}\.html' if source == '1688' else r'/product/(?:[^/]*-)?\d{5,20}/?'
        if u.scheme not in ('https', 'http') or u.hostname not in hosts or u.username or u.password or u.port not in (None, 80, 443) or not re.fullmatch(pattern, u.path):
            raise ValueError()
    except (TypeError, ValueError):
        raise ValueError('Вставьте полную ссылку на товар выбранного сайта.') from None
    return ('https://detail.1688.com' if source == '1688' else 'https://ozon.kz') + u.path


def search_url(source, query):
    source_name(source)
    query = str(query or '').strip()
    if not query or len(query) > 200:
        raise ValueError('Введите запрос до 200 символов.')
    effective = query
    if source == '1688':
        if re.search('[а-яА-ЯёЁ]', query):
            effective = next((cn for ru, cn in _CN if ru in query.lower()), '')
            if not effective:
                raise ValueError('Для 1688 введите запрос на китайском или откройте товар по ссылке. Пример: 收纳盒 — органайзер.')
        try:
            encoded = urllib.parse.quote(effective.encode('gbk'))
        except UnicodeEncodeError:
            raise ValueError('1688 не поддерживает эти символы в поиске. Введите название без эмодзи.') from None
        return 'https://s.1688.com/selloffer/offer_search.htm?keywords=' + encoded + '&n=y', effective
    return 'https://ozon.kz/search/?' + urllib.parse.urlencode({'text': effective}), effective


def category_url(source, value):
    source_name(source)
    try:
        u = urllib.parse.urlsplit(str(value).strip())
        if u.scheme != 'https' or u.username or u.password or u.port or u.fragment:
            raise ValueError()
        if source == '1688':
            query = urllib.parse.parse_qs(u.query)
            if len(query.get('keywords', [''])[0]) > 120 or not query.get('keywords', [''])[0]:
                raise ValueError()
            if u.hostname == 'air.1688.com' and u.path == '/kapp/1688-global/sales/search':
                return 'https://air.1688.com/kapp/1688-global/sales/search?' + urllib.parse.urlencode({'keywords':query['keywords'][0]})
            if u.hostname == 's.1688.com' and u.path == '/selloffer/offer_search.htm' and query.get('charset') == ['utf8']:
                return 'https://s.1688.com/selloffer/offer_search.htm?' + urllib.parse.urlencode({'charset':'utf8','keywords':query['keywords'][0]})
            raise ValueError()
        if u.hostname not in ('ozon.kz', 'www.ozon.kz') or not re.fullmatch(r'/category/[a-z0-9-]+-\d+/',u.path):
            raise ValueError()
        return 'https://ozon.kz' + u.path
    except (TypeError, ValueError):
        raise ValueError('Выберите категорию в списке площадки.') from None


def catalog(source):
    source_name(source)
    path = os.path.join(ROOT, 'data', 'supplier-search-' + source + '.json')
    with _CATALOG_LOCK:
        try:
            with open(path, encoding='utf-8') as f:
                result = json.load(f)
            if not isinstance(result, dict) or not isinstance(result.get('items'), list):
                raise ValueError()
        except (OSError, ValueError):
            result = {'items': [], 'query': ''}
    return dict(result, success=True, source=source, city=_city_settings()[0])


def _city_settings():
    from core import secrets
    cfg=secrets.read_config(os.path.join(ROOT,'config.json'))
    return str(cfg.get('wb_city_name') or cfg.get('kaspi_city_name') or '').strip(),cfg.get('preorder_buffer_days',3)


def _save_catalog(source, result):
    source_name(source)
    path = os.path.join(ROOT, 'data', 'supplier-search-' + source + '.json')
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with _CATALOG_LOCK:
        with open(path + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False)
        os.replace(path + '.tmp', path)


def _browser_read(source, mode, url, photo_path=None):
    """One page at a time. Keep a challenged tab open for the user to resolve."""
    global _LAST_READ
    if not _LOCK.acquire(blocking=False):
        raise SupplierError('Уже идёт загрузка товара. Дождитесь её завершения.')
    ws = None
    try:
        error = wb_browser._ensure_browser()
        if error:
            raise SupplierError('Не удалось открыть браузер. Установите Edge или Chrome и повторите.')
        pause = 3 - (time.monotonic() - _LAST_READ)
        if pause > 0:
            time.sleep(pause)
        port = wb_browser.PORT
        tabs = wb_browser._http_json(f'http://127.0.0.1:{port}/json/list')
        tab = next((t for t in tabs if t.get('id') == _TABS.get(source)), None)
        if tab is None:
            # Reuse the marketplace tab in this app's browser after app restart.
            hosts = {'s.1688.com','detail.1688.com','air.1688.com'} if source == '1688' else {'ozon.kz','www.ozon.kz'}
            tab = next((t for t in tabs if t.get('type') == 'page' and urllib.parse.urlsplit(t.get('url','')).hostname in hosts), None)
        if tab is None:
            tab = wb_browser._http_json(f'http://127.0.0.1:{port}/json/new?' + urllib.parse.quote(url, safe=''), method='PUT')
        _TABS[source] = tab['id']
        ws = _SupplierWS(tab['webSocketDebuggerUrl'], timeout=8)
        ws.call('Page.enable')
        if tab.get('url') != url:
            ws.call('Page.navigate', {'url': url})
        if photo_path:
            ws.call('DOM.enable')
            for _ in range(15):
                time.sleep(1)
                try:
                    doc = ws.call('DOM.getDocument', {'depth': 0})
                    node = ws.call('DOM.querySelector', {'nodeId': doc['root']['nodeId'], 'selector': 'input.image-file-reader-wrapper'})
                    if node.get('nodeId'):
                        ws.call('DOM.setFileInputFiles', {'nodeId': node['nodeId'], 'files': [photo_path]})
                        break
                except RuntimeError:
                    # Redirects replace the document between DOM calls.
                    continue
            else:
                raise SupplierError('1688 не показал загрузку фото. Откройте фотопоиск на сайте, пройдите вход или проверку и повторите.')
            for _ in range(12):
                time.sleep(1)
                clicked = ws.eval("""(() => { const e=[...document.querySelectorAll('button,div,span,a')].find(e=>['Поиск изображений','图片搜索','搜索图片'].includes(e.textContent.trim()) && e.children.length<2); if(e){e.click();return true;} return false; })()""")
                if clicked:
                    break
        with open(os.path.join(ROOT, 'core', 'supplier_page.js'), encoding='utf-8') as script_file:
            script = script_file.read()
        expr = script + '\nreadSupplierPage(' + json.dumps(source) + ',' + json.dumps(mode) + ')'
        deadline = time.monotonic() + 45
        started = time.monotonic()
        while time.monotonic() < deadline:
            time.sleep(2)
            try:
                if photo_path and not ws.eval("location.hostname==='air.1688.com' && location.pathname.includes('pc-image-search')"):
                    continue
                if source == '1688' and mode == 'categories':
                    point = ws.eval("""(() => {if(location.hostname!=='www.1688.com'||document.querySelector('[class*="modal_subcategory_section--"]'))return null;const e=document.querySelector('[class*="lv1ItemLink--"]');if(!e)return null;const r=e.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()""")
                    if point:
                        ws.call('Input.dispatchMouseEvent', {'type':'mouseMoved','x':point['x'],'y':point['y']})
                        time.sleep(0.5)
                result = ws.eval(expr, timeout=16)
            except (OSError, RuntimeError):
                continue
            if result and (result.get('items') if mode in ('search','categories') else result.get('variants')):
                if source=='ozon' and mode=='product' and not result.get('delivery_raw',{}).get('text') and time.monotonic()-started<20:
                    continue
                if photo_path:
                    result['photo_url'] = ws.eval('location.href')
                _LAST_READ = time.monotonic()
                return result
            if mode == 'categories' and time.monotonic()-started > 8 and result is not None:
                return {'items': []}
        if photo_path and ws.eval("location.hostname==='air.1688.com' && /空空|здесь пусто/.test(document.body.innerText)"):
            return {'items': [], 'photo_url': ws.eval('location.href')}
        raise SupplierError('Сайт пока не отдал товары. Посмотрите открытое окно браузера: если сайт просит вход или проверку, пройдите её сами и повторите загрузку. Разрешения браузера выбираете вы.')
    finally:
        _LAST_READ = time.monotonic()
        if ws:
            ws.close()
        _LOCK.release()


def search(source, query):
    url, effective = search_url(source, query)
    result = _browser_read(source, 'search', url)
    # Validate links again on the server before returning scraped content.
    result['items'] = [dict(item, url=product_url(source, item['url'])) for item in result.get('items', [])[:20]]
    result.update(success=True, query=effective, search_url=url)
    _save_catalog(source, result)
    return result


def categories(source, parent_url=None):
    source_name(source)
    url=category_url(source,parent_url) if parent_url else ('https://www.1688.com/' if source=='1688' else 'https://ozon.kz/')
    result=_browser_read(source,'categories',url)
    def clean(item):
        return {'name':str(item.get('name') or '').strip()[:120], 'url':category_url(source,item.get('url'))}
    items=[]
    for raw in result.get('items',[])[:100]:
        try:
            item=clean(raw)
            if source=='1688':
                item['children']=[]
                for child in raw.get('children',[])[:200]:
                    if not child.get('url'):continue
                    group=clean(child)
                    group['children']=[clean(leaf) for leaf in child.get('children',[])[:200] if leaf.get('url')]
                    item['children'].append(group)
            items.append(item)
        except (ValueError,TypeError,AttributeError):
            continue
    return {'success':True,'source':source,'items':items,'parent_url':parent_url or ''}


def search_category(source, value):
    url=category_url(source,value)
    result=_browser_read(source,'search',url)
    result['items']=[dict(item,url=product_url(source,item['url'])) for item in result.get('items',[])[:20]]
    result.update(success=True,query='категория',search_url=url)
    _save_catalog(source,result)
    return result


def read_product(source, url):
    url = product_url(source, url)
    result = _browser_read(source, 'product', url)
    result['url'] = product_url(source, result.get('url', ''))
    result['checked_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if source=='ozon':
        from core.supplier_delivery import delivery_info
        city,buffer=_city_settings()
        result['delivery']=delivery_info(result.pop('delivery_raw',{}),city,buffer)
        for variant in result.get('variants',[]):
            if str(variant.get('id'))==str(result.get('id')):
                variant['delivery']=dict(result['delivery'])
    if len(_PRODUCTS) >= 30:
        _PRODUCTS.pop(next(iter(_PRODUCTS)))
    _PRODUCTS[(source, result['url'])] = result
    return {'success': True, 'product': result}


def photo_search(data=None, uploaded=None):
    """Upload only a selected product image, never arbitrary local files or URLs."""
    if uploaded:
        content = uploaded.read(8_000_001)
    else:
        try:
            wb_id = int((data or {}).get('wb_id'))
        except (TypeError, ValueError):
            raise ValueError('Выберите фото товара WB или загрузите изображение.') from None
        with open(os.path.join(ROOT, 'data', 'catalog.json'), encoding='utf-8') as f:
            catalog = json.load(f)
        item = next((it for it in catalog if int(it.get('id') or 0) == wb_id), None)
        if not item:
            raise ValueError('Товар WB не найден в списке.')
        image_url = item.get('img_main') or item.get('img_url') or ''
        u = urllib.parse.urlsplit(image_url)
        allowed_host=re.fullmatch(r'(?:basket-\d+\.wbbasket\.ru|[a-z]{2,4}-basket-cdn-\d+\.geobasket\.net)',u.hostname or '')
        if u.scheme != 'https' or not allowed_host or u.username or u.password or u.port not in (None, 443):
            raise ValueError('Не удалось скачать исходное фото WB. Сохраните фото и загрузите его через раздел 1688.')
        import requests
        with requests.get(image_url, timeout=20, stream=True, allow_redirects=False) as r:
            if r.status_code != 200:
                raise ValueError('WB не отдал фото. Сохраните и загрузите его вручную.')
            content = r.raw.read(8_000_001)
    if not content or len(content) > 8_000_000:
        raise ValueError('Выберите изображение размером до 8 МБ.')
    from PIL import Image
    try:
        im = Image.open(io.BytesIO(content))
        if im.width * im.height > 40_000_000:
            raise ValueError()
        im.load()
        im = im.convert('RGB')
    except Exception:
        raise ValueError('Не удалось прочитать фото. Выберите JPG, PNG или WebP до 40 мегапикселей.') from None
    folder = os.path.join(ROOT, 'data', 'supplier-search')
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, uuid.uuid4().hex + '.jpg')
    try:
        im.thumbnail((2400, 2400))
        im.save(path, 'JPEG', quality=92)
        url, _ = search_url('1688', '收纳盒')
        result = _browser_read('1688', 'search', url, photo_path=path)
        photo_url = result.get('photo_url') or ''
        if not photo_url.startswith('https://air.1688.com/kapp/1688-search/pc-image-search/'):
            photo_url = 'https://s.1688.com/'
        result.update(success=True, query='по фотографии', search_url=photo_url)
        return result
    finally:
        if os.path.exists(path):
            os.remove(path)


def estimate(data):
    """Manual estimate per unit; do not guess tariffs or missing package sizes."""
    source = source_name(data.get('source'))
    def n(key, positive=False):
        try:
            raw = data.get(key)
            if raw is None or raw == '' or isinstance(raw, bool):
                raise ValueError()
            value = float(raw)
            if not math.isfinite(value) or value < 0 or (positive and value <= 0):
                raise ValueError()
            return value
        except (TypeError, ValueError):
            raise ValueError('Заполните корректно все поля расчёта; неизвестные значения нельзя считать нулём.') from None
    purchase = n('price', True) * (n('cny_rate', True) if source == '1688' else 1)
    volume = None
    if source == '1688':
        volume = n('length_cm', True) * n('width_cm', True) * n('height_cm', True) / 1_000_000
        freight = max(n('weight_kg', True) * n('per_kg', True), volume * n('per_m3', True))
    else:
        freight = n('freight')
    total = purchase + freight + n('other_costs')
    fees = n('fees_pct') / 100
    if fees >= 1:
        raise ValueError('Сумма комиссии и налогов должна быть меньше 100%.')
    sale = n('sale_price', True)
    profit = sale * (1 - fees) - total
    return {'success': True, 'purchase_kzt': round(purchase, 2), 'freight_kzt': round(freight, 2),
            'volume_m3': volume, 'cost_kzt': round(total, 2), 'profit_kzt': round(profit, 2),
            'break_even_kzt': math.ceil(total / (1 - fees))}


def register(app):
    from flask import jsonify, request
    def catalog_api(source):
        try:
            return jsonify(catalog(source))
        except ValueError as error:
            return jsonify(success=False, error=str(error)), 400
    app.add_url_rule('/api/suppliers/catalog/<source>', 'suppliers_catalog', catalog_api, methods=['GET'])
    def categories_api(source):
        try:return jsonify(categories(source,request.args.get('parent_url') or None))
        except ValueError as error:return jsonify(success=False,error=str(error)),400
        except SupplierError as error:return jsonify(success=False,error=str(error)),503
        except Exception:return jsonify(success=False,error='Не удалось загрузить категории площадки. Повторите позже.'),503
    app.add_url_rule('/api/suppliers/categories/<source>','suppliers_categories',categories_api,methods=['GET'])
    def api(action):
        if action == 'photo' and request.content_length and request.content_length > 8_100_000:
            return jsonify(success=False, error='Фото должно быть не больше 8 МБ.'), 413
        uploaded = request.files.get('image') if action == 'photo' else None
        data = {} if uploaded else request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(success=False, error='Ожидается запрос с данными.'), 400
        try:
            if action == 'photo':
                result = photo_search(data, uploaded)
            elif action == 'search':
                result = search_category(data.get('source'),data['category_url']) if data.get('category_url') else search(data.get('source'), data.get('query'))
            elif action == 'product':
                result = read_product(data.get('source'), data.get('url'))
            elif action == 'drafts':
                source = source_name(data.get('source'))
                url = product_url(source, data.get('url'))
                product = _PRODUCTS.get((source, url))
                if product is None:
                    raise ValueError('Загрузите товар перед созданием черновиков.')
                from core.supplier_drafts import make
                if source=='ozon' and product.get('delivery',{}).get('expected_city')!=_city_settings()[0]:
                    raise ValueError('Город изменён. Повторно загрузите товар Ozon для нового города.')
                result = make(product, data.get('preorder_days'), data.get('variant_ids'))
            else:
                result = estimate(data)
            return jsonify(result)
        except ValueError as error:
            return jsonify(success=False, error=str(error)), 400
        except SupplierError as error:
            return jsonify(success=False, error=str(error)), 503
        except Exception:
            # No raw exceptions: third-party URLs or browser state may contain private data.
            return jsonify(success=False, error='Не удалось загрузить данные. Проверьте окно браузера, пройдите проверку сайта или вход и повторите. Если другая загрузка ещё идёт, дождитесь её завершения.'), 503
    for action in ('search', 'product', 'estimate', 'drafts', 'photo'):
        app.add_url_rule('/api/suppliers/' + action, 'suppliers_' + action,
                         lambda action=action: api(action), methods=['POST'])
