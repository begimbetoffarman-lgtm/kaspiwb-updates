// Напоминалка: праздники КЗ и Китая + налоги и платежи ИП. Тонкая строка под шапкой во всех разделах.
// Налоги появляются только ближе к сроку и спрашивают «заплатили?»: «да» убирает напоминание, «ещё нет» повторит при следующем входе.
(function () {
  const D = (y, m, d) => new Date(y, m - 1, d);
  // FIXED повторяются каждый год: [тип, месяц, день, дней, название, совет]
  const FIXED = [
    ['kz', 1, 1, 2, 'Новый год', 'Курьеры работают с перебоями: закройте магазин или предупредите покупателей о сроках.'],
    ['kz', 1, 7, 1, 'Рождество', 'Возможны выходные и переносы: доставка может сдвинуться.'],
    ['kz', 3, 8, 1, 'Женский день', 'Выходной: доставка сдвигается.'],
    ['kz', 3, 21, 3, 'Наурыз', 'Три выходных подряд: заказы доставят позже, закройте магазин на нужные даты.'],
    ['kz', 5, 1, 1, 'День единства', 'Выходной: доставка сдвигается.'],
    ['kz', 5, 7, 1, 'День защитника', 'Выходной: доставка сдвигается.'],
    ['kz', 5, 9, 1, 'День Победы', 'Выходной: доставка сдвигается.'],
    ['kz', 7, 6, 1, 'День столицы', 'Выходной: доставка сдвигается.'],
    ['kz', 8, 30, 1, 'День Конституции', 'Выходной: доставка сдвигается.'],
    ['kz', 10, 25, 1, 'День Республики', 'Выходной: доставка сдвигается.'],
    ['kz', 12, 16, 2, 'День Независимости', 'Два выходных: закройте магазин или предупредите покупателей о сроках.'],
    ['cn', 5, 1, 5, 'Праздник труда (Китай)', 'Заводы и склады отдыхают до 5 дней: отгрузки и граница встанут.'],
    ['cn', 10, 1, 7, 'Золотая неделя (Китай)', 'Неделя без отгрузок: заказывайте у поставщика за 3–4 недели.'],
  ];
  // Плавающие даты (примерные): [тип, дата, дней, название, совет]
  const MOVING = [
    ['cn', D(2027, 2, 6), 7, 'Китайский Новый год', 'Главная пауза года: фабрики закрываются на 2–4 недели, граница и карго встают. Закажите у поставщиков заранее.'],
    ['cn', D(2028, 1, 26), 7, 'Китайский Новый год', 'Главная пауза года: фабрики закрываются на 2–4 недели. Закажите заранее.'],
    ['cn', D(2027, 4, 5), 3, 'Цинмин (Китай)', 'Короткий выходной: отгрузки задержатся на несколько дней.'],
    ['cn', D(2028, 4, 4), 3, 'Цинмин (Китай)', 'Короткий выходной: отгрузки задержатся на несколько дней.'],
    ['cn', D(2027, 6, 9), 3, 'Дуаньу (Китай)', 'Короткий выходной: отгрузки задержатся на несколько дней.'],
    ['cn', D(2028, 5, 28), 3, 'Дуаньу (Китай)', 'Короткий выходной: отгрузки задержатся на несколько дней.'],
    ['cn', D(2027, 9, 15), 3, 'Середина осени (Китай)', 'Короткий выходной: отгрузки задержатся на несколько дней.'],
    ['cn', D(2028, 10, 3), 3, 'Середина осени (Китай)', 'Короткий выходной: отгрузки задержатся на несколько дней.'],
    ['kz', D(2027, 5, 16), 2, 'Курбан-айт ≈', 'Дата плавает, уточните. Выходные: доставка сдвигается.'],
    ['kz', D(2028, 5, 5), 2, 'Курбан-айт ≈', 'Дата плавает, уточните. Выходные: доставка сдвигается.'],
  ];
  const MON = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];

  // ---- налоги ИП на упрощёнке (форма 910). Выпавшие на выходной сдвигаются на понедельник.
  const workday = d => { const w = d.getDay(); return w === 6 ? new Date(d.getTime() + 2 * 864e5) : w === 0 ? new Date(d.getTime() + 864e5) : d; };
  const ls = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* без хранилища не запомним */ } },
  };
  const ss = {
    get(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { sessionStorage.setItem(k, v); } catch (e) { /* не страшно */ } },
  };
  // Отметки «заплатил» хранятся на компьютере в папке программы (data/tax_paid.json), в браузере только копия.
  let PAID = {};
  try { PAID = JSON.parse(ls.get('taxPaid') || '{}') || {}; } catch (e) { PAID = {}; }
  let START = Number(ls.get('taxStart')) || 0;
  const paidKeys = () => PAID;
  const markPaid = id => {
    PAID[id] = Date.now(); ls.set('taxPaid', JSON.stringify(PAID));
    if (typeof apiPost === 'function') apiPost('/api/reminders/paid', { id: id, paid: true }).catch(() => {});
  };
  function taxEvents(today) {
    const out = [];
    const add = (d, name, q, tip, win) => { const due = workday(d); out.push({ t: 'tax', d: due, n: 1, name: name, q: q, tip: tip, win: win, tax: 1, id: name + '|' + due.getTime() }); };
    for (let y = today.getFullYear() - 1; y <= today.getFullYear() + 1; y++) {
      add(D(y, 2, 15), 'Декларация 910 за 2-е полугодие', 'Вы сдали упрощённую декларацию?', 'Срок сдачи декларации за вторую половину прошлого года.', 10);
      add(D(y, 2, 25), 'Оплата налогов по упрощёнке', 'Вы оплатили ИПН и соцналог?', 'Оплата налогов по итогам полугодия.', 10);
      add(D(y, 8, 15), 'Декларация 910 за 1-е полугодие', 'Вы сдали упрощённую декларацию?', 'Срок сдачи декларации за январь–июнь.', 10);
      add(D(y, 8, 25), 'Оплата налогов по упрощёнке', 'Вы оплатили ИПН и соцналог?', 'Оплата налогов по итогам полугодия.', 10);
    }
    for (let k = -1; k <= 2; k++) {
      const m = D(today.getFullYear(), today.getMonth() + 1 + k, 25);
      add(m, 'Платежи ИП за себя', 'Вы заплатили ежемесячные платежи по ИП?', 'ОПВ, СО, ВОСМС, ООСМС: до 25-го числа каждого месяца.', 7);
    }
    return out;
  }
  function build() {
    const now = new Date();
    const today = D(now.getFullYear(), now.getMonth() + 1, now.getDate());
    const paid = paidKeys();
    const list = [];
    for (let y = today.getFullYear(); y <= today.getFullYear() + 1; y++) {
      FIXED.forEach(f => list.push({ t: f[0], d: D(y, f[1], f[2]), n: f[3], name: f[4], tip: f[5] }));
    }
    MOVING.forEach(m => list.push({ t: m[0], d: m[1], n: m[2], name: m[3], tip: m[4] }));
    const withLeft = h => {
      const end = new Date(h.d.getTime() + (h.n - 1) * 864e5);
      return Object.assign(h, { end: end, left: Math.round((h.d - today) / 864e5), on: today >= h.d && today <= end });
    };
    const base = list.map(withLeft).filter(h => h.on || h.left > 0);
    // налоги: только в окне перед сроком (7 дней для платежей, 10 для деклараций), без оплаченных; просрочка видна 30 дней
    // считаем только сроки после первого запуска напоминалки: прошлые платежи не трогаем
    if (!START) { START = today.getTime(); ls.set('taxStart', String(START)); }
    const start = START;
    const taxes = taxEvents(today).map(withLeft).filter(h => h.d.getTime() >= start && !paid[h.id] && h.left <= h.win && h.left >= -30);
    return base.concat(taxes).sort((a, b) => a.d - b.d);
  }
  const fmt = h => h.d.getDate() + (h.n > 1 ? '–' + h.end.getDate() : '') + ' ' + MON[h.d.getMonth()];
  const left = h => h.tax && h.left < 0 ? 'просрочено на ' + (-h.left) + ' дн' : h.on || h.left === 0 ? (h.tax ? 'срок сегодня' : 'идёт сейчас') : h.left === 1 ? 'завтра' : 'через ' + h.left + ' дн';
  const icon = h => (h.t === 'tax' ? '💼' : h.t === 'cn' ? '🏮' : '🌙');
  const hdr = document.querySelector('.topbar');
  if (!hdr || document.getElementById('holStrip')) return;
  const perm = () => (typeof Notification === 'undefined' ? 'none' : Notification.permission);

  const s = document.createElement('div');
  s.id = 'holStrip';
  hdr.after(s);
  let hiddenToday = ls.get('holHide') === new Date().toDateString();

  function render() {
    const all = build();
    const taxDue = all.find(h => h.tax);
    // главное в строке: налоги (важнее всего) → китайский Новый год за 60 дней → ближайший праздник
    const cn = all.find(h => h.t === 'cn' && h.name.indexOf('Новый год') > -1 && h.left <= 60);
    const next = taxDue || cn || all.find(h => !h.tax);
    if (!next) { s.style.display = 'none'; return; }
    const urgent = next.tax ? (next.left <= 3) : (next.on || next.left <= 7);
    s.className = 'hol-strip' + (urgent ? ' hot' : next.left <= 21 || next.tax ? ' warm' : '');
    const askNo = next.tax && ss.get('taxNo:' + next.id);
    const tipHtml = next.tax
      ? '<span class="hol-q">' + next.q + '</span>' +
        (askNo ? '<span class="hol-tip">Хорошо, напомню при следующем входе.</span>'
          : '<button type="button" class="hol-yes">✅ Да, заплатил</button><button type="button" class="hol-no">⏳ Ещё нет</button>')
      : '<span class="hol-tip">' + next.tip + '</span>';
    s.innerHTML = '<span class="hol-ico">' + icon(next) + '</span><span class="hol-main"><b>' + next.name + '</b> · до ' + fmt(next) + ' · ' + left(next) + '</span>' + tipHtml +
      '<button type="button" class="hol-more" aria-expanded="false">Все даты ▾</button>' +
      (next.tax ? '' : '<button type="button" class="hol-x" title="Скрыть до завтра" aria-label="Скрыть до завтра">×</button>') +
      '<div class="hol-pop" hidden>' + all.slice(0, 9).map(h => '<div class="hol-row"><span>' + icon(h) + '</span><b>' + fmt(h) + '</b><span>' + h.name + '</span><em>' + left(h) + '</em></div>').join('') +
      '<div class="hol-note">Налоги показаны для ИП на упрощёнке (форма 910) без работников и появляются за 7–10 дней до срока; другой режим или работники: уточните у бухгалтера. Плавающие праздники примерные. Китайский Новый год: заказывайте за 4–6 недель.</div>' +
      '<button type="button" class="hol-bell" id="holBell"></button></div>';
    s.style.display = hiddenToday && !next.tax ? 'none' : '';
    const pop = s.querySelector('.hol-pop');
    const more = s.querySelector('.hol-more');
    more.onclick = () => { pop.hidden = !pop.hidden; more.setAttribute('aria-expanded', String(!pop.hidden)); };
    const x = s.querySelector('.hol-x');
    if (x) x.onclick = () => { s.style.display = 'none'; hiddenToday = true; ls.set('holHide', new Date().toDateString()); };
    const yes = s.querySelector('.hol-yes');
    if (yes) yes.onclick = () => { markPaid(next.id); render(); };
    const no = s.querySelector('.hol-no');
    if (no) no.onclick = () => { ss.set('taxNo:' + next.id, '1'); render(); };
    paintBell();
  }
  function paintBell() {
    const bell = document.getElementById('holBell');
    if (!bell) return;
    const p = perm();
    bell.textContent = p === 'granted' ? '🔔 Уведомления включены' : p === 'denied' ? '🔕 Уведомления запрещены в браузере' : p === 'none' ? '🔕 Браузер не поддерживает уведомления' : '🔔 Включить уведомления';
    bell.disabled = p !== 'default';
    bell.onclick = () => { Notification.requestPermission().then(() => { paintBell(); push(); }); };
  }
  function say(title, text, tag) {
    if (perm() === 'granted') { try { new Notification(title, { body: text, tag: tag }); return; } catch (e) { /* ниже запасной вариант */ } }
    if (window.showToast) window.showToast(title + ': ' + text);
  }
  // Налоги: при каждом новом входе (сессии), пока не отмечено «заплатил». Праздники: за 7 дней и в день начала, один раз.
  function push() {
    build().forEach(h => {
      if (h.tax) {
        const key = 'taxPush:' + h.id;
        if (ss.get(key)) return;
        ss.set(key, '1');
        say('💼 ' + h.name + ' · ' + left(h), h.q + ' Откройте программу и отметьте.', key);
      } else {
        const d = h.on ? 0 : h.left;
        if (d !== 7 && d !== 0) return;
        const key = 'holN:' + h.name + ':' + h.d.getTime() + ':' + d;
        if (ls.get(key)) return;
        ls.set(key, '1');
        say(icon(h) + ' ' + h.name + ' · ' + left(h), h.tip, key);
      }
    });
  }
  render();
  // подтягиваем отметки с компьютера: они общие для всех браузеров; старые отметки из браузера переносим на сервер
  let ready = false;
  function init() {
    if (typeof apiGet !== 'function') { push(); return; }
    apiGet('/api/reminders/paid?start=' + (START || '')).then(r => {
      if (r && r.ok && r.data) {
        const local = Object.assign({}, PAID);
        PAID = Object.assign({}, local, r.data.paid || {});
        if (r.data.start) { START = r.data.start; ls.set('taxStart', String(START)); }
        ls.set('taxPaid', JSON.stringify(PAID));
        const extra = {};
        Object.keys(local).forEach(k => { if (!(r.data.paid || {})[k]) extra[k] = local[k]; });
        if (Object.keys(extra).length && typeof apiPost === 'function') apiPost('/api/reminders/paid', { import: extra }).catch(() => {});
      }
    }).catch(() => {}).then(() => { ready = true; render(); push(); });
  }
  init();
  setInterval(render, 3600 * 1000);
})();
