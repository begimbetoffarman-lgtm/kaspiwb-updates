// «В пути» и «Возвраты»: отдают готовый HTML для экрана «Заказы» (пункты меню статусов в app.js).
(function () {
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const money = n => (Number(n) || 0).toLocaleString('ru-RU') + ' ₸';
  const box = 'border:1px solid #ddd;border-radius:8px;padding:8px;margin-bottom:6px;';
  const items = list => (list || []).map(i => esc(i.sku) + ' × ' + esc(i.qty) + ' — ' + esc(i.name)).join('<br>');

  window.flow = {
    // числа для пунктов меню
    async counts() {
      const r = await apiGet('/api/orders/digest');
      if (!r.ok) return { transit: 0, returns: 0, returns_sum: 0 };
      const d = r.data;
      return { transit: d.in_transit || 0, returns: d.returns_open || 0, returns_sum: d.returns_open_sum || 0 };
    },
    async transit() {
      const r = await apiGet('/api/orders/transit');
      if (!r.ok) return esc(r.error);
      const d = r.data;
      return `<div class="help-text" style="margin-bottom:6px;">В пути: <b>${d.in_transit}</b> · ждут передачи курьеру: <b>${d.waiting}</b>` +
        (d.late ? ` · <b style="color:#B91C1C">просрочена доставка: ${d.late}</b>` : '') + '</div>' +
        (d.rows.map(o => `<div style="${box}${o.done ? 'opacity:.7' : ''}"><b>${esc(o.code)}</b> · ` +
          (o.done ? '✅ доставлен ' + esc(o.completed || '') : (o.late ? '⚠️ доставка задерживается' : '🚚 в пути')) +
          `${o.city ? ' · ' + esc(o.city) : ''}<br>${items(o.items)}<br>` +
          `<span class="help-text">Передан: ${esc(o.handed || '—')}${o.done ? '' : ' · доставить до: ' + esc(o.planned || '—')} · сумма ${money(o.total)}</span></div>`).join('') || 'Пока ничего нет.');
    },
    async returns() {
      const r = await apiGet('/api/orders/returns');
      if (!r.ok) return esc(r.error);
      const d = r.data;
      return `<div style="margin-bottom:8px;font-weight:600;">Всего возвратов: ${d.count} на ${money(d.total)} · <span style="color:#B91C1C">не забрано: ${d.open_count} на ${money(d.open_sum)}</span></div>` +
        (d.rows.map(o => `<div style="${box}${o.got ? 'opacity:.65' : ''}"><b>${esc(o.code)}</b> · ${esc(o.status_ru)} · ${esc(o.state)}` +
          ` · <b>${money(o.total)}</b>${o.city ? ' · ' + esc(o.city) : ''}<br>${items(o.items)}<br>` +
          `<span class="help-text">Передан: ${esc(o.handed || '—')} · найден: ${esc(o.first_seen || '')}${o.reason ? ' · причина: ' + esc(o.reason) : ''}${o.got_at ? ' · забрал: ' + esc(o.got_at) : ''}</span> ` +
          `<button type="button" class="btn btn-sm ${o.got ? 'btn-secondary' : 'btn-accent'}" data-ret="${esc(o.code)}" data-got="${o.got ? 0 : 1}">${o.got ? 'Вернуть в «не забрано»' : '✓ Забрал'}</button></div>`).join('') || 'Возвратов за этот период нет.') +
        ((d.top || []).length ? '<div class="help-text" style="margin-top:8px;"><b>Чаще всего возвращают:</b><br>' +
          d.top.map(s => `${esc(s.sku)} — ${esc(s.name)}: возвратов ${s.returns}` + (s.rate != null ? ` (${s.rate}% от продаж и возвратов)` : '')).join('<br>') + '</div>' : '');
    },
    async mark(code, got) { return apiPost('/api/orders/returns/mark', { code, got }); },
  };
})();
