// Мотивационные баннеры в верху разделов поиска и калькулятора (чистый CSS, без картинок).
(function () {
  const Q = {
    'tab-radar': { t: 'Лучше усердно трудиться в молодости, чем в старости надеяться на пенсию.', c: 'q-gold' },
    'tab-1688': { t: 'Не сдавайся. Победа достаётся тому, кто не остановился за шаг до результата.', c: 'q-green' },
    'tab-ozon': { t: 'Деньги любят терпеливых: сегодня труд, завтра свобода.', c: 'q-blue' },
    'tab-margin': { t: 'Семь раз посчитай — один раз закажи.', c: 'q-violet' },
    'daysBox': { t: 'Хороший отпуск — это инвестиция: отдохнувший хозяин зарабатывает больше уставшего.', c: 'q-teal', sym: '☾', plain: true },
  };
  Object.keys(Q).forEach(id => {
    const pane = document.getElementById(id);
    if (!pane || pane.querySelector('.quote-banner')) return;
    if (id === 'daysBox') {
      const v = document.createElement('div');
      v.className = 'vac-banner'; v.setAttribute('role', 'note');
      v.innerHTML = '<div class="vb-sun"></div><svg class="vb-palm" viewBox="0 0 120 150" aria-hidden="true"><path d="M60 148C58 110 64 80 74 50" stroke="#6b4a2b" stroke-width="7" fill="none" stroke-linecap="round"/><g class="vb-fr"><path d="M74 50C50 36 30 44 18 62C40 52 58 52 74 50z" fill="#2f9e5b"/><path d="M74 50C98 34 118 44 124 64C102 52 88 52 74 50z" fill="#3bb56a"/><path d="M74 50C64 28 76 10 92 4C86 22 82 36 74 50z" fill="#278a4e"/><path d="M74 50C52 52 38 70 36 88C52 70 64 60 74 50z" fill="#3bb56a"/></g></svg><div class="vb-wave vb-w1"></div><div class="vb-wave vb-w2"></div><div class="qb-text vb-text">' + Q[id].t + '</div>';
      pane.insertBefore(v, pane.firstChild);
      return;
    }
    const b = document.createElement('div');
    b.className = 'quote-banner ' + Q[id].c; if (!Q[id].plain) pane.classList.add('pane-dollars');
    b.setAttribute('role', 'note');
    let bills = '';
    for (let i = 0; i < 16; i++) {
      bills += `<i style="left:${(i * 6.4 + (i % 3) * 2).toFixed(1)}%;animation-delay:${(-(i * 1.7) % 11).toFixed(1)}s;animation-duration:${9 + (i % 5) * 2}s;font-size:${16 + (i % 4) * 7}px">${Q[id].sym || '$'}</i>`;
    }
    b.innerHTML = `<div class="qb-bills" aria-hidden="true">${bills}</div><div class="qb-text">${Q[id].t}</div>`;
    pane.insertBefore(b, pane.firstChild);
  });
})();
