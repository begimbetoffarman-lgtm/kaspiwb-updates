"""Прибыль магазина «по-честному»: завершённые заказы Kaspi минус себестоимость, комиссия Kaspi, доставка, налог.
Только чтение. Завершённые заказы не меняются, поэтому их позиции кэшируются в data/profit_cache.json."""
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from core import kaspi_store as ks
from core import order_flow as of
from core import orders_screen as osr

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_CACHE = os.path.join(ROOT, "data", "profit_cache.json")
_LOCK = threading.Lock()


def _cache_load():
    try:
        with open(_CACHE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _entries_priced(order_id):
    try:
        d = osr._get(f"https://kaspi.kz/shop/api/v2/orders/{order_id}/entries?include=product")
    except Exception:
        return None
    out = []
    for e in d.get("data", []):
        a = e.get("attributes", {})
        off = a.get("offer") or {}
        qty = int(a.get("quantity") or 1)
        unit = a.get("basePrice")
        if unit is None and a.get("totalPrice") is not None:
            unit = float(a["totalPrice"]) / max(qty, 1)
        out.append({"sku": off.get("code"), "name": off.get("name"), "qty": qty, "unit": float(unit or 0)})
    return out


def _costs():
    """sku -> себестоимость: ваша правка > файл себестоимостей > черновик карточки > оценка магазина."""
    out = {}
    try:
        for p in ks.load_live_products():
            if p.get("sku") and (p.get("default_cost") or 0) > 0:
                out[str(p["sku"])] = float(p["default_cost"])
    except Exception:
        pass
    try:
        with open(os.path.join(ROOT, "data", "kaspi_card_drafts.json"), encoding="utf-8") as f:
            for d in json.load(f):
                if d.get("sku") and (d.get("cost") or 0) > 0:
                    out[str(d["sku"])] = float(d["cost"])
    except Exception:
        pass
    try:
        with open(os.path.join(ROOT, "data", "my_store_costs.json"), encoding="utf-8") as f:
            for k, v in json.load(f).items():
                if float(v or 0) > 0:
                    out[str(k)] = float(v)
    except Exception:
        pass
    try:
        for k, v in ks.load_overrides().items():
            if float(v.get("cost_price") or 0) > 0:
                out[str(k)] = float(v["cost_price"])
    except Exception:
        pass
    return out


def report(days=28):
    windows = max(1, min(4, -(-days // 14)))
    orders = [o for o in of._scan(["ARCHIVE"], windows=windows) if o["attributes"].get("status") == "COMPLETED"]
    cutoff = int(time.time() * 1000) - days * 86400000
    orders = [o for o in orders if (o["attributes"].get("completionDate") or 0) >= cutoff]
    with _LOCK:
        cache = _cache_load()
        todo = [o for o in orders if o["id"] not in cache]
        if todo:
            with ThreadPoolExecutor(6) as ex:
                got = list(ex.map(lambda o: _entries_priced(o["id"]), todo))
            for o, g in zip(todo, got):
                if g is not None:
                    cache[o["id"]] = g
            os.makedirs(os.path.dirname(_CACHE), exist_ok=True)
            ks._atomic_json_write(_CACHE, cache)
    costs = _costs()
    by_day, by_prod = {}, {}
    no_cost_orders = 0
    for o in orders:
        a = o["attributes"]
        items = cache.get(o["id"])
        if not items:
            continue
        day = time.strftime("%Y-%m-%d", time.localtime((a.get("completionDate") or 0) / 1000))
        d = by_day.setdefault(day, {"date": day, "orders": 0, "revenue": 0.0, "profit": 0.0})
        d["orders"] += 1
        unknown = False
        for it in items:
            rev = it["unit"] * it["qty"]
            cost = costs.get(str(it["sku"]))
            p = by_prod.setdefault(str(it["sku"]), {"sku": it["sku"], "name": it["name"], "qty": 0, "revenue": 0.0,
                                                    "profit": 0.0, "known": True})
            p["qty"] += it["qty"]
            p["revenue"] += rev
            d["revenue"] += rev
            if cost:
                econ = ks.calculate_product_economics(it["unit"], cost)
                pr = float(econ.get("net_profit") or 0) * it["qty"]
                p["profit"] += pr
                d["profit"] += pr
            else:
                p["known"] = False
                unknown = True
        no_cost_orders += 1 if unknown else 0
    days_list = sorted(by_day.values(), key=lambda x: x["date"], reverse=True)
    today = time.strftime("%Y-%m-%d")
    week_from = time.strftime("%Y-%m-%d", time.localtime(time.time() - 6 * 86400))
    def agg(f):
        sel = [d for d in days_list if f(d["date"])]
        return {"orders": sum(d["orders"] for d in sel), "revenue": round(sum(d["revenue"] for d in sel)),
                "profit": round(sum(d["profit"] for d in sel))}
    prods = sorted(by_prod.values(), key=lambda p: -p["profit"])
    for p in prods:
        p["revenue"], p["profit"] = round(p["revenue"]), round(p["profit"])
    losers = [p for p in prods if p["known"] and p["profit"] < 0]
    return {"today": agg(lambda d: d == today), "week": agg(lambda d: d >= week_from), "period": agg(lambda d: True),
            "days": [dict(d, revenue=round(d["revenue"]), profit=round(d["profit"])) for d in days_list[:30]],
            "top": prods[:8], "losers": losers[:8], "no_cost_orders": no_cost_orders, "period_days": days}
