"""Выставление на готовые карточки Kaspi (присоединение к существующей карточке).
Адреса взяты из кода кабинета (kaspi.kz/mc, страница «Добавить товар → присоединиться к карточке»):
  данные карточки:  GET  mc.shop.kaspi.kz/content/item/api/v1/item/<код карточки>
  новый суффикс:    GET  mc.shop.kaspi.kz/content/pending/mc/product/<merchant_id>/new-code
  присоединить:     POST mc.shop.kaspi.kz/content/pending/mc/product/link-to-master  {merchantCode, merchantProductCode, masterProductCode}
preview() только читает. link() пишет в живой Kaspi: вызывать только после подтверждения пользователя."""
import re

from core import kaspi_cabinet as kc

_HDR = {"Origin": "https://kaspi.kz", "Referer": "https://kaspi.kz/mc/"}


def parse_code(text):
    """Код карточки из числа или ссылки kaspi.kz/shop/p/...-123456789/ ."""
    s = str(text or "").strip()
    m = re.search(r"-(\d{5,})/?(?:[?#].*)?$", s) or re.fullmatch(r"(\d{5,})", s)
    if not m:
        raise RuntimeError("Не нашёл код карточки. Вставьте ссылку на товар Kaspi (оканчивается на -числа) или сам код.")
    return m.group(1)


def preview(text):
    """Что за карточка (название, категория, фото). Ничего не меняет."""
    code = parse_code(text)
    kc._ensure()
    for _ in range(8):                      # карточка может быть «переехавшей» на другой код
        r = kc._session().get(kc.MC + f"/content/item/api/v1/item/{code}", headers=_HDR, timeout=30)
        if r.status_code != 200:
            raise RuntimeError(f"Kaspi не отдал карточку {code} ({r.status_code}).")
        d = r.json()
        if d.get("status") == "ACTUAL":
            break
        nxt = (d.get("redirectCodes") or [None])[0]
        if not nxt:
            raise RuntimeError("Карточка недоступна (удалена или не опубликована).")
        code = str(nxt)
    card = d.get("card") or {}
    imgs = d.get("galleryImages") or []
    return {"code": str(card.get("id") or code), "title": card.get("title"), "category": d.get("masterCategoryName"),
            "img": (imgs[0].get("medium") if imgs else None), "link": (card.get("shopLink") or "").replace("/p/", "/shop/p/", 1) if str(card.get("shopLink") or "").startswith("/p/") else card.get("shopLink")}


def link(text, price=None, preorder_days=None):
    from core import license as _lic
    _lic.require()
    """Присоединяет магазин к карточке; если указаны цена и срок — сразу выставляет. ПИШЕТ В ЖИВОЙ KASPI."""
    info = preview(text)
    mid = kc.merchant_id()
    r = kc._session().get(kc.MC + f"/content/pending/mc/product/{mid}/new-code", headers=_HDR, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"Kaspi не выдал код товара ({r.status_code}).")
    suffix = re.sub(r"[^0-9A-Za-z_-]", "", r.text.strip())
    if not suffix:
        raise RuntimeError("Kaspi вернул пустой код товара.")
    sku = f"{info['code']}_{suffix}"
    body = {"merchantCode": mid, "merchantProductCode": sku, "masterProductCode": info["code"]}
    resp = None
    for q in ({}, {"m": mid}, {"_m": mid}):
        resp = kc._session().post(kc.MC + "/content/pending/mc/product/link-to-master", params=q, json=body, timeout=60,
                                  headers=dict(_HDR, **{"Content-Type": "application/json"}))
        if resp.status_code not in (403, 404):
            break
    if resp.status_code >= 400:
        kc._log("link_error", card=info["code"], http=resp.status_code)
        raise RuntimeError(f"Kaspi не присоединил карточку ({resp.status_code}): {resp.text[:200]}")
    kc._save_session()
    kc._log("link_to_master", card=info["code"], sku=sku)
    out = {"ok": True, "sku": sku, "card": info, "offer_set": False}
    if price:
        try:
            kc.set_offer(sku, price=int(price), preorder_days=preorder_days, available=True, stock=10)
            out["offer_set"] = True
        except Exception as e:
            out["offer_error"] = str(e)[:200]
    return out
