"""Резервная копия ваших данных одним файлом и восстановление (в том числе на другом компьютере).
В копию НЕ попадают токены, пароли, лицензия и сессии: только ваши рабочие данные (черновики карточек, история поиска,
возвраты, себестоимость, настройки экрана)."""
import io
import json
import os
import time
import zipfile

from core import kaspi_store as ks

DATA = ks.DATA_DIR
ALLOWED = (
    "kaspi_card_drafts.json", "forks_history.json", "kaspi_links.json", "returns.json", "found.json", "my_store_costs.json",
    "my_store_custom.json", "my_store_import.json", "my_store_overrides.json", "repricer_config.json", "ui_state.json",
    "wb_tracking.json", "kaspi_reject_log.json", "zh-ru-cache.json", "profit_cache.json", "card_prefs.json", "catalog.json", "tax_paid.json",
)
MAX_BYTES = 60 * 1024 * 1024


def export_bytes():
    buf = io.BytesIO()
    names = []
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for n in ALLOWED:
            p = os.path.join(DATA, n)
            if os.path.isfile(p):
                z.write(p, n)
                names.append(n)
        z.writestr("manifest.json", json.dumps({"app": "kaspi-wb", "created": time.strftime("%Y-%m-%d %H:%M:%S"), "files": names},
                                               ensure_ascii=False))
    return buf.getvalue(), names


def restore(blob):
    """Восстанавливает только разрешённые файлы. Всё остальное в архиве игнорируется."""
    if len(blob) > MAX_BYTES:
        raise ValueError("Файл слишком большой для резервной копии.")
    try:
        z = zipfile.ZipFile(io.BytesIO(blob))
    except zipfile.BadZipFile:
        raise ValueError("Это не файл резервной копии программы.")
    if "manifest.json" not in z.namelist():
        raise ValueError("Это не файл резервной копии программы (нет манифеста).")
    restored = []
    for n in z.namelist():
        if n not in ALLOWED:                       # любые другие имена и пути игнорируем
            continue
        info = z.getinfo(n)
        if info.file_size > MAX_BYTES:
            continue
        raw = z.read(n)
        json.loads(raw.decode("utf-8"))            # битые файлы не пишем
        p = os.path.join(DATA, n)
        if os.path.isfile(p):                      # перед заменой сохраняем прежний файл рядом
            try:
                os.replace(p, p + ".before-restore")
            except OSError:
                pass
        os.makedirs(DATA, exist_ok=True)
        with open(p + ".tmp", "wb") as f:
            f.write(raw)
        os.replace(p + ".tmp", p)
        restored.append(n)
    if not restored:
        raise ValueError("В копии нет подходящих данных.")
    return restored
