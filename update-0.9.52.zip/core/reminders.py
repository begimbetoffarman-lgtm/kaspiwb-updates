"""Напоминания о налогах ИП: какие сроки уже оплачены/сданы. Хранится в папке программы (data/tax_paid.json),
поэтому отметка сохраняется независимо от браузера. Секретов тут нет."""
import json
import os
import threading
import time

from core import kaspi_store as ks

_PATH = os.path.join(ks.DATA_DIR, "tax_paid.json")
_LOCK = threading.Lock()
_MAX = 400          # хранить не больше стольких отметок
_ID_MAX = 160


def _load():
    try:
        with open(_PATH, "r", encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            return d
    except (OSError, ValueError):
        pass
    return {}


def _save(d):
    os.makedirs(os.path.dirname(_PATH), exist_ok=True)
    tmp = _PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(tmp, _PATH)


def get(start_hint=None):
    """Отметки и дата первого запуска напоминалки (для неё берём подсказку из браузера, если файла ещё нет)."""
    with _LOCK:
        d = _load()
        d.setdefault("paid", {})
        if not d.get("start"):
            try:
                d["start"] = int(start_hint) if start_hint else int(time.time() * 1000)
            except (TypeError, ValueError):
                d["start"] = int(time.time() * 1000)
            _save(d)
        return {"paid": d["paid"], "start": d["start"]}


def mark(item_id, paid=True):
    item_id = str(item_id or "")[:_ID_MAX]
    if not item_id:
        raise ValueError("Не указан срок.")
    with _LOCK:
        d = _load()
        p = d.setdefault("paid", {})
        if paid:
            p[item_id] = int(time.time() * 1000)
        else:
            p.pop(item_id, None)
        if len(p) > _MAX:                      # старые отметки не нужны
            for k in sorted(p, key=p.get)[:len(p) - _MAX]:
                p.pop(k, None)
        d.setdefault("start", int(time.time() * 1000))
        _save(d)
        return {"id": item_id, "paid": bool(paid)}


def import_many(items):
    """Перенос отметок, сделанных раньше только в браузере."""
    n = 0
    with _LOCK:
        d = _load()
        p = d.setdefault("paid", {})
        for k, v in (items or {}).items():
            k = str(k)[:_ID_MAX]
            if k and k not in p:
                try:
                    p[k] = int(v)
                except (TypeError, ValueError):
                    p[k] = int(time.time() * 1000)
                n += 1
        if n:
            d.setdefault("start", int(time.time() * 1000))
            _save(d)
    return n
