// Курьер-помощник: сидит в углу, подсказывает сроки, налоги и заказы. За курсором не бегает и кнопки не закрывает.
(function () {
  if (document.getElementById('courier')) return;
  const ls = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* без хранилища не запомним */ } },
  };
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const MODES = ['normal', 'soft', 'off'];
  const MODE_RU = { normal: 'обычные', soft: 'мягкие', off: 'выкл' };
  let mode = MODES.indexOf(ls.get('kwAnim')) >= 0 ? ls.get('kwAnim') : 'normal';
  const root = document.documentElement;
  root.setAttribute('data-anim', mode);

  // персонаж рисуется в SVG, цвета близки к Kaspi (красный), логотипов нет
  const svg = `
<svg viewBox="0 0 100 124" width="86" height="106" aria-hidden="true">
  <g class="cr-all">
    <ellipse cx="50" cy="120" rx="26" ry="3.5" fill="rgba(0,0,0,.18)"/>
    <rect x="37" y="100" width="10" height="16" rx="3" fill="#2b2d42"/><rect x="53" y="100" width="10" height="16" rx="3" fill="#2b2d42"/>
    <rect x="34" y="112" width="15" height="6" rx="3" fill="#fff"/><rect x="51" y="112" width="15" height="6" rx="3" fill="#fff"/>
    <rect x="28" y="60" width="44" height="42" rx="12" fill="#f14635"/>
    <path d="M42 60l8 9 8-9z" fill="#fff"/>
    <rect x="28" y="84" width="44" height="4" fill="#d93a2b"/>
    <g class="cr-box"><rect x="23" y="72" width="54" height="30" rx="4" fill="#d9a465"/><rect x="47" y="72" width="6" height="30" fill="#f2d7a8"/><rect x="29" y="80" width="14" height="9" rx="2" fill="#fff" opacity=".9"/><text x="36" y="87.5" font-size="8" text-anchor="middle" font-weight="800" fill="#f14635" font-family="Arial">₸</text></g>
    <circle cx="22" cy="92" r="5.5" fill="#ffd9b8"/><circle cx="78" cy="92" r="5.5" fill="#ffd9b8"/>
    <g class="cr-head">
      <circle cx="50" cy="40" r="19" fill="#ffd9b8"/>
      <circle cx="40" cy="45" r="3.2" fill="#ff9d8f" opacity=".55"/><circle cx="60" cy="45" r="3.2" fill="#ff9d8f" opacity=".55"/>
      <g class="cr-eyes"><ellipse cx="43" cy="39" rx="2.4" ry="3" fill="#2b2d42"/><ellipse cx="57" cy="39" rx="2.4" ry="3" fill="#2b2d42"/></g>
      <path class="cr-mouth" d="M44 48q6 5 12 0" stroke="#2b2d42" stroke-width="2" fill="none" stroke-linecap="round"/>
      <path d="M30 36Q30 14 50 13Q70 14 70 36Z" fill="#f14635"/>
      <path d="M28 36h46q8 0 8 4h-54z" fill="#d93a2b"/>
      <circle cx="50" cy="25" r="6" fill="#fff"/><text x="50" y="28.2" font-size="9" text-anchor="middle" font-weight="800" fill="#f14635" font-family="Arial">₸</text>
      <g class="cr-lamp"><polygon points="68,30 100,18 100,44" fill="url(#crBeam)"/><circle cx="68" cy="30" r="3" fill="#fff7c2"/></g>
      <path class="cr-sweat" d="M72 30q3 5 0 8q-3-3 0-8z" fill="#7ac7ff"/>
    </g>
  </g>
  <defs><linearGradient id="crBeam" x1="0" x2="1"><stop offset="0" stop-color="#fff3b0" stop-opacity=".9"/><stop offset="1" stop-color="#fff3b0" stop-opacity="0"/></linearGradient></defs>
</svg>`;

  const box = document.createElement('div');
  box.id = 'courier';
  box.className = 'courier p-idle';
  box.innerHTML = '<div class="c-bubble" hidden><button type="button" class="c-x" aria-label="Закрыть">×</button><div class="c-text"></div><button type="button" class="c-mode"></button></div>' +
    '<button type="button" class="c-body" title="Курьер-помощник: нажмите, чтобы узнать, что на сегодня">' + svg + '</button>' +
    '<button type="button" class="c-wake" title="Показать курьера" aria-label="Показать курьера">🛵</button>';
  document.body.appendChild(box);
  const bubble = box.querySelector('.c-bubble'), text = box.querySelector('.c-text'), modeBtn = box.querySelector('.c-mode');
  let hideT = null, tax = null, info = { collect: 0, returns: 0, returnsSum: 0, late: [] };

  function applyMode() {
    root.setAttribute('data-anim', mode);
    box.classList.toggle('c-off', mode === 'off');
    modeBtn.textContent = 'Анимации: ' + MODE_RU[mode] + ' ↻';
  }
  function pose(p, ms) {
    box.className = box.className.replace(/\bp-\w+/g, '') + ' p-' + p;
    if (ms) setTimeout(() => pose(info.late.length || tax ? 'hurry' : 'idle'), ms);
  }
  function lines() {
    const l = [];
    if (tax) l.push('💼 ' + tax.text);
    info.late.slice(0, 2).forEach(t => l.push('⚠️ ' + t));
    if (info.collect > 0) l.push('📦 Нужно собрать заказов: ' + info.collect);
    if (info.returns > 0) l.push('↩️ Не забрано возвратов: ' + info.returns + (info.returnsSum ? ' на ' + info.returnsSum.toLocaleString('ru-RU') + ' ₸' : ''));
    return l;
  }
  function say(arr, sticky) {
    if (mode === 'off') return;
    text.innerHTML = arr.map(esc).join('<br>');
    bubble.hidden = false;
    clearTimeout(hideT);
    if (!sticky) hideT = setTimeout(() => { bubble.hidden = true; }, 11000);
  }
  box.querySelector('.c-x').onclick = () => { bubble.hidden = true; clearTimeout(hideT); };
  box.querySelector('.c-body').onclick = () => {
    if (!bubble.hidden) { bubble.hidden = true; return; }
    const l = lines();
    say(l.length ? l : ['Всё спокойно: срочных дел нет. Хорошего дня! 🙂'], true);
    pose(l.length ? 'hurry' : 'happy', 2200);
  };
  modeBtn.onclick = () => { mode = MODES[(MODES.indexOf(mode) + 1) % MODES.length]; ls.set('kwAnim', mode); applyMode(); };
  box.querySelector('.c-wake').onclick = () => { mode = 'normal'; ls.set('kwAnim', mode); applyMode(); };

  // налоговое напоминание приходит из строки праздников
  window.addEventListener('kw:tax', e => {
    tax = e.detail || null;
    if (!info.late.length) pose(tax ? 'hurry' : 'idle');
  });

  // монетки и радость: вызывается при отметке «заплатил» и т.п.
  window.kwHappy = function (el) {
    if (mode === 'off') return;
    pose('happy', 2600);
    if (mode !== 'normal') return;
    const r = (el && el.getBoundingClientRect) ? el.getBoundingClientRect() : { left: innerWidth - 120, top: innerHeight - 150, width: 0, height: 0 };
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    for (let i = 0; i < 14; i++) {
      const c = document.createElement('i');
      c.className = 'kw-coin'; c.textContent = '₸';
      c.style.cssText = 'left:' + cx + 'px;top:' + cy + 'px;--dx:' + Math.round((Math.random() - 0.5) * 220) + 'px;--dy:' + Math.round(-60 - Math.random() * 150) + 'px;animation-delay:' + (i * 25) + 'ms';
      document.body.appendChild(c);
      setTimeout(() => c.remove(), 1700);
    }
  };

  async function refresh() {
    if (document.hidden || typeof apiGet !== 'function') return;
    try {
      const [d, dl] = await Promise.all([apiGet('/api/orders/digest'), apiGet('/api/home/deadlines')]);
      if (d && d.ok && d.data) info = Object.assign(info, { collect: d.data.to_collect || 0, returns: d.data.returns_open || 0, returnsSum: d.data.returns_open_sum || 0 });
      if (dl && dl.ok && dl.data) info.late = (dl.data.items || []).filter(x => x.level === 'late').map(x => x.text);
    } catch (e) { /* без связи просто молчим */ }
    pose(info.late.length || tax ? 'hurry' : 'idle');
  }
  applyMode();
  setTimeout(() => { refresh().then(() => { const l = lines(); if (l.length) say(l.slice(0, 3), false); }); }, 5000);
  setInterval(refresh, 5 * 60 * 1000);
  setInterval(() => { const l = lines(); if (l.length && !document.hidden) say(l.slice(0, 2), false); }, 15 * 60 * 1000);
})();
