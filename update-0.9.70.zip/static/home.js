// Главная: дашборд (сводка, график прибыли по дням, сроки, товары, слежение за WB, отказы Kaspi). Плюс резервная копия в настройках.
(function () {
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const num = n => (Number(n) || 0).toLocaleString('ru-RU');
  const money = n => num(n) + ' ₸';
  let loadedAt = 0;

  // число плавно «набегает» от нуля
  function countUp(el, to, fmt) {
    if (!el) return;
    const end = Number(to) || 0, t0 = performance.now(), dur = 700;
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = fmt(end); return; }
    (function step(now) {
      const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      el.textContent = fmt(Math.round(end * e));
      if (k < 1) requestAnimationFrame(step);
    })(t0);
  }
  function kpi(cls, icon, id, label, sub) {
    return `<div class="kpi ${cls}"><div class="kpi-ico">${icon}</div><div><b id="${id}">0</b><span>${label}</span>${sub ? `<em>${sub}</em>` : ''}</div></div>`;
  }

  // столбики прибыли по дням (SVG, без библиотек)
  function chart(days) {
    const d = (days || []).slice().sort((a, b) => a.date < b.date ? -1 : 1);
    if (!d.length) return '<div class="dash-empty">За этот период нет завершённых заказов.</div>';
    const W = 640, H = 150, pad = 4, gap = 4;
    const max = Math.max(1, ...d.map(x => Math.abs(x.profit)));
    const zero = H * (d.some(x => x.profit < 0) ? 0.72 : 0.94);
    const bw = Math.max(6, (W - pad * 2 - gap * (d.length - 1)) / d.length);
    const bars = d.map((x, i) => {
      const h = Math.max(2, Math.abs(x.profit) / max * (x.profit >= 0 ? zero - 8 : H - zero - 6));
      const y = x.profit >= 0 ? zero - h : zero;
      const xx = pad + i * (bw + gap);
      return `<rect class="bar ${x.profit >= 0 ? 'up' : 'down'}" x="${xx.toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="3" style="animation-delay:${i * 25}ms"><title>${esc(x.date)}: ${money(x.profit)} (заказов ${x.orders})</title></rect>`;
    }).join('');
    return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Прибыль по дням"><line x1="0" x2="${W}" y1="${zero}" y2="${zero}" class="zero"/>${bars}</svg>` +
      `<div class="axis"><span>${esc(d[0].date)}</span><span>${esc(d[d.length - 1].date)}</span></div>`;
  }
  const prods = (list, cls, empty) => (list && list.length)
    ? list.map(p => `<div class="prod"><div class="prod-n"><b>${esc(p.sku)}</b><span>${esc((p.name || '').slice(0, 54))}</span></div><div class="prod-v ${cls}">${p.profit > 0 ? '+' : ''}${money(p.profit)}</div></div>`).join('')
    : `<div class="dash-empty">${empty}</div>`;

  // «Следующий шаг»: одна подсказка по состоянию магазина (данные уже есть в других запросах)
  const S = { d: undefined, drafts: undefined };
  function renderNext() {
    const el = $('homeNext'); if (!el || S.d === undefined) return;
    let t = null;
    if (!S.d) t = ['Подключите магазин Kaspi', 'Без этого программа не видит заказы и карточки. Это три шага в мастере.', 'Подключить Kaspi', 'tab-setup'];
    else if (S.d.to_collect > 0) t = ['Соберите заказы: ' + S.d.to_collect, 'Эти заказы ждут сборки и передачи курьеру.', 'Открыть заказы', 'tab-orders'];
    else if (S.drafts === undefined) { el.innerHTML = ''; return; }
    else if (S.drafts > 0) t = ['Проверьте черновики: ' + S.drafts, 'Проверьте название, цену и категорию и отправьте в Kaspi. Пока вы не нажмёте «Отправить в Kaspi», ничего не уходит.', 'Открыть карточки', 'tab-cards'];
    else if (S.drafts === 0) t = ['Найдите первый товар для продажи', 'Откройте поиск на Wildberries, выберите хит и создайте черновик карточки.', 'Перейти к поиску WB', 'tab-radar'];
    el.innerHTML = t ? '<div class="dash-card" style="margin-bottom:14px"><div class="dash-head"><h4>Следующий шаг</h4></div><div style="font-size:17px;font-weight:700;margin:4px 0">' + esc(t[0]) + '</div><div class="dash-sub" style="margin-bottom:10px">' + esc(t[1]) + '</div><button type="button" class="btn btn-primary wz-go" data-go="' + t[3] + '">' + esc(t[2]) + '</button></div>' : '';
  }

  async function loadHome() {
    if (!$('homeBox')) return;
    if (Date.now() - loadedAt < 20000) return;          // не дёргаем Kaspi при каждом переключении вкладок
    loadedAt = Date.now();
    apiGet('/api/orders/digest').then(r => {
      const d = r.ok ? r.data : null;
      S.d = d; renderNext();
      if (!d) { $('homeDigest').innerHTML = '<div class="dash-empty" style="grid-column:1/-1">Здесь появятся заказы, прибыль и сроки после подключения Kaspi.</div>'; return; }
      $('homeDigest').innerHTML =
        kpi(d.to_collect > 0 ? 'k-red' : 'k-green', `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/></svg>`, 'kpiCollect', 'собрать сейчас') +
        kpi('k-blue', `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 6h13v10H1z"/><path d="M14 9h4l3 3v4h-7"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/></svg>`, 'kpiTransit', 'в пути к покупателю') +
        kpi(d.returns_open > 0 ? 'k-amber' : 'k-green', `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg>`, 'kpiReturns', 'возвратов не забрано', d.returns_open_sum > 0 ? money(d.returns_open_sum) : '') +
        kpi('k-violet', `<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M14.5 9.2c-.5-.8-1.4-1.2-2.5-1.2-1.4 0-2.5.8-2.5 2s1 1.7 2.5 2 2.5.8 2.5 2-1.1 2-2.5 2c-1.1 0-2-.4-2.5-1.2M12 6v2M12 16v2"/></svg>`, 'kpiProfit', 'чистая прибыль за 7 дней');
      countUp($('kpiCollect'), d.to_collect, String);
      countUp($('kpiTransit'), d.in_transit, String);
      countUp($('kpiReturns'), d.returns_open, String);
      if (window.__homeWeek != null) countUp($('kpiProfit'), window.__homeWeek, money);
    });
    apiGet('/api/cards').then(r => {
      const dr = r.ok && r.data && Array.isArray(r.data.drafts) ? r.data.drafts : null;
      S.drafts = dr ? dr.filter(x => !['sent', 'accepted', 'selling', 'on_sale'].includes(x.status)).length : undefined;
      if (dr && !dr.length) S.drafts = 0;
      renderNext();
    });
    apiGet('/api/home/deadlines').then(r => {
      const it = r.ok ? r.data.items : [];
      $('homeDeadlines').innerHTML = it.length
        ? it.slice(0, 6).map(x => `<div class="dl ${esc(x.level)}"><i></i><span>${esc(x.text)}</span></div>`).join('')
        : `<div class="dash-empty">${r.ok ? 'Срочных дел нет. Можно выдохнуть 🙂' : 'Появятся после подключения Kaspi.'}</div>`;
    });
    apiGet('/api/profit?days=28').then(r => {
      if (!r.ok) { $('homeChart').textContent = 'Данные появятся после подключения Kaspi («Подключение магазина»). ' + (r.error || ''); $('homeTop').textContent = ''; $('homeLosers').textContent = ''; return; }
      const d = r.data;
      window.__homeWeek = d.week.profit;
      if ($('kpiProfit')) countUp($('kpiProfit'), d.week.profit, money);
      $('homeProfitNums').innerHTML =
        `<div><b class="${d.today.profit < 0 ? 'neg' : ''}">${money(d.today.profit)}</b><span>сегодня · заказов ${d.today.orders}</span></div>` +
        `<div><b class="${d.week.profit < 0 ? 'neg' : ''}">${money(d.week.profit)}</b><span>7 дней · заказов ${d.week.orders}</span></div>` +
        `<div><b class="${d.period.profit < 0 ? 'neg' : ''}">${money(d.period.profit)}</b><span>28 дней · выручка ${money(d.period.revenue)}</span></div>`;
      $('homeChart').innerHTML = chart(d.days);
      $('homeProfitNote').textContent = (d.no_cost_orders ? 'Для ' + d.no_cost_orders + ' заказов не указана себестоимость, прибыль по ним не посчитана. ' : '') +
        'Прибыль = цена продажи минус себестоимость, комиссия Kaspi, доставка и налог. Возвраты считаются отдельно.';
      $('homeTop').innerHTML = prods((d.top || []).slice(0, 5), 'plus', 'Пока нет данных.');
      $('homeLosers').innerHTML = prods((d.losers || []).slice(0, 5), 'minus', 'Товаров в минусе нет 🎉');
    });
    apiGet('/api/home/tracker').then(r => {
      if (!r.ok) { $('homeTracker').textContent = r.error; return; }
      const d = r.data;
      $('homeTracker').innerHTML = d.tracked
        ? `<div class="chip-line"><span class="chip ok">Слежу за ${d.tracked} товарами</span><span class="dash-sub">проверка: ${esc(d.last_run || '—')}</span></div>` +
          (d.problems.length ? d.problems.map(p => `<div class="dl late"><i></i><span>${esc(p.sku)}: ${esc(p.action)}</span></div>`).join('') : '<div class="dash-empty">Всё в порядке ✅</div>')
        : '<div class="dash-empty">Слежение начнётся после первой продажи товара, выставленного из WB.</div>';
    });
    apiGet('/api/home/rejects').then(r => {
      const it = r.ok ? r.data.items : [];
      $('homeRejects').innerHTML = it.length
        ? it.slice(0, 4).map(x => `<div class="dl soon"><i></i><span>${esc(x.example)} · ${x.count} раз, исправлено ${x.fixed}</span></div>`).join('')
        : '<div class="dash-empty">Отказов Kaspi пока не было ✅</div>';
    });
  }
  window.loadHome = loadHome;

  // ---- резервная копия
  if ($('bkImport')) {
    $('bkImport').addEventListener('change', async e => {
      const f = e.target.files[0]; if (!f) return;
      if (!confirm('Восстановить данные из файла «' + f.name + '»? Текущие файлы будут заменены (старые сохранятся рядом с пометкой .before-restore).')) { e.target.value = ''; return; }
      $('bkStatus').textContent = 'Восстанавливаю…';
      try {
        const r = await fetch('/api/backup/import', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: await f.arrayBuffer() });
        const j = await r.json();
        $('bkStatus').textContent = j.success ? 'Восстановлено файлов: ' + j.restored.length + '. Перезапустите программу.' : (j.error || 'Не удалось восстановить.');
      } catch (err) { $('bkStatus').textContent = 'Ошибка: ' + err.message; }
      e.target.value = '';
    });
  }

  // главная открывается первой
  setTimeout(() => { const a = document.querySelector('.nav-item.active'); if (a && a.dataset.tab === 'tab-home') loadHome(); }, 600);
})();

  // «Как добавить в предзаказ»: открыт при первом запуске, потом свёрнут
  (function () {
    const d = document.getElementById('radarHowto'); if (!d) return;
    try { if (localStorage.getItem('howtoSeen')) d.open = false; } catch (e) {}
    d.addEventListener('toggle', () => { try { localStorage.setItem('howtoSeen', '1'); } catch (e) {} });
  })();
