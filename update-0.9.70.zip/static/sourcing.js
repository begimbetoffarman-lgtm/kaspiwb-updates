// «Где закупить дешевле»: окно с вариантами на WB для карточки «Мой магазин».
// Работает только по клику на «🔍 дешевле». Закупка меняется только кнопкой «Взять как закупку».
(function () {
  const fmt = n => Math.round(n || 0).toLocaleString('ru-RU');
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function ensureModal() {
    let m = document.getElementById('srcModal');
    if (m) return m;
    m = document.createElement('div');
    m.id = 'srcModal';
    m.className = 'src-modal';
    m.hidden = true;
    m.innerHTML = '<div class="src-box" role="dialog" aria-modal="true" aria-labelledby="srcTitle">' +
      '<button type="button" class="src-close" aria-label="Закрыть">×</button>' +
      '<h3 id="srcTitle">Где закупить дешевле</h3><div id="srcBody"></div></div>';
    document.body.appendChild(m);
    m.addEventListener('click', e => { if (e.target === m || e.target.classList.contains('src-close')) m.hidden = true; });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') m.hidden = true; });
    return m;
  }

  function findProduct(sku) {
    try { return (storeData && storeData.products || []).find(x => x.sku === sku); } catch (e) { return null; }
  }

  const MK = { wb: 'WB', ozon: 'Ozon', '1688': '1688' };
  const safeUrl = u => (/^https?:\/\//i.test(String(u || '')) ? String(u) : '#');
  function rowHtml(it, p) {
    const labs = { source: ['src-same', 'ваш исходный товар на WB'], same: ['src-same', 'то же фото'], name: ['src-same', 'то же по названию'] };
    const lb = labs[it.label];
    const lab = lb ? '<span class="src-tag ' + lb[0] + '">' + lb[1] + '</span>' : '<span class="src-tag">похожий, проверьте</span>';
    const mk = MK[it.market] || 'WB';
    const pr = it.net_profit != null ? '<b class="' + (it.net_profit < 0 ? 'src-neg' : 'src-pos') + '">' + fmt(it.net_profit) + ' ₸ (' + it.margin_pct + '%)</b>' : '—';
    const sav = it.saving > 0 ? '<div class="src-sub">дешевле вашей закупки на ' + fmt(it.saving) + ' ₸</div>' : '';
    const meta = it.market === '1688'
      ? '<div class="src-sub">¥' + it.cny + ' за штуку · доставка 14–17 дней · цена оценочная</div>'
      : '<div class="src-sub">★ ' + (it.rating || '—') + ' · отзывов ' + (it.feedbacks || 0) + '</div>';
    const num = it.need_weight
      ? '<div class="src-price">≈ ' + fmt(it.goods_kzt) + ' ₸</div><div class="src-sub">только товар. Введите вес, чтобы посчитать доставку и прибыль</div>'
      : '<div class="src-price">' + fmt(it.price) + ' ₸</div><div class="src-sub">прибыль с шт.: ' + pr + '</div>' + sav;
    const take = it.need_weight ? '' : '<button type="button" class="sup-mini src-take" data-price="' + it.price + '" data-sku="' + esc(p.sku) + '">Взять как закупку</button>';
    return '<div class="src-row"><img src="' + esc(safeUrl(it.img) === '#' ? '' : it.img) + '" alt="" loading="lazy" referrerpolicy="no-referrer">' +
      '<div class="src-info"><div class="src-name">' + esc(it.name) + '</div><span class="src-mk">' + mk + '</span> ' + lab + meta + '</div>' +
      '<div class="src-num">' + num + '</div>' +
      '<div class="src-act"><a class="sup-mini" target="_blank" rel="noopener noreferrer" href="' + esc(safeUrl(it.url)) + '">Открыть на ' + mk + '</a>' + take + '</div></div>';
  }

  let curSku = '';
  function wKey(sku) { return 'srcW_' + sku; }
  function append1688(p) {
    const body = document.getElementById('srcBody');
    let w = '', q = '10';
    try { const v = JSON.parse(localStorage.getItem(wKey(p.sku)) || '{}'); w = v.w || ''; q = v.q || '10'; } catch (e) { }
    const box = document.createElement('div');
    box.className = 'src-1688';
    box.innerHTML = '<div class="src-sep"></div><div class="src-name">Китай (1688)</div>' +
      '<div class="src-sub">Ищет по фото на 1688 и считает закупку по настройкам калькулятора маржи (курс юаня и карго). Доставка 14–17 дней.</div>' +
      '<div class="src-ctl"><label>Вес 1 шт, кг <input id="src1688w" type="number" min="0" step="0.05" value="' + esc(w) + '"></label> ' +
      '<label>Партия, шт <input id="src1688q" type="number" min="1" step="1" value="' + esc(q) + '"></label> ' +
      '<button type="button" class="sup-mini" id="src1688go">Искать на 1688</button></div><div id="src1688res"></div>';
    body.appendChild(box);
  }

  async function run1688() {
    const p = findProduct(curSku), out = document.getElementById('src1688res');
    if (!p || !out) return;
    const w = parseFloat(document.getElementById('src1688w').value) || 0, q = parseInt(document.getElementById('src1688q').value, 10) || 10;
    try { localStorage.setItem(wKey(p.sku), JSON.stringify({ w: w || '', q: q })); } catch (e) { }
    out.innerHTML = '<p class="src-msg">Ищу на 1688 по фото… это занимает 2–4 минуты. Если 1688 попросит вход, войдите в окне ego.</p>';
    let res;
    try {
      const r = await fetch('/api/kaspi/sourcing', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sku: p.sku, card_code: p.card_code, title: p.title, price: p.sell_price, img: p.img,
          comm_rate: p.commission_rate, cost_now: p.cost_price || 0, markets: ['1688'], weight_kg: w, qty: q })
      });
      res = await r.json();
    } catch (e) { res = { ok: false, error: 'Нет связи с программой. Повторите.' }; }
    if (!res.ok) { out.innerHTML = '<p class="src-msg">' + esc(res.error || 'Поиск не удался.') + '</p>'; return; }
    if (!res.items.length) { out.innerHTML = '<p class="src-msg">На 1688 нет похожих по фото товаров дешевле вашей цены (с доставкой). Попробуйте поиск по названию в разделе 1688.</p>'; return; }
    out.innerHTML = '<div class="src-list">' + res.items.map(it => rowHtml(it, p)).join('') + '</div>' +
      (w ? '' : '<p class="src-note">Вес не введён: показана только цена товара. Введите вес и нажмите «Искать на 1688» ещё раз.</p>');
  }

  function render(p, res) {
    const body = document.getElementById('srcBody');
    const head = '<div class="src-head">' + esc(p.title) + '<br><span>Ваша цена на Kaspi: <b>' + fmt(p.sell_price) + ' ₸</b>' +
      (p.cost_price > 0 ? ' · ваша закупка: <b>' + fmt(p.cost_price) + ' ₸</b>' : ' · закупка не указана') + '</span></div>';
    curSku = p.sku;
    if (!res.ok) { body.innerHTML = head + '<p class="src-msg">' + esc(res.error || 'Поиск не удался.') + '</p>'; append1688(p); return; }
    if (!res.items.length) {
      body.innerHTML = head + '<p class="src-msg">' + (res.empty
        ? 'На WB и Ozon не нашлось похожих товаров. Возможно, товар китайский: Попробуйте блок «Китай (1688)» ниже.'
        : 'На WB и Ozon нет товаров дешевле вашей цены Kaspi или похожих. Выгодной закупки там нет.') + '</p>';
      append1688(p);
      return;
    }
    const rows = res.items.map(it => rowHtml(it, p)).join('');
    body.innerHTML = head + '<div class="src-list">' + rows + '</div>' +
      '<p class="src-note">Цена на сайте сейчас, она может измениться. Доставка с WB бесплатная, поэтому закупка = цена на сайте; доставку Ozon до вас проверьте при заказе. ' +
      (res.cached ? 'Показан сохранённый результат (до 6 часов). ' : '') + '<a href="#" class="src-again">Искать заново</a></p>';
    append1688(p);
  }

  async function run(sku, force) {
    const p = findProduct(sku);
    if (!p) return;
    const m = ensureModal();
    m.hidden = false;
    document.getElementById('srcBody').innerHTML = '<p class="src-msg">Ищу на WB и Ozon по фото вашей карточки… Это занимает 2–3 минуты, окно можно не закрывать.</p>';
    let res;
    try {
      const r = await fetch('/api/kaspi/sourcing', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sku: p.sku, card_code: p.card_code, title: p.title, price: p.sell_price, img: p.img,
          comm_rate: p.commission_rate, cost_now: p.cost_price || 0, force: !!force })
      });
      res = await r.json();
    } catch (e) { res = { ok: false, error: 'Нет связи с программой. Повторите.' }; }
    if (!res.ok && /ego/i.test(res.error || '')) res.error += ' Установить его можно в Настройках → «Браузер ego».';
    render(p, res);
  }

  document.addEventListener('click', e => {
    if (e.target && e.target.id === 'src1688go') { run1688(); return; }
    const f = e.target.closest && e.target.closest('.sup-find');
    if (f) { e.preventDefault(); run(f.dataset.sku, false); return; }
    const a = e.target.closest && e.target.closest('.src-again');
    if (a) { e.preventDefault(); if (curSku) run(curSku, true); return; }
    const t = e.target.closest && e.target.closest('.src-take');
    if (t) {
      const price = parseFloat(t.dataset.price) || 0, p = findProduct(t.dataset.sku);
      if (!p || !price) return;
      if (confirm('Записать закупку ' + fmt(price) + ' ₸ для этой карточки?')) {
        updateCostPrice(p.sku, price);
        document.getElementById('srcModal').hidden = true;
      }
    }
  });

  // блок «Браузер ego» в Настройках
  async function egoCheck() {
    const st = document.getElementById('egoStatus');
    if (!st) return;
    st.textContent = 'Проверяю…';
    try {
      const r = await (await fetch('/api/ego/status')).json();
      const on = !!r.installed;
      st.innerHTML = on ? '<b style="color:#047857">✓ ego установлен, поиск по фото работает.</b>' : '<b>ego не найден на этом компьютере.</b> Установите его по шагам ниже.';
      const steps = document.getElementById('egoSteps'), dl = document.getElementById('egoDownload');
      if (steps) steps.hidden = on;
      if (dl) dl.hidden = on;
    } catch (e) { st.textContent = 'Не удалось проверить. Повторите.'; }
  }
  document.addEventListener('click', e => { if (e.target && e.target.id === 'egoRecheck') egoCheck(); });
  document.addEventListener('click', e => { const n = e.target.closest && e.target.closest('.nav-item[data-tab="tab-settings"],.nav-sub[data-tab="tab-settings"]'); if (n) setTimeout(egoCheck, 300); });
  setTimeout(egoCheck, 1500);
})();
