"""Мастер первого запуска: магазин, склад, город Kaspi и регион WB берутся из кабинета, а не зашиты в код.
Проверено на живом Kaspi 07.11.2026: getKDPoints отдаёт склад и город; регион WB определяется по координатам склада."""
import json
import os
import threading
import time
import urllib.parse
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = os.path.join(ROOT, "config.json")

_Q = ("query getKDPoints($merchantUid: String!) { merchant(id: $merchantUid) { id points(kdSchedule: true, enabled: true) "
      "{ address { geoPoint { latitude longitude } } city { id name } enabled id name type "
      "kaspiDelivery { enabled pickupType } } } }")


def _load():
    from core import secrets as _sec
    return _sec.read_config(CFG)


def _save(c):
    from core import secrets as _sec
    _sec.write_config(c, CFG)


_ALI = {"logged": False, "ts": 0.0, "busy": False}
_ALI_TTL = 120


def _alibaba_refresh():
    try:
        from core import suppliers
        _ALI["logged"] = bool(suppliers.alibaba_login_status().get("logged_in"))
    except Exception:
        pass
    finally:
        _ALI["ts"] = time.time()
        _ALI["busy"] = False


def _alibaba_cached():
    """Вход в 1688 берём из памяти, а проверку (она открывает браузер и идёт до минуты) делаем в фоне:
    страница мастера отвечает сразу, а актуальный ответ появится при следующем обновлении."""
    if not _ALI["busy"] and time.time() - _ALI["ts"] > _ALI_TTL:
        _ALI["busy"] = True
        threading.Thread(target=_alibaba_refresh, daemon=True).start()
    return bool(_ALI["logged"])


def status():
    """Что уже настроено (без значений секретов)."""
    c = _load()
    from core import kaspi_cabinet as k, mail_code
    steps = {
        "merchant": bool(str(c.get("kaspi_merchant_id") or "").strip()),
        "token": bool(str(c.get("kaspi_api_token") or "").strip()),
        "cabinet": False,
        "store": bool(c.get("kaspi_store_id") and c.get("kaspi_store_city") and c.get("wb_dest")),
        "mail": mail_code.configured(),
        "price": False,
    }
    try:
        from core import kaspi_store
        steps["price"] = bool(kaspi_store.load_imported_products())
    except Exception:
        pass
    try:
        steps["cabinet"] = bool(steps["merchant"] and k.is_logged_in())
    except Exception:
        pass
    steps["alibaba"] = _alibaba_cached()
    return {"steps": steps, "merchant_id": str(c.get("kaspi_merchant_id") or ""), "store_id": c.get("kaspi_store_id", ""),
            "city": c.get("kaspi_city_name", ""), "wb_city": c.get("wb_city_name", ""), "wb_dest": c.get("wb_dest", ""),
            "cities": list(CITIES),
            "done": all(steps[x] for x in ("merchant", "token", "cabinet", "store"))}


def _dest_from_xinfo(xinfo):
    for part in str(xinfo or "").split("&"):
        if part.startswith("dest="):
            return part[5:]
    return None


def wb_dest_by_coords(lat, lon):
    """Регион доставки WB (dest) по координатам склада. None — не удалось.
    Сначала прямой запрос (2 попытки); WB иногда режет запросы из программ — тогда спрашиваем через браузер ego."""
    u = ("https://user-geo-data.wildberries.ru/get-geo-info?" +
         urllib.parse.urlencode({"latitude": lat, "longitude": lon, "currency": "KZT", "locale": "ru"}))
    for _ in range(2):
        try:
            d = json.load(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}), timeout=20))
            dest = _dest_from_xinfo(d.get("xinfo"))
            if dest:
                return dest
        except Exception:
            pass
    try:
        from core import ego_bridge
        if ego_bridge.available():
            expr = ("(async()=>{try{const r=await fetch(" + json.dumps(u) + ",{credentials:'include'});const d=await r.json();"
                    "return d&&d.xinfo?{done:true,value:d.xinfo}:{done:false};}catch(e){return {done:false};}})()")
            res = ego_bridge.run([{"t": "goto", "url": "https://www.wildberries.ru/", "soft": True},
                                  {"t": "poll", "expr": expr, "key": "x", "every": 1500, "timeout": 40000}],
                                 space="kaspi-wb", timeout=100)
            return _dest_from_xinfo((res.get("values") or {}).get("x"))
    except Exception:
        pass
    return None


def detect(point_id=None):
    """Склад, город Kaspi и регион WB из кабинета. Нужен вход в кабинет. Сохраняет в config.json."""
    from core import kaspi_cabinet as k
    k._ensure()
    m = k.merchant_id()
    if not m:
        raise RuntimeError("Не указан Merchant ID.")
    r = k._session().post(k.MC + "/mc/facade/graphql", params={"opName": "getKDPoints"}, timeout=30,
                          json={"operationName": "getKDPoints", "query": _Q, "variables": {"merchantUid": m}},
                          headers=dict(k._HDR, **{"Content-Type": "application/json"}))
    pts = (((r.json().get("data") or {}).get("merchant") or {}).get("points")) or []
    if not pts:
        raise RuntimeError("Kaspi не отдал склады магазина. Проверьте Merchant ID и права сотрудника.")
    pts = [p for p in pts if p.get("enabled")] or pts
    pt = next((p for p in pts if p["id"] == point_id), None) or next((p for p in pts if p.get("type") == "WAREHOUSE"), pts[0])
    geo = ((pt.get("address") or {}).get("geoPoint") or {})
    dest = wb_dest_by_coords(geo.get("latitude"), geo.get("longitude")) if geo.get("latitude") else None
    c = _load()
    c["kaspi_store_id"] = pt["id"]
    c["kaspi_store_city"] = (pt.get("city") or {}).get("id", "")
    c["kaspi_city_name"] = (pt.get("city") or {}).get("name", "")
    if dest and not c.get("wb_city_name"):      # выбранный вручную город не затираем
        c["wb_dest"] = dest
    _save(c)
    return {"store_id": c["kaspi_store_id"], "city": c["kaspi_city_name"], "wb_dest": dest,
            "points": [{"id": p["id"], "city": (p.get("city") or {}).get("name")} for p in pts],
            "wb_dest_found": bool(dest)}


CITIES = {"Алматы": (43.238, 76.945), "Астана": (51.169, 71.449), "Шымкент": (42.315, 69.587), "Актобе": (50.283, 57.167),
          "Караганда": (49.806, 73.085), "Атырау": (47.107, 51.903), "Павлодар": (52.287, 76.967),
          "Усть-Каменогорск": (49.948, 82.628), "Семей": (50.411, 80.227), "Костанай": (53.214, 63.625),
          "Кызылорда": (44.853, 65.509), "Уральск": (51.233, 51.367), "Петропавловск": (54.866, 69.150),
          "Актау": (43.650, 51.150), "Тараз": (42.900, 71.367), "Туркестан": (43.297, 68.251),
          "Талдыкорган": (45.017, 78.373), "Кокшетау": (53.283, 69.383), "Темиртау": (50.054, 72.964),
          "Экибастуз": (51.723, 75.323)}


def set_city(name):
    """Город продавца для цен и наличия WB: регион доставки WB (dest) определяется по координатам города."""
    if name not in CITIES:
        raise RuntimeError("Выберите город из списка.")
    dest = wb_dest_by_coords(*CITIES[name])
    if not dest:
        raise RuntimeError("WB не вернул регион для этого города: он блокирует запросы с этого компьютера или сети. Откройте wildberries.ru в браузере ego, пройдите проверку, если она есть, и повторите.")
    c = _load()
    c["wb_dest"] = dest
    c["wb_city_name"] = name
    _save(c)
    return {"city": name, "wb_dest": dest}


def city_name():
    """Название города для подписей: выбранный в программе, иначе город склада Kaspi."""
    try:
        c = _load()
        return c.get("wb_city_name") or c.get("kaspi_city_name") or "вашего города"
    except Exception:
        return "вашего города"
