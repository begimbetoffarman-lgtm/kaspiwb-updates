"""🔭 Сканер ниш: сам обходит подкатегории WB, сверяет лучшие товары с Kaspi и откладывает только надёжные связки.

Работает в фоне, пока открыта программа. Ничего не отправляет в Kaspi и не покупает: читает WB и Kaspi,
складывает «кандидатов» в data/scanner.json и пишет заметки (по файлу на подкатегорию) в папку Obsidian.
Раз в сутки перепроверяет цены кандидатов: если прибыль пропала или товар исчез, кандидат снимается.
"""
import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from core import fork_radar as fr
from core import ratelimit

ROOT = fr.ROOT
STATE_FILE = os.path.join(ROOT, 'data', 'scanner.json')
DEFAULT_NOTES = os.path.join(ROOT, 'obsidian')

# какие разделы WB обходим (одежда и книги не про арбитраж); сколько подкатегорий берём из раздела
SECTIONS = [('Дом', 60), ('Красота', 30), ('Автотовары', 30), ('Электроника', 40),
            ('Бытовая техника', 20), ('Спорт', 20)]
PER_CATEGORY_CHECK = 24
MIN_PROFIT = 1500
MIN_MARGIN = 20
MIN_RPM = 0.3                 # отзывов в месяц у точных карточек Kaspi (≈ 1 в 3 месяца): ниже — спроса почти нет
MIN_FEEDBACKS = 30            # отзывов на WB: подтверждает, что товар реально покупают
MIN_RATING = 4.3
SEEN_DAYS = 7                 # не проверять один и тот же товар на Kaspi чаще, чем раз в 7 дней
MIN_LEFT = 15                 # меньше стольких запросов в суточном лимите: новые проверки не начинаем
TRACK_EVERY = 20 * 3600
PAUSE_BETWEEN = 60            # пауза между подкатегориями: Kaspi начал отвечать 403 при частых запросах

class WbDown(RuntimeError):
    pass


_LOCK = threading.RLock()
_STOP = threading.Event()
_THREAD = None
_STATE = None
_LIVE = {'current': '', 'step': ''}


# ---------------------------------------------------------------- состояние
def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def _load():
    global _STATE
    if _STATE is not None:
        return _STATE
    try:
        with open(STATE_FILE, encoding='utf-8') as f:
            _STATE = json.load(f)
    except (OSError, ValueError):
        _STATE = {}
    for k, v in (('running', False), ('idx', 0), ('queue', []), ('done', {}), ('candidates', {}),
                 ('notes_dir', ''), ('last_track', 0), ('log', []), ('stats', {'checked': 0, 'categories': 0})):
        _STATE.setdefault(k, v)
    return _STATE


def _save():
    st = _load()
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    tmp = STATE_FILE + '.tmp'
    with _LOCK:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(st, f, ensure_ascii=False)
        os.replace(tmp, STATE_FILE)


def _log(text):
    st = _load()
    st['log'] = (st['log'] + ['%s  %s' % (time.strftime('%H:%M'), text)])[-40:]


def notes_dir():
    return _load().get('notes_dir') or DEFAULT_NOTES


def set_notes_dir(path):
    path = str(path or '').strip().strip('"')
    if path:
        if not os.path.isabs(path):
            raise ValueError('Укажите полный путь к папке, например D:\\Obsidian\\Каспи.')
        os.makedirs(path, exist_ok=True)
    _load()['notes_dir'] = path
    _save()
    write_notes()
    return notes_dir()


# ---------------------------------------------------------------- очередь подкатегорий
def build_queue():
    items = fr.categories().get('items') or []
    queue = []
    for section, cap in SECTIONS:
        n = 0
        for it in items:
            p = it.get('path') or []
            if p and p[0] == section:
                queue.append(' / '.join(p))
                n += 1
                if n >= cap:
                    break
    return queue


# ---------------------------------------------------------------- критерии
def qualifies(it):
    """Надёжная связка: реальная цена Kaspi (точная карточка), прибыль, спрос, без предупреждений."""
    e = it.get('economy') or {}
    k = it.get('kaspi') or {}
    if it.get('sell_source') != 'kaspi' or it.get('price_risk'):
        return False
    if (e.get('profit_kzt') or 0) < MIN_PROFIT or (e.get('margin_pct') or 0) < MIN_MARGIN:
        return False
    if not (k.get('exact_matches') or 0):
        return False
    rpm = k.get('reviews_per_month')
    if rpm is None or rpm < MIN_RPM:
        return False
    if (it.get('feedbacks') or 0) < MIN_FEEDBACKS:
        return False
    if it.get('rating') and it['rating'] < MIN_RATING:
        return False
    return True


def fail_reasons(it):
    """Почему связка с реальной ценой Kaspi не стала кандидатом (для настройки порогов)."""
    e, k = it.get('economy') or {}, it.get('kaspi') or {}
    why = []
    if it.get('price_risk'):
        why.append('предупреждение о цене')
    if (e.get('profit_kzt') or 0) < MIN_PROFIT:
        why.append('прибыль мала')
    if (e.get('margin_pct') or 0) < MIN_MARGIN:
        why.append('маржа мала')
    rpm = k.get('reviews_per_month')
    if rpm is None or rpm < MIN_RPM:
        why.append('спрос слабый')
    if (it.get('feedbacks') or 0) < MIN_FEEDBACKS:
        why.append('мало отзывов на WB')
    if it.get('rating') and it['rating'] < MIN_RATING:
        why.append('низкий рейтинг')
    return why


def niche_flag(sellers, rpm):
    """Метка конкуренции для кандидата: пустая строка, если ничего особенного."""
    if not isinstance(sellers, int) or rpm is None:
        return ''
    if sellers <= 1 and rpm >= MIN_RPM:
        return 'один продавец при живом спросе: окно свободно, но он может резко снизить цену'
    if sellers <= 3 and rpm >= MIN_RPM * 2:
        return 'мало продавцов (%d) при сильном спросе: окно открыто' % sellers
    if sellers >= 10:
        return 'много продавцов (%d): конкуренция за цену' % sellers
    return ''


def _record(it, category):
    e, k = it['economy'], it.get('kaspi') or {}
    return {
        'flag': niche_flag(k.get('sellers'), k.get('reviews_per_month')),
        'id': it['id'], 'name': it.get('name') or '', 'url': it.get('url') or '', 'image': it.get('image') or '',
        'category': category, 'kaspi_query': it.get('kaspi_query') or '',
        'kaspi_url': k.get('kaspi_url') or '', 'rating': it.get('rating'), 'feedbacks': it.get('feedbacks'),
        'buy': e.get('buy_kzt'), 'sell': e.get('sell_kzt'), 'profit': e.get('profit_kzt'), 'margin': e.get('margin_pct'),
        'sellers': k.get('sellers'), 'reviews': k.get('reviews_total'), 'rpm': k.get('reviews_per_month'),
        'first_seen': _now(), 'last_seen': _now(), 'last_check': _now(), 'status': 'active', 'reason': '', 'misses': 0,
        'history': [[_now(), e.get('buy_kzt'), e.get('sell_kzt'), e.get('profit_kzt')]],
    }


def _check_items(items, ids):
    """Kaspi-проверка выбранных связок по две одновременно (как очередь в интерфейсе)."""
    st = _load()
    seen = st.setdefault('seen', {})
    horizon = time.time() - SEEN_DAYS * 86400
    # то, что проверяли за последние 7 дней, заново не проверяем: экономим запросы к Kaspi
    todo = [it for it in items if it.get('id') in set(ids) and seen.get(it.get('id'), 0) < horizon]
    skipped = len([i for i in ids if seen.get(i, 0) >= horizon])
    if skipped:
        _log('пропущено повторных проверок (были за %d дн): %d' % (SEEN_DAYS, skipped))
    tried = []

    def one(it):
        if _STOP.is_set() or ratelimit.remaining() < MIN_LEFT:
            return                                              # лимит дня почти выбран: новые проверки не начинаем
        tried.append(it)
        with ratelimit.enforced():                           # паузы между запросами и общий суточный счёт
            fr._attach_kaspi(it, True)
        fr.reprice(it)
        if (it.get('kaspi') or {}).get('checked'):
            seen[it['id']] = time.time()

    with ThreadPoolExecutor(max_workers=1) as ex:         # по одной связке: щадим Kaspi
        list(ex.map(one, todo))
    bad = len([it for it in tried if not (it.get('kaspi') or {}).get('checked')])
    return len(tried), bad


# ---------------------------------------------------------------- обход
def scan_category(cat):
    st = _load()
    _LIVE.update(current=cat, step='ищу на WB')
    out = fr.search_forks(category=cat, source='wb', mode='spread', min_margin=0, limit=60,
                          live_kaspi=True, lazy=True, record=False)
    if not out.get('live') or any(x.get('seed') for x in (out.get('items') or [])):
        # WB не отдал выдачу (блокировка или завис браузер): показаны эталонные данные — это не результат, подкатегорию не засчитываем
        raise WbDown((out.get('notes') or {}).get('wb') or 'WB не ответил')
    items = out.get('items') or []
    pend = out.get('pending') or []
    _LIVE['step'] = 'сверяю с Kaspi (%d)' % len(pend)
    n, bad = _check_items(items, pend)
    st['stats']['checked'] += n
    found, verified = [], 0
    why = st['stats'].setdefault('why', {})
    for it in items:
        if it.get('sell_source') == 'kaspi':
            verified += 1
            if not qualifies(it):
                for w in fail_reasons(it):
                    why[w] = why.get(w, 0) + 1
            st['stats']['verified'] = st['stats'].get('verified', 0) + 1
        if qualifies(it):
            found.append(it)
    # несколько разных товаров WB на одну карточку Kaspi: одна карточка не может быть всеми ими сразу, не берём ни один
    by_card = {}
    for it in items:
        if it.get('sell_source') == 'kaspi':
            by_card.setdefault(((it.get('kaspi') or {}).get('competitor_title'), it['economy'].get('sell_kzt')), []).append(it)
    shared = {id(x) for g in by_card.values() if len(g) > 1 for x in g}
    keep = [it for it in found if id(it) not in shared]
    new = 0
    for it in keep:
        cur = st['candidates'].get(it['id'])
        if not cur or cur.get('status') != 'active':
            st['candidates'][it['id']] = _record(it, cat)
            new += 1
        else:
            cur['last_seen'] = _now()                             # снова попался в выдаче
    st['done'][cat] = {'at': _now(), 'total': out.get('total'), 'checked': n, 'verified': verified,
                       'found': len(keep), 'ids': [x['id'] for x in keep]}
    st['stats']['categories'] = len(st['done'])
    _log('%s: проверено %d, с реальной ценой %d, подошло %d' % (cat, n, verified, len(keep)))
    _save()
    try:
        write_category_note(cat)
        write_notes()
    except Exception as e:
        _log('заметки не записались: %s' % e)
    return bad, n


def track_pass():
    """Раз в сутки: свежая цена WB и Kaspi по каждому кандидату; пропала прибыль или товар — снимаем."""
    st = _load()
    rate = fr._config()
    active = [c for c in st['candidates'].values() if c.get('status') == 'active']
    _LIVE.update(current='слежение за кандидатами', step='%d шт.' % len(active))
    for c in active:
        if _STOP.is_set():
            break
        try:
            words = (c.get('name') or '').split()
            query = ' '.join(words[:6])
            rows, err = fr._search_source('wb', query, 60, rate, skip_cache=True)
            it = next((x for x in rows if x['id'] == c['id']), None)
            if not it:
                c['misses'] = c.get('misses', 0) + 1
                if c['misses'] >= 2:
                    c['status'], c['reason'] = 'dropped', 'товар не найден на WB (возможно, закончился)'
                c['last_check'] = _now()
                continue
            c['misses'] = 0
            fr._attach_kaspi(it, True)
            fr.reprice(it)
            e = it['economy']
            c['last_check'] = _now()
            c['buy'], c['sell'], c['profit'], c['margin'] = e.get('buy_kzt'), e.get('sell_kzt'), e.get('profit_kzt'), e.get('margin_pct')
            c['history'] = (c.get('history') or []) + [[_now(), c['buy'], c['sell'], c['profit']]]
            c['history'] = c['history'][-60:]
            if not (it.get('kaspi') or {}).get('checked'):
                continue                                   # Kaspi не ответил — решим в следующий раз
            if not qualifies(it):
                c['status'] = 'dropped'
                c['reason'] = ('прибыль %s ₸ (%s%%)' % (c['profit'], c['margin'])) if it.get('sell_source') == 'kaspi' else 'точной карточки на Kaspi больше нет'
        except Exception as ex:
            _log('слежение: %s' % ex)
        time.sleep(PAUSE_BETWEEN)
    st['last_track'] = time.time()
    _log('слежение: активных %d' % len([c for c in st['candidates'].values() if c.get('status') == 'active']))
    _save()
    try:
        write_notes()
    except Exception:
        pass


def _loop():
    st = _load()
    if not st['queue']:
        st['queue'] = build_queue()
        st['idx'] = 0
    # подкатегории, «пройденные» на эталонных данных из-за сбоя WB (проверено 0), делаем заново
    redo = [i for i, c in enumerate(st['queue']) if c in st['done'] and not st['done'][c].get('checked') and not st['done'][c].get('verified')]
    if redo:
        for i in redo:
            st['done'].pop(st['queue'][i], None)
        st['idx'] = min(st['idx'], redo[0])
        st['stats']['categories'] = len(st['done'])
        _log('возвращаюсь к %d подкатегориям, пройденным без данных WB' % len(redo))
    _log('сканер запущен: подкатегорий в очереди %d' % len(st['queue']))
    _save()
    while not _STOP.is_set():
        try:
            if time.time() - st.get('last_track', 0) > TRACK_EVERY and any(
                    c.get('status') == 'active' for c in st['candidates'].values()):
                track_pass()
            if st['idx'] >= len(st['queue']):
                _log('обход завершён: все подкатегории проверены')
                st['running'] = False
                _save()
                break
            if ratelimit.remaining() < MIN_LEFT * 4:
                wait = min(ratelimit.seconds_to_tomorrow(), 3600)
                _log('суточный лимит запросов к Kaspi выбран (%d из %d), продолжу завтра' % (ratelimit.used(), ratelimit.DAILY_LIMIT))
                _LIVE['step'] = 'пауза: лимит Kaspi на сегодня выбран'
                _save()
                _STOP.wait(wait)
                continue
            cat = st['queue'][st['idx']]
            bad, n = scan_category(cat)
            st['wb_fails'] = 0
            st['idx'] += 1
            _save()
            if n and bad >= max(6, n // 2):               # Kaspi почти не отвечает (блокировка): растущая пауза 10 → 20 → 40 мин … до 2 ч
                cool = min(7200, int(st.get('cool', 300)) * 2)
                st['cool'] = cool
                _log('Kaspi отвечает плохо (проверено %d, без ответа %d), пауза %d мин' % (n, bad, cool // 60))
                _LIVE['step'] = 'пауза: Kaspi перегружен'
                _save()
                _STOP.wait(cool)
            else:
                if n:
                    st['cool'] = 300
                _STOP.wait(PAUSE_BETWEEN)
        except fr.RadarBusy:
            _STOP.wait(10)
        except WbDown as e:
            fails = st.get('wb_fails', 0) + 1
            st['wb_fails'] = fails
            pause = 120 if fails < 4 else 600                # не долбим WB: 2 минуты, а после четвёртой неудачи 10 минут
            _log('WB не отдал выдачу (%d подряд), повтор через %d мин: %s' % (fails, pause // 60, str(e)[:90]))
            _LIVE['step'] = 'пауза: WB не отвечает'
            _save()
            _STOP.wait(pause)
        except Exception as e:
            _log('ошибка по подкатегории: %s' % e)
            st['idx'] += 1
            _save()
            _STOP.wait(30)
    _LIVE.update(current='', step='')
    st['running'] = False
    _save()


def start():
    global _THREAD
    st = _load()
    with _LOCK:
        if _THREAD and _THREAD.is_alive():
            return status()
        _STOP.clear()
        st['running'] = True
        _save()
        _THREAD = threading.Thread(target=_loop, daemon=True, name='niche-scanner')
        _THREAD.start()
    return status()


def stop():
    st = _load()
    _STOP.set()
    st['running'] = False
    _log('сканер остановлен')
    _save()
    return status()


def reset():
    """Начать обход заново (очередь и список проверенных подкатегорий очищаются, кандидаты остаются)."""
    st = _load()
    if _THREAD and _THREAD.is_alive():
        raise ValueError('Сначала остановите сканер.')
    st['queue'], st['idx'], st['done'] = [], 0, {}
    _save()
    return status()


def resume_if_needed():
    if _load().get('running'):
        start()


def status():
    st = _load()
    alive = bool(_THREAD and _THREAD.is_alive())
    cands = list(st['candidates'].values())
    return {'success': True, 'running': alive, 'current': _LIVE['current'], 'step': _LIVE['step'],
            'idx': st['idx'], 'total': len(st['queue']) or len(build_queue()),
            'checked': st['stats']['checked'], 'categories': st['stats']['categories'],
            'active': len([c for c in cands if c.get('status') == 'active']),
            'dropped': len([c for c in cands if c.get('status') == 'dropped']),
            'verified': st['stats'].get('verified', 0), 'why': st['stats'].get('why', {}),
            'kaspi_used': ratelimit.used(), 'kaspi_limit': ratelimit.DAILY_LIMIT,
            'log': st['log'][-12:], 'notes_dir': notes_dir(), 'last_track': st.get('last_track') or 0}


def candidates():
    cands = sorted(_load()['candidates'].values(), key=lambda c: (c.get('status') != 'active', -(c.get('profit') or 0)))
    return {'success': True, 'items': cands}


# ---------------------------------------------------------------- заметки Obsidian
def _safe(name):
    return re.sub(r'[\\/:*?"<>|]+', '-', str(name)).strip()[:90] or 'без-названия'


def _money(v):
    try:
        return '{:,}'.format(int(round(float(v)))).replace(',', ' ') + ' ₸'
    except (TypeError, ValueError):
        return '—'


def write_category_note(cat):
    st = _load()
    d = st['done'].get(cat)
    if not d:
        return
    folder = os.path.join(notes_dir(), 'Сканер', 'Категории')
    os.makedirs(folder, exist_ok=True)
    lines = ['# %s' % cat, '', 'Проверено: %s' % d['at'],
             '- товаров с WB в выдаче: %s, сверено с Kaspi: %s' % (d.get('total'), d.get('checked')),
             '- нашлось точных карточек Kaspi с реальной ценой: %s' % d.get('verified'),
             '- прошли все проверки (кандидаты): %s' % d.get('found'), '']
    for cid in d.get('ids') or []:
        c = st['candidates'].get(cid)
        if c:
            lines.append('- [%s](%s): закупка %s, продажа %s, прибыль %s (%s%%), спрос ≈%s отзывов/мес' % (
                c['name'][:70], c['url'], _money(c['buy']), _money(c['sell']), _money(c['profit']), c['margin'], c.get('rpm')))
    with open(os.path.join(folder, _safe(cat) + '.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def write_notes():
    st = _load()
    folder = os.path.join(notes_dir(), 'Сканер')
    os.makedirs(folder, exist_ok=True)
    act = [c for c in st['candidates'].values() if c.get('status') == 'active']
    drop = [c for c in st['candidates'].values() if c.get('status') == 'dropped']
    act.sort(key=lambda c: -(c.get('profit') or 0))
    lines = ['# Кандидаты на перепродажу WB → Kaspi', '',
             'Обновлено: %s. Подкатегорий проверено: %s из %s. Товаров сверено с Kaspi: %s.' % (
                 _now(), st['stats']['categories'], len(st['queue']), st['stats']['checked']), '',
             'Критерии: точная карточка Kaspi, прибыль от %s ₸ и маржа от %s%%, спрос от %s отзывов/мес, без предупреждений.' % (
                 MIN_PROFIT, MIN_MARGIN, MIN_RPM), '',
             '## Активные (%d)' % len(act), '',
             '| Товар | Закупка | Продажа | Прибыль | Маржа | Спрос (отз./мес) | Продавцов | Найден | Проверен |',
             '|---|---|---|---|---|---|---|---|---|']
    for c in act:
        lines.append('| [%s](%s) · [Kaspi](%s) | %s | %s | %s | %s%% | %s | %s | %s | %s |' % (
            c['name'][:60].replace('|', '/'), c['url'], c.get('kaspi_url') or '', _money(c['buy']), _money(c['sell']),
            _money(c['profit']), c['margin'], c.get('rpm'), c.get('sellers'), c['first_seen'][:10], c['last_check'][:10]))
    lines += ['', '## Сняты (%d)' % len(drop), '']
    for c in drop[-40:]:
        lines.append('- %s: %s (%s)' % (c['name'][:60], c.get('reason'), c['last_check'][:10]))
    with open(os.path.join(folder, 'Кандидаты.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


# ---------------------------------------------------------------- Flask
OWNER_FLAG = os.path.join(ROOT, 'data', 'scanner_owner.flag')


def enabled():
    """Сканер пока в разработке: включается только флагом data\\scanner_owner.flag (папка data в релиз не попадает)."""
    return os.path.exists(OWNER_FLAG)


def register(app):
    from flask import jsonify, request
    if not enabled():
        return

    def guard(fn):
        try:
            return jsonify(fn())
        except ValueError as e:
            return jsonify(success=False, error=str(e)), 400
        except Exception as e:
            return jsonify(success=False, error='Сканер: %s' % e), 500

    def where():
        import sys
        import traceback
        out = {}
        for t in threading.enumerate():
            if t.name == 'niche-scanner' and t.ident in sys._current_frames():
                out['stack'] = ''.join(traceback.format_stack(sys._current_frames()[t.ident])[-6:])
        return dict(success=True, **out)
    app.add_url_rule('/api/scanner/where', 'scanner_where', lambda: guard(where), methods=['GET'])
    app.add_url_rule('/api/scanner/status', 'scanner_status', lambda: guard(status), methods=['GET'])
    app.add_url_rule('/api/scanner/start', 'scanner_start', lambda: guard(start), methods=['POST'])
    app.add_url_rule('/api/scanner/stop', 'scanner_stop', lambda: guard(stop), methods=['POST'])
    app.add_url_rule('/api/scanner/reset', 'scanner_reset', lambda: guard(reset), methods=['POST'])
    app.add_url_rule('/api/scanner/candidates', 'scanner_candidates', lambda: guard(candidates), methods=['GET'])

    def notes():
        d = request.get_json(silent=True) or {}
        return guard(lambda: dict(success=True, notes_dir=set_notes_dir(d.get('notes_dir'))))
    app.add_url_rule('/api/scanner/notes_dir', 'scanner_notes_dir', notes, methods=['POST'])
    threading.Timer(20, resume_if_needed).start()                # после перезапуска продолжаем с того же места
