import sys, urllib.request, json, ssl, time
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8')

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE

def export_customers():
    with open(r'D:\kaspi-arbitrage-app\config.json', 'r', encoding='utf-8') as f:
        cfg = json.load(f)
    token = cfg.get('kaspi_api_token')

    now_ms = int(time.time() * 1000)
    day_ms = 24 * 3600 * 1000
    all_orders = []

    print("Сбор заказов из Kaspi API за последние 90 дней...")
    for i in range(7):
        end_ms = now_ms - i * 13 * day_ms
        start_ms = end_ms - 13 * day_ms
        url = f'https://kaspi.kz/shop/api/v2/orders?page[number]=0&page[size]=100&filter[orders][creationDate][$ge]={start_ms}&filter[orders][creationDate][$le]={end_ms}'
        req = urllib.request.Request(url, headers={'X-Auth-Token': token, 'User-Agent': 'Mozilla/5.0'})
        try:
            with urllib.request.urlopen(req, context=CTX, timeout=10) as r:
                data = json.loads(r.read().decode('utf-8'))
                orders = data.get('data', [])
                all_orders.extend(orders)
        except Exception as e:
            print(f"Ошибка периода {i}: {e}")
            break

    print(f"Всего заказов получено: {len(all_orders)}")
    customers = {}
    for o in all_orders:
        attrs = o.get('attributes', {})
        cust = attrs.get('customer') or {}
        name = cust.get('name') or 'Не указано'
        phone = cust.get('cellPhone') or 'Нет'
        delivery = attrs.get('deliveryAddress') or {}
        city = delivery.get('town') or 'Не указан'
        total = attrs.get('totalPrice', 0)
        date_str = datetime.fromtimestamp(attrs.get('creationDate', 0) / 1000).strftime('%d.%m.%Y')

        if name not in customers:
            customers[name] = {
                'name': name,
                'phone': phone,
                'city': city,
                'orders_count': 0,
                'total_sum': 0,
                'last_order': date_str
            }
        customers[name]['orders_count'] += 1
        customers[name]['total_sum'] += total

    print(f"Уникальных покупателей: {len(customers)}")
    return customers

if __name__ == '__main__':
    export_customers()
