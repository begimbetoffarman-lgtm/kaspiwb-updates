"""Накладные Kaspi Доставки: скачать из кабинета, склеить и подготовить к печати.

Проверено на живом Kaspi 07.11.2026: GET mc.shop.kaspi.kz/mc/api/merchant/kaspi-delivery/waybill?_m=&orderCode=
отдаёт PDF 100x150 мм (одна накладная одного заказа). Данные покупателей здесь не читаются и не логируются.
Раскладки:
  thermal — одна накладная на этикетку 75x120 мм (масштаб по умолчанию 67%, как печатает продавец),
  a4      — по 4 накладные на лист А4 (2x2).
"""
import io
import json
import os
import sys
import time
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "vendor"))  # pypdf лежит рядом с программой, pip не нужен

from core import kaspi_cabinet as cab  # noqa: E402

MM = 72 / 25.4
OUT_DIR = os.path.join(ROOT, "data", "waybills")
LAYOUTS = {"thermal": "Термопринтер 75×120 мм", "thermal100": "Термопринтер 100×150 мм",
           "a4_1": "A4, 1 накладная", "a4": "A4, 4 накладные (2×2)", "a4_8": "A4, 8 накладных (2×4)",
           "a4_9": "A4, 9 накладных (3×3)"}
GRIDS = {"a4_1": (1, 1), "a4": (2, 2), "a4_4": (2, 2), "a4_8": (2, 4), "a4_9": (3, 3)}  # колонки, строки


def _config():
    with open(os.path.join(ROOT, "config.json"), encoding="utf-8") as f:
        return json.load(f)


def list_orders(days=13):
    """Заказы Kaspi Доставки у продавца (код, собран ли, плановая дата). Без данных покупателей."""
    token = (_config().get("kaspi_api_token") or "").strip()
    if not token:
        raise RuntimeError("Не указан токен Kaspi API.")
    now = int(time.time() * 1000)
    url = ("https://kaspi.kz/shop/api/v2/orders?page[number]=0&page[size]=100"
           "&filter[orders][state]=KASPI_DELIVERY"
           f"&filter[orders][creationDate][$ge]={now - days * 86400000}&filter[orders][creationDate][$le]={now}")
    req = urllib.request.Request(url, headers={"X-Auth-Token": token, "User-Agent": "Mozilla/5.0",
                                               "Accept": "application/vnd.api+json;charset=UTF-8"})
    data = json.load(urllib.request.urlopen(req, timeout=30))
    out = []
    for o in data.get("data", []):
        a = o.get("attributes", {})
        out.append({"code": str(a.get("code")), "status": a.get("status"), "assembled": bool(a.get("assembled")),
                    "planned": a.get("plannedDeliveryDate")})
    return out


def fetch_waybill(code):
    """PDF накладной одного заказа (байты)."""
    cab._ensure(allow_login=False)
    r = cab._session().get(cab.MC + "/mc/api/merchant/kaspi-delivery/waybill",
                           params={"_m": cab.merchant_id(), "orderCode": str(code)}, timeout=60,
                           headers={"Origin": "https://kaspi.kz", "Referer": "https://kaspi.kz/mc/"})
    if r.status_code != 200 or r.content[:4] != b"%PDF":
        raise RuntimeError(f"Kaspi не отдал накладную {code} ({r.status_code}).")
    return r.content


def _label_pdf(w_pt, h_pt, text):
    """Маленький PDF-слой с одной строкой текста (латиница/цифры) — своя наклейка."""
    safe = "".join(ch if 32 <= ord(ch) < 127 and ch not in "()\\" else " " for ch in text)
    stream = f"BT /F1 7 Tf 4 4 Td ({safe}) Tj ET".encode()
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {w_pt:.2f} {h_pt:.2f}] /Contents 4 0 R "
            f"/Resources << /Font << /F1 5 0 R >> >> >>".encode(),
            b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    buf, offs = io.BytesIO(b"%PDF-1.4\n"), []
    for i, o in enumerate(objs, 1):
        offs.append(buf.tell())
        buf.write(f"{i} 0 obj\n".encode() + o + b"\nendobj\n")
    x = buf.tell()
    buf.write(f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode())
    for o in offs:
        buf.write(f"{o:010d} 00000 n \n".encode())
    buf.write(f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{x}\n%%EOF".encode())
    return buf.getvalue()


def build(pdfs, layout="thermal", scale=0.67, labels=None):
    """pdfs: список байтов накладных; labels: список строк для своей наклейки (или None).
    Возвращает байты итогового PDF."""
    from pypdf import PdfReader, PdfWriter, Transformation, PageObject
    out = PdfWriter()
    pages = []
    for i, b in enumerate(pdfs):
        for p in PdfReader(io.BytesIO(b)).pages:
            pages.append((p, (labels or [None] * len(pdfs))[i]))

    def place(dst, src, x, y, cw, ch, k):
        w, h = float(src.mediabox.width), float(src.mediabox.height)
        src.add_transformation(Transformation().scale(k).translate(x + (cw - w * k) / 2, y + (ch - h * k) / 2))
        dst.merge_page(src)

    if layout in GRIDS:
        cols, rows = GRIDS[layout]
        W, H = 210 * MM, 297 * MM
        cw, ch = W / cols, H / rows
        per = cols * rows
        for n in range(0, len(pages), per):
            sheet = PageObject.create_blank_page(width=W, height=H)
            for j, (p, _) in enumerate(pages[n:n + per]):
                col, row = j % cols, j // cols
                k = min(cw / float(p.mediabox.width), ch / float(p.mediabox.height))
                place(sheet, p, col * cw, H - (row + 1) * ch, cw, ch, k)
            out.add_page(sheet)
    else:
        if layout in ("thermal100", "thermal"):  # без масштаба: оригинал 100x150, масштаб задаёт печать (Adobe)
            W, H, scale = 100 * MM, 150 * MM, 1.0
        else:
            W, H = 75 * MM, 120 * MM
        for p, lab in pages:
            sheet = PageObject.create_blank_page(width=W, height=H)
            place(sheet, p, 0, 0, W, H, scale)
            if lab:
                sheet.merge_page(PdfReader(io.BytesIO(_label_pdf(W, H, lab))).pages[0])
            out.add_page(sheet)
    buf = io.BytesIO()
    out.write(buf)
    return buf.getvalue()


def make(codes, layout="thermal", scale=0.67, labels=None):
    """Скачивает накладные заказов и сохраняет один PDF в data/waybills. Возвращает путь и число страниц."""
    if layout not in LAYOUTS:
        raise ValueError("layout: thermal или a4")
    pdfs = [fetch_waybill(c) for c in codes]
    data = build(pdfs, layout, scale, labels)
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, time.strftime("waybills-%Y%m%d-%H%M%S") + f"-{layout}.pdf")
    with open(path, "wb") as f:
        f.write(data)
    return {"path": path, "orders": len(codes), "layout": layout}
