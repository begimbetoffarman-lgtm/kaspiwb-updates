"""Самодиагностика: проверяет, что ключевые функции работают (только чтение, ничего не меняет в Kaspi и WB).
Если Kaspi или WB поменяли сайт, здесь появится «функция X не работает» и подсказка, что делать."""
import json
import os
import shutil
import time
import urllib.request

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILE = os.path.join(BASE, "data", "selfcheck.json")


def _cfg():
    return json.load(open(os.path.join(BASE, "config.json"), encoding="utf-8"))


def _t_token():
    tok = (_cfg().get("kaspi_api_token") or "").strip()
    if not tok:
        raise RuntimeError("не указан токен")
    now = int(time.time() * 1000)
    u = (f"https://kaspi.kz/shop/api/v2/orders?page[number]=0&page[size]=1&filter[orders][state]=NEW"
         f"&filter[orders][creationDate][$ge]={now - 86400000}&filter[orders][creationDate][$le]={now}")
    urllib.request.urlopen(urllib.request.Request(u, headers={"X-Auth-Token": tok, "User-Agent": "Mozilla/5.0",
                           "Accept": "application/vnd.api+json;charset=UTF-8"}), timeout=25).read()
    return "токен принят"


def _t_cabinet():
    from core import kaspi_cabinet as k
    if not k.merchant_id():
        raise RuntimeError("не указан Merchant ID")
    if not k.is_logged_in():
        raise RuntimeError("вход в кабинет не выполнен")
    return "кабинет подключён"


def _t_points():
    from core import setup_wizard
    from core import kaspi_cabinet as k
    k._ensure(allow_login=False)
    resp = k._session().post(k.MC + "/mc/facade/graphql", params={"opName": "getKDPoints"}, timeout=30,
                             json={"operationName": "getKDPoints", "query": setup_wizard._Q,
                                   "variables": {"merchantUid": k.merchant_id()}},
                             headers=dict(k._HDR, **{"Content-Type": "application/json"}))
    pts = (((resp.json().get("data") or {}).get("merchant") or {}).get("points")) or []
    if not pts:
        raise RuntimeError("Kaspi не отдал склады")
    return f"складов: {len(pts)}"


def _t_days():
    from core import kaspi_cabinet as k
    return f"выходные читаются ({len(k.list_special_days())} записей)"


def _t_orders_waybill():
    from core import orders_screen, kaspi_cabinet as k
    k._ensure(allow_login=False)
    orders = orders_screen.active_orders()
    if not orders:
        return "активных заказов нет, накладную проверить нечем"
    code = orders[0]["code"]
    r = k._session().get(k.MC + f"/mc/api/order/{code}/actions", params={"_m": k.merchant_id()}, headers=k._HDR, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"данные заказа не читаются ({r.status_code})")
    return f"заказов: {len(orders)}, данные заказа читаются"


def _t_wb():
    from core import wb_tracker
    ids = [i["wb_id"] for i in wb_tracker.tracked()[:1]] or [175163786]
    d = wb_tracker.fetch_wb(ids)
    w = d.get(ids[0])
    if not w or not w.get("price"):
        raise RuntimeError("WB не вернул цену (возможно, товара нет в наличии или WB поменял ответ)")
    return f"цена WB читается ({w['price']} ₸)"


def _t_wbgeo():
    from core import setup_wizard
    d = setup_wizard.wb_dest_by_coords(50.283, 57.167)
    if not d:
        raise RuntimeError("сервис регионов WB не ответил")
    return f"регион определяется ({d})"


def _t_mail():
    from core import mail_code
    if not mail_code.configured():
        return "почта не настроена (необязательно)"
    r = mail_code.test()
    return f"почта подключена, писем Kaspi за 7 дней: {r['kaspi_mails_7d']}"


def _t_license():
    from core import license
    st = license.init_or_load_license()
    if not st.get("is_active"):
        raise RuntimeError(st.get("status_label", "лицензия не активна"))
    return st.get("status_label", "")


def _t_browser():
    from core import wb_browser
    if wb_browser.find_browser():
        return "браузер найден"
    raise RuntimeError("не найден Edge или Chrome")


def _t_disk():
    free = shutil.disk_usage(BASE).free / 1e9
    os.makedirs(os.path.dirname(FILE), exist_ok=True)
    if free < 1:
        raise RuntimeError(f"мало места на диске: {free:.1f} ГБ")
    return f"свободно {free:.0f} ГБ"


CHECKS = [
    ("license", "Лицензия", _t_license, "Введите ключ в окне активации."),
    ("browser", "Браузер Edge/Chrome", _t_browser, "Установите Microsoft Edge или Google Chrome (нужен для цен WB)."),
    ("disk", "Место на диске", _t_disk, "Освободите место на диске."),
    ("token", "Токен Kaspi API", _t_token, "Проверьте токен: кабинет Kaspi → Настройки → Токен API."),
    ("cabinet", "Вход в кабинет Kaspi", _t_cabinet, "Настройки → Подключение к кабинету: введите пароль сотрудника и код из письма."),
    ("points", "Склады и город Kaspi", _t_points, "Проверьте права сотрудника. Если не помогло, Kaspi мог изменить кабинет: нужно обновление программы."),
    ("days", "Выходные дни", _t_days, "Kaspi мог изменить кабинет: нужно обновление программы."),
    ("orders", "Заказы и данные для накладных", _t_orders_waybill, "Kaspi мог изменить кабинет: нужно обновление программы."),
    ("wbgeo", "Регион доставки WB", _t_wbgeo, "Проверьте интернет; если сохраняется, WB изменил сервис: нужно обновление программы."),
    ("wb", "Цены и наличие WB", _t_wb, "WB мог изменить ответ или заблокировать запрос: проверьте браузер, нужно обновление программы."),
    ("mail", "Почта для кода входа", _t_mail, "Проверьте адрес и пароль приложения в Настройках."),
]


def run():
    res = []
    for cid, name, fn, hint in CHECKS:
        t = time.time()
        try:
            detail, ok = fn(), True
        except Exception as e:
            detail, ok = str(e)[:160], False
        res.append({"id": cid, "name": name, "ok": ok, "detail": detail, "hint": "" if ok else hint,
                    "sec": round(time.time() - t, 1)})
    out = {"at": time.strftime("%Y-%m-%d %H:%M:%S"), "ok": all(r["ok"] for r in res),
           "failed": [r["id"] for r in res if not r["ok"]], "results": res}
    try:
        os.makedirs(os.path.dirname(FILE), exist_ok=True)
        json.dump(out, open(FILE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    except Exception:
        pass
    return out


def last():
    try:
        return json.load(open(FILE, encoding="utf-8"))
    except Exception:
        return None
