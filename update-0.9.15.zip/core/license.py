"""Лицензия: подписанные ключи (Ed25519), проверка у клиента без сервера.
Ключ выписывает только владелец закрытого ключа (D:\\kaspi-arbitrage-license-private\\make_license.py); в программе лежит
только открытая часть — она умеет проверять подпись, но не умеет выпускать ключи. Ключ содержит имя, срок и номер ПК
(или "*" — любой компьютер). Пробный период хранится в data/.license.json (подписан HMAC)."""
import base64
import hashlib
import hmac
import json
import math
import os
import time
import uuid

from core import ed25519

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
LICENSE_FILE = os.path.join(DATA_DIR, ".license.json")

PUBLIC_KEY = bytes.fromhex("08df876180b0865a481dcec523747803d6ec94710553b6ea0fdd59f1c884ea49")
_LOCAL_SALT = "KaspiWB-local-v2"        # только для отпечатка ПК и подписи файла пробного периода
TRIAL_DURATION_SECONDS = 7 * 24 * 3600  # 7 дней


def get_machine_id():
    """Стабильный отпечаток этого компьютера (показывается в окне активации)."""
    try:
        raw = f"{uuid.getnode()}:{os.environ.get('USERNAME', os.environ.get('USER', 'kaspi_seller'))}:KaspiArbitragePro2026_SecuredKey_SaltX9"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16].upper()
    except Exception:
        return "KASPI-CLIENT-MACHINE-01"


def _sign_payload(data):
    clean = f"{data.get('machine_id')}:{data.get('first_run')}:{data.get('license_key')}:{data.get('status')}"
    return hmac.new(_LOCAL_SALT.encode(), clean.encode(), hashlib.sha256).hexdigest()


def _unb64(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def verify_key(key_str, machine_id=None):
    """(верно, сообщение, данные ключа). Проверяет подпись, номер ПК и срок."""
    key = (key_str or "").strip()
    if not key:
        return False, "Ключ не введён", None
    try:
        tag, raw, sig = key.split(".")
        if tag != "KWB1":
            raise ValueError
        raw_b, sig_b = _unb64(raw), _unb64(sig)
        if not ed25519.verify(PUBLIC_KEY, raw_b, sig_b):
            return False, "Неверный ключ активации", None
        info = json.loads(raw_b.decode("utf-8"))
    except Exception:
        return False, "Неверный ключ активации", None
    try:      # список отозванных ключей приходит с подписанным файлом обновления
        blocked = json.load(open(os.path.join(DATA_DIR, ".blocked.json")))
        if hashlib.sha256(key.encode()).hexdigest()[:16] in blocked:
            return False, "Ключ отозван владельцем программы", info
    except Exception:
        pass
    mid = machine_id or get_machine_id()
    if info.get("m") not in ("*", mid):
        return False, "Ключ выписан для другого компьютера", None
    if info.get("e") and time.time() > info["e"]:
        return False, "Срок лицензии истёк", info
    return True, f"PRO лицензия: {info.get('n', '')}", info


def _pro_status(info, key, machine_id):
    if info.get("e"):
        days = max(1, math.ceil((info["e"] - time.time()) / 86400))
        label = f"PRO до {time.strftime('%d.%m.%Y', time.localtime(info['e']))} ({days} дн.)"
    else:
        days, label = 9999, "PRO Лицензия (Бессрочная)"
    return {"is_active": True, "status": "PRO", "status_label": label, "days_left": days, "license_key": key,
            "machine_id": machine_id}


def init_or_load_license():
    os.makedirs(DATA_DIR, exist_ok=True)
    machine_id = get_machine_id()
    now = int(time.time())
    data = None
    if os.path.exists(LICENSE_FILE):
        try:
            with open(LICENSE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("signature") != _sign_payload(data):
                data = None
        except Exception:
            data = None
    if data:
        if data.get("status") == "PRO":
            ok, msg, info = verify_key(data.get("license_key"), machine_id)
            if ok:
                return _pro_status(info, data["license_key"], machine_id)
            return {"is_active": False, "status": "EXPIRED", "status_label": msg, "days_left": 0,
                    "license_key": "", "machine_id": machine_id}
        elapsed = now - data.get("first_run", now)
        if elapsed < TRIAL_DURATION_SECONDS:
            return {"is_active": True, "status": "TRIAL",
                    "status_label": f"Тест-драйв: {max(1, math.ceil((TRIAL_DURATION_SECONDS - elapsed) / 86400))} дн.",
                    "days_left": max(1, math.ceil((TRIAL_DURATION_SECONDS - elapsed) / 86400)),
                    "hours_left": max(1, math.ceil((TRIAL_DURATION_SECONDS - elapsed) / 3600)),
                    "license_key": "", "machine_id": machine_id}
        return {"is_active": False, "status": "EXPIRED", "status_label": "Тест-драйв завершён", "days_left": 0,
                "license_key": "", "machine_id": machine_id}
    fresh = {"machine_id": machine_id, "first_run": now, "license_key": "", "status": "TRIAL",
             "created_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    fresh["signature"] = _sign_payload(fresh)
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(fresh, f, ensure_ascii=False, indent=2)
    return {"is_active": True, "status": "TRIAL", "status_label": "Тест-драйв: 7 дн.", "days_left": 7, "hours_left": 168,
            "license_key": "", "machine_id": machine_id}


def activate_license(key_str):
    machine_id = get_machine_id()
    ok, msg, info = verify_key(key_str, machine_id)
    if not ok:
        return {"success": False, "error": msg}
    data = {"machine_id": machine_id, "first_run": int(time.time()), "license_key": key_str.strip(), "status": "PRO",
            "activated_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    data["signature"] = _sign_payload(data)
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    st = _pro_status(info, key_str.strip(), machine_id)
    try:
        from core import telemetry
        telemetry.report("activation")
    except Exception:
        pass
    return {"success": True, "message": msg, "status": "PRO", "status_label": st["status_label"], "days_left": st["days_left"]}


def generate_key_for_client(*a, **k):
    raise RuntimeError("Ключи выписываются только владельцем: D:\\kaspi-arbitrage-license-private\\make_license.py")


if __name__ == "__main__":
    print(json.dumps(init_or_load_license(), ensure_ascii=False, indent=2))
