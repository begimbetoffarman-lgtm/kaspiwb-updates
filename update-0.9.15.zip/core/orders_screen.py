"""Экран заказов: что собрать и когда, срок предзаказа. Контакт покупателя (имя, телефон) показывается только
на экране заказа для доставки — не пишется в логи и не выгружается списками."""
import json
import os
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DONE = {"COMPLETED", "CANCELLED", "CANCELLING", "RETURNED", "KASPI_DELIVERY_RETURN_REQUESTED"}
STATUS_RU = {"APPROVED_BY_BANK": "Ждёт принятия", "ACCEPTED_BY_MERCHANT": "Принят", "ASSEMBLE": "Собирается",
             "DELIVERY": "На доставке"}


def _get(url):
    with open(os.path.join(ROOT, "config.json"), encoding="utf-8") as f:
        token = (json.load(f).get("kaspi_api_token") or "").strip()
    req = urllib.request.Request(url, headers={"X-Auth-Token": token, "User-Agent": "Mozilla/5.0",
                                               "Accept": "application/vnd.api+json;charset=UTF-8"})
    return json.load(urllib.request.urlopen(req, timeout=30))


def _day(ms):
    try:
        return time.strftime("%d.%m %H:%M", time.localtime(int(ms) / 1000))
    except Exception:
        return None


def _entries(order_id):
    try:
        d = _get(f"https://kaspi.kz/shop/api/v2/orders/{order_id}/entries?include=product")
        out = []
        for e in d.get("data", []):
            a = e.get("attributes", {})
            off = a.get("offer") or {}
            pc = (((e.get("relationships") or {}).get("product") or {}).get("data") or {}).get("id")
            if pc:
                try:
                    import base64
                    pc = base64.b64decode(pc + "=" * (-len(pc) % 4)).decode()
                except Exception:
                    pass
            out.append({"sku": off.get("code"), "name": off.get("name"), "qty": a.get("quantity"), "pcode": pc})
        return out
    except Exception:
        return []


def _images():
    """sku -> картинка: из карточек WB (drafts) и из товаров магазина."""
    out = {}
    try:
        l = json.load(open(os.path.join(ROOT, "data", "my_store_live_products.json"), encoding="utf-8"))
        for x in (l if isinstance(l, list) else l.values()):
            if x.get("sku") and x.get("img"):
                out[str(x["sku"])] = x["img"]
    except Exception:
        pass
    try:
        dr = json.load(open(os.path.join(ROOT, "data", "kaspi_card_drafts.json"), encoding="utf-8"))
        for x in (dr if isinstance(dr, list) else dr.get("drafts", [])):
            if x.get("sku") and x.get("images"):
                out[str(x["sku"])] = x["images"][0]
    except Exception:
        pass
    return out


def _kaspi_photos(codes):
    """Фото карточек Kaspi по кодам (через кабинет). Ошибка — просто без фото."""
    codes = sorted({str(c) for c in codes if c})
    if not codes:
        return {}
    try:
        import sys
        sys.path.insert(0, ROOT)
        from core import kaspi_cabinet as kc
        kc._ensure(allow_login=False)
        r = kc._session().get("https://mc.shop.kaspi.kz/content/item/product/snippet/list",
                              params={"productCodes": ",".join(codes)}, timeout=20,
                              headers={"Origin": "https://kaspi.kz", "Referer": "https://kaspi.kz/mc/"})
        d = r.json() if r.status_code == 200 else {}
        return {c: "https://resources.cdn-kaspi.kz/img/m/p/" + v["s3Images"][0] + "?format=gallery-small"
                for c, v in d.items() if isinstance(v, dict) and v.get("s3Images")}
    except Exception:
        return {}


def active_orders(days=13):
    now = int(time.time() * 1000)
    orders = []
    for state in ("NEW", "KASPI_DELIVERY", "DELIVERY", "PICKUP"):
        try:
            d = _get("https://kaspi.kz/shop/api/v2/orders?page[number]=0&page[size]=100"
                     f"&filter[orders][state]={state}&filter[orders][creationDate][$ge]={now - days * 86400000}"
                     f"&filter[orders][creationDate][$le]={now}")
        except Exception:
            continue
        orders += d.get("data", [])
    orders = [o for o in orders if o["attributes"].get("status") not in DONE]
    with ThreadPoolExecutor(6) as ex:
        ents = list(ex.map(lambda o: _entries(o["id"]), orders))
    out = []
    imgs = _images()
    ph = _kaspi_photos(i.get("pcode") for items in ents for i in items)
    for o, items in zip(orders, ents):
        for i in items:
            i["img"] = imgs.get(str(i.get("sku"))) or ph.get(str(i.get("pcode")))
        a = o["attributes"]
        kd = a.get("kaspiDelivery") or {}
        cust = a.get("customer") or {}
        addr = (a.get("deliveryAddress") or {})
        out.append({
            "code": str(a.get("code")), "state": a.get("state"), "status": STATUS_RU.get(a.get("status"), a.get("status")),
            "assembled": bool(a.get("assembled")), "preorder": bool(a.get("preOrder")),
            "transmitted": bool(kd.get("courierTransmissionDate")),
            "created": _day(a.get("creationDate")), "handover": _day(kd.get("courierTransmissionPlanningDate")),
            "handover_ms": kd.get("courierTransmissionPlanningDate") or 0,
            "total": a.get("totalPrice"), "city": addr.get("town") or addr.get("city"), "items": items,
            "contact": {"name": " ".join(filter(None, [cust.get("firstName"), cust.get("lastName")])),
                        "phone": cust.get("cellPhone")} if a.get("state") in ("DELIVERY", "PICKUP", "NEW") else None,
        })
    out.sort(key=lambda x: (x["assembled"], x["handover_ms"] or 9e15))
    return out
