"""Накопительная база найденных товаров.

Каждый поиск (Радар WB, 1688, Ozon) дописывается в общую копилку data/found.json.
Ничего не затирается: повторный поиск того же товара обновляет дату и счётчик находок.

Файл защищён блокировкой и пишется через временный файл, чтобы база не побьётся,
если программа закроется в момент сохранения.
"""
import json
import os
import re
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FOUND_FILE = os.path.join(ROOT, 'data', 'found.json')
_LOCK = threading.Lock()
MAX_ITEMS = 20000          # предохранитель: база не растёт бесконечно
_SOURCES = ('wb', '1688', 'ozon')


def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def _clean(value, limit):
    """Только строка, без управляющих символов: в базу не попадёт мусор из чужой страницы."""
    text = str(value or '').replace('\n', ' ').replace('\r', ' ').strip()
    text = re.sub(r'[\x00-\x1f\x7f]', '', text)
    return text[:limit]


def _num(value, limit):
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    if result != result or result in (float('inf'), float('-inf')):    # NaN / inf
        return None
    if abs(result) > limit:
        return None
    return round(result, 2)


def key_for(source, item):
    """Устойчивый ключ товара: сначала площадка + id, иначе ссылка, иначе название."""
    source = _clean(source, 20) or 'wb'
    uid = item.get('id') or item.get('item_id') or item.get('product_id')
    uid = _clean(uid, 40)
    if uid:
        return source + ':' + uid
    url = _clean(item.get('url') or item.get('wb_url') or item.get('link'), 300)
    if url:
        return source + ':url:' + url
    return source + ':name:' + _clean(item.get('name') or item.get('title'), 120).lower()


def entry_from(source, item, query='', extra=None):
    """Привести товар любой площадки к одному виду копилки."""
    if not isinstance(item, dict):
        return None
    name = _clean(item.get('name') or item.get('title') or item.get('kaspi_name'), 200)
    url = _clean(item.get('url') or item.get('wb_url') or item.get('link'), 400)
    if not name and not url:
        return None
    entry = {
        'key': key_for(source, item),
        'source': _clean(source, 20) or 'wb',
        'id': _clean(item.get('id') or item.get('item_id') or item.get('product_id'), 40),
        'name': name,
        'url': url,
        'image': _clean(item.get('image') or item.get('img_main') or item.get('img_url'), 500),
        'price': _num(item.get('price') or item.get('price_kzt') or item.get('kaspi_price'), 1e9),
        'currency': _clean(item.get('currency'), 8),
        'query': _clean(query, 200),
        'found_at': _now(),
        'times': 1,
    }
    for field in ('feedbacks', 'rating', 'brand'):
        value = _num(item.get(field), 1e9)
        if value is not None:
            entry[field] = value
    if isinstance(extra, dict):
        entry.update({k: v for k, v in extra.items() if k not in entry})
    return entry


def _read():
    if not os.path.exists(FOUND_FILE):
        return []
    try:
        with open(FOUND_FILE, encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, ValueError):
        return []
    if isinstance(data, dict):
        data = data.get('items')
    if not isinstance(data, list):
        return []
    return [it for it in data if isinstance(it, dict) and it.get('key')]


def _write(items):
    os.makedirs(os.path.dirname(FOUND_FILE), exist_ok=True)
    tmp = FOUND_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(items, f, ensure_ascii=False, indent=1)
    os.replace(tmp, FOUND_FILE)


def add_many(source, items, query=''):
    """Дописать находки. Возвращает (сколько новых, сколько обновлено, всего в базе)."""
    if not isinstance(items, list):
        return 0, 0, len(_read())
    fresh = {}
    for raw in items:
        entry = entry_from(source, raw, query)
        if entry is None:
            continue
        key = entry['key']
        if key in fresh:
            fresh[key]['times'] += 1
            continue
        fresh[key] = entry
    if not fresh:
        return 0, 0, len(_read())
    with _LOCK:
        base = _read()
        index = {it['key']: pos for pos, it in enumerate(base)}
        added = updated = 0
        for key, entry in fresh.items():
            pos = index.get(key)
            if pos is None:
                base.insert(0, entry)
                index[key] = 0
                added += 1
            else:
                old = base[pos]
                old['times'] = int(old.get('times') or 1) + 1
                old['found_at'] = entry['found_at']
                if entry.get('query'):
                    old['query'] = entry['query']
                for field in ('price', 'image', 'url', 'currency', 'name'):
                    if entry.get(field):
                        old[field] = entry[field]
                for field in ('feedbacks', 'rating', 'brand'):
                    if entry.get(field) is not None:
                        old[field] = entry[field]
                updated += 1
        if len(base) > MAX_ITEMS:
            base = base[:MAX_ITEMS]
        _write(base)
        total = len(base)
    return added, updated, total


def listing(source='', query='', limit=100, offset=0):
    """Постраничный список для экрана «Найденное»."""
    source = _clean(source, 20).lower()
    needle = _clean(query, 120).lower()
    items = _read()
    if source and source in _SOURCES:
        items = [it for it in items if it.get('source') == source]
    if needle:
        items = [it for it in items
                 if needle in str(it.get('name') or '').lower() or needle in str(it.get('query') or '').lower()]
    try:
        limit = max(1, min(500, int(limit)))
    except (TypeError, ValueError):
        limit = 100
    try:
        offset = max(0, int(offset))
    except (TypeError, ValueError):
        offset = 0
    counts = {}
    for it in _read():
        counts[it.get('source')] = counts.get(it.get('source'), 0) + 1
    counts['all'] = len(_read())
    return {'items': items[offset:offset + limit], 'total': len(items), 'counts': counts,
            'offset': offset, 'limit': limit}


def export_rows(source='', query=''):
    """Строки для CSV: без картинок и служебных полей."""
    data = listing(source, query, limit=500, offset=0)
    rows = []
    while data['items']:
        rows.extend(data['items'])
        data = listing(source, query, limit=500, offset=len(rows))
        if len(rows) >= data['total']:
            break
    return rows


def clear(source=''):
    """Очистить копилку целиком или только по одной площадке."""
    source = _clean(source, 20).lower()
    with _LOCK:
        if source and source in _SOURCES:
            base = [it for it in _read() if it.get('source') != source]
        else:
            base = []
        _write(base)
        return len(base)


def register(app):
    from flask import jsonify, request, Response

    def api_list():
        data = listing(request.args.get('source', ''), request.args.get('query', ''),
                       request.args.get('limit', 100), request.args.get('offset', 0))
        data['success'] = True
        return jsonify(data)

    def api_export():
        import csv
        import io
        rows = export_rows(request.args.get('source', ''), request.args.get('query', ''))
        buf = io.StringIO()
        writer = csv.writer(buf, delimiter=';')
        writer.writerow(['Площадка', 'Название', 'Ссылка', 'Цена', 'Валюта', 'Отзывы',
                         'Рейтинг', 'Бренд', 'Запрос', 'Найден', 'Раз'])
        for it in rows:
            writer.writerow([it.get('source', ''), it.get('name', ''), it.get('url', ''),
                             it.get('price', ''), it.get('currency', ''), it.get('feedbacks', ''),
                             it.get('rating', ''), it.get('brand', ''), it.get('query', ''),
                             it.get('found_at', ''), it.get('times', 1)])
        body = '﻿' + buf.getvalue()          # BOM: Excel откроет кириллицу без настройки
        return Response(body, mimetype='text/csv; charset=utf-8', headers={
            'Content-Disposition': 'attachment; filename=found.csv'})

    def api_clear():
        payload = request.get_json(silent=True) or {}
        return jsonify({'success': True, 'left': clear(payload.get('source', ''))})

    app.add_url_rule('/api/found', 'found_list', api_list, methods=['GET'])
    app.add_url_rule('/api/found/export', 'found_export', api_export, methods=['GET'])
    app.add_url_rule('/api/found/clear', 'found_clear', api_clear, methods=['POST'])
