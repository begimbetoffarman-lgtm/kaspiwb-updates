"""Отчёт владельцу программы об активации и ежедневном использовании: имя из ключа, номер ПК, версия, дата, хеш Merchant ID.
Адрес отчётов задаёт владелец (core/endpoints.py REPORT_URL, например веб-приложение Google Apps Script → таблица).
Никаких данных магазина, заказов, покупателей, паролей и токенов не отправляется; номер магазина уходит только в виде
хеша sha256 (по нему сервер считает «одна проба на магазин»). Об этом сказано в инструкции и оферте.
Пока REPORT_URL пуст или сервер не отвечает, программа работает как обычно: ничего не блокируется."""
import json
import os
import threading
import time
import urllib.request

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _url():
    try:
        c = json.load(open(os.path.join(BASE, "config.json"), encoding="utf-8"))
    except Exception:
        c = {}
    try:
        from core import endpoints
        d = endpoints.REPORT_URL
    except Exception:
        d = ""
    return (c.get("report_url") or d or "").strip()


def _post(url, payload, timeout=15):
    """POST JSON. Возвращает разобранный JSON-ответ или None."""
    body = json.dumps(payload).encode()
    raw = urllib.request.urlopen(urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}),
                                 timeout=timeout).read()
    try:
        return json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return None


def report(event):
    """Отправка в фоне; любая ошибка молча игнорируется (программа от неё не зависит)."""
    url = _url()
    if not url:
        return

    def go():
        try:
            from core import license as lic, updater
            st = lic.init_or_load_license()
            name = ""
            try:
                d = json.load(open(os.path.join(BASE, "data", ".license.json"), encoding="utf-8"))
                k = d.get("license_key") or ""
                if k.startswith("KWB1."):
                    name = json.loads(lic._unb64(k.split(".")[1]).decode("utf-8")).get("n", "")
            except Exception:
                pass
            _post(url, {"event": event, "name": name, "machine": st.get("machine_id"), "status": st.get("status"),
                        "version": updater.current_version(), "merchant_hash": lic.merchant_hash(),
                        "failed": ((__import__("core.selfcheck", fromlist=["x"]).last() or {}).get("failed") or []),
                        "ts": time.strftime("%Y-%m-%d %H:%M:%S")})
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()


def trial_check(wait=False):
    """Спрашивает у сервера, когда этот магазин (по хешу Merchant ID) впервые начал пробный период; ответ запоминается.
    Нет адреса, нет Merchant ID, нет ответа или ответ странный: ничего не меняется (никаких ложных блокировок)."""
    url = _url()
    if not url:
        return None

    def go():
        try:
            from core import license as lic
            mh = lic.merchant_hash()
            if not mh:
                return None
            r = _post(url, {"event": "trial_check", "merchant_hash": mh, "machine": lic.get_machine_id()})
            if isinstance(r, dict) and r.get("ok") and r.get("first_seen"):
                lic.save_server_trial(mh, int(r["first_seen"]))
                return True
        except Exception:
            pass
        return None
    if wait:
        return go()
    threading.Thread(target=go, daemon=True).start()
    return None
