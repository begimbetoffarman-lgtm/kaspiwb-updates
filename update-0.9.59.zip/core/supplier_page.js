// Reads only the current marketplace page. Never submits orders or changes offers.
async function readSupplierPage(source, mode) {
  if(source==='1688' && location.hostname==='s.1688.com') {
    try { const r=await fetch(location.href,{credentials:'include'}); const t=await r.text();
      if(/FAIL_SYS_USER_VALIDATE|punish\?|action=captcha|_____tmd_____|login\.taobao/i.test(t) || t.length<4000)
        return {items:[],blocked:true,reason:/login\.taobao/i.test(t)?'login':'captcha'};
    } catch {}
  }
  const num = value => {
    if (value === null || value === undefined || value === '') return null;
    const n = Number(String(value).replace(/[\s\u2009\u202f₸¥￥]/g, '').replace(',', '.'));
    return Number.isFinite(n) && n >= 0 ? n : null;
  };
  const image = value => {
    const s = typeof value === 'string' ? value : value?.src || value?.imageUrl || '';
    try { const u = new URL(s, location.href); return /^https?:$/.test(u.protocol) && s ? u.href : ''; } catch { return ''; }
  };
  const canonical = value => {
    try {
      const u = new URL(value, location.href);
      if (source === '1688' && u.hostname === 'detail.1688.com' && /^\/offer\/\d+\.html$/.test(u.pathname)) return 'https://detail.1688.com'+u.pathname;
      if (source === 'ozon' && /^(www\.)?ozon\.(kz|ru)$/.test(u.hostname) && /^\/product\/[^/]+\/?$/.test(u.pathname)) return 'https://ozon.kz'+u.pathname;
    } catch {}
    return '';
  };
  if(mode==='categories') {
    const safe=value=>{try{const u=new URL(value,location.href);if(source==='1688'&&u.searchParams.get('keywords')&&((u.hostname==='air.1688.com'&&u.pathname==='/kapp/1688-global/sales/search')||(u.hostname==='s.1688.com'&&u.pathname==='/selloffer/offer_search.htm'&&u.searchParams.get('charset')==='utf8')))return u.href;if(source==='ozon'&&u.hostname==='ozon.kz'&&/^\/category\/[a-z0-9-]+-\d+\/$/.test(u.pathname))return u.origin+u.pathname;}catch{}return '';};
    const node=a=>({name:a.textContent.trim().slice(0,120),url:safe(a.href)});
    if(source==='1688') {
      const roots=[...document.querySelectorAll('[class*="modal_category_link--"]')].map(node).filter(x=>x.url);
      const sections=[...document.querySelectorAll('[class*="modal_subcategory_section--"]')];
      if(roots.length&&sections.length===roots.length)return {items:roots.map((r,i)=>({...r,children:[...(sections[i]?.querySelectorAll('a[class*="modal_subcategory_link--"]')||[])].map(node).filter(x=>x.url&&x.name&&x.name!==r.name)}))};
      const domestic=[...document.querySelectorAll('[class*="category_wrap--"] > li')];
      if(domestic.length){return {items:domestic.map(li=>{const root=node(li.querySelector(':scope > a'));return {...root,children:[...li.querySelectorAll(':scope > ul > li')].map(group=>{const parent=node(group.querySelector(':scope > a[class*="cTitle--"]'));return {...parent,children:[...group.querySelectorAll(':scope > [class*="cBox--"] > a')].map(node).filter(x=>x.url&&x.name)};}).filter(x=>x.url&&x.name)};}).filter(x=>x.url&&x.name)};}
      return {items:[]};
    }
    if(location.pathname==='/') {
      const b=[...document.querySelectorAll('button')].find(e=>e.textContent.trim()==='Каталог');
      if(b&&[...document.querySelectorAll('a[href*="/category/"]')].filter(e=>e.parentElement?.tagName==='LI'&&!e.parentElement.className).length<20){b.click();await new Promise(resolve=>setTimeout(resolve,400));}
      return {items:[...document.querySelectorAll('a[href*="/category/"]')].filter(e=>e.parentElement?.tagName==='LI'&&!e.parentElement.className).map(node).filter(x=>x.url&&x.name).filter((x,i,a)=>a.findIndex(y=>y.url===x.url)===i).slice(0,80)};
    }
    const h=document.querySelector('h1');
    const list=h?.parentElement?.parentElement?.parentElement?.parentElement?.parentElement?.querySelectorAll('a[href*="/category/"]')||[];
    return {items:[...list].map(node).filter(x=>x.url&&x.name&&new URL(x.url).pathname!==location.pathname).filter((x,i,a)=>a.findIndex(y=>y.url===x.url)===i).slice(0,100)};
  }
  if (mode === 'search') {
    if (source === '1688' && location.pathname.includes('pc-image-search')) {
      const search = location.search || '';
      if (!search.includes('imageSearch') && !search.includes('imageId') && !search.includes('imageAddress')) {
        return null;
      }
    }
    const LIM = source==='1688' ? 90 : 20;
    // 1688 подгружает карточки при прокрутке (около 55 на страницу): листаем вниз, пока число не перестанет расти
    if(source==='1688' && location.hostname==='s.1688.com') {
      const total=new Set([...document.querySelectorAll('a[href*="detail.1688.com/offer/"]')].map(a=>a.href.split('?')[0])).size;
      const st=window.__kwbS=window.__kwbS||{n:0,last:-1,still:0};
      st.still=total===st.last?st.still+1:0; st.last=total;
      if(total<54 && st.n<14 && st.still<3){ st.n++; window.scrollBy(0,1800); return {items:[],scrolling:true}; }
    }
    // доп. данные карточки 1688: продажи, повторные покупки, поставщик, метки
    const rich = box => {
      if(source!=='1688') return {};
      const t=box.innerText||'';
      const sm=t.match(/(\d+(?:\.\d+)?)\s*(万)?\s*\+?\s*件(?!起|装|套)/);
      let sales=sm?Math.round(Number(sm[1])*(sm[2]?10000:1)):null;
      const mm=t.match(/月销\s*(\d+)/); if(sales===null&&mm) sales=Number(mm[1]);
      const rp=t.match(/回头率\s*(\d+)\s*%/), sh=t.match(/运费\s*(\d+(?:\.\d+)?)\s*元/);
      const lines=t.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
      const supplier=[...lines].reverse().find(x=>/公司|工厂|厂|商行|店|工贸|贸易|科技|企业|经营部|五金|制品/.test(x)&&x.length<40)||'';
      return {sales, repeat:rp?Number(rp[1]):null, supplier, free_return:/退货包运费/.test(t), dropship:/代发/.test(t), free_ship:/包邮/.test(t), ship_cny:sh?Number(sh[1]):null, pay_later:/先采后付/.test(t), eta:(t.match(/(当天达|明天达|后天达|次日达|\d天达)/)||[''])[0]};
    };
    // корень карточки находим по структуре, а не по имени класса: самый большой предок, внутри которого только один товар
    const offerId = h => (String(h||'').match(/offer\/(\d{5,20})/)||[])[1]||'';
    const cardRoot = a => {
      const id=offerId(a.href); let best=a.parentElement;
      for(let n=a.parentElement,i=0;n&&n!==document.body&&i<8;n=n.parentElement,i++){
        const ids=new Set([...n.querySelectorAll('a[href*="detail.1688.com/offer/"]')].map(x=>offerId(x.href)).filter(Boolean));
        if(ids.size>1||(ids.size===1&&!ids.has(id))) break;
        best=n;
      }
      return best||a;
    };
    const found = new Map();
    if(source==='1688') for(const card of document.querySelectorAll('[data-offerid]')) {
      const id=card.getAttribute('data-offerid'),name=card.querySelector('.cgf-card-title')?.textContent.trim();
      if(!/^\d{5,20}$/.test(id||'')||!name)continue;
      const text=card.innerText||'',m=text.match(/(\d[\d\s.,]*)\s*([¥￥₸])/);
      const currency=m?.[2]==='₸'?'KZT':'CNY';
      const price=m?num(m[1]):null,url='https://detail.1688.com/offer/'+id+'.html';
      found.set(url,{source,url,id,name:name.slice(0,500),price,currency,image:image(card.querySelector('img')?.src),...rich(card.closest('[class*="offerCard"]')||(card.tagName==='A'?cardRoot(card):card))});
      if(found.size>=LIM)break;
    }
    // The current photo results use clickable divs, without product anchors.
    if(source==='1688') for(const card of document.querySelectorAll('[data-tracker="offer"][data-renderkey]')) {
      const id=card.getAttribute('data-renderkey')?.match(/_(\d{5,20})$/)?.[1];
      const title=(card.querySelector('[class*="titleText--"], [class*="offerTitle--"]')?.textContent||'').trim();
      if(!id||!title)continue;
      const url='https://detail.1688.com/offer/'+id+'.html';
      const img=card.querySelector('img[class*="offerCpvImage"]')||card.querySelector('img');
      const priceText=card.querySelector('[class*="priceItem--"]')?.textContent?.match(/[¥￥]\s*(\d+(?:\s*\.\s*\d+)?)/)?.[1]
        || card.querySelector('[class*="priceCardWrap--"]')?.textContent?.match(/[¥￥]\s*(\d+(?:\s*\.\s*\d+)?)/)?.[1];
      found.set(url,{source,url,id,name:title.slice(0,500),price:num(priceText),currency:'CNY',image:image(img?.currentSrc||img?.src),...rich(card.closest('[class*="offerCard"]')||(card.tagName==='A'?cardRoot(card):card))});
      if(found.size>=LIM)break;
    }
    const selector = source === '1688' ? 'a[href*="detail.1688.com/offer/"]' : 'a[href*="/product/"]';
    for (const a of document.querySelectorAll(selector)) {
      if(found.size>=LIM)break;
      const url = canonical(a.href);
      if (!url || found.has(url)) continue;
      let card = a;
      if (source === 'ozon') {
        for (let i=0;i<5 && card.parentElement;i++) {
          if (card.querySelector('img') && card.innerText.includes('₸')) break;
          card=card.parentElement;
        }
      }
      const text = card.innerText || a.innerText || '';
      const img=card.querySelector('img');
      const name = source === '1688'
        ? (text.split('\n')[0] || img?.alt)
        : (Array.from(card.querySelectorAll('a[href*="/product/"]')).filter(x=>!x.querySelector('img')).map(x=>x.innerText.trim()).sort((a,b)=>b.length-a.length)[0] || img?.alt || 'Товар Ozon');
      // A search price is only a preview. Exclude Ozon instalment amounts explicitly.
      const priceText = source === '1688' ? text.match(/[¥￥]\s*(\d+(?:\s*\.\s*\d+)?)/)?.[1]
        : text.split('\n').find(x=>x.includes('₸') && !/[×x]|мес/i.test(x))?.match(/[\d\s\u2009\u202f]+(?=₸)/)?.[0];
      found.set(url,{source,url,id:url.match(source==='1688'?/\/(\d+)\.html/:/-(\d+)\/?$/)?.[1]||'',
        name:String(name||'Товар 1688').slice(0,500),price:num(priceText),currency:source==='1688'?'CNY':'KZT',image:image(img?.currentSrc||img?.src),...rich(card.closest('[class*="offerCard"]')||(card.tagName==='A'?cardRoot(card):card))});
      if(found.size>=LIM) break;
    }
    if(source==='1688' && !found.size && (document.body.innerText||'').length>3000 && !/验证码|滑块|请登录|punish/.test(document.body.innerText)) return {items:[],layout_changed:true};
    return {items:[...found.values()],pages:Number((document.body.innerText.match(/共\s*(\d+)\s*页/)||[])[1])||0};
  }
  const url=canonical(location.href);
  if(!url) return null;
  if(source==='1688') {
    const d=window.context?.result?.data;
    if(!d?.Root?.fields?.dataJson) return null;
    const root=d.Root.fields.dataJson,model=root.skuModel||{};
    const photos=(d.gallery?.fields?.offerImgList||[]).map(image).filter(Boolean);
    const packs=d.productPackInfo?.fields?.pieceWeightScale?.pieceWeightScaleInfo||[];
    const values=(model.skuProps||[]).flatMap(p=>p.value||[]);
    const entries=Object.entries(model.skuInfoMap||{});
    if(entries.length>1000) throw new Error('Слишком много вариантов: требуется отдельная обработка.');
    // «Цвет/размер» варианта: имя свойства из skuProps -> значение (для переноса в характеристики Kaspi)
    const specOf=s=>{const o={};for(const part of String(s).split(/;|&gt;|>/)){const p=(model.skuProps||[]).find(x=>(x.value||[]).some(y=>y.name===part));if(p&&p.prop) o[p.prop]=part;}return o;};
    const variants=entries.map(([key,v])=>{
      const pack=packs.find(p=>String(p.skuId)===String(v.skuId))||{};
      const photo=values.find(p=>String(v.specAttrs||key).split(';').includes(p.name));
      return {id:String(v.skuId||v.specId||key),name:v.specAttrs||key,price:num(v.price),stock:num(v.canBookCount),
        min_quantity:num(root.orderParamModel?.orderParam?.beginNum),price_quantity:num(v.priceAmount),
        image:image(photo?.imageUrl)||photos[0]||'',weight_kg:num(pack.weight)===null?null:num(pack.weight)/1000,
        length_cm:num(pack.length),width_cm:num(pack.width),height_cm:num(pack.height),url,
        spec:specOf(v.specAttrs||key)};
    });
    if(!variants.length) return null;
    // поставщик и оценки: читаем из текста страницы (все поля необязательные)
    const T=document.body.innerText||'',m1=(re,i=1)=>{const x=T.match(re);return x?x[i]:null;},pc=re=>{const v=m1(re);return v===null?null:Number(v);};
    const stars={'一':1,'二':2,'三':3,'四':4,'五':5};
    const star=m1(/([一二三四五])星供应链/);
    const supplier={name:(m1(/\n([^\n]{2,40})\n关注\n客服/)||'').trim(),years:pc(/入驻(\d+)年/),main:(m1(/主营[：:]\s*([^\n]{1,60})/)||'').trim(),
      stars:star?stars[star]:null,quality:pc(/品质达标率\s*\n?\s*([\d.]+)%/),fulfil:pc(/综合履约率\s*\n?\s*([\d.]+)%/),repeat:pc(/店铺回头率\s*\n?\s*([\d.]+)%/),
      rating:pc(/商品评价\s*\n\s*([\d.]+)\s*\n/),reviews:(m1(/商品评价\s*\n\s*[\d.]+\s*\n\s*(\d+\+?)条评价/)||''),
      tags:['实力商家','超级工厂','源头工厂','深度验厂','诚信通','金牌供应商','先采后付','退货包运费','7天无理由','一件代发'].filter(t=>T.includes(t))};
    return {source,url,id:url.match(/\/(\d+)\.html/)[1],name:d.productTitle?.fields?.title||d.gallery?.fields?.subject||'',supplier,
      currency:'CNY',images:photos,variants,
      // таблица «商品属性»: пары название/значение (th + td); запасной вариант — прежний сырой текст
      attrs:Array.from(document.querySelectorAll('.attr-descriptions th')).map(th=>{const td=th.nextElementSibling;return td?[th.innerText.trim(),td.innerText.trim()]:null;}).filter(p=>p&&p[0]&&p[1]).slice(0,60),
      attributes:Array.from(document.querySelectorAll('[class*="offer-attr"], [class*="attribute"]')).map(n=>n.innerText).filter(Boolean).slice(0,40)};
  }
  const controller=new AbortController(), timer=setTimeout(()=>controller.abort(),12000);
  let j;
  try {
    const response=await fetch('/api/composer-api.bx/page/json/v2?url='+encodeURIComponent(location.pathname),{credentials:'include',signal:controller.signal});
    if(!response.ok) return null;
    j=await response.json();
  } finally { clearTimeout(timer); }
  const widgets={};
  for(const [k,v] of Object.entries(j.widgetStates||{})) {
    if(!/^web(ProductHeading|Gallery|Aspects|Price|ShortCharacteristics)/.test(k)) continue;
    try { widgets[k.split('-')[0]]=typeof v==='string'?JSON.parse(v):v; } catch {}
  }
  const heading=widgets.webProductHeading,price=widgets.webPrice||{},gallery=widgets.webGallery||{};
  if(!heading?.title) return null;
  // A currency mismatch must never become a tenge estimate.
  const currency=/₸|KZT/.test(String(price.price||'')+' '+String(price.disclaimerPriceHeader||''))?'KZT':null;
  const photos=(gallery.images||[]).map(image).filter(Boolean),id=String(gallery.sku||url.match(/-(\d+)\/?$/)?.[1]||'');
  const variants=new Map([[id,{id,name:heading.title,price:currency?num(price.price):null,currency,stock:null,
    availability:price.isAvailable===false?'outOfStock':'unknown',image:photos[0]||'',url}]]);
  for(const aspect of widgets.webAspects?.aspects||[]) for(const v of aspect.variants||[]) {
    const variantUrl=canonical(v.link);
    if(!v.sku||!variantUrl) continue;
    const key=String(v.sku),existing=variants.get(key);
    const labels=existing?.labels||[];
    labels.push(aspect.aspectName+': '+(v.data?.searchableText||''));
    variants.set(key,{...(existing||{}),id:key,name:v.data?.title||existing?.name||key,
      price:existing?.price??(currency?num(v.data?.price??v.price):null),currency,stock:null,
      availability:key===id&&price.isAvailable===false?'outOfStock':v.availability||existing?.availability||'unknown',image:existing?.image||image(v.data?.coverImage),url:variantUrl,labels});
  }
  const city=document.querySelector('[data-widget="addressBookBarWeb"] button')?.textContent.trim()||'';
  const deliveryTexts=[...document.querySelectorAll('[data-widget="webAddToCart"]')].map(e=>(e.innerText||'').match(/Доставим\s+[^\n]{1,100}/i)?.[0]).filter(Boolean);
  const deliveryText=[...new Set(deliveryTexts)].join(' / ').slice(0,300);
  return {source,url,id,name:heading.title,currency,images:photos,variants:[...variants.values()],delivery_raw:{city,text:deliveryText},
    attributes:(widgets.webShortCharacteristics?.characteristics||[]).map(c=>({name:(c.title?.textRs||[]).map(t=>t.content||'').join(''),value:(c.values||[]).map(v=>v.text||'').join(', ')}))};
}
