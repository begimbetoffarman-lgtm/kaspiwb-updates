// Выполняет список шагов в браузере ego. Запускается через `ego-browser nodejs`.
// Вход: файл задания (?job=...), результат пишется в файл (?out=...). Только чтение страниц, ничего не покупается и не отправляется.
const fs = await import('node:fs/promises');
const q = new URL(import.meta.url).searchParams;
const jobPath = q.get('job'), outPath = q.get('out');
const job = JSON.parse(await fs.readFile(jobPath, 'utf8'));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const result = { ok: true, values: {} };
let task = null;
try {
  task = await taskSpace(job.space || 'kaspi-wb');
  const pages = await task.pages();
  const page = pages && pages.length ? pages[0] : await task.newPage();
  stepLoop:
  for (const s of job.steps) {
    if (s.t === 'goto') {
      try { await page.goto(s.url, { timeout: s.timeout || 45000, waitUntil: s.waitUntil || 'domcontentloaded' }); }
      catch (e) { if (!s.soft) throw e; }
    } else if (s.t === 'files') {
      await page.setInputFiles(s.selector, s.files);
    } else if (s.t === 'sleep') {
      await sleep(s.ms || 500);
    } else if (s.t === 'eval') {
      const v = await page.evaluate(s.expr);
      if (s.key) result.values[s.key] = v;
    } else if (s.t === 'poll') {
      const deadline = Date.now() + (s.timeout || 45000);
      let blocked = 0, last = null, done = false;
      while (Date.now() < deadline) {
        let r = null;
        try { r = await page.evaluate(s.expr); } catch (e) { r = null; }
        if (r && r.hover) {
          for (const p of r.hover) { try { await page.mouse.move(p.x, p.y); } catch (e) {} await sleep(150); }
          await sleep(s.hover_wait || 500);
          continue;
        }
        if (r && r.blocked) {
          blocked++;
          if (blocked >= (s.blocked_limit || 3)) { result.blocked = true; if (s.key) result.values[s.key] = null; break stepLoop; }
        } else if (r && r.done) {
          if (s.key) result.values[s.key] = r.value;
          done = true; break;
        } else if (r && r.value !== undefined) {
          last = r.value;
        }
        await sleep(s.every || 2000);
      }
      if (!done) {
        result.timeout = true;
        if (s.key) result.values[s.key] = last;
        if (s.required !== false) break stepLoop;
        result.timeout = false;
      }
    }
  }
} catch (e) {
  result.ok = false;
  result.error = String(e && e.message || e).slice(0, 300);
}
try { if (task) await task.finish({ keep: [] }); } catch (e) {}
await fs.writeFile(outPath, JSON.stringify(result), 'utf8');
console.log('[kwb] done');
