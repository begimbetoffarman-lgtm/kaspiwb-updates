"""Ускорение отдачи данных интерфейсу: сжатие (gzip) больших текстовых ответов. Содержимое не меняется."""
import gzip

_TYPES = ('text/', 'application/json', 'application/javascript', 'text/javascript')


def register(app):
    from flask import request

    @app.after_request
    def _compress(resp):
        try:
            if (resp.status_code != 200 or 'Content-Encoding' in resp.headers
                    or 'gzip' not in request.headers.get('Accept-Encoding', '').lower()):
                return resp
            if resp.direct_passthrough or resp.is_streamed:
                # файлы (страница, скрипты) сжимаем, если размер известен и невелик; потоковые ответы (скан по частям) не трогаем
                cl = resp.content_length
                if not cl or cl > 3_000_000:
                    return resp
                resp.direct_passthrough = False
            ctype = resp.headers.get('Content-Type', '')
            if not ctype.startswith(_TYPES):
                return resp
            data = resp.get_data()
            if len(data) < 1024:
                return resp
            packed = gzip.compress(data, compresslevel=5)
            if len(packed) >= len(data):
                return resp
            resp.set_data(packed)
            resp.headers['Content-Encoding'] = 'gzip'
            resp.headers['Content-Length'] = str(len(packed))
            resp.headers.add('Vary', 'Accept-Encoding')
        except Exception:
            pass                                   # сжатие не должно ломать ответ
        return resp
