"""Состояние экрана (вкладка, введённые запросы, фильтры) хранится в папке программы: data/ui_state.json.
Так оно сохраняется для каждого пользователя на его компьютере, в любом браузере. Секретов здесь нет."""
import json
import os
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_FILE = os.path.join(ROOT, 'data', 'ui_state.json')
_LOCK = threading.Lock()
_MAX_BYTES = 20000


def _clean(state):
    """Только простые значения: строки/числа/логические, без вложенных сюрпризов и без больших текстов."""
    out = {}
    if not isinstance(state, dict):
        return out
    for key in ('tab', 'rm'):
        v = state.get(key)
        if isinstance(v, str) and len(v) <= 60:
            out[key] = v
    fk = state.get('fk')
    if isinstance(fk, dict):
        out['fk'] = {k: str(v)[:20] for k, v in fk.items() if k in ('source', 'mode')}
    f = state.get('f')
    if isinstance(f, dict):
        out['f'] = {str(k)[:40]: (v if isinstance(v, bool) else str(v)[:300]) for k, v in list(f.items())[:60]}
    return out


def load():
    try:
        with open(_FILE, encoding='utf-8') as fh:
            return _clean(json.load(fh))
    except (OSError, ValueError):
        return {}


def save(state):
    state = _clean(state)
    if len(json.dumps(state, ensure_ascii=False)) > _MAX_BYTES:
        raise ValueError('Слишком большой объём.')
    os.makedirs(os.path.dirname(_FILE), exist_ok=True)
    with _LOCK:
        with open(_FILE + '.tmp', 'w', encoding='utf-8') as fh:
            json.dump(state, fh, ensure_ascii=False)
        os.replace(_FILE + '.tmp', _FILE)


def register(app):
    from flask import jsonify, request

    def get_state():
        return jsonify(success=True, state=load())

    def post_state():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(success=False, error='Ожидаются данные.'), 400
        try:
            save(data)
        except ValueError as e:
            return jsonify(success=False, error=str(e)), 400
        return jsonify(success=True)

    app.add_url_rule('/api/ui_state', 'ui_state_get', get_state, methods=['GET'])
    app.add_url_rule('/api/ui_state', 'ui_state_post', post_state, methods=['POST'])
