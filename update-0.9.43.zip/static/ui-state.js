// Запоминает, где вы были и что вводили: после закрытия и повторного запуска программы всё возвращается.
// Хранится в папке программы (data/ui_state.json), с копией в браузере; только настройки экрана, без паролей и данных магазина.
(function () {
  'use strict';
  const KEY = 'kwb_ui_v1';
  const IDS = ['scanQuery', 'scanLimit', 'scanMinFeedbacks', 'forksQuery', 'forksMargin', 'forksLiveKaspi',
    'cnQuery', 'cnPreorderDefault', 'cnFilter', 'cnMin', 'cnMax', 'cnSort',
    'ozQuery', 'ozFilter', 'ozMin', 'ozMax', 'ozSort'];
  let state = {};
  try { state = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { state = {}; }
  let timer = null;
  let ready = false;            // пока не загружено сохранённое состояние, ничего не записываем (иначе затрём его пустым)
  function save() {
    if (!ready) return;
    clearTimeout(timer);
    timer = setTimeout(() => {
      try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
      // главное хранилище — файл data/ui_state.json в папке программы
      try { fetch('/api/ui_state', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(state) }).catch(() => {}); } catch (e) {}
    }, 300);
  }
  const $ = id => document.getElementById(id);

  function restore() {
    // поля ввода: только если пользователь их менял раньше
    for (const id of IDS) {
      const el = $(id), v = state.f && state.f[id];
      if (!el || v === undefined) continue;
      if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
    }
    const m = $('forksMargin'), mv = $('forksMarginVal'); if (m && mv) mv.textContent = m.value + '%';
    // кнопки «Источник» и «Сортировка» в «Арбитраже» (без запуска поиска)
    if (window.forksUiState && state.fk) window.forksUiState.set(state.fk);
    // вкладка и режим радара
    if (state.rm) { const b = document.querySelector('.rms-btn[data-radar-mode="' + state.rm + '"]'); if (b && !b.classList.contains('active')) b.click(); }
    if (state.tab) { const t = document.querySelector('.nav-item[data-tab="' + state.tab + '"]'); if (t && !t.classList.contains('active')) t.click(); }
  }

  function bind() {
    document.addEventListener('input', e => {
      const id = e.target && e.target.id; if (!id || IDS.indexOf(id) < 0) return;
      state.f = state.f || {}; state.f[id] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; save();
    });
    document.addEventListener('change', e => {
      const id = e.target && e.target.id; if (!id || IDS.indexOf(id) < 0) return;
      state.f = state.f || {}; state.f[id] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; save();
    });
    document.addEventListener('click', e => {
      const nav = e.target.closest && e.target.closest('.nav-item[data-tab]');
      if (nav) { state.tab = nav.dataset.tab; save(); }
      const rm = e.target.closest && e.target.closest('.rms-btn[data-radar-mode]');
      if (rm) { state.rm = rm.dataset.radarMode; save(); }
      if (e.target.closest && e.target.closest('#forksSource .seg-btn, #forksModeBtns .seg-btn')) {
        setTimeout(() => { if (window.forksUiState) { state.fk = window.forksUiState.get(); save(); } }, 50);
      }
    }, true);
    fetch('/api/ui_state').then(r => r.json()).then(j => {
      if (j && j.success && j.state && Object.keys(j.state).length) state = j.state;
    }).catch(() => {}).then(() => setTimeout(() => { restore(); setTimeout(() => { ready = true; }, 800); }, 300));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();
})();
