// Главная: сводка, ближайшие сроки, прибыль, слежение за WB, причины отказов. Плюс резервная копия в настройках.
(function () {
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const money = n => (Number(n) || 0).toLocaleString('ru-RU') + ' ₸';
  let loadedAt = 0;

  function tile(value, label, warn) { return `<div class="home-tile${warn ? ' warn' : ''}"><b>${value}</b><span>${label}</span></div>`; }

  async function loadHome() {
    if (!$('homeBox')) return;
    if (Date.now() - loadedAt < 20000) return;          // не дёргаем Kaspi при каждом переключении вкладок
    loadedAt = Date.now();
    apiGet('/api/orders/digest').then(r => {
      const d = r.ok ? r.data : null;
      $('homeDigest').innerHTML = d
        ? tile(d.to_collect, 'собрать сейчас', d.to_collect > 0) + tile(d.in_transit, 'в пути к покупателю') +
          tile(d.returns_open, 'возвратов не забрано', d.returns_open > 0) + tile(money(d.returns_open_sum), 'сумма возвратов', d.returns_open_sum > 0)
        : '<div class="help-text">Подключите Kaspi в «Первом запуске», чтобы видеть заказы. ' + esc(r.error || '') + '</div>';
    });
    apiGet('/api/home/deadlines').then(r => {
      const it = r.ok ? r.data.items : [];
      $('homeDeadlines').innerHTML = it.length ? it.map(x => `<div class="home-row ${esc(x.level)}">${x.level === 'late' ? '⚠️ ' : x.level === 'soon' ? '⏰ ' : ''}${esc(x.text)}</div>`).join('')
        : (r.ok ? 'Срочных дел нет.' : esc(r.error));
    });
    apiGet('/api/profit?days=28').then(r => {
      if (!r.ok) { $('homeProfit').textContent = r.error; return; }
      const d = r.data;
      const losers = (d.losers || []).map(p => `${esc(p.sku)} — ${esc((p.name || '').slice(0, 45))}: <b style="color:#B91C1C">${money(p.profit)}</b>`).join('<br>');
      const top = (d.top || []).slice(0, 3).map(p => `${esc(p.sku)} — ${esc((p.name || '').slice(0, 45))}: <b>${money(p.profit)}</b>`).join('<br>');
      $('homeProfit').innerHTML = `<div class="home-grid">${tile(money(d.today.profit), 'чистая за сегодня · заказов ' + d.today.orders)}${tile(money(d.week.profit), 'за 7 дней · заказов ' + d.week.orders)}${tile(money(d.period.profit), 'за 28 дней · выручка ' + money(d.period.revenue))}</div>` +
        (top ? `<div style="margin-top:8px;"><b>Больше всего приносят:</b><br>${top}</div>` : '') +
        (losers ? `<div style="margin-top:8px;"><b>В минусе:</b><br>${losers}</div>` : '') +
        (d.no_cost_orders ? `<div style="margin-top:8px;">Для ${d.no_cost_orders} заказов не указана себестоимость, прибыль по ним не посчитана.</div>` : '') +
        '<div style="margin-top:6px;opacity:.7;">Прибыль: цена продажи минус себестоимость, комиссия Kaspi, доставка и налог. Возвраты считаются отдельно.</div>';
    });
    apiGet('/api/home/tracker').then(r => {
      if (!r.ok) { $('homeTracker').textContent = r.error; return; }
      const d = r.data;
      $('homeTracker').innerHTML = d.tracked
        ? `Слежу за ${d.tracked} товарами WB. Последняя проверка: ${esc(d.last_run || '—')}.` +
          (d.problems.length ? '<br>' + d.problems.map(p => `⚠️ ${esc(p.sku)}: ${esc(p.action)}`).join('<br>') : '<br>Всё в порядке.') +
          (d.log.length ? '<br><span style="opacity:.7;">Последние действия: ' + d.log.map(l => esc(l.msg)).join(' · ') + '</span>' : '')
        : 'Нет товаров, выставленных из WB: слежение начнётся после первой продажи из «Карточки Kaspi».';
    });
    apiGet('/api/home/rejects').then(r => {
      const it = r.ok ? r.data.items : [];
      $('homeRejects').innerHTML = it.length ? it.slice(0, 5).map(x => `${esc(x.example)} — <b>${x.count}</b> раз, исправлено автоматически: ${x.fixed}`).join('<br>') : 'Отказов Kaspi пока не было.';
    });
  }
  window.loadHome = loadHome;

  // ---- резервная копия
  if ($('bkImport')) {
    $('bkImport').addEventListener('change', async e => {
      const f = e.target.files[0]; if (!f) return;
      if (!confirm('Восстановить данные из файла «' + f.name + '»? Текущие файлы будут заменены (старые сохранятся рядом с пометкой .before-restore).')) { e.target.value = ''; return; }
      $('bkStatus').textContent = 'Восстанавливаю…';
      try {
        const r = await fetch('/api/backup/import', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: await f.arrayBuffer() });
        const j = await r.json();
        $('bkStatus').textContent = j.success ? 'Восстановлено файлов: ' + j.restored.length + '. Перезапустите программу.' : (j.error || 'Не удалось восстановить.');
      } catch (err) { $('bkStatus').textContent = 'Ошибка: ' + err.message; }
      e.target.value = '';
    });
  }

  // главная открывается первой
  setTimeout(() => { const a = document.querySelector('.nav-item.active'); if (a && a.dataset.tab === 'tab-home') loadHome(); }, 600);
})();
