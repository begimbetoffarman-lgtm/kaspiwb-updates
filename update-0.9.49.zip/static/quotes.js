// Мотивационные баннеры в верху разделов поиска и калькулятора (чистый CSS, без картинок).
(function () {
  const Q = {
    'tab-radar': { t: 'Лучше усердно трудиться в молодости, чем в старости надеяться на пенсию.', c: 'q-gold' },
    'tab-1688': { t: 'Не сдавайся. Победа достаётся тому, кто не остановился за шаг до результата.', c: 'q-green' },
    'tab-ozon': { t: 'Деньги любят терпеливых: сегодня труд, завтра свобода.', c: 'q-blue' },
    'tab-margin': { t: 'Семь раз посчитай — один раз закажи.', c: 'q-violet' },
  };
  Object.keys(Q).forEach(id => {
    const pane = document.getElementById(id);
    if (!pane || pane.querySelector('.quote-banner')) return;
    const b = document.createElement('div');
    b.className = 'quote-banner ' + Q[id].c; pane.classList.add('pane-dollars');
    b.setAttribute('role', 'note');
    let bills = '';
    for (let i = 0; i < 16; i++) {
      bills += `<i style="left:${(i * 6.4 + (i % 3) * 2).toFixed(1)}%;animation-delay:${(-(i * 1.7) % 11).toFixed(1)}s;animation-duration:${9 + (i % 5) * 2}s;font-size:${16 + (i % 4) * 7}px">$</i>`;
    }
    b.innerHTML = `<div class="qb-bills" aria-hidden="true">${bills}</div><div class="qb-text">${Q[id].t}</div>`;
    pane.insertBefore(b, pane.firstChild);
  });
})();
