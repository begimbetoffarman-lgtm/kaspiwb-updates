/* Сканер ниш: карточка вверху раздела «Арбитраж». Кнопки запуска/остановки, статус, кандидаты, папка Obsidian. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = v => (v == null ? '—' : Math.round(Number(v)).toLocaleString('ru-RU') + ' ₸');
  async function api(path, body) {
    try {
      const r = await fetch(path, body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
      return await r.json();
    } catch (e) { return { success: false, error: String(e) }; }
  }

  function mount() {
    const panel = $('radarForksPanel');
    if (!panel || $('scCard')) return !!$('scCard');
    const box = document.createElement('section');
    box.id = 'scCard';
    box.className = 'sc-card';
    box.innerHTML = `
      <div class="sc-head"><b>🔭 Сканер ниш</b>
        <span class="sc-hint">сам обходит подкатегории WB (дом, красота, авто, электроника, техника, спорт), сверяет с Kaspi и оставляет только надёжные связки</span></div>
      <div class="sc-row">
        <button type="button" class="btn btn-primary btn-sm" id="scStart">▶ Запустить сканер</button>
        <button type="button" class="btn btn-secondary btn-sm" id="scStop">■ Остановить</button>
        <button type="button" class="btn btn-secondary btn-sm" id="scReset" title="Начать обход заново; кандидаты остаются">↺ Заново</button>
        <span id="scState" class="sc-state"></span>
      </div>
      <div id="scProg" class="sc-prog"><i></i></div>
      <div id="scLog" class="sc-log"></div>
      <div class="sc-row">
        <label class="sc-lbl">Папка Obsidian для заметок</label>
        <input id="scNotes" class="sc-in" placeholder="D:\\Obsidian\\Каспи">
        <button type="button" class="btn btn-secondary btn-sm" id="scNotesSave">Сохранить</button>
        <span id="scNotesMsg" class="sc-hint"></span>
      </div>
      <div class="sc-row"><b>Кандидаты</b> <span id="scCount" class="sc-hint"></span></div>
      <div id="scList" class="sc-list"></div>`;
    panel.parentNode.insertBefore(box, panel);
    $('scStart').onclick = async () => { const r = await api('/api/scanner/start', {}); if (!r.success) alert(r.error || 'Не удалось запустить.'); refresh(); };
    $('scStop').onclick = async () => { await api('/api/scanner/stop', {}); refresh(); };
    $('scReset').onclick = async () => {
      if (!confirm('Начать обход подкатегорий заново? Найденные кандидаты останутся.')) return;
      const r = await api('/api/scanner/reset', {}); if (!r.success) alert(r.error || 'Не удалось.'); refresh();
    };
    $('scNotesSave').onclick = async () => {
      const r = await api('/api/scanner/notes_dir', { notes_dir: $('scNotes').value });
      $('scNotesMsg').textContent = r.success ? 'Сохранено: ' + r.notes_dir : (r.error || 'Не удалось.');
    };
    return true;
  }

  async function refresh() {
    if (!mount()) return;
    const s = await api('/api/scanner/status');
    if (!s.success) return;
    $('scStart').disabled = s.running; $('scStop').disabled = !s.running;
    $('scState').textContent = s.running
      ? '● работает: ' + (s.current || '…') + (s.step ? ' (' + s.step + ')' : '')
      : (s.idx >= s.total && s.total ? 'обход завершён' : 'остановлен');
    $('scProg').firstElementChild.style.width = (s.total ? Math.min(100, s.idx / s.total * 100) : 0) + '%';
    $('scLog').textContent = 'Подкатегорий: ' + s.idx + ' из ' + s.total + ' · товаров сверено с Kaspi: ' + s.checked +
      ' · кандидатов: ' + s.active + (s.dropped ? ' (снято ' + s.dropped + ')' : '') + (s.log.length ? '\n' + s.log.slice(-4).join('\n') : '');
    if (document.activeElement !== $('scNotes') && !$('scNotes').value) $('scNotes').value = s.notes_dir || '';
    const c = await api('/api/scanner/candidates');
    if (c.success) renderList(c.items);
  }

  function renderList(items) {
    $('scCount').textContent = items.length ? '— сначала самые прибыльные' : '— пока пусто: сканер ищет';
    $('scList').innerHTML = items.slice(0, 60).map(c => `
      <div class="sc-item ${c.status !== 'active' ? 'sc-off' : ''}">
        ${c.image ? `<img src="${esc(c.image)}" alt="" width="46" height="46" loading="lazy" onerror="this.style.visibility='hidden'">` : ''}
        <div class="sc-main">
          <div class="sc-name"><a href="${esc(c.url)}" target="_blank" rel="noopener">${esc(c.name.slice(0, 80))}</a></div>
          <div class="sc-meta">${esc(c.category)} · закупка ${money(c.buy)} → Kaspi ${money(c.sell)} · спрос ≈${esc(c.rpm)} отз./мес · продавцов ${esc(c.sellers)}</div>
        </div>
        <div class="sc-profit">${c.status === 'active' ? '+' + money(c.profit) + '<small>' + esc(c.margin) + '%</small>' : '<small>снят: ' + esc(c.reason) + '</small>'}
          ${c.kaspi_url ? `<a href="${esc(c.kaspi_url)}" target="_blank" rel="noopener">Kaspi ↗</a>` : ''}</div>
      </div>`).join('');
  }

  // Сканер включён только у владельца: у остальных маршрутов нет, и карточка не показывается
  api('/api/scanner/status').then(s => {
    if (!s || !s.success) return;
    const t = setInterval(() => { if (mount()) { clearInterval(t); refresh(); setInterval(() => { if (!document.hidden) refresh(); }, 8000); } }, 700);
  });
})();
