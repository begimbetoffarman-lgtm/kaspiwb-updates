"""Выставление на готовые карточки Kaspi (присоединение к существующей карточке).
Адреса взяты из кода кабинета (kaspi.kz/mc, страница «Добавить товар → присоединиться к карточке»):
  данные карточки:  GET  mc.shop.kaspi.kz/content/item/api/v1/item/<код карточки>
  новый суффикс:    GET  mc.shop.kaspi.kz/content/pending/mc/product/<merchant_id>/new-code
  присоединить:     POST mc.shop.kaspi.kz/content/pending/mc/product/link-to-master  {merchantCode, merchantProductCode, masterProductCode}
preview() только читает. link() пишет в живой Kaspi: вызывать только после подтверждения пользователя."""
import re

from core import kaspi_cabinet as kc

_HDR = {"Origin": "https://kaspi.kz", "Referer": "https://kaspi.kz/mc/"}


def parse_code(text):
    """Код карточки из числа или ссылки kaspi.kz/shop/p/...-123456789/ ."""
    s = str(text or "").strip()
    m = re.search(r"-(\d{5,})/?(?:[?#].*)?$", s) or re.fullmatch(r"(\d{5,})", s)
    if not m:
        raise RuntimeError("Не нашёл код карточки. Вставьте ссылку на товар Kaspi (оканчивается на -числа) или сам код.")
    return m.group(1)


def preview(text):
    """Что за карточка (название, категория, фото). Ничего не меняет."""
    code = parse_code(text)
    kc._ensure()
    for _ in range(8):                      # карточка может быть «переехавшей» на другой код
        r = kc._session().get(kc.MC + f"/content/item/api/v1/item/{code}", headers=_HDR, timeout=30)
        if r.status_code != 200:
            raise RuntimeError(f"Kaspi не отдал карточку {code} ({r.status_code}).")
        d = r.json()
        if d.get("status") == "ACTUAL":
            break
        nxt = (d.get("redirectCodes") or [None])[0]
        if not nxt:
            raise RuntimeError("Карточка недоступна (удалена или не опубликована).")
        code = str(nxt)
    card = d.get("card") or {}
    imgs = d.get("galleryImages") or []
    return {"code": str(card.get("id") or code), "title": card.get("title"), "category": d.get("masterCategoryName"),
            "img": (imgs[0].get("medium") if imgs else None), "link": (card.get("shopLink") or "").replace("/p/", "/shop/p/", 1) if str(card.get("shopLink") or "").startswith("/p/") else card.get("shopLink")}


def _public_card(code, title):
    """Отзывы, рейтинг и цена «от» из публичной выдачи Kaspi: ищем карточку по названию и берём ту, у которой тот же код."""
    import json
    import urllib.parse
    import urllib.request
    from core import kaspi_store as ks
    try:
        city = str(ks._config_value("kaspi_city", "750000000"))
        q = urllib.parse.quote(str(title or "")[:80])
        h = {"User-Agent": ks.USER_AGENT, "Accept": "application/json, text/plain, */*", "Referer": "https://kaspi.kz/shop/search/"}
        h.update(ks._city_headers(city))
        req = urllib.request.Request(f"https://kaspi.kz/yml/product-view/pl/results?page=0&q={q}&text={q}&c={city}", headers=h)
        with ks._urlopen(req, 10) as r:
            data = json.loads(r.read().decode("utf-8")).get("data") or []
    except Exception:
        return {}
    for c in data:
        if str(c.get("id")) == str(code):
            return {"reviews": c.get("reviewsQuantity"), "rating": c.get("rating"), "price_from": c.get("unitPrice")}
    return {}


def info(text):
    """Данные карточки Kaspi по ссылке: название, фото, отзывы, цены и число продавцов. Только чтение."""
    from core import kaspi_store as ks
    code = parse_code(text)
    out = {"code": code, "title": None, "img": None, "category": None, "link": None}
    try:
        p = preview(code)
        out.update({k: p.get(k) for k in ("code", "title", "img", "category", "link")})
    except Exception as e:                      # кабинет не открыт: покажем хотя бы продавцов
        out["preview_error"] = str(e)[:160]
    pub = _public_card(out["code"], out.get("title")) if out.get("title") else {}
    out.update({"reviews": pub.get("reviews"), "rating": pub.get("rating")})
    r = ks.fetch_competitor_prices(out["code"])
    offers = r.get("offers") or []
    prices = [o["price"] for o in offers if o.get("price")]
    out["offers_ok"] = bool(r.get("ok"))
    out["offers_error"] = r.get("error") or ""
    out["sellers"] = len(offers)
    out["price_min"] = min(prices) if prices else pub.get("price_from")
    out["price_max"] = max(prices) if prices else None
    out["preorder_sellers"] = sum(1 for o in offers if (o.get("preorder") or 0) > 0)
    out["top"] = [{"merchant": o.get("merchant"), "price": o.get("price"), "preorder": o.get("preorder") or 0,
                   "rating": o.get("rating"), "reviews": o.get("reviews")} for o in offers[:5]]
    return out


def link(text, price=None, preorder_days=None):
    from core import license as _lic
    _lic.require()
    """Присоединяет магазин к карточке; если указаны цена и срок — сразу выставляет. ПИШЕТ В ЖИВОЙ KASPI."""
    info = preview(text)
    mid = kc.merchant_id()
    r = kc._session().get(kc.MC + f"/content/pending/mc/product/{mid}/new-code", headers=_HDR, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"Kaspi не выдал код товара ({r.status_code}).")
    suffix = re.sub(r"[^0-9A-Za-z_-]", "", r.text.strip())
    if not suffix:
        raise RuntimeError("Kaspi вернул пустой код товара.")
    sku = f"{info['code']}_{suffix}"
    body = {"merchantCode": mid, "merchantProductCode": sku, "masterProductCode": info["code"]}
    resp = None
    for q in ({}, {"m": mid}, {"_m": mid}):
        resp = kc._session().post(kc.MC + "/content/pending/mc/product/link-to-master", params=q, json=body, timeout=60,
                                  headers=dict(_HDR, **{"Content-Type": "application/json"}))
        if resp.status_code not in (403, 404):
            break
    if resp.status_code >= 400:
        kc._log("link_error", card=info["code"], http=resp.status_code)
        raise RuntimeError(f"Kaspi не присоединил карточку ({resp.status_code}): {resp.text[:200]}")
    kc._save_session()
    kc._log("link_to_master", card=info["code"], sku=sku)
    out = {"ok": True, "sku": sku, "card": info, "offer_set": False}
    if price:
        try:
            kc.set_offer(sku, price=int(price), preorder_days=preorder_days, available=True, stock=10)
            out["offer_set"] = True
        except Exception as e:
            out["offer_error"] = str(e)[:200]
    return out
