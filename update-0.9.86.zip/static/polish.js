// Плавающая подсветка в переключателях, тумблеры и счётчик цифр в плитках магазина. Только оформление, логику страниц не трогает.
(function () {
  'use strict';
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---- 1. плавающая подсветка активного пункта ----
  function place(host, ind, animate) {
    const a = host.querySelector(':scope > .active');
    if (!a || !a.offsetWidth) { ind.style.opacity = '0'; return; }
    host.classList.toggle('pill-nomove', !animate || reduce);
    ind.style.opacity = '1';
    ind.style.width = a.offsetWidth + 'px'; ind.style.height = a.offsetHeight + 'px';
    ind.style.transform = 'translate(' + a.offsetLeft + 'px,' + a.offsetTop + 'px)';
  }
  function setupPill(host) {
    if (host.__pill) return;
    const ind = document.createElement('span'); ind.className = 'pill-ind'; ind.style.left = '0'; ind.style.top = '0';
    host.insertBefore(ind, host.firstChild);
    host.classList.add('pill-host', 'pill-ready'); host.__pill = ind;
    const upd = anim => place(host, ind, anim);
    new MutationObserver(() => upd(true)).observe(host, { attributes: true, attributeFilter: ['class'], subtree: true });
    window.addEventListener('resize', () => upd(false));
    if (window.ResizeObserver) new ResizeObserver(() => upd(false)).observe(host);
    upd(false);
    setTimeout(() => upd(false), 400);                       // после загрузки шрифтов
  }
  function scanPills() { document.querySelectorAll('.radar-mode-switch, .seg-ctl').forEach(setupPill); }

  // ---- 2. тумблеры ----
  function setupSwitches() {
    ['apAll', 'auOn', 'autopilotEnabled', 'forksLiveKaspi'].forEach(id => {
      const el = document.getElementById(id); if (el) el.classList.add('sw');
    });
  }

  // ---- 3. счётчик цифр в плитках магазина ----
  function countUp(el) {
    let busy = false;
    new MutationObserver(() => {
      if (busy || reduce) return;
      const txt = el.textContent, m = txt.match(/^([^\d-]*)(-?[\d\s ]+)(.*)$/);
      if (!m) return;
      const to = parseInt(m[2].replace(/[\s ]/g, ''), 10);
      const from = el.__v == null ? 0 : el.__v;
      el.__v = to;
      if (!isFinite(to) || from === to || Math.abs(to - from) < 2) return;
      busy = true;
      const t0 = performance.now(), D = 600;
      (function step(t) {
        const k = Math.min(1, (t - t0) / D), e = 1 - Math.pow(1 - k, 3);
        el.textContent = m[1] + Math.round(from + (to - from) * e).toLocaleString('ru-RU') + m[3];
        if (k < 1) requestAnimationFrame(step); else { el.textContent = txt; busy = false; }
      })(t0);
    }).observe(el, { childList: true, characterData: true, subtree: true });
  }
  function setupCounters() { ['storeTotalProfit', 'storeTotalRevenue'].forEach(id => { const el = document.getElementById(id); if (el) countUp(el); }); }

  // ---- 4. кнопки: крутилка, пока работает, и галочка после ----
  (function () {
    let lastClick = 0, lastBtn = null;
    document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('.btn'); if (b) { lastClick = Date.now(); lastBtn = b; } }, true);
    new MutationObserver(list => {
      list.forEach(m => {
        const b = m.target; if (!b.classList || !b.classList.contains('btn')) return;
        if (b.disabled) {
          if (b === lastBtn && Date.now() - lastClick < 1500) { b.__busyAt = Date.now(); b.classList.add('is-busy'); }
        } else if (b.__busyAt) {
          const long = Date.now() - b.__busyAt > 250; b.__busyAt = 0; b.classList.remove('is-busy');
          if (long) { b.classList.add('is-done'); setTimeout(() => b.classList.remove('is-done'), 1100); }
        }
      });
    }).observe(document.body, { attributes: true, attributeFilter: ['disabled'], subtree: true });
  })();

  // ---- 5. «Копировать» с галочкой ----
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('#btnCopyFeed'); if (!b || b.__t) return;
    const old = b.textContent; b.textContent = '✓ Скопировано';
    b.__t = setTimeout(() => { b.textContent = old; b.__t = 0; }, 1400);
  });

  // ---- 6. быстрый поиск по разделам (Ctrl+K) ----
  (function () {
    let box, input, list, items = [], sel = 0;
    function collect() {
      const out = [];
      document.querySelectorAll('button.nav-item[data-tab]').forEach(b => {
        const t = b.textContent.replace(/\s+/g, ' ').trim(); if (t) out.push({ t, sub: 'раздел', run: () => b.click() });
      });
      const modes = { vacuum: 'Хиты WB без конкурентов', forks: 'Выгодные связки (арбитраж WB / Ozon → Kaspi)', link: 'Предзаказ по ссылке Kaspi' };
      Object.keys(modes).forEach(k => out.push({ t: modes[k], sub: 'Предзаказ / Арбитраж', run: () => {
        const n = document.querySelector('button.nav-item[data-tab="tab-radar"]'); if (n) n.click();
        setTimeout(() => { const m = document.querySelector('.rms-btn[data-radar-mode="' + k + '"]'); if (m) m.click(); }, 120); } }));
      return out;
    }
    function render() {
      const q = input.value.trim().toLowerCase();
      const shown = items.filter(i => !q || i.t.toLowerCase().includes(q) || i.sub.toLowerCase().includes(q));
      sel = Math.min(sel, Math.max(0, shown.length - 1));
      list.innerHTML = '';
      shown.forEach((i, n) => {
        const li = document.createElement('li'); li.className = n === sel ? 'on' : '';
        li.innerHTML = '<span></span><small></small>'; li.firstChild.textContent = i.t; li.lastChild.textContent = i.sub;
        li.onclick = () => go(i); list.appendChild(li);
      });
      box.__shown = shown;
    }
    function go(i) { close(); i.run(); }
    function close() { box.classList.remove('open'); }
    function open() {
      if (!box) {
        box = document.createElement('div'); box.id = 'qk';
        box.innerHTML = '<div class="qk-box"><input type="text" placeholder="Куда перейти? Например: магазин, арбитраж, заказы"><ul></ul><div class="qk-hint">Стрелки выбирают, Enter открывает, Esc закрывает</div></div>';
        document.body.appendChild(box); input = box.querySelector('input'); list = box.querySelector('ul');
        box.addEventListener('mousedown', e => { if (e.target === box) close(); });
        input.addEventListener('input', () => { sel = 0; render(); });
        input.addEventListener('keydown', e => {
          const n = (box.__shown || []).length;
          if (e.key === 'ArrowDown') { sel = (sel + 1) % Math.max(1, n); render(); e.preventDefault(); }
          else if (e.key === 'ArrowUp') { sel = (sel - 1 + Math.max(1, n)) % Math.max(1, n); render(); e.preventDefault(); }
          else if (e.key === 'Enter') { const i = (box.__shown || [])[sel]; if (i) go(i); }
          else if (e.key === 'Escape') close();
        });
      }
      items = collect(); input.value = ''; sel = 0; render(); box.classList.add('open'); input.focus();
    }
    document.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && (e.key === 'k' || e.key === 'K' || e.key === 'л' || e.key === 'Л')) { e.preventDefault(); (box && box.classList.contains('open')) ? close() : open(); }
    });
  })();

  // ---- 7. наклон плиток за курсором, магнитные кнопки, каскад карточек ----
  (function () {
    if (reduce) return;
    const SEL = '.store-kpi-card, .fk-card';
    let cur = null, raf = 0, last = null;
    function apply() {
      raf = 0; if (!cur || !last) return;
      const r = cur.getBoundingClientRect(); if (!r.width) return;
      const px = Math.max(0, Math.min(1, (last.clientX - r.left) / r.width)), py = Math.max(0, Math.min(1, (last.clientY - r.top) / r.height));
      const k = cur.classList.contains('fk-card') ? 1.4 : 7;
      cur.style.setProperty('--ry', ((px - .5) * 2 * k).toFixed(2) + 'deg');
      cur.style.setProperty('--rx', ((.5 - py) * 2 * k).toFixed(2) + 'deg');
      cur.style.setProperty('--mx', (px * 100).toFixed(1) + '%'); cur.style.setProperty('--my', (py * 100).toFixed(1) + '%');
      cur.style.setProperty('--ty', cur.classList.contains('fk-card') ? '0px' : '-3px');
    }
    function release(el) { if (!el) return; el.classList.remove('tilting'); el.style.removeProperty('--rx'); el.style.removeProperty('--ry'); el.style.removeProperty('--ty'); }
    document.addEventListener('pointermove', e => {
      if (e.pointerType !== 'mouse') return;
      const el = e.target.closest && e.target.closest(SEL);
      if (el !== cur) { release(cur); cur = el; if (cur) cur.classList.add('tilting'); }
      last = e; if (cur && !raf) raf = requestAnimationFrame(apply);
      // магнитные главные кнопки
      const b = e.target.closest && e.target.closest('.btn-accent, .btn-primary');
      if (b && !b.disabled && b.offsetWidth > 90) {
        const r = b.getBoundingClientRect();
        b.classList.add('mag');
        b.style.transform = 'translate(' + (((e.clientX - r.left) / r.width - .5) * 6).toFixed(1) + 'px,' + (((e.clientY - r.top) / r.height - .5) * 4).toFixed(1) + 'px)';
        b.__mag = true;
      }
    }, { passive: true });
    document.addEventListener('pointerout', e => {
      const b = e.target.closest && e.target.closest('.btn.mag');
      if (b && !(e.relatedTarget && b.contains(e.relatedTarget))) b.style.transform = '';
      if (cur && !(e.relatedTarget && cur.contains(e.relatedTarget))) { release(cur); cur = null; }
    }, { passive: true });
    // при прокрутке наклон снимается: курсор уже не над той плиткой
    window.addEventListener('scroll', () => { if (cur) { release(cur); cur = null; } }, { passive: true, capture: true });
    // каскад: новые карточки связок появляются по очереди
    new MutationObserver(list => {
      let n = 0;
      list.forEach(m => m.addedNodes.forEach(x => {
        if (x.nodeType === 1 && x.classList.contains('fk-card') && n < 10) { x.style.setProperty('--i', n++); x.classList.add('pl-in'); setTimeout(() => x.classList.remove('pl-in'), 1100); }
      }));
    }).observe(document.body, { childList: true, subtree: true });
  })();


  // ---- 8. кнопка быстрого поиска внизу бокового меню ----
  function navSearch() {
    const menu = document.querySelector('.sidebar .nav-menu'); if (!menu || menu.querySelector('.nav-search')) return;
    const b = document.createElement('button'); b.type = 'button'; b.className = 'nav-search'; b.title = 'Быстрый переход по разделам';
    b.innerHTML = '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg><span>Быстрый поиск</span><kbd>Ctrl K</kbd>';
    b.onclick = () => document.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', ctrlKey: true, bubbles: true }));
    menu.appendChild(b);
  }

  function init() { navSearch(); scanPills(); setupSwitches(); setupCounters(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  // разделы могут дорисовываться позже
  setTimeout(scanPills, 1200);
})();
