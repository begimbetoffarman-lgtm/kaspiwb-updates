// Предзаказ по ссылке Kaspi: данные карточки (отзывы, цены, продавцы) и кнопка «Поставить на предзаказ».
(function () {
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fmt = n => (n == null || n === '') ? '—' : Math.round(+n).toLocaleString('ru-RU') + ' ₸';
  const post = async (u, b) => { const r = await apiPost(u, b); return r.data || { success: false, error: r.error }; };
  let card = null;

  // кнопка в «Предзаказ карточек» ведёт сюда
  document.addEventListener('click', e => {
    if (!(e.target.closest && e.target.closest('#kfOpen'))) return;
    setTimeout(() => { const b = document.querySelector('.rms-btn[data-radar-mode="link"]'); if (b) b.click(); }, 80);
  });
  if (!$('kfBox')) return;

  function show(c) {
    const range = c.price_min != null ? (c.price_max && c.price_max !== c.price_min ? fmt(c.price_min) + ' – ' + fmt(c.price_max) : fmt(c.price_min)) : '—';
    const sellers = c.sellers ? String(c.sellers) : (c.offers_ok ? '0' : '—');
    const pre = c.sellers ? (c.preorder_sellers ? c.preorder_sellers + ' на предзаказе' : 'все в наличии') : (c.offers_ok ? '' : esc(c.offers_error || 'не прочитались'));
    const rows = (c.top || []).map(o => `<tr><td>${esc(o.merchant || 'продавец')}</td><td>${o.preorder ? 'предзаказ ' + o.preorder + ' дн.' : 'в наличии'}</td><td><b>${fmt(o.price)}</b></td></tr>`).join('');
    const href = c.link ? (c.link.startsWith('http') ? c.link : 'https://kaspi.kz' + c.link) : '';
    $('kfInfo').innerHTML =
      '<div class="kf-head">' +
      (c.img ? `<img class="kf-img" src="${esc(c.img)}" referrerpolicy="no-referrer" alt="">` : '') +
      `<div><div class="kf-title">${esc(c.title || 'Карточка ' + c.code)}</div>` +
      `<div class="kf-sub">${esc(c.category || '')}${c.category ? ' · ' : ''}код ${esc(c.code)}${href ? ` · <a href="${esc(href)}" target="_blank" rel="noopener">открыть на Kaspi</a>` : ''}</div>` +
      (c.preview_error ? `<div class="kf-sub">Название и фото не прочитались: войдите в кабинет Kaspi (${esc(c.preview_error)})</div>` : '') +
      '</div></div>' +
      '<div class="kf-tiles">' +
      `<div class="kf-tile"><span>Цена на Kaspi</span><b>${range}</b></div>` +
      `<div class="kf-tile"><span>Продавцов${pre ? ' · ' + pre : ''}</span><b>${sellers}</b></div>` +
      `<div class="kf-tile"><span>Отзывов</span><b>${c.reviews != null ? c.reviews : '—'}</b></div>` +
      `<div class="kf-tile"><span>Рейтинг</span><b>${c.rating ? (+c.rating).toFixed(1) : '—'}</b></div></div>` +
      (rows ? `<table class="kf-sellers">${rows}</table>` : '');
  }

  $('kfFind').onclick = async () => {
    $('kfForm').style.display = 'none'; card = null;
    $('kfInfo').textContent = 'Читаю карточку…';
    $('kfFind').disabled = true;
    try {
      const d = await post('/api/link/info', { code: $('kfUrl').value });
      if (!d.success) { $('kfInfo').innerHTML = '<div class="wbt-banner bad"><b class="t">Не получилось</b><br>' + esc(d.error) + '</div>'; return; }
      card = d.info; show(card);
      if (card.title) { $('kfPrice').value = card.price_min || ''; $('kfForm').style.display = 'flex'; }
    } finally { $('kfFind').disabled = false; }
  };
  $('kfUrl').addEventListener('keydown', e => { if (e.key === 'Enter') $('kfFind').click(); });

  $('kfGo').onclick = async () => {
    if (!card) return;
    const price = +$('kfPrice').value || 0, days = parseInt($('kfDays').value, 10) || 0;
    if (!price || !days) { $('kfInfo').insertAdjacentHTML('beforeend', '<div class="wbt-banner bad">Укажите цену и срок предзаказа в днях.</div>'); return; }
    if (!confirm('Присоединить ваш магазин к карточке «' + card.title + '» в живом Kaspi: цена ' + price + ' ₸, предзаказ ' + days + ' дн.?')) return;
    $('kfGo').disabled = true;
    const keep = $('kfInfo').innerHTML;
    $('kfInfo').textContent = 'Отправляю в Kaspi…';
    try {
      const d = await post('/api/link/apply', { code: card.code, price, days, confirm: true });
      if (!d.success) { $('kfInfo').innerHTML = '<div class="wbt-banner bad"><b class="t">Не получилось поставить на предзаказ</b><br>' + esc(d.error) + '</div>' + keep; return; }
      $('kfForm').style.display = 'none';
      $('kfInfo').innerHTML = '<div class="wbt-banner ok">Готово. Артикул ' + esc(d.sku) + (d.offer_set ? ': цена и предзаказ выставлены.' : '. Цену и срок поставьте в кабинете' + (d.offer_error ? ' (' + esc(d.offer_error) + ')' : '') + '.') + '</div>' + keep;
    } finally { $('kfGo').disabled = false; }
  };
})();
