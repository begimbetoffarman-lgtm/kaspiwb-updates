"""Реферальная программа: свой код пользователя, ввод кода друга, бонус к пробному периоду.

Что считается здесь, без сервера: код пользователя (из постоянного номера ПК, с контрольным символом от опечаток),
+3 дня к пробному периоду приглашённого (один раз, только пока идёт проба). Награды пригласившему (+1 день за начатую
пробу друга, +7 дней после его оплаты) начисляет владелец при выдаче ключа по таблице «Журнал» (событие referral_apply)."""
import hashlib
import hmac
import json
import os
import threading
import time

from core import license as lic

BONUS_TRIAL_DAYS = 3
_ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"        # без O, I, 0, 1: код читается без путаницы
REF_FILE = os.path.join(lic.DATA_DIR, ".referral.json")
DOWNLOAD_URL = "https://drive.google.com/drive/folders/1YYtNOXQrme_d3_m96hkbBypEM6AgEyNP"


def _body(seed):
    h = hashlib.sha256(("KWB-ref-v1:" + seed).encode("utf-8")).digest()
    return "".join(_ALPHA[b % 32] for b in h[:6])


def _check(body):
    return _ALPHA[hashlib.sha256(("KWB-chk:" + body).encode("utf-8")).digest()[0] % 32]


def my_code():
    body = _body(lic.display_id())
    return "KW-" + body + _check(body)


def normalize(code):
    c = "".join(str(code or "").upper().split())
    if c.startswith("KW-"):
        c = c[3:]
    return c.replace("-", "")


def is_valid(code):
    c = normalize(code)
    return len(c) == 7 and all(ch in _ALPHA for ch in c) and _check(c[:6]) == c[6]


def _sig(code, ts, revoked=False):
    raw = f"{lic.display_id()}:{code}:{ts}" + (":revoked" if revoked else "")
    return hmac.new(lic._LOCAL_SALT.encode(), raw.encode("utf-8"), hashlib.sha256).hexdigest()


def _load():
    try:
        with open(REF_FILE, encoding="utf-8") as f:
            d = json.load(f)
        if d.get("code") and d.get("signature") == _sig(d["code"], d.get("applied_at"), bool(d.get("revoked"))):
            return d
    except Exception:
        pass
    return None


_confirm_started = False


def bonus_days():
    """Сколько дней к пробному периоду дал код друга. 0, если кода нет, файл подделан, бонус отозван
    или магазин Kaspi ещё не подключён (так пустые аккаунты бонус не получают)."""
    global _confirm_started
    d = _load()
    if not d or d.get("revoked"):
        return 0
    try:
        has_store = bool(lic.merchant_hash())
    except Exception:
        has_store = False
    if not has_store:
        return 0
    if not d.get("confirmed") and not _confirm_started:
        _confirm_started = True
        threading.Thread(target=_confirm, daemon=True).start()
    return BONUS_TRIAL_DAYS


def _ask(event, extra, timeout=15):
    """Вопрос таблице владельца. Ответ-словарь или None (нет адреса, нет связи, странный ответ): тогда ничего не блокируем."""
    try:
        from core import telemetry, updater
        url = telemetry._url()
        if not url:
            return None
        r = telemetry._post(url, {"event": event, "machine": lic.display_id(), "version": updater.current_version(),
                                  "merchant_hash": lic.merchant_hash(), "ts": time.strftime("%Y-%m-%d %H:%M:%S"), **extra},
                            timeout=timeout)
        return r if isinstance(r, dict) else None
    except Exception:
        return None


def _write(d):
    with open(REF_FILE, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    lic._cache["t"] = 0


def _confirm():
    """Магазин подключён: просим таблицу подтвердить, что этот магазин ещё не получал бонус."""
    d = _load()
    if not d or d.get("revoked") or d.get("confirmed"):
        return
    r = _ask("referral_confirm", {"ref_code": d["code"], "my_code": my_code()})
    if not r or not r.get("ok"):
        return
    if r.get("accepted") is False:
        d["revoked"] = True
        d["signature"] = _sig(d["code"], d.get("applied_at"), True)
    else:
        d["confirmed"] = True
    try:
        _write(d)
    except Exception:
        pass


def apply_friend_code(code):
    """Применяет код друга. Только в пробный период, один раз, не свой код. Возвращает {success, message|error}."""
    c = normalize(code)
    if not is_valid(c):
        return {"success": False, "error": "Код не подходит: проверьте символы (например, KW-ABCDEF7)."}
    full = "KW-" + c
    if full == my_code():
        return {"success": False, "error": "Нельзя ввести собственный код."}
    if _load():
        return {"success": False, "error": "Код друга уже введён на этом компьютере."}
    st = lic.init_or_load_license()
    if st.get("status") != "TRIAL":
        return {"success": False, "error": "Код друга вводится только в пробный период."}
    r = _ask("referral_apply", {"ref_code": full, "my_code": my_code()})
    if r and r.get("ok") and r.get("accepted") is False:
        return {"success": False, "error": "У этого кода закончились приглашения (лимит "
                + str(r.get("limit") or 10) + " человек). Попросите у друга другой код или напишите владельцу."}
    ts = int(time.time())
    data = {"code": full, "applied_at": ts, "signature": _sig(full, ts)}
    os.makedirs(lic.DATA_DIR, exist_ok=True)
    _write(data)
    return {"success": True, "message": f"Код принят. +{BONUS_TRIAL_DAYS} дня к пробному периоду появятся, "
                                         "как только вы подключите свой магазин Kaspi."}


def info():
    d = _load()
    code = my_code()
    text = ("Пробуй программу для продавцов Kaspi (поиск товаров на 1688/WB, карточки, заказы). "
            f"Скачать: {DOWNLOAD_URL} . Введи мой код при активации: {code} , получишь +{BONUS_TRIAL_DAYS} дня к пробе.")
    return {"success": True, "code": code, "download_url": DOWNLOAD_URL, "share_text": text,
            "friend_code": (d or {}).get("code", ""), "bonus_days": bonus_days(),
            "bonus_pending": bool(d) and not d.get("revoked") and bonus_days() == 0,
            "bonus_revoked": bool(d and d.get("revoked")),
            "rules": ["Друг получает +3 дня к пробному периоду по вашему коду.",
                      "Вы получаете +1 день, когда друг начнёт пробу (не больше 5 дней), и +7 дней, когда он оплатит подписку."]}


def stats():
    """Статусы друзей для пригласившего (из таблицы владельца). None, если таблица недоступна."""
    r = _ask("referral_stats", {"my_code": my_code()}, timeout=12)
    if not r or not r.get("ok"):
        return {"success": False, "error": "Таблица пока недоступна"}
    return {"success": True, "invited": int(r.get("invited") or 0), "paid": int(r.get("paid") or 0),
            "limit": int(r.get("limit") or 10), "bonus_days": int(r.get("bonus_days") or 0)}
