"""⚡ Радар вилок: межмаркетплейсный арбитраж WB / Ozon -> Kaspi.

Находит связку «закупка на WB/Ozon — продажа на Kaspi», считает чистую прибыль
(комиссия, Kaspi Pay, доставка, налог ИП) и отдаёт готовые карточки в интерфейс.

Источники:
  - WB: core.wb_parser.parse_wb_search_sync (живая выдача, цены в ₸ для города из Первого запуска);
  - Ozon: core.suppliers.search (Ozon в браузере программы, цены в KZT);
  - Kaspi: core.kaspi_store.check_kaspi_vacuum (форс-обновление цены и продавцов
    для цены-подсказки Kaspi и режима «Вакуум»).
Если сеть недоступна, отдаётся проверенный эталонный кэш data/forks_cache.json.
В Kaspi ничего не отправляется: модуль только читает и складывает в «Найденное».
"""
import datetime
import hashlib
import json
import os
import threading
import time

from core import secrets as _secrets
from core import supplier_delivery
from core.kaspi_store import calculate_product_economics, check_kaspi_vacuum
from core.wb_parser import clean_kaspi_title, parse_wb_search_sync

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_FILE = os.path.join(ROOT, 'data', 'forks_cache.json')
COMMISSIONS_FILE = os.path.join(ROOT, 'core', 'kaspi_commissions.json')

DEFAULT_RATE = 5.2            # ₽ -> ₸
DEFAULT_COMMISSION = 12.5
DEFAULT_PACK = 150            # упаковка, ₸
DEFAULT_SCOPE = 'kz'
MODES = ('spread', 'speed', 'vacuum')
SOURCES = ('all', 'wb', 'ozon')
VACUUM_MIN_FEEDBACKS = 500
VACUUM_MAX_SELLERS = 3
TTL_OK = 30 * 60              # живая выдача свежа 30 минут
TTL_FAIL = 10 * 60            # неудачу не повторяем 10 минут (не долбим площадки)
TTL_VACUUM = 6 * 60 * 60      # проверка Kaspi — 6 часов
CACHE_LIMIT = 1500

_MEMO = {}                    # (source, query|category) -> {'at': ts, 'error': str, 'items': [...]}
_VACUUM_MEMO = {}             # (query, mode) -> (ts, result)
_LOCK = threading.Lock()
_PROBE_SEM = threading.BoundedSemaphore(4)
_COMMISSIONS = []
_CACHE = None
_WARN = []


class RadarBusy(RuntimeError):
    pass


# ---------------------------------------------------------------- настройки
def _config():
    try:
        cfg = _secrets.read_config() or {}
    except Exception:
        cfg = {}
    try:
        rate = float(cfg.get('rub_to_kzt_rate') or DEFAULT_RATE)
    except (TypeError, ValueError):
        rate = DEFAULT_RATE
    return rate if 1 <= rate <= 30 else DEFAULT_RATE


_COMM_PREP = []               # [(слова категории, ставка)] — разбор таблицы делаем один раз
_COMM_MEMO = {}               # категория -> ставка (None, если не нашли)


def _commission_rate(category=''):
    """Реальная ставка Kaspi по категории (таблица kaspi_commissions.json). Неизвестная категория -> None (дальше берётся 12.5 по умолчанию).
    Таблица большая (4 тыс. строк), а «Мой магазин» спрашивает ставку для каждого товара: разбор делаем один раз, ответы запоминаем."""
    global _COMMISSIONS, _COMM_PREP
    key = str(category or '')
    if key in _COMM_MEMO:
        return _COMM_MEMO[key]
    if not _COMM_PREP:
        if not _COMMISSIONS:
            try:
                with open(COMMISSIONS_FILE, encoding='utf-8') as f:
                    _COMMISSIONS = [tuple(p) for p in json.load(f) if isinstance(p, list) and len(p) == 2]
            except (OSError, ValueError):
                _COMMISSIONS = []
        prep = []
        for name, rate in _COMMISSIONS:
            try:
                prep.append((frozenset(_stems(name)), float(rate)))
            except (TypeError, ValueError):
                continue
        _COMM_PREP = prep
    words = _stems(key)
    result = None
    if words and _COMM_PREP:
        need = min(2, len(words))
        best, rates = 0, []
        for stems, rate in _COMM_PREP:
            n = len(words & stems)
            if n < need:
                continue
            if n > best:
                best, rates = n, [rate]
            elif n == best:
                rates.append(rate)
        if rates:
            result = max(set(rates), key=lambda r: (rates.count(r), r))
    if len(_COMM_MEMO) > 5000:
        _COMM_MEMO.clear()
    _COMM_MEMO[key] = result
    return result


def _stems(text):
    return {w[:5] for w in _words(text) if len(w) > 3}


def _words(text):
    import re
    return [w for w in re.sub(r'[^\w\s]', ' ', str(text or '').lower()).split() if len(w) > 2]


def retail_price(purchase_kzt):
    """Цена продажи-ориентир: та же формула, что «Мой магазин» — двойная наценка с шагом 100 ₸."""
    from core.wb_parser import round_kaspi_price
    return round_kaspi_price(max(0, float(purchase_kzt or 0)) * 2.4)


# ---------------------------------------------------------------- экономика
def compute(buy_kzt, sell_kzt, rate=DEFAULT_RATE, commission=None, scope=DEFAULT_SCOPE, category=''):
    """Честный расчёт вилки. Все суммы в ₸."""
    rate = rate or DEFAULT_RATE
    buy = max(0, float(buy_kzt or 0))
    sell = max(0, float(sell_kzt or 0))
    buy_rub = round(buy / rate) if buy else None
    if sell <= 0:
        sell = retail_price(buy)
    if commission is None and category:
        commission = _commission_rate(category)
    comm = DEFAULT_COMMISSION if commission is None else commission
    econ = calculate_product_economics(sell, buy, comm_rate=comm, pack_kzt=DEFAULT_PACK, delivery_scope=scope)
    return {
        'buy_kzt': int(round(buy)),
        'buy_rub': buy_rub,
        'rate': rate,
        'sell_kzt': int(sell),
        'commission_rate': comm,
        'commission_assumed': commission is None,     # категория не учтена: взята ставка по умолчанию, это нужно показать честно
        'commission_kzt': econ['comm_kzt'],
        'kaspi_pay_kzt': econ['pay_kzt'],
        'tax_kzt': econ['tax_kzt'],
        'delivery_kzt': econ['delivery_kzt'],
        'delivery_tier': econ['delivery_tier'],
        'delivery_vat_kzt': econ['delivery_vat'],
        'pack_kzt': econ['pack_kzt'],
        'fees_kzt': econ['kaspi_deductions'],
        'payout_kzt': econ['kaspi_payout'],
        'profit_kzt': econ['net_profit'],
        'roi_pct': econ['roi_pct'],
        'margin_pct': econ['margin_pct'],
        'status': econ['verdict_status'],
        'sell_source': 'estimate',
    }


# ---------------------------------------------------------------- кэш диска
def _load_cache():
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    data = {}
    try:
        with open(CACHE_FILE, encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    data.setdefault('version', 1)
    data.setdefault('items', {})
    data.setdefault('vacuum', {})
    data.setdefault('seeds', [])
    if not isinstance(data.get('items'), dict):
        data['items'] = {}
    _CACHE = data
    return _CACHE


def _save_cache():
    try:
        data = _load_cache()
        os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
        tmp = CACHE_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, separators=(',', ':'))
        try:
            os.replace(tmp, CACHE_FILE)
        except OSError:
            import time
            time.sleep(0.05)
            try:
                os.replace(tmp, CACHE_FILE)
            except OSError:
                with open(CACHE_FILE, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, separators=(',', ':'))
                if os.path.exists(tmp):
                    try:
                        os.remove(tmp)
                    except OSError:
                        pass
    except Exception:
        pass


def _int(value, default, low, high):
    try:
        return max(low, min(high, int(float(value))))
    except (TypeError, ValueError):
        return default


def _ts():
    return int(datetime.datetime.now().timestamp())


def _now():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _key(source, query):
    raw = '%s|%s' % (source, ' '.join(_words(query)) or str(query or '').strip().lower())
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:16]


def _cache_put(query, source, items, error=''):
    data = _load_cache()
    data['items'][_key(source, query)] = {'query': query, 'source': source, 'items': items,
                                          'at': _ts(), 'error': error}
    if len(data['items']) > CACHE_LIMIT:
        for k, _ in sorted(data['items'].items(), key=lambda kv: kv[1].get('at', 0))[:len(data['items']) - CACHE_LIMIT]:
            data['items'].pop(k, None)
    _save_cache()


def _cache_get(query, source, max_age=None):
    entry = _load_cache()['items'].get(_key(source, query))
    if not entry:
        return None
    if max_age is not None and _ts() - int(entry.get('at') or 0) > max_age:
        return None
    return entry


# ---------------------------------------------------------------- MB -> связка
def _from_wb(row, rate):
    price_kzt = row.get('price_kzt') or row.get('cost_total')
    if not price_kzt:
        return None
    econ = compute(price_kzt, row.get('kaspi_price') or 0, rate, category=row.get('kaspi_search_query') or '')
    return {
        'id': 'wb:%s' % row.get('id'),
        'source': 'wb',
        'source_label': 'Wildberries',
        'name': row.get('name') or '',
        'brand': row.get('brand') or '',
        'image': row.get('img_main') or ((row.get('images') or [''])[0]),
        'url': row.get('wb_url') or '',
        'rating': row.get('rating'),
        'feedbacks': int(row.get('feedbacks') or 0),
        'stock': row.get('wb_qty'),
        'category': row.get('kaspi_search_query') or '',
        'kaspi_query': row.get('kaspi_search_query') or '',
        'economy': econ,
        'sell_source': 'estimate',
    }


def _from_ozon(row, rate):
    # Ozon в отдельном окне программы показывает цены в тенге (ozon.kz).
    price_kzt = row.get('price')
    if not price_kzt or str(row.get('currency') or '').upper() == 'CNY':
        return None
    econ = compute(price_kzt, 0, rate, category=row.get('category') or row.get('name') or '')
    name = str(row.get('name') or '')
    return {
        'id': 'ozon:%s' % (row.get('id') or row.get('url')),
        'source': 'ozon',
        'source_label': 'Ozon',
        'name': name,
        'brand': '',
        'image': row.get('image') or '',
        'url': row.get('url') or '',
        'rating': None,
        'feedbacks': 0,
        'stock': None,
        'category': '',
        'kaspi_query': ' '.join([w for w in _words(name) if len(w) > 3][:3]),
        'economy': econ,
    }


def _fresh_cnx():
    if not _LOCK.acquire(blocking=False):
        raise RadarBusy('Радар уже ищет по другой категории. Подождите пару секунд и повторите.')
    return True


# ---------------------------------------------------------------- источник
def _wb_items(query, limit, rate):
    cnx = _fresh_cnx()
    try:
        try:
            rows = parse_wb_search_sync(query, limit=max(limit, 30))
            if not rows:                      # WB иногда отвечает пусто/498 при частых запросах — одна повторная попытка
                time.sleep(5)
                rows = parse_wb_search_sync(query, limit=max(limit, 30))
            error = ''
            if not rows:
                from core import wb_parser
                error = wb_parser.LAST_ERROR or 'WB не вернул товары по этому запросу.'
        except Exception as e:
            rows, error = [], 'WB недоступен: %s' % e
        items = [x for x in (_from_wb(r, rate) for r in rows) if x]
        return items, error
    finally:
        if cnx:
            _LOCK.release()


def _ozon_items(query, limit, rate):
    cnx = _fresh_cnx()
    try:
        try:
            from core import suppliers
            result = suppliers.search('ozon', query)
            rows = result.get('items') or []
            error = '' if rows else 'Ozon не вернул товары (нужен вход в Ozon в окне программы или смена запроса).'
            if result.get('blocked'):
                error = 'Ozon требует проверку входа. Откройте Ozon в окне программы и повторите.'
        except Exception as e:
            rows, error = [], 'Ozon недоступен: %s' % e
        items = [x for x in (_from_ozon(r, rate) for r in rows[:limit]) if x]
        return items, error
    finally:
        if cnx:
            _LOCK.release()


def _search_source(source, query, limit, rate, skip_cache=False):
    """Живой поиск с памятью в процессе: удача держится 30 минут, ошибка — 10.

    skip_cache=True — когда ищем по выбранной категории: результат, случайно взятый
    площадкой из чужого кэша, владелец воспринимает как ошибку категории.
    """
    memo_key = (source, _key(source, query))
    hit = _MEMO.get(memo_key)
    if skip_cache and hit and not hit['error']:
        hit = None
    if hit:
        age = _ts() - hit['at']
        if (not hit['error'] and age <= TTL_OK) or (hit['error'] and age <= TTL_FAIL):
            return hit['items'], hit['error']
    items, error = (_wb_items if source == 'wb' else _ozon_items)(query, limit, rate)
    if not items and not error:
        error = 'По запросу ничего не нашлось.'
    _MEMO[memo_key] = {'at': _ts(), 'error': error, 'items': items}
    if items or not hit:
        _cache_put(query, source, items, error)
    return items, error


# ---------------------------------------------------------------- Kaspi
def _kaspi_blank():
    return {'exact_matches': None, 'sellers': None, 'competitor_price': None,
            'competitor_title': '', 'kaspi_url': '', 'vacuum_status': 'unknown', 'checked': False, 'note': ''}


def _kaspi_title_url(title):
    import urllib.parse
    return 'https://kaspi.kz/shop/search/?text=' + urllib.parse.quote(title or '')


def _photo_set(image):
    """Главное фото + ещё 2 ракурса WB (…/1.webp → 2, 3): так фото сравнивается надёжнее."""
    import re as _re
    if not image:
        return []
    out = [image]
    m = _re.search(r'(/images/[^/]+/)1(\.webp)', image)
    if m:
        out += [image.replace(m.group(0), m.group(1) + str(n) + m.group(2)) for n in (2, 3)]
    return out


def _competitor_link(res):
    """Ссылка на реально найденную карточку Kaspi (а не на поиск по длинному названию WB)."""
    link = str(res.get('competitor_url') or '')
    if link.startswith('/'):
        link = 'https://kaspi.kz' + link
    return link if link.startswith('https://kaspi.kz/') else ''


def _kaspi_probe(item):
    global _LOCK
    q = item.get('kaspi_query') or item.get('name') or ''
    memo_key = ('kaspi', q.lower())
    hit = _VACUUM_MEMO.get(memo_key)
    if hit and _ts() - hit[0] <= TTL_VACUUM:
        return dict(hit[1])
    if not _PROBE_SEM.acquire(timeout=30):          # одновременно не больше 4 проверок Kaspi: быстрее и не злим Kaspi
        return _kaspi_blank()
    try:
        res = check_kaspi_vacuum(item.get('name') or '', q, _photo_set(item.get('image')))
    except Exception as e:
        res = {'vacuum_status': 'unknown', 'explanation': 'Kaspi недоступен: %s' % e}
    finally:
        _PROBE_SEM.release()
    short = {
        'exact_matches': res.get('exact_matches'),
        'sellers': res.get('sellers'),
        'competitor_price': res.get('competitor_price'),
        'competitor_title': res.get('competitor_title') or '',
        'similar_count': res.get('similar_count'),
        'v': 2,                                  # версия правил сопоставления: старый кэш с ложными совпадениями по фото не используем
        'photo_matches': res.get('photo_matches') or 0,
        'reviews_total': res.get('reviews_total'),
        'reviews_per_month': res.get('reviews_per_month'),
        'cards': res.get('cards') or [],
        'kaspi_url': _competitor_link(res) or _kaspi_title_url(res.get('search_query') or item.get('kaspi_query') or item.get('name')),
        'vacuum_status': res.get('vacuum_status') or 'unknown',
        'checked': res.get('vacuum_status') in ('vacuum_full', 'vacuum_low_competition', 'saturated'),
        'note': _short_note(res),
    }
    _VACUUM_MEMO[memo_key] = (_ts(), short)
    if short['checked']:
        data = _load_cache()
        data['vacuum'][_key('kaspi', q)] = dict(short, title=item.get('name'), at=_ts())
        if len(data['vacuum']) > 800:
            for k, _ in sorted(data['vacuum'].items(), key=lambda kv: kv[1].get('at', 0))[:200]:
                data['vacuum'].pop(k, None)
        _save_cache()
    return short


def _short_note(res):
    ex = res.get('exact_matches')
    if ex is None:
        return res.get('explanation') or 'Kaspi не ответил, показана цена-подсказка.'
    sellers = res.get('sellers')
    if res.get('vacuum_status') == 'vacuum_full':
        if res.get('similar_count'):
            return 'Точной карточки на Kaspi не нашли. Похожих: %s (ссылки ниже) — сверьте глазами.' % res.get('similar_count')
        return 'Точных карточек на Kaspi не найдено — ниша свободна.'
    if res.get('vacuum_status') == 'vacuum_low_competition':
        return 'Похожих карточек: %s, продавцов: %s. Слабая конкуренция.' % (ex, sellers if sellers is not None else '?')
    return 'На Kaspi уже %s карточек, продавцов: %s.' % (ex, sellers if sellers is not None else '?')


def _cached_kaspi(item):
    data = _load_cache()['vacuum'].get(_key('kaspi', item.get('kaspi_query') or item.get('name') or ''))
    if not data:
        return None
    if data.get('v') != 2:                                               # запись по старым правилам — перепроверим заново
        return None
    short = {k: v for k, v in data.items() if k != 'at'}
    short.setdefault('kaspi_url', _kaspi_title_url(item.get('kaspi_query') or item.get('name')))
    return short


def _attach_kaspi(item, live):
    info = (_kaspi_probe(item) if live else None) or _cached_kaspi(item) or _kaspi_blank()
    item['kaspi'] = info
    econ = item['economy']
    if not info.get('checked') and info.get('vacuum_status') == 'unknown':
        econ['status'] = 'ESTIMATE'
    return item


def _with_kaspi_price(item, price, estimate=False):
    """Пересчитать вилку по реальной цене Kaspi; estimate — цена-подсказка, а не BuyBox."""
    econ = compute(item['economy']['buy_kzt'], price, item['economy']['rate'], category=item.get('category') or item.get('kaspi_query') or '')
    if estimate:
        econ['status'] = 'ESTIMATE'
    item['economy'] = econ
    item['sell_source'] = 'estimate' if estimate else 'kaspi'
    return item


# ---------------------------------------------------------------- публичный поиск
def _search_phrase(path):
    """Из пути категории WB («Игрушки / Мягкие игрушки») в поиск уходит последний осмысленный сегмент.

    Полный путь с разделителем « / » площадка не находит и отдаёт чужую выдачу.
    """
    parts = [p.strip() for p in str(path or '').split('/') if p.strip()]
    if not parts:
        return ''
    return parts[-1][:200]                # WB: самый точный последний раздел; «Посуда для кухни» шире, чем «Тарелки»


def search_forks(query='', category='', source='all', mode='spread', min_margin=20, limit=40, live_kaspi=True, lazy=False, record=True):
    limit = _int(limit, 40, 1, 200)
    query = ' '.join(str(query or '').split())[:200]
    category = ' '.join(str(category or '').split())[:200]
    by_category = not query and bool(category)      # выбрана категория — площадку спрашиваем её термином
    if by_category:
        query = _search_phrase(category)
    if not query:
        raise ValueError('Введите запрос или выберите категорию.')
    source = source if source in SOURCES else 'all'
    mode = mode if mode in MODES else 'spread'
    min_margin = _int(min_margin, 20, 0, 90)
    rate = _config()
    wanted = max(limit * 2, 40)

    sources = ('wb', 'ozon') if source == 'all' else (source,)
    items, notes, live = [], {}, False
    for src in sources:
        got, error = _search_source(src, query, wanted, rate, skip_cache=by_category)
        if got:
            live = True
            items.extend(got)
        elif error:
            notes[src] = error

    if not items:
        if not by_category:
            cached = []
            for src in sources:
                cached.extend((_cache_get(query, src) or {}).get('items') or [])
            if cached:
                items = cached
                notes['cache'] = 'Сеть площадок не ответила: показаны последние найденные по этому запросу связки из кэша.'
        else:
            notes['category'] = ('По категории «%s» товары сейчас не пришли — показаны эталонные связки по нише, '
                                 'они не из выбранной категории. Проверьте связку кнопкой «Обновить данные».' % query)
        if not items:
            seeds = _seed_items(sources, category or query, rate)
            if seeds:
                items = seeds
                if 'category' not in notes and 'cache' not in notes:
                    notes['cache'] = 'Сеть площадок не ответила: показаны эталонные связки по нише. Цены проверьте кнопкой «Обновить данные».'
    if not items:
        raise ValueError('Ничего не нашлось. ' + ' '.join(notes.values()))

    # Kaspi: живая проверка по 8 связкам шорт-листа (спред — самые прибыльные,
    # оборот — самые дешёвые), не дольше ~25 сек, чтобы UI отдавал результат сразу.
    import time
    from concurrent.futures import ThreadPoolExecutor, wait
    short_ids = {id(x) for x in _shortlist(items, mode)[:(24 if lazy else 8)]}      # в фоновой очереди проверяем больше: список уже на экране
    live_items = []
    for it in items:
        it['_shortlisted'] = bool(live_kaspi and live and id(it) in short_ids)
        if it['_shortlisted']:
            live_items.append(it)
        elif _cached_kaspi(it):
            _attach_kaspi(it, live=False)
        else:
            it['kaspi'] = _kaspi_blank()
            if not live_kaspi:
                notes['kaspi_off'] = 'Включите «Проверять Kaspi сейчас», чтобы подставить реальную цену и число продавцов Kaspi.'
    if live_items and lazy:                          # список отдаём сразу, проверку Kaspi доделает интерфейс по одному товару
        for it in live_items:
            _attach_kaspi(it, live=False)
    elif live_items:                                 # проверка Kaspi по нескольким товарам одновременно (раньше по одному)
        ex = ThreadPoolExecutor(max_workers=4)
        futs = {ex.submit(_attach_kaspi, it, True): it for it in live_items}
        wait(list(futs), timeout=25)
        ex.shutdown(wait=False)
        for it in live_items:
            if 'kaspi' not in it:                    # не успели за 25 секунд — покажем, что есть в кэше, остальное проверит кнопка
                it['kaspi'] = (_cached_kaspi(it) or _kaspi_blank())
    items = _apply_links(items)
    items = _rank(items, mode, rate, live_kaspi, min_margin)
    items = [it for it in items if (it['economy'].get('margin_pct') or 0) >= min_margin]
    pending = [it.get('id') for it in items if lazy and it.get('_shortlisted') and not (it.get('kaspi') or {}).get('checked')]
    for it in items:
        it.pop('_shortlisted', None)
        it['revenue_delta'] = int(it['economy']['sell_kzt'] - it['economy']['buy_kzt'])

    if record:
        data = _load_cache()
        data['last_query'] = {'query': query, 'category': category, 'source': source, 'mode': mode,
                              'min_margin': min_margin, 'at': _now()}
        _save_cache()
    out = {
        'success': True,
        'query': query,
        'category': category,
        'searched_as': query,
        'by_category': by_category,
        'source': source,
        'mode': mode,
        'min_margin': min_margin,
        'live': live,
        'notes': notes,
        'total': len(items),
        'checked_at': _now(),
        'items': items[:limit],
        'pending': pending,
    }
    if record:
        try:
            out['hid'] = _hist_add(out)
        except Exception:
            pass                  # история не должна ломать поиск
    return out


# ---------------------------------------------------------------- подтверждения владельца: «это он» / «не он»
_LINKS_FILE = os.path.join(ROOT, 'data', 'kaspi_links.json')
_LINKS_LOCK = threading.Lock()


def _links_load():
    try:
        with open(_LINKS_FILE, encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _links_write(d):
    os.makedirs(os.path.dirname(_LINKS_FILE), exist_ok=True)
    with open(_LINKS_FILE + '.tmp', 'w', encoding='utf-8') as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(_LINKS_FILE + '.tmp', _LINKS_FILE)


def link_decide(item_id, decision, card):
    """decision: yes — карточка подтверждена; no — карточка отклонена; reset — забыть решения по товару."""
    item_id = str(item_id or '')[:80]
    url = str((card or {}).get('url') or '')
    if not item_id or decision not in ('yes', 'no', 'reset') or (decision != 'reset' and not url.startswith('https://kaspi.kz/')):
        raise ValueError('Не удалось сохранить решение.')
    clean = {k: (card or {}).get(k) for k in ('title', 'price', 'url', 'img', 'brand')}
    sellers = None
    if decision == 'yes':
        import re as _re
        m = _re.search(r'-(\d{5,})/', url)
        if m:
            try:
                from core.kaspi_store import fetch_competitor_prices
                r = fetch_competitor_prices(m.group(1), max_age_sec=1800, min_gap_sec=0.3)
                if r.get('ok'):
                    sellers = len(r.get('offers', []))
            except Exception:
                sellers = None
    with _LINKS_LOCK:
        d = _links_load()
        entry = d.get(item_id) or {}
        if decision == 'yes':
            entry['confirmed'] = clean
            entry['sellers'] = sellers
            entry['at'] = _now()
        elif decision == 'no':
            entry.setdefault('rejected', [])
            if url not in entry['rejected']:
                entry['rejected'].append(url)
            if (entry.get('confirmed') or {}).get('url') == url:
                entry.pop('confirmed', None)
        else:
            entry = {}
        if entry:
            d[item_id] = entry
        else:
            d.pop(item_id, None)
        _links_write(d)


def _fix_kurl(u):
    return u.replace('https://kaspi.kz/p/', 'https://kaspi.kz/shop/p/', 1) if isinstance(u, str) else u


def _apply_links(items):
    for it in items:                      # старые сохранённые результаты содержат ссылки /p/… (404): приводим к /shop/p/…
        ks0 = it.get('kaspi') or {}
        if ks0.get('kaspi_url'):
            ks0['kaspi_url'] = _fix_kurl(ks0['kaspi_url'])
        if ks0.get('competitor_url'):
            ks0['competitor_url'] = _fix_kurl(ks0['competitor_url'])
        for c in ks0.get('cards') or []:
            c['url'] = _fix_kurl(c.get('url'))
    links = _links_load()
    if not links:
        return items
    for lk in links.values():
        if (lk.get('confirmed') or {}).get('url'):
            lk['confirmed']['url'] = _fix_kurl(lk['confirmed']['url'])
    for it in items:
        link = links.get(str(it.get('id')))
        if not link:
            continue
        ks = dict(it.get('kaspi') or _kaspi_blank())
        conf = link.get('confirmed')
        if conf:
            n = link.get('sellers')
            ks.update(checked=True, sellers=n, kaspi_url=conf.get('url') or ks.get('kaspi_url'),
                      vacuum_status='vacuum_low_competition' if (n or 0) <= 3 else 'saturated', confirmed=True,
                      cards=[dict(conf, score=100, exact=True, confirmed=True)],
                      note='Карточка подтверждена вами. Продавцов: %s.' % (n if n is not None else 'не получено'))
        elif link.get('rejected'):
            ks['cards'] = [c for c in (ks.get('cards') or []) if c.get('url') not in link['rejected']]
        it['kaspi'] = ks
    return items


# ---------------------------------------------------------------- история поиска (хранится на диске)
_HIST_FILE = os.path.join(ROOT, 'data', 'forks_history.json')
_HIST_LOCK = threading.Lock()
_HIST_MAX = 25


def _hist_load():
    try:
        with open(_HIST_FILE, encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _hist_write(lst):
    os.makedirs(os.path.dirname(_HIST_FILE), exist_ok=True)
    with open(_HIST_FILE + '.tmp', 'w', encoding='utf-8') as f:
        json.dump(lst, f, ensure_ascii=False)
    os.replace(_HIST_FILE + '.tmp', _HIST_FILE)


def _hist_add(result):
    key = '|'.join([str(result.get('category') or ''), str(result.get('query') or ''),
                    str(result.get('source') or ''), str(result.get('mode') or ''), str(result.get('min_margin') or '')])
    hid = hashlib.sha1(key.encode('utf-8')).hexdigest()[:10]
    entry = {'id': hid, 'label': result.get('category') or result.get('query') or '', 'by_category': bool(result.get('by_category')),
             'source': result.get('source'), 'mode': result.get('mode'), 'at': result.get('checked_at'),
             'total': result.get('total'), 'result': dict(result, hid=hid)}
    with _HIST_LOCK:
        lst = [e for e in _hist_load() if e.get('id') != hid]
        lst.insert(0, entry)
        _hist_write(lst[:_HIST_MAX])
    return hid


def hist_clear():
    """Очищает историю поисков (только список на этом компьютере)."""
    with _HIST_LOCK:
        _hist_write([])


def hist_list():
    return [{k: e.get(k) for k in ('id', 'label', 'by_category', 'source', 'mode', 'at', 'total')} for e in _hist_load()]


def hist_get(hid):
    for e in _hist_load():
        if e.get('id') == hid:
            res = e.get('result')
            if isinstance(res, dict):
                _apply_links(res.get('items') or [])
            return res
    return None


def hist_update_kaspi(hid, item_id, info):
    with _HIST_LOCK:
        lst = _hist_load()
        for e in lst:
            if e.get('id') == hid:
                for it in (e.get('result') or {}).get('items', []):
                    if str(it.get('id')) == str(item_id):
                        it['kaspi'] = info
                _hist_write(lst)
                return


def _seed_items(sources, needle, rate):
    words = {w[:5] for w in _words(needle)}
    out = []
    for seed in _load_cache().get('seeds') or []:
        if seed.get('source') not in sources:
            continue
        tags = {t.lower() for t in seed.get('tags') or []}
        title_stems = {w[:5] for w in _words(seed.get('name'))}
        if words and not (words & tags or words & title_stems):
            continue
        it = _seed_to_item(seed, rate)
        if it:
            out.append(it)
    return out


def _seed_to_item(seed, rate):
    buy = seed.get('buy_kzt')
    if not buy:
        return None
    econ = compute(buy, seed.get('sell_kzt') or 0, rate, category=seed.get('category') or '')
    item = {
        'id': 'seed:%s' % seed.get('id'),
        'source': seed.get('source') or 'wb',
        'source_label': 'Wildberries' if seed.get('source') == 'wb' else 'Ozon',
        'name': seed.get('name') or '',
        'brand': seed.get('brand') or '',
        'image': seed.get('image') or '',
        'url': seed.get('url') or '',
        'rating': seed.get('rating'),
        'feedbacks': int(seed.get('feedbacks') or 0),
        'stock': None,
        'category': seed.get('category') or '',
        'sell_source': 'estimate',
        'kaspi_query': seed.get('kaspi_query') or ' '.join(_words(seed.get('name'))[:3]),
        'economy': econ,
        'seed': True,
    }
    it_ks = seed.get('kaspi') or {}
    item['kaspi'] = {
        'exact_matches': it_ks.get('exact_matches'),
        'sellers': it_ks.get('sellers'),
        'competitor_price': it_ks.get('competitor_price'),
        'competitor_title': '',
        'kaspi_url': _kaspi_title_url(item['kaspi_query']),
        'vacuum_status': it_ks.get('vacuum_status') or 'unknown',
        'checked': False,
        'note': 'Эталонная связка из кэша. Нажмите «Обновить данные» для живой проверки.',
    }
    return item


# ---------------------------------------------------------------- ранжирование
def _shortlist(items, mode):
    """Спред: самые прибыльные. Оборот: самый мелкий чек (там рейтинг 4.7+ и есть смысл сверять Kaspi)."""
    if mode == 'speed':
        return sorted(items, key=lambda x: x['economy'].get('buy_kzt') or 10 ** 9)[:40]
    # Прибыль до проверки Kaspi условная (формула ×2,4 — это просто цена), поэтому первыми проверяем то, что
    # на WB реально покупают: рейтинг от 4,5 и больше отзывов. Так в проверку попадают товары со спросом.
    def demand(x):
        return (0 if (x.get('rating') or 0) >= 4.5 or not x.get('rating') else 1, -(x.get('feedbacks') or 0),
                -(x['economy'].get('profit_kzt') or 0))
    return sorted(items, key=demand)[:40]


MAX_RATIO_NO_PHOTO = 3.5


def market_price(info):
    """Реальная цена Kaspi: минимальная цена ТОЧНЫХ карточек (по фото или названию). Похожие карточки не в счёт."""
    info = info or {}
    if info.get('vacuum_status') not in ('saturated', 'vacuum_low_competition'):
        return 0
    if not (info.get('exact_matches') or 0):
        return 0
    return int(info.get('competitor_price') or 0)


def _similar_prices(info):
    return sorted(int(c.get('price') or 0) for c in ((info or {}).get('cards') or [])
                  if not c.get('exact') and not c.get('confirmed') and (c.get('price') or 0) > 0)


def price_risk(item):
    """Расчётная цена (×2,4) выше цен похожих карточек Kaspi вдвое и больше — прибыль, скорее всего, завышена."""
    if item.get('sell_source') == 'kaspi':
        return ''
    prices = _similar_prices(item.get('kaspi'))
    sell = (item.get('economy') or {}).get('sell_kzt') or 0
    if len(prices) >= 3 and sell:
        med = prices[len(prices) // 2]
        if med * 2 < sell:
            return 'Похожие на Kaspi стоят около %s ₸ (в 2 раза и более дешевле расчётной цены): прибыль, скорее всего, завышена.' % '{:,}'.format(med).replace(',', ' ')
    return ''


def confidence(item):
    """verified — цена продажи реальная (точная карточка на Kaspi); free — на Kaspi такого нет, цена гипотеза;
    estimate — Kaspi не проверен."""
    if item.get('sell_source') == 'kaspi':
        return 'verified'
    return 'free' if (item.get('kaspi') or {}).get('checked') else 'estimate'


_CONF_ORDER = {'verified': 0, 'free': 1, 'estimate': 2}


def reprice(item):
    """Подставить реальную цену Kaspi, если точная карточка найдена; пометить риск и уровень доверия."""
    info = item.get('kaspi') or {}
    price = market_price(info)
    mismatch = ''
    if price and not item.get('seed'):
        buy = (item.get('economy') or {}).get('buy_kzt') or 0
        # Совпало по названию, но не по фото, а цена карточки в 3,5+ раза выше закупки: почти наверняка другой товар
        if buy and not info.get('photo_matches') and price / buy > MAX_RATIO_NO_PHOTO:
            mismatch = ('Карточка Kaspi дороже закупки в %.1f раза, а фото не совпало: скорее всего, это другой товар или другой комплект. '
                        'Цена Kaspi не использована.' % (price / buy)).replace('.', ',')
        else:
            _with_kaspi_price(item, price)
    item['price_risk'] = mismatch or price_risk(item)
    item['confidence'] = confidence(item)
    return item


def _rank(items, mode, rate, live_kaspi, min_margin=0):
    seen = set()
    uniq = []
    for it in items:
        if it['id'] in seen:
            continue
        seen.add(it['id'])
        uniq.append(it)
    # одинаковые товары под разными id (цвета, дубли продавца): оставляем один — с большим числом отзывов
    best = {}
    for it in uniq:
        k = (it.get('source'), ' '.join(str(it.get('name') or '').lower().split()),
             int((it.get('economy') or {}).get('buy_kzt') or 0))
        if k not in best or (it.get('feedbacks') or 0) > (best[k].get('feedbacks') or 0):
            best[k] = it
    uniq = [it for it in uniq if best[(it.get('source'), ' '.join(str(it.get('name') or '').lower().split()),
                                       int((it.get('economy') or {}).get('buy_kzt') or 0))] is it]

    def by_profit(x):
        return x['economy'].get('profit_kzt') or 0

    def by_buy(x):
        return x['economy'].get('buy_kzt') or 10 ** 9

    if mode in ('spread', 'speed') and live_kaspi:
        # если у связки есть реальная цена Kaspi (точная карточка) — считаем прибыль от неё, а не от формулы
        for it in uniq:
            reprice(it)
        groups = {}
        for it in uniq:                          # несколько разных связок WB на одну карточку Kaspi — вероятно, разные комплекты/размеры
            if it.get('sell_source') == 'kaspi':
                groups.setdefault(((it.get('kaspi') or {}).get('competitor_title'), it['economy'].get('sell_kzt')), []).append(it)
        for g in groups.values():
            for it in g:
                it['group_note'] = ('К этой карточке Kaspi подошло %d связок WB с разной закупкой: проверьте, что комплект и размер те же.' % len(g)) if len(g) > 1 else ''
    if mode == 'spread':
        # сначала связки с реальной ценой Kaspi, потом «на Kaspi такого нет», потом непроверенные (там маржа условная)
        return sorted(uniq, key=lambda x: (_CONF_ORDER.get(x.get('confidence') or confidence(x), 2), -by_profit(x), -(x.get('rating') or 0)))
    if mode == 'speed':
        shortlisted = [x for x in uniq if x.get('_shortlisted')]
        if shortlisted:
            return sorted(shortlisted, key=lambda x: (_CONF_ORDER.get(x.get('confidence') or confidence(x), 2),
                                                      0 if (x.get('rating') or 0) >= 4.7 else 1,
                                                      by_buy(x), -by_profit(x)))

        def speed_key(x):
            rating_ok = (x.get('rating') or 0) >= 4.7
            return (0 if rating_ok else 1, x['economy'].get('buy_kzt') or 10 ** 9,
                    -(x['economy'].get('profit_kzt') or 0))
        return sorted(uniq, key=speed_key)
    # vacuum: хиты, которых нет на Kaspi (0 конкурентов) или почти нет
    out = []
    for it in uniq:
        ks = it.get('kaspi') or {}
        if not ks.get('checked'):
            continue
        if ks.get('vacuum_status') == 'vacuum_full':
            it['vacuum_level'] = 'free'
        elif (ks.get('vacuum_status') == 'vacuum_low_competition' and (ks.get('sellers') or 99) <= VACUUM_MAX_SELLERS):
            it['vacuum_level'] = 'weak'
        else:
            continue
        hits = it.get('feedbacks') or 0
        if it.get('source') == 'wb' and hits < VACUUM_MIN_FEEDBACKS:
            continue
        # вакуум — про свободную нишу, но убыточную связку не показываем
        if it['kaspi'].get('competitor_price'):
            _with_kaspi_price(it, it['kaspi']['competitor_price'], estimate=bool(it.get('seed')))
        if (it['economy'].get('margin_pct') or 0) < min_margin:
            continue
        out.append(it)
    return sorted(out, key=lambda x: (x.get('vacuum_level') != 'free', -(x.get('feedbacks') or 0),
                                      -(x['economy'].get('profit_kzt') or 0)))


# ---------------------------------------------------------------- сохранение в «Найденное»
def save_to_found(payload):
    items = payload.get('items')
    if not isinstance(items, list) or not items:
        raise ValueError('Не выбраны связки для сохранения.')
    from core import found
    groups = {}
    for it in items[:50]:
        if not isinstance(it, dict) or it.get('seed'):
            continue
        econ = it.get('economy') or {}
        source = it.get('source') if it.get('source') in ('wb', 'ozon') else 'wb'
        groups.setdefault(source, []).append({
            'id': str(it.get('id') or '').split(':', 1)[-1][:60],
            'name': it.get('name') or '',
            'url': it.get('url') or '',
            'image': it.get('image') or '',
            'price': econ.get('buy_kzt'),
            'rating': it.get('rating'),
            'feedbacks': it.get('feedbacks'),
            'brand': it.get('brand') or '',
        })
    added = updated = 0
    for source, batch in groups.items():
        a, u, _ = found.add_many(source, batch, payload.get('query') or 'радар вилок')
        added += a
        updated += u
    return {'success': True, 'added': added, 'updated': updated,
            'message': 'В «Найденное» добавлено: %d, обновлено: %d.' % (added, updated)}


# ---------------------------------------------------------------- индекс категорий
def categories():
    file = os.path.join(ROOT, 'static', 'wb_categories.json')
    try:
        with open(file, encoding='utf-8') as f:
            tree = json.load(f)
    except (OSError, ValueError):
        tree = []
    leaves = []
    for root in tree if isinstance(tree, list) else []:
        rname = str(root.get('n') or '')
        for child in root.get('c') or []:
            cname = str(child.get('n') or '')
            subs = child.get('c') or []
            if subs:
                for leaf in subs:
                    leaves.append({'name': str(leaf.get('n') or ''), 'path': [rname, cname, str(leaf.get('n') or '')]})
            elif cname:
                leaves.append({'name': cname, 'path': [rname, cname]})
    return {'success': True, 'total': len(leaves), 'items': leaves}


# ---------------------------------------------------------------- Flask
def register(app):
    from flask import jsonify, request

    def api_forks():
        args = request.args
        try:
            data = search_forks(
                query=args.get('query') or '',
                category=args.get('category') or '',
                source=args.get('source') or 'all',
                mode=args.get('mode') or 'spread',
                min_margin=args.get('min_margin') or 20,
                limit=_int(args.get('limit'), 40, 1, 200),
                live_kaspi=(args.get('live_kaspi', '1') != '0'),
                lazy=(args.get('lazy') == '1'),
            )
        except ValueError as e:
            return jsonify(success=False, error=str(e)), 400
        except RadarBusy as e:
            return jsonify(success=False, error=str(e)), 429
        except Exception as e:
            _WARN.append(str(e))
            return jsonify(success=False, error='Радар временно недоступен: %s' % e), 503
        return jsonify(data)

    def api_save():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(success=False, error='Ожидается список связок.'), 400
        try:
            return jsonify(save_to_found(data))
        except ValueError as e:
            return jsonify(success=False, error=str(e)), 400

    def api_categories():
        return jsonify(categories())

    def api_kaspi_check():
        data = request.get_json(silent=True)
        if not isinstance(data, dict) or not str(data.get('name') or '').strip():
            return jsonify(success=False, error='Не передано название товара.'), 400
        item = {'name': str(data.get('name'))[:300], 'kaspi_query': str(data.get('kaspi_query') or '')[:300],
                'image': str(data.get('image') or '')[:500]}
        info = _kaspi_probe(item)
        if not info.get('checked'):
            return jsonify(success=False, error=info.get('note') or 'Kaspi сейчас не ответил. Повторите через минуту.'), 503
        econ_out = {}
        try:                                          # пересчёт вилки по реальной цене Kaspi (раньше он делался только при новом поиске)
            buy = float(data.get('buy_kzt') or 0)
            if buy > 0:
                tmp = {'name': item['name'], 'kaspi': info, 'sell_source': 'estimate',
                       'economy': compute(buy, 0, float(data.get('rate') or 0) or DEFAULT_RATE, category=str(data.get('category') or data.get('kaspi_query') or ''))}
                reprice(tmp)
                econ_out = {'economy': tmp['economy'], 'sell_source': tmp['sell_source'],
                            'price_risk': tmp['price_risk'], 'confidence': tmp['confidence']}
        except Exception:
            econ_out = {}
        if data.get('hid') and data.get('id'):
            try:
                hist_update_kaspi(str(data['hid'])[:20], data['id'], info)
            except Exception:
                pass
        return jsonify(dict(success=True, kaspi=info, **econ_out))

    def api_hist():
        return jsonify(success=True, items=hist_list())

    def api_hist_one(hid):
        res = hist_get(hid)
        if not res:
            return jsonify(success=False, error='Этот поиск уже удалён из истории.'), 404
        return jsonify(res)

    def api_hist_clear():
        hist_clear()
        return jsonify(success=True, items=[])

    app.add_url_rule('/api/radar/forks_history/clear', 'radar_forks_history_clear', api_hist_clear, methods=['POST'])
    app.add_url_rule('/api/radar/forks_history', 'radar_forks_history', api_hist, methods=['GET'])
    app.add_url_rule('/api/radar/forks_history/<hid>', 'radar_forks_history_one', api_hist_one, methods=['GET'])
    def api_kaspi_confirm():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(success=False, error='Ожидаются данные.'), 400
        try:
            link_decide(data.get('id'), data.get('decision'), data.get('card'))
        except ValueError as e:
            return jsonify(success=False, error=str(e)), 400
        probe = [{'id': str(data.get('id')), 'kaspi': data.get('kaspi') if isinstance(data.get('kaspi'), dict) else {}}]
        _apply_links(probe)
        info = probe[0]['kaspi']
        if data.get('hid'):
            try:
                hist_update_kaspi(str(data['hid'])[:20], data['id'], info)
            except Exception:
                pass
        return jsonify(success=True, kaspi=info)

    app.add_url_rule('/api/radar/kaspi_confirm', 'radar_kaspi_confirm', api_kaspi_confirm, methods=['POST'])
    app.add_url_rule('/api/radar/kaspi_check', 'radar_kaspi_check', api_kaspi_check, methods=['POST'])
    app.add_url_rule('/api/radar/forks', 'radar_forks', api_forks, methods=['GET'])
    app.add_url_rule('/api/radar/save_to_found', 'radar_save_to_found', api_save, methods=['POST'])
    app.add_url_rule('/api/radar/categories', 'radar_categories', api_categories, methods=['GET'])