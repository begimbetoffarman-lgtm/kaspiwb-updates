"""«В пути» и «Возвраты»: что с заказом после передачи курьеру и где деньги/товар по возвратам.
Данные из API Kaspi (только чтение). Ваши отметки «товар пришёл / забрал» хранятся в data/returns.json.
Контакты покупателей здесь не используются и не сохраняются."""
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from core import orders_screen as osr

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_FILE = os.path.join(ROOT, "data", "returns.json")
_LOCK = threading.Lock()
DAY = 86400000
RETURN_STATUSES = {"RETURNED", "KASPI_DELIVERY_RETURN_REQUESTED"}
STATUS_RU = {"RETURNED": "Возврат оформлен", "KASPI_DELIVERY_RETURN_REQUESTED": "Запрошен возврат",
             "CANCELLED": "Отмена после передачи курьеру"}


def _load():
    try:
        with open(_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(d):
    os.makedirs(os.path.dirname(_FILE), exist_ok=True)
    with open(_FILE + ".tmp", "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(_FILE + ".tmp", _FILE)


def _fetch(state, start_ms, end_ms):
    out = []
    for page in range(3):
        try:
            d = osr._get("https://kaspi.kz/shop/api/v2/orders?page[number]=%d&page[size]=100"
                         "&filter[orders][state]=%s&filter[orders][creationDate][$ge]=%d&filter[orders][creationDate][$le]=%d"
                         % (page, state, start_ms, end_ms))
        except Exception:
            break
        data = d.get("data", [])
        out += data
        if len(data) < 100:
            break
    return out


def _scan(states, windows=1):
    """Заказы указанных состояний за windows*14 дней (Kaspi отдаёт не больше 14 дней за один запрос)."""
    now = int(time.time() * 1000)
    jobs = [(s, now - (w + 1) * 14 * DAY, now - w * 14 * DAY) for s in states for w in range(windows)]
    with ThreadPoolExecutor(4) as ex:
        res = list(ex.map(lambda j: _fetch(*j), jobs))
    seen, out = set(), []
    for chunk in res:
        for o in chunk:
            if o["id"] not in seen:
                seen.add(o["id"])
                out.append(o)
    return out


def _date(ms):
    return osr._day(ms) if ms else None


def _items(orders):
    with ThreadPoolExecutor(6) as ex:
        return list(ex.map(lambda o: osr._entries(o["id"]), orders))


def _flat(items):
    return [{"sku": i.get("sku"), "name": i.get("name"), "qty": i.get("qty")} for i in items]


def transit():
    """Переданные курьеру заказы (в пути), ожидающие передачи и недавно доставленные."""
    now = int(time.time() * 1000)
    live = _scan(["KASPI_DELIVERY", "DELIVERY", "PICKUP"])
    done = _scan(["ARCHIVE"])
    waiting, moving = [], []
    for o in live:
        a = o["attributes"]
        if a.get("status") in osr.DONE:
            continue
        kd = a.get("kaspiDelivery") or {}
        (moving if kd.get("courierTransmissionDate") else waiting).append(o)
    delivered = [o for o in done if o["attributes"].get("status") == "COMPLETED"]
    delivered.sort(key=lambda o: o["attributes"].get("completionDate") or 0, reverse=True)
    delivered = delivered[:15]
    show = moving + delivered
    ents = _items(show)
    rows = []
    for o, it in zip(show, ents):
        a = o["attributes"]
        kd = a.get("kaspiDelivery") or {}
        is_done = a.get("status") == "COMPLETED"
        planned = a.get("plannedDeliveryDate")
        rows.append({
            "code": str(a.get("code")), "done": is_done, "total": a.get("totalPrice"), "city": (a.get("deliveryAddress") or {}).get("town"),
            "handed": _date(kd.get("courierTransmissionDate")), "planned": _date(planned),
            "completed": _date(a.get("completionDate")),
            "late": bool(planned and not is_done and planned < now), "items": _flat(it),
        })
    rows.sort(key=lambda r: (r["done"], not r["late"]))
    return {"in_transit": sum(1 for r in rows if not r["done"]), "waiting": len(waiting),
            "late": sum(1 for r in rows if r["late"]), "rows": rows}


def returns():
    """Возвраты за ~42 дня + ваши отметки. Найденные возвраты запоминаются и не пропадают, когда выходят из окна Kaspi."""
    orders = _scan(["ARCHIVE", "KASPI_DELIVERY", "DELIVERY", "PICKUP"], windows=3)
    cases = []
    for o in orders:
        a = o["attributes"]
        st = a.get("status")
        kd = a.get("kaspiDelivery") or {}
        if st in RETURN_STATUSES or (st == "CANCELLED" and kd.get("courierTransmissionDate")):
            cases.append(o)
    ents = _items(cases)
    with _LOCK:
        store = _load()
        for o, it in zip(cases, ents):
            a = o["attributes"]
            kd = a.get("kaspiDelivery") or {}
            code = str(a.get("code"))
            cur = store.get(code) or {"first_seen": time.strftime("%Y-%m-%d"), "got": False, "got_at": None}
            cur.update({"code": code, "status": a.get("status"), "total": a.get("totalPrice"),
                        "city": (a.get("deliveryAddress") or {}).get("town"),
                        "handed": _date(kd.get("courierTransmissionDate")), "created": _date(a.get("creationDate")),
                        "reason": a.get("cancellationReason") or "", "kaspi_wh": bool(kd.get("returnedToWarehouse")),
                        "items": _flat(it) or cur.get("items", [])})
            store[code] = cur
        _save(store)
    rows = sorted(store.values(), key=lambda r: (r.get("got"), r.get("first_seen") or ""), reverse=False)
    for r in rows:
        r["status_ru"] = STATUS_RU.get(r.get("status"), r.get("status"))
        r["state"] = ("забрал" if r.get("got") else "на складе Kaspi — заберите" if r.get("kaspi_wh")
                      else "возврат оформлен — отметьте, когда получите" if r.get("status") == "RETURNED" else "ещё в пути")
    open_rows = [r for r in rows if not r.get("got")]
    total = sum(float(r.get("total") or 0) for r in rows)
    open_sum = sum(float(r.get("total") or 0) for r in open_rows)
    # доля возвратов по товарам за период
    stat = {}
    for r in rows:
        for i in r.get("items") or []:
            k = i.get("sku") or i.get("name")
            s = stat.setdefault(k, {"sku": i.get("sku"), "name": i.get("name"), "returns": 0, "sold": 0})
            s["returns"] += int(i.get("qty") or 1)
    completed = [o for o in orders if o["attributes"].get("status") == "COMPLETED"][:60]
    if stat and completed:                       # продажи считаем только когда есть что сравнивать
        for o, it in zip(completed, _items(completed)):
            for i in it:
                k = i.get("sku") or i.get("name")
                if k in stat:
                    stat[k]["sold"] += int(i.get("qty") or 1)
    top = sorted(stat.values(), key=lambda s: -s["returns"])[:8]
    for s in top:
        base = s["sold"] + s["returns"]
        s["rate"] = round(100.0 * s["returns"] / base) if base else None
    return {"rows": rows, "count": len(rows), "open_count": len(open_rows), "total": round(total),
            "open_sum": round(open_sum), "top": top}


def mark(code, got):
    code = str(code or "")[:40]
    with _LOCK:
        store = _load()
        if code not in store:
            raise ValueError("Такого возврата нет в списке.")
        store[code]["got"] = bool(got)
        store[code]["got_at"] = time.strftime("%Y-%m-%d") if got else None
        _save(store)
    return store[code]


def digest():
    """Короткая сводка для верха раздела: сколько собрать, что в пути, какие возвраты ждут и на какую сумму."""
    act = _scan(["NEW", "KASPI_DELIVERY", "DELIVERY", "PICKUP"])
    live = [o for o in act if o["attributes"].get("status") not in osr.DONE]
    to_collect = sum(1 for o in live if not o["attributes"].get("assembled"))
    moving = sum(1 for o in live if (o["attributes"].get("kaspiDelivery") or {}).get("courierTransmissionDate"))
    store = _load()
    open_ret = [r for r in store.values() if not r.get("got")]
    return {"to_collect": to_collect, "in_transit": moving, "returns_open": len(open_ret),
            "returns_open_sum": round(sum(float(r.get("total") or 0) for r in open_ret))}


def deadlines():
    """Ближайшие сроки: что передать курьеру в первую очередь и какие возвраты висят дольше недели."""
    now = int(time.time() * 1000)
    live = [o for o in _scan(["NEW", "KASPI_DELIVERY", "DELIVERY", "PICKUP"]) if o["attributes"].get("status") not in osr.DONE]
    todo = []
    for o in live:
        a = o["attributes"]
        kd = a.get("kaspiDelivery") or {}
        plan = kd.get("courierTransmissionPlanningDate")
        if plan and not kd.get("courierTransmissionDate"):
            todo.append((plan, str(a.get("code")), a.get("assembled")))
    todo.sort()
    out = []
    for plan, code, assembled in todo[:5]:
        left = (plan - now) / 3600000
        out.append({"text": "Передать заказ %s до %s%s" % (code, osr._day(plan), "" if assembled else " (не собран)"),
                    "level": "late" if left < 0 else ("soon" if left < 24 else "ok")})
    week_ago = time.strftime("%Y-%m-%d", time.localtime(time.time() - 7 * 86400))
    for r in _load().values():
        if not r.get("got") and (r.get("first_seen") or "9") < week_ago:
            out.append({"text": "Возврат по заказу %s на %s ждёт отметки больше недели"
                        % (r.get("code"), "{:,.0f} ₸".format(float(r.get("total") or 0)).replace(",", " ")), "level": "late"})
    try:
        from core import auto_preorder as _ap
        for a in _ap.alerts()[:4]:
            out.insert(0, {"text": "Ушёл в предзаказ: %s. Закажите поставщику, чтобы пополнить остаток" % a["title"], "level": "soon"})
    except Exception:
        pass
    return {"items": out[:8]}
