def generate_kaspi_description(item: dict) -> str:
    name = item.get("kaspi_name") or item.get("name", "Товар")
    brand = item.get("brand", "ProHome")
    cat = item.get("category", "Товары для дома")
    
    desc = f"""🔥 {name.upper()} — ОРИГИНАЛЬНОЕ КАЧЕСТВО И ПРЕМИУМ ДИЗАЙН

✦ ГЛАВНЫЕ ПРЕИМУЩЕСТВА:
• 100% практичность и экономия пространства: продуманная эргономика для максимального удобства каждый день.
• Высокопрочные износостойкие материалы: устойчивы к влаге, повреждениям и перепадам температур.
• Быстрая и простая установка: не требует специальных инструментов, готов к использованию за считанные минуты.
• Современный минимализм: лаконичный дизайн, который органично впишется в интерьер вашего дома или авто.

📦 КОМПЛЕКТАЦИЯ И СВОЙСТВА:
• Бренд: {brand}
• Категория: {cat}
• Комплектация: Товар в заводской защитной упаковке, полный комплект монтажа/аксессуаров, руководство.

🛡 ПРЕДЗАКАЗ И ГАРАНТИЯ:
Товар поставляется под заказ с обязательным входным контролем качества перед отправкой клиенту. Гарантия целостности и соответствия описанию."""
    return desc.strip()


# ---------------------------------------------------------------- шаблонный текст карточки (без внешнего ИИ)
import re as _re

_CJK_RE = _re.compile(r'[㐀-鿿]+')


def _clean(text):
    s = _CJK_RE.sub(' ', str(text or ''))
    return _re.sub(r'\s+', ' ', s).strip(' —-;,/')


def build_card_text(d):
    """Название и описание для Kaspi по-русски, только по фактам из карточки/1688 (ничего не выдумываем).
    Возвращает {'title': str, 'description': str}. Нераспознанные иероглифы выбрасываются; проверяет человек."""
    from core import supplier_attrs
    cat = _clean(d.get('category_title'))
    brand = _clean(d.get('brand'))
    old = _clean(d.get('title'))
    opts, seen = [], set()
    for o in (supplier_attrs.card_for(d).get('options') or []):
        name, val = str(o.get('name') or '').strip(), str(o.get('value') or '').strip()
        if name and val and (name, val) not in seen:
            seen.add((name, val))
            opts.append((name, val))
    color = next((v for n, v in opts if n == 'цвет'), '')
    base = old or (cat.split('/')[-1].strip() if cat else '') or 'Товар'
    title = base
    if brand and brand.lower() not in title.lower():
        title = f'{title} {brand}'
    if color and color.lower() not in title.lower():
        title = f'{title}, {color}'
    title = title[:200]
    lines = [base + '.']
    if cat:
        lines.append('Категория: ' + cat.replace(' / ', ' → ') + '.')
    if opts:
        lines += ['', 'Характеристики:'] + [f'• {n.capitalize()}: {v}' for n, v in opts]
    lines += ['', 'Товар под заказ: срок доставки указан в карточке. Перед отправкой проверяем комплектацию и внешний вид.']
    return {'title': title, 'description': '\n'.join(lines)}
