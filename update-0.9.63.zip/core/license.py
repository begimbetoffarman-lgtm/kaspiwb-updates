"""Лицензия: подписанные ключи (Ed25519), проверка у клиента без сервера.
Ключ выписывает только владелец закрытого ключа (D:\\kaspi-arbitrage-license-private\\make_license.py); в программе лежит
только открытая часть — она умеет проверять подпись, но не умеет выпускать ключи. Ключ содержит имя, срок и номер ПК
(или "*" — любой компьютер). Пробный период хранится в data/.license.json (подписан HMAC)."""
import base64
import hashlib
import hmac
import json
import math
import os
import time
import uuid

from core import ed25519

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
LICENSE_FILE = os.path.join(DATA_DIR, ".license.json")

PUBLIC_KEY = bytes.fromhex("08df876180b0865a481dcec523747803d6ec94710553b6ea0fdd59f1c884ea49")
_LOCAL_SALT = "KaspiWB-local-v2"        # только для отпечатка ПК и подписи файла пробного периода
TRIAL_DURATION_SECONDS = 12 * 24 * 3600  # 12 дней: у тех, кто начал пробу до TRIAL_CUTOFF (текущие тестировщики)
NEW_TRIAL_DURATION_SECONDS = 7 * 24 * 3600  # 7 дней: для всех, кто начал пробу позже
# Граница между «старой» и «новой» пробой: момент выпуска 0.9.61 (13.11.2026). Начавшие пробу раньше сохраняют 12 дней.
# иначе установившие в промежутке получат 7 дней вместо обещанных 12.
TRIAL_CUTOFF = 1794558914


def trial_seconds(start):
    """Длина пробного периода для начавшего в момент start: 12 дней до границы, 7 после, плюс бонус кода друга."""
    base = TRIAL_DURATION_SECONDS if start < TRIAL_CUTOFF else NEW_TRIAL_DURATION_SECONDS
    try:
        from core import referral
        base += referral.bonus_days() * 86400
    except Exception:
        pass
    return base


def get_machine_id():
    """Стабильный отпечаток этого компьютера (показывается в окне активации)."""
    try:
        raw = f"{uuid.getnode()}:{os.environ.get('USERNAME', os.environ.get('USER', 'kaspi_seller'))}:KaspiArbitragePro2026_SecuredKey_SaltX9"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16].upper()
    except Exception:
        return "KASPI-CLIENT-MACHINE-01"


def stable_id():
    """Постоянный отпечаток ПК: идентификатор самой системы (не меняется от сетевых адаптеров, VPN, Wi-Fi).
    Windows: MachineGuid, macOS: IOPlatformUUID, Linux: /etc/machine-id. None, если получить не удалось."""
    raw = ""
    try:
        if os.name == "nt":
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
                                0, winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)) as k:
                raw = str(winreg.QueryValueEx(k, "MachineGuid")[0])
        else:
            import subprocess
            if os.path.exists("/usr/sbin/ioreg"):
                out = subprocess.run(["/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                                     capture_output=True, text=True, timeout=5).stdout
                raw = next((l.split('"')[-2] for l in out.splitlines() if "IOPlatformUUID" in l), "")
            elif os.path.exists("/etc/machine-id"):
                raw = open("/etc/machine-id").read().strip()
    except Exception:
        raw = ""
    raw = raw.strip().lower()
    if len(raw) < 8:
        return None
    return hashlib.sha256(("KWB-stable-v1:" + raw).encode("utf-8")).hexdigest()[:16].upper()


def display_id():
    """Номер ПК для окна активации: постоянный, а если его не получить, прежний."""
    return stable_id() or get_machine_id()


def _sign_payload(data):
    clean = f"{data.get('machine_id')}:{data.get('first_run')}:{data.get('license_key')}:{data.get('status')}"
    if data.get("stable_id"):          # у новых файлов отпечаток тоже под подписью (иначе файл можно перенести на другой ПК)
        clean += ":" + str(data["stable_id"])
    return hmac.new(_LOCAL_SALT.encode(), clean.encode(), hashlib.sha256).hexdigest()


SERVER_TRIAL_FILE = os.path.join(DATA_DIR, ".trial_server.json")


def merchant_hash():
    """sha256 номера магазина Kaspi (сам номер наружу не уходит). Пусто, если магазин ещё не указан."""
    try:
        from core import secrets as _sec
        mid = str(_sec._raw().get("kaspi_merchant_id") or "").strip()
    except Exception:
        mid = ""
    return hashlib.sha256(("KWB|" + mid).encode("utf-8")).hexdigest() if mid else ""


def save_server_trial(mh, first_seen):
    """Запоминает ответ сервера: когда этот магазин впервые начал пробный период (одна проба на магазин)."""
    d = {"merchant_hash": mh, "first_seen": int(first_seen)}
    d["signature"] = hmac.new(_LOCAL_SALT.encode(), f"{mh}:{d['first_seen']}".encode(), hashlib.sha256).hexdigest()
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(SERVER_TRIAL_FILE, "w", encoding="utf-8") as f:
        json.dump(d, f)
    _cache["t"] = 0


def _server_first_seen():
    """Начало пробного периода по данным сервера или None (нет данных, не тот магазин, подпись не сходится)."""
    try:
        with open(SERVER_TRIAL_FILE, encoding="utf-8") as f:
            d = json.load(f)
        mh = d.get("merchant_hash")
        fs = int(d.get("first_seen"))
        ok = hmac.compare_digest(str(d.get("signature")), hmac.new(_LOCAL_SALT.encode(), f"{mh}:{fs}".encode(), hashlib.sha256).hexdigest())
        if ok and mh and mh == merchant_hash() and 0 < fs <= time.time() + 3600:
            return fs
    except Exception:
        pass
    return None


def _unb64(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def verify_key(key_str, machine_id=None, stored=None):
    """(верно, сообщение, данные ключа). Проверяет подпись, номер ПК и срок.
    stored — подписанный файл активации: если ключ уже был активирован на этом же ПК (по постоянному отпечатку),
    прежний номер из файла остаётся действительным, даже когда сетевой номер ПК изменился."""
    key = (key_str or "").strip()
    if not key:
        return False, "Ключ не введён", None
    try:
        tag, raw, sig = key.split(".")
        if tag != "KWB1":
            raise ValueError
        raw_b, sig_b = _unb64(raw), _unb64(sig)
        if not ed25519.verify(PUBLIC_KEY, raw_b, sig_b):
            return False, "Неверный ключ активации", None
        info = json.loads(raw_b.decode("utf-8"))
    except Exception:
        return False, "Неверный ключ активации", None
    try:      # список отозванных ключей приходит с подписанным файлом обновления
        blocked = json.load(open(os.path.join(DATA_DIR, ".blocked.json")))
        if hashlib.sha256(key.encode()).hexdigest()[:16] in blocked:
            return False, "Ключ отозван владельцем программы", info
    except Exception:
        pass
    mid = machine_id or get_machine_id()
    sid = stable_id()
    allowed = {"*", mid}
    if sid:
        allowed.add(sid)
        if stored and stored.get("stable_id") == sid and stored.get("machine_id"):
            allowed.add(stored["machine_id"])      # активирован здесь раньше: прежний номер тоже принимаем
    if info.get("m") not in allowed:
        return False, "Ключ выписан для другого компьютера", None
    if info.get("e") and time.time() > info["e"]:
        return False, "Срок лицензии истёк", info
    return True, f"PRO лицензия: {info.get('n', '')}", info


def _pro_status(info, key, machine_id):
    if info.get("e"):
        days = max(1, math.ceil((info["e"] - time.time()) / 86400))
        label = f"PRO до {time.strftime('%d.%m.%Y', time.localtime(info['e']))} ({days} дн.)"
    else:
        days, label = 9999, "PRO Лицензия (Бессрочная)"
    return {"is_active": True, "status": "PRO", "status_label": label, "days_left": days, "license_key": key,
            "machine_id": machine_id}


def init_or_load_license():
    os.makedirs(DATA_DIR, exist_ok=True)
    machine_id = get_machine_id()
    now = int(time.time())
    data = None
    if os.path.exists(LICENSE_FILE):
        try:
            with open(LICENSE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("signature") != _sign_payload(data):
                data = None
        except Exception:
            data = None
    if data:
        if data.get("status") == "PRO":
            ok, msg, info = verify_key(data.get("license_key"), machine_id, stored=data)
            if ok:
                sid = stable_id()
                if sid and not data.get("stable_id"):      # запоминаем постоянный отпечаток: дальше смена сети лицензию не собьёт
                    try:
                        data["stable_id"] = sid
                        data["signature"] = _sign_payload(data)
                        with open(LICENSE_FILE, "w", encoding="utf-8") as f:
                            json.dump(data, f, ensure_ascii=False, indent=2)
                    except Exception:
                        pass
                return _pro_status(info, data["license_key"], display_id())
            return {"is_active": False, "status": "EXPIRED", "status_label": msg, "days_left": 0,
                    "license_key": "", "machine_id": display_id()}
        start = data.get("first_run", now)
        fs = _server_first_seen()
        if fs and fs < start:          # магазин уже начинал пробный период раньше (удалили файл, другой компьютер)
            start = fs
        elapsed = now - start
        total = trial_seconds(start)
        if elapsed < total:
            return {"is_active": True, "status": "TRIAL",
                    "status_label": f"Тест-драйв: {max(1, math.ceil((total - elapsed) / 86400))} дн.",
                    "days_left": max(1, math.ceil((total - elapsed) / 86400)),
                    "hours_left": max(1, math.ceil((total - elapsed) / 3600)),
                    "license_key": "", "machine_id": display_id()}
        return {"is_active": False, "status": "EXPIRED", "status_label": "Тест-драйв завершён", "days_left": 0,
                "license_key": "", "machine_id": display_id()}
    fresh = {"machine_id": machine_id, "first_run": now, "license_key": "", "status": "TRIAL",
             "created_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    fresh["signature"] = _sign_payload(fresh)
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(fresh, f, ensure_ascii=False, indent=2)
    total = trial_seconds(now)
    return {"is_active": True, "status": "TRIAL", "status_label": f"Тест-драйв: {total // 86400} дн.",
            "days_left": total // 86400, "hours_left": total // 3600, "license_key": "", "machine_id": display_id()}


def activate_license(key_str):
    machine_id = get_machine_id()
    ok, msg, info = verify_key(key_str, machine_id)
    if not ok:
        return {"success": False, "error": msg}
    data = {"machine_id": machine_id, "stable_id": stable_id() or "", "first_run": int(time.time()), "license_key": key_str.strip(), "status": "PRO",
            "activated_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    data["signature"] = _sign_payload(data)
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    st = _pro_status(info, key_str.strip(), display_id())
    _cache["t"] = 0
    try:
        from core import telemetry
        telemetry.report("activation")
    except Exception:
        pass
    return {"success": True, "message": msg, "status": "PRO", "status_label": st["status_label"], "days_left": st["days_left"]}


def generate_key_for_client(*a, **k):
    raise RuntimeError("Ключи выписываются только владельцем: D:\\kaspi-arbitrage-license-private\\make_license.py")


if __name__ == "__main__":
    print(json.dumps(init_or_load_license(), ensure_ascii=False, indent=2))


# ---------- «замок»: что можно делать без активной лицензии ----------
EXPIRED_MSG = ("Пробный период закончился. Активируйте ключ PRO (слева внизу «Активировать PRO»). "
               "Связь: +7 700 394 00 94 (WhatsApp / Telegram).")
_cache = {"t": 0, "v": True}


def is_active():
    """Активна ли лицензия (пробный период или PRO). Результат кэшируется на 20 секунд."""
    if time.time() - _cache["t"] < 20:
        return _cache["v"]
    try:
        v = bool(init_or_load_license().get("is_active"))
    except Exception:
        v = True          # сбой чтения не должен ломать работу клиента
    _cache["t"], _cache["v"] = time.time(), v
    return v


def require():
    """Бросает ошибку, если лицензия не активна. Ставится в функции, которые пишут в Kaspi."""
    if not is_active():
        raise RuntimeError(EXPIRED_MSG)
