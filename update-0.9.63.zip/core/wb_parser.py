import json
import re
import urllib.parse
import urllib.request
import ssl

CTX = ssl._create_unverified_context()
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

def get_basket_number(short_id: int) -> int:
    if short_id <= 143: return 1
    if short_id <= 287: return 2
    if short_id <= 431: return 3
    if short_id <= 719: return 4
    if short_id <= 1007: return 5
    if short_id <= 1061: return 6
    if short_id <= 1115: return 7
    if short_id <= 1169: return 8
    if short_id <= 1313: return 9
    if short_id <= 1601: return 10
    if short_id <= 1655: return 11
    if short_id <= 1919: return 12
    if short_id <= 2045: return 13
    if short_id <= 2189: return 14
    if short_id <= 2405: return 15
    if short_id <= 2621: return 16
    if short_id <= 2837: return 17
    if short_id <= 3053: return 18
    if short_id <= 3269: return 19
    if short_id <= 3485: return 20
    if short_id <= 3701: return 21
    if short_id <= 3917: return 22
    if short_id <= 4133: return 23
    return 24

def get_wb_images(item_id: int, count: int = 5) -> list[str]:
    vol = item_id // 100000
    part = item_id // 1000
    b = get_basket_number(vol)
    b_str = f"{b:02d}"
    return [
        f"https://basket-{b_str}.wbbasket.ru/vol{vol}/part{part}/{item_id}/images/big/{i}.webp"
        for i in range(1, count + 1)
    ]

def clean_kaspi_title(brand: str, raw_name: str, category: str = "") -> str:
    # Kaspi format: [Тип] + [Бренд] + [Модель/Назначение] + [Свойства]
    name = re.sub(r'[\/\\\|\*\#\$\@\^\&\(\)]', ' ', raw_name)
    name = ' '.join(name.split())
    
    b_str = (brand or "ProHome").strip()
    if b_str.lower() in ['нет бренда', 'no name', 'no-name', 'noname', 'китай', 'россия']:
        b_str = "ProHome"
        
    if b_str.lower() not in name.lower():
        title = f"{name} {b_str}"
    else:
        title = name
        
    words = title.split()
    if len(' '.join(words)) > 75:
        title = ' '.join(words[:8])
    return title.strip()

def round_kaspi_price(price: float) -> int:
    p = round(price / 100) * 100
    if p < price:
        p += 100
    return int(max(1990, p - 10))

LAST_ERROR = ""

def parse_wb_search_sync(query: str, limit: int = 50, config: dict = None) -> list[dict]:
    if config is None:
        config = {}
    global LAST_ERROR
    LAST_ERROR = ""
    rub_rate = config.get("rub_to_kzt_rate", 5.1)
    mult = config.get("margin_multiplier", 2.4)
    pkg = config.get("packaging_cost_kzt", 150)
    
    # Direct search endpoint
    url = f"https://search.wb.ru/exactmatch/ru/common/v18/search?ab_testing=false&appType=1&curr=rub&dest=-1257786&query={urllib.parse.quote(query)}&resultset=catalog&sort=popular&spp=30"
    
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    try:
        with urllib.request.urlopen(req, context=CTX, timeout=12) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            products = data.get('products') or data.get('data', {}).get('products') or []
    except Exception as e:
        # Fallback to local harvested catalog if network challenge occurs
        products = []
        LAST_ERROR = f"Wildberries не отдал выдачу ({getattr(e, 'code', '') or type(e).__name__}). Сайт WB блокирует автоматические запросы."
        
    if not products:
        # прямой запрос закрыт антибот-защитой WB: читаем выдачу через установленный браузер
        try:
            from core.wb_browser import search_wb
            found, berr = search_wb(query, limit=limit)
        except Exception as e:
            found, berr = [], f"Браузерный поиск недоступен: {e}"
        if found:
            LAST_ERROR = ""
            products = [{"id": f["id"], "name": f["name"], "brand": f["brand"], "feedbacks": f["feedbacks"],
                         "reviewRating": f["rating"], "_img": f.get("img", ""), "sizes": [{"price": {"product": f["price_rub"] * 100}}]} for f in found]
        else:
            LAST_ERROR = berr or LAST_ERROR

    # Цены для Актобе в тенге (как видит покупатель WB в Казахстане, доставка до ПВЗ уже в цене).
    # Раньше считали «рубли Москвы × курс» — это не та цена, по которой вы реально покупаете.
    kz_prices = {}
    if products:
        try:
            from core.wb_tracker import fetch_wb
            kz_prices = fetch_wb([p.get('id') for p in products[:150] if p.get('id')])
        except Exception as e:
            LAST_ERROR = f"Не удалось получить цены WB для вашего города: {e}"

    COMMODITY_STOP_WORDS = [
        'pampers', 'подгузник', 'трусик', 'the act', 'пенка для умывания', 'креатин', 'протеин',
        'mishido', 'омега', 'шины', 'постельн', 'бель', 'джинс', 'футболк', 'носк',
        'куртк', 'плать', 'кофт', 'штан', 'шампун', 'synergetic', 'мыло жидк',
        'подушк', 'наматрасник', 'рубашк', 'брюк', 'кальсон', 'колье', 'зарядка для iphone',
        'полотенц', 'халат', 'свитер', 'юбка'
    ]

    results = []
    for it in products:
        if len(results) >= limit:
            break
        pid = it.get('id')
        name = it.get('name', '').strip()
        brand = it.get('brand', '').strip() or "ProHome"
        
        check_text = f"{name} {brand}".lower()
        if any(sw in check_text for sw in COMMODITY_STOP_WORDS):
            continue

        feedbacks = it.get('feedbacks', 0)
        rating = it.get('reviewRating') or it.get('rating') or 4.8
        
        sizes = it.get('sizes', [])
        price_rub = 0
        if sizes:
            price_rub = sizes[0].get('price', {}).get('product', 0) // 100
            
        if price_rub < 100:
            price_rub = 500  # Default reasonable price
            
        kz = kz_prices.get(int(pid)) if pid else None
        if kz and kz.get("price") and int(kz.get("price")) > 0:
            from core import setup_wizard as _sw
            price_kzt, price_src = int(kz["price"]), f"WB {_sw.city_name()}, ₸"
        else:
            price_kzt = int(round(price_rub * rub_rate))
            price_src = f"WB (курс {rub_rate}), ₸"
            continue                                  # нет цены/наличия для Актобе — товар не подходит
        cost_total = price_kzt + pkg
        kaspi_price = round_kaspi_price(cost_total * mult)
        
        # та же экономика, что в «Моём магазине»: комиссия, Kaspi Pay, налог И доставка Kaspi по тарифу
        from core.kaspi_store import calculate_product_economics, category_commission
        _cr = category_commission(it.get('subjectName') or it.get('entity') or '')
        econ = calculate_product_economics(kaspi_price, price_kzt, comm_rate=_cr, pack_kzt=pkg)
        comm = round(kaspi_price * _cr / 100)
        kpay = round(kaspi_price * 0.0095)
        tax = round(kaspi_price * 0.03)
        profit = int(econ.get("net_profit") or 0)
        total_fees = kaspi_price - profit - cost_total
        payout = kaspi_price - total_fees
        roi = round((profit / cost_total) * 100, 1) if cost_total else 0
        
        imgs = [it['_img']] if it.get('_img') else get_wb_images(pid, count=4)
        
        clean_words = [w for w in re.sub(r'[^\w\s]', ' ', name).split() if len(w) > 3][:3]
        search_q = " ".join(clean_words) if clean_words else name[:30]

        results.append({
            "id": pid,
            "brand": brand,
            "name": name,
            "kaspi_name": clean_kaspi_title(brand, name),
            "kaspi_search_query": search_q,
            "feedbacks": feedbacks,
            "rating": round(float(rating), 1),
            "price_rub": price_rub,
            "price_kzt": price_kzt,
            "price_source": price_src,
            "price_checked_at": int(__import__("time").time()),
            "wb_qty": (kz or {}).get("qty"),
            "wb_delivery_h": [(kz or {}).get("t1"), (kz or {}).get("t2")] if kz else None,
            "cost_total": cost_total,
            "kaspi_price": kaspi_price,
            "comm_kaspi": comm,
            "kaspi_pay": kpay,
            "tax": tax,
            "total_fees": total_fees,
            "payout": payout,
            "profit": profit,
            "roi": roi,
            "margin_pct": round(float(econ.get("margin_pct") or 0), 1),
            "wb_url": f"https://www.wildberries.ru/catalog/{pid}/detail.aspx",
            "img_main": imgs[0],
            "images": imgs,
            "status_kaspi": "Свободная ниша (0 конкурентов)",
            "ai_image": None
        })
        
    return results
