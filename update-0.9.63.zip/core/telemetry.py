"""Отчёт владельцу программы об активации и ежедневном использовании: имя из ключа, номер ПК, версия, дата, хеш Merchant ID.
Адрес отчётов задаёт владелец (core/endpoints.py REPORT_URL, например веб-приложение Google Apps Script → таблица).
Никаких данных магазина, заказов, покупателей, паролей и токенов не отправляется; номер магазина уходит только в виде
хеша sha256 (по нему сервер считает «одна проба на магазин»). Об этом сказано в инструкции и оферте.
Пока REPORT_URL пуст или сервер не отвечает, программа работает как обычно: ничего не блокируется."""
import json
import re
import os
import threading
import time
import urllib.request

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _url():
    try:
        c = json.load(open(os.path.join(BASE, "config.json"), encoding="utf-8"))
    except Exception:
        c = {}
    try:
        from core import endpoints
        d = endpoints.REPORT_URL
    except Exception:
        d = ""
    return (c.get("report_url") or d or "").strip()


CONTACT_FILE = os.path.join(BASE, "data", ".contact.json")


def normalize_phone(raw):
    """Казахстанский/российский номер -> +7XXXXXXXXXX; иначе None."""
    d = "".join(c for c in str(raw or "") if c.isdigit())
    if len(d) == 11 and d[0] in "78":
        return "+7" + d[1:]
    if len(d) == 10:
        return "+7" + d
    return None


def _contact():
    try:
        d = json.load(open(CONTACT_FILE, encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def get_phone():
    return str(_contact().get("phone") or "")


def get_name():
    return str(_contact().get("name") or "")


def clean_name(raw):
    s = re.sub(r"\s+", " ", str(raw or "")).strip()[:60]
    return s if len(s) >= 2 else ""


def can_postpone():
    """«Позже» доступно один раз: на 3 дня."""
    return not _contact().get("later_used")


def postponed():
    """True, пока идут 3 дня отсрочки."""
    try:
        return float(_contact().get("later_until") or 0) > time.time()
    except (TypeError, ValueError):
        return False


def postpone():
    c = _contact()
    if c.get("phone") or c.get("later_used"):
        return False
    c.update({"later_used": True, "later_until": time.time() + 3 * 86400})
    os.makedirs(os.path.dirname(CONTACT_FILE), exist_ok=True)
    json.dump(c, open(CONTACT_FILE, "w", encoding="utf-8"))
    return True


def set_phone(raw, name=None):
    p = normalize_phone(raw)
    if not p:
        return None
    os.makedirs(os.path.dirname(CONTACT_FILE), exist_ok=True)
    c = _contact()
    c.update({"phone": p, "at": time.strftime("%Y-%m-%d %H:%M:%S")})
    if name:
        c["name"] = name
    json.dump(c, open(CONTACT_FILE, "w", encoding="utf-8"))
    report("contact")                      # сразу сообщить автору (в фоне)
    return p


def _post(url, payload, timeout=15):
    """POST JSON. Возвращает разобранный JSON-ответ или None."""
    body = json.dumps(payload).encode()
    raw = urllib.request.urlopen(urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}),
                                 timeout=timeout).read()
    try:
        return json.loads(raw.decode("utf-8", "replace"))
    except Exception:
        return None


def report(event):
    """Отправка в фоне; любая ошибка молча игнорируется (программа от неё не зависит)."""
    url = _url()
    if not url:
        return

    def go():
        try:
            from core import license as lic, updater
            st = lic.init_or_load_license()
            name, until = "", ""
            try:
                d = json.load(open(os.path.join(BASE, "data", ".license.json"), encoding="utf-8"))
                k = d.get("license_key") or ""
                if k.startswith("KWB1."):
                    info = json.loads(lic._unb64(k.split(".")[1]).decode("utf-8"))
                    name = info.get("n", "")
                    until = time.strftime("%Y-%m-%d", time.localtime(info["e"])) if info.get("e") else "бессрочно"
            except Exception:
                pass
            _post(url, {"event": event, "name": name or get_name(), "machine": st.get("machine_id"), "status": st.get("status"),
                        "version": updater.current_version(), "merchant_hash": lic.merchant_hash(), "until": until, "phone": get_phone(),
                        "failed": ((__import__("core.selfcheck", fromlist=["x"]).last() or {}).get("failed") or []),
                        "ts": time.strftime("%Y-%m-%d %H:%M:%S")})
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()


def trial_check(wait=False):
    """Спрашивает у сервера, когда этот магазин (по хешу Merchant ID) впервые начал пробный период; ответ запоминается.
    Нет адреса, нет Merchant ID, нет ответа или ответ странный: ничего не меняется (никаких ложных блокировок)."""
    url = _url()
    if not url:
        return None

    def go():
        try:
            from core import license as lic
            mh = lic.merchant_hash()
            if not mh:
                return None
            r = _post(url, {"event": "trial_check", "merchant_hash": mh, "machine": lic.get_machine_id()})
            if isinstance(r, dict) and r.get("ok") and r.get("first_seen"):
                lic.save_server_trial(mh, int(r["first_seen"]))
                return True
        except Exception:
            pass
        return None
    if wait:
        return go()
    threading.Thread(target=go, daemon=True).start()
    return None


def payment_claim(contact=""):
    """Заявка «Я оплатил»: номер компьютера, контакт, версия. True, если таблица автора ответила."""
    url = _url()
    if not url:
        return False
    try:
        from core import license as lic, updater
        r = _post(url, {"event": "payment_claim", "machine": lic.get_machine_id(), "contact": str(contact)[:80],
                        "version": updater.current_version(), "merchant_hash": lic.merchant_hash(),
                        "ts": time.strftime("%Y-%m-%d %H:%M:%S")}, timeout=30)
        return bool(isinstance(r, dict) and r.get("ok"))
    except Exception:
        return False
