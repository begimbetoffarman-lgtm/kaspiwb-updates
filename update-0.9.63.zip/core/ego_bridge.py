"""Чтение страниц WB / 1688 / Ozon через браузер ego (тот же, где открыта программа).

Если ego-browser установлен, программа НЕ запускает Edge/Chrome: вход в 1688 и поиск идут в ego,
под вашим входом. Без ego остаётся прежний путь через Edge/Chrome (только когда это реально нужно).
Выполняются только операции чтения; покупок и отправок нет.
"""
import json
import os
import shutil
import subprocess
import sys
import threading
import urllib.parse
import uuid

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUNNER = os.path.join(ROOT, 'core', 'ego_runner.mjs')
WORK = os.path.join(ROOT, 'data', 'ego')
_LOCK = threading.Lock()


class EgoError(RuntimeError):
    """Безопасное сообщение для продавца."""


def _candidates():
    home = os.path.expanduser('~')
    name = 'ego-browser.exe' if sys.platform == 'win32' else 'ego-browser'
    yield shutil.which('ego-browser')
    yield os.path.join(home, '.local', 'share', 'ego', 'active_version_dir', name)
    yield os.path.join(home, '.local', 'bin', name)


def find_cli():
    if os.environ.get('KWB_BROWSER', '').lower() == 'edge':
        return None
    for p in _candidates():
        if p and os.path.exists(p):
            return p
    return None


def available():
    return find_cli() is not None


def find_app():
    """Само приложение ego (чтобы открыть в нём окно входа)."""
    if sys.platform == 'win32':
        for base in (os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)'), os.environ.get('LOCALAPPDATA')):
            if base:
                for sub in (r'Citro Labs\ego lite\Application\ego.exe', r'Programs\Citro Labs\ego lite\Application\ego.exe'):
                    p = os.path.join(base, sub)
                    if os.path.exists(p):
                        return p
    elif sys.platform == 'darwin':
        for p in ('/Applications/ego lite.app', '/Applications/ego.app'):
            if os.path.exists(p):
                return p
    return None


def open_in_ego(url):
    """Открывает страницу для пользователя именно в ego; без ego (или если он не найден) — в браузере по умолчанию."""
    app = find_app() if available() else None
    try:
        if app and sys.platform == 'win32':
            subprocess.Popen([app, url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif app and sys.platform == 'darwin':
            subprocess.Popen(['open', '-a', app, url])
        elif sys.platform == 'win32':
            subprocess.Popen('start "" "%s"' % url, shell=True)
        else:
            import webbrowser
            webbrowser.open(url)
    except Exception:
        raise EgoError('Не удалось открыть окно браузера. Откройте адрес вручную: ' + url) from None


_CLEANED = False


def _kill_orphans():
    """После перезапуска программы старый запуск ego мог остаться висеть и держит страницу: новый запрос тогда ждёт вечно."""
    global _CLEANED
    if _CLEANED or os.name != 'nt':
        return
    _CLEANED = True
    try:
        subprocess.run(['powershell', '-NoProfile', '-Command',
                        "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'ego_runner' } | "
                        "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"],
                       capture_output=True, timeout=20, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except Exception:
        pass


def run(steps, space='kaspi-wb', timeout=150):
    """Выполняет шаги в ego, возвращает словарь результата runner-а."""
    cli = find_cli()
    if not cli:
        raise EgoError('Браузер ego не найден.')
    with _LOCK:
        _kill_orphans()
    os.makedirs(WORK, exist_ok=True)
    tag = uuid.uuid4().hex
    job = os.path.join(WORK, tag + '.job.json')
    out = os.path.join(WORK, tag + '.out.json')
    with open(job, 'w', encoding='utf-8') as f:
        json.dump({'space': space, 'steps': steps}, f, ensure_ascii=False)
    url = ('file:///' + urllib.parse.quote(RUNNER.replace('\\', '/'), safe='/:') + '?job=' +
           urllib.parse.quote(job.replace('\\', '/'), safe='') + '&out=' + urllib.parse.quote(out.replace('\\', '/'), safe=''))
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    try:
        with _LOCK:
            try:
                proc = subprocess.run([cli, 'nodejs', '-e', "await import('%s')" % url], capture_output=True,
                                      timeout=timeout, creationflags=flags)
            except subprocess.TimeoutExpired:
                raise EgoError('Браузер ego не ответил вовремя. Проверьте окно ego и повторите.') from None
            except OSError:
                raise EgoError('Не удалось запустить ego-browser.') from None
        if not os.path.exists(out):
            tail = (proc.stderr or proc.stdout or b'').decode('utf-8', 'replace').strip().splitlines()
            hint = tail[0][:160] if tail else ''
            raise EgoError('Браузер ego не выполнил задание. ' + hint)
        with open(out, encoding='utf-8') as f:
            res = json.load(f)
    finally:
        for p in (job, out):
            try:
                os.remove(p)
            except OSError:
                pass
    if not res.get('ok'):
        raise EgoError('Браузер ego: ' + str(res.get('error') or 'ошибка') + '. Если окно ego просит действие, выполните его и повторите.')
    return res
