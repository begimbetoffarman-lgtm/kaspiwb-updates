"""История цен конкурентов на ваших карточках Kaspi.
При каждой проверке продавцов (раз в 30 минут) сохраняем точку: самая низкая цена конкурента, ваша цена, ваше место.
Точка пишется только если значения изменились или прошло 6 часов. Хранится до 400 точек на карточку, около 60 дней.
Файл data/price_history.json. Это только запись ваших же наблюдений, в Kaspi ничего не отправляется."""
import json
import os
import threading
import time

from core import kaspi_store as ks

_FILE = os.path.join(ks.DATA_DIR, "price_history.json")
_LOCK = threading.RLock()
MAX_POINTS = 400
KEEP_DAYS = 60
SAME_SEC = 6 * 3600


def _load():
    try:
        with open(_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def record(code, offers, my_id):
    """offers: список продавцов карточки (как отдаёт fetch_competitor_prices). Ничего не бросает наружу."""
    try:
        code = str(code or "")
        if not code.isdigit() or not offers:
            return
        mine = [o for o in offers if my_id and str(o.get("merchant_id")) == str(my_id)]
        others = [o for o in offers if not (my_id and str(o.get("merchant_id")) == str(my_id))]
        lo = min((o["price"] for o in others), default=None)
        my = mine[0]["price"] if mine else None
        prices = sorted(o["price"] for o in offers)
        pos = (prices.index(my) + 1) if my in prices else None
        now = int(time.time())
        pt = [now, lo, my, pos, len(offers)]
        with _LOCK:
            d = _load()
            s = d.setdefault(code, [])
            if s and s[-1][1:] == pt[1:] and now - s[-1][0] < SAME_SEC:
                return
            s.append(pt)
            cut = now - KEEP_DAYS * 86400
            d[code] = [p for p in s if p[0] >= cut][-MAX_POINTS:]
            os.makedirs(os.path.dirname(_FILE), exist_ok=True)
            tmp = _FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f)
            os.replace(tmp, _FILE)
    except Exception:
        pass


def series(codes):
    """Код карточки -> список точек [время, мин. цена конкурента, ваша цена, место, число продавцов]."""
    d = _load()
    return {str(c): d.get(str(c), []) for c in codes if str(c).isdigit()}
