"""Суточный счётчик запросов программы к публичному Kaspi (идея из web-collector: один счётчик на домен для всех запусков).

Все запросы считаются (data/ratelimit.json, сбрасывается каждый день), но блокирует и притормаживает счётчик только
фоновый сканер ниш (внутри `with enforced():`): ваши ручные поиски и проверки никогда не упираются в лимит.
"""
import contextlib
import datetime as _dt
import json
import os
import random
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILE = os.path.join(ROOT, 'data', 'ratelimit.json')
DAILY_LIMIT = int(os.getenv('KWB_KASPI_DAILY', '1500'))       # запросов к Kaspi в сутки для сканера
PAUSE_MIN, PAUSE_MAX = 1.0, 2.5                               # случайная пауза перед запросом сканера, сек

_LOCK = threading.Lock()
_TL = threading.local()


def _today():
    return _dt.date.today().isoformat()


def _load():
    try:
        with open(FILE, encoding='utf-8') as f:
            d = json.load(f)
        if d.get('date') == _today():
            return d
    except (OSError, ValueError):
        pass
    return {'date': _today(), 'counts': {}}


def _save(d):
    try:
        os.makedirs(os.path.dirname(FILE), exist_ok=True)
        tmp = FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(d, f)
        os.replace(tmp, FILE)
    except OSError:
        pass


@contextlib.contextmanager
def enforced():
    """Внутри блока запросы потока идут с паузами; число оставшихся смотрите через remaining()."""
    _TL.on = True
    try:
        yield
    finally:
        _TL.on = False


_NEXT_SLOT = [0.0]


def is_enforced():
    return bool(getattr(_TL, 'on', False))


def hit(domain='kaspi.kz', on=None):
    """Учесть один запрос к домену. Для сканера запросы выстраиваются в очередь со случайной паузой 1–2,5 с
    между ними (общая для всех потоков). on — передать режим в рабочий поток (флаг потока там не виден)."""
    on = is_enforced() if on is None else on
    wait = 0.0
    with _LOCK:
        if on:
            now = time.time()
            slot = max(now, _NEXT_SLOT[0])
            _NEXT_SLOT[0] = slot + random.uniform(PAUSE_MIN, PAUSE_MAX)
            wait = slot - now
        d = _load()
        d['counts'][domain] = d['counts'].get(domain, 0) + 1
        _save(d)
        n = d['counts'][domain]
    if wait > 0:
        time.sleep(wait)
    return n


def used(domain='kaspi.kz'):
    with _LOCK:
        return _load()['counts'].get(domain, 0)


def remaining(domain='kaspi.kz'):
    return max(0, DAILY_LIMIT - used(domain))


def seconds_to_tomorrow():
    now = _dt.datetime.now()
    nxt = (now + _dt.timedelta(days=1)).replace(hour=0, minute=5, second=0, microsecond=0)
    return int((nxt - now).total_seconds())
