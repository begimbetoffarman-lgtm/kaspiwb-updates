"""Локальные копии фото товаров поставщика (1688/Ozon): чтобы превью не зависели от ссылок поставщика.

В Kaspi фото по-прежнему уходят по исходной ссылке (Kaspi скачивает их сам), копия нужна для показа,
ИИ-фото и на случай, если ссылка поставщика перестанет открываться."""
import hashlib
import os
import urllib.request

from core import kaspi_store as ks

PHOTO_DIR = os.path.join(ks.DATA_DIR, "supplier-photos")
_MAX_BYTES = 6 * 1024 * 1024
_MAX_PER_CALL = 12
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"


def _ext(data):
    if data[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    return ""


def archive(urls):
    """Скачивает фото (не больше 12 за раз). Возвращает {ссылка: имя файла}. Ошибки отдельных фото пропускаются."""
    os.makedirs(PHOTO_DIR, exist_ok=True)
    out = {}
    for url in list(dict.fromkeys(u for u in urls if isinstance(u, str) and u.startswith(("https://", "http://"))))[:_MAX_PER_CALL]:
        stem = hashlib.sha256(url.encode()).hexdigest()[:24]
        have = next((f for f in (stem + e for e in (".jpg", ".png", ".webp")) if os.path.exists(os.path.join(PHOTO_DIR, f))), None)
        if have:
            out[url] = have
            continue
        try:
            req = urllib.request.Request(url, headers={"User-Agent": _UA})
            with urllib.request.urlopen(req, timeout=15) as r:
                data = r.read(_MAX_BYTES + 1)
            ext = _ext(data)
            if not ext or len(data) > _MAX_BYTES:
                continue
            name = stem + ext
            with open(os.path.join(PHOTO_DIR, name), "wb") as f:
                f.write(data)
            out[url] = name
        except Exception:
            continue
    return out


def folder():
    return PHOTO_DIR
