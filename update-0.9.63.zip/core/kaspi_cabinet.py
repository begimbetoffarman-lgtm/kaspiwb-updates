"""
Кабинет продавца Kaspi от имени СОТРУДНИКА (логин/пароль сотрудника вводит владелец в настройках).
Программа делает те же запросы, что и страница кабинета, но без окна браузера:

  вход:      idmc.shop.kaspi.kz/api/p/login  (email+пароль, при необходимости код из письма)
  товар:     mc.shop.kaspi.kz/bff/offer-view/details?m=<магазин>&s=<артикул>
  изменить:  mc.shop.kaspi.kz/pricefeed/upload/merchant/process   (цена, наличие, предзаказ)
  проверка:  kaspi.kz/yml/offer-view/offers/<код карточки>        (как видит покупатель)

Проверено на живом магазине 06.11.2026: полка WB345042520 выставлена 11 790 ₸, предзаказ 7 дней.
Kaspi применяет изменения через очередь (обычно до ~1 часа), поэтому статус «отправлено» ≠ «применено».
"""
import json
import os
import pickle
import threading
import time

import requests
from urllib.parse import urljoin

from core import kaspi_store as ks

IDMC = "https://idmc.shop.kaspi.kz"
MC = "https://mc.shop.kaspi.kz"
SESSION_FILE = os.path.join(ks.DATA_DIR, "kaspi_cabinet_session.pkl")
LOG_FILE = os.path.join(ks.DATA_DIR, "kaspi_cabinet_log.json")
PENDING_FILE = os.path.join(ks.DATA_DIR, "kaspi_cabinet_pending.json")
CODE_TTL = 600   # Kaspi даёт ~3 мин на ввод кода; 10 мин не перезапрашиваем код сами
UA = ks.USER_AGENT
_lock = threading.RLock()
_state = {"session": None, "pending_email": None}


def _pending():
    """Ожидание кода хранится в файле (а не в памяти), чтобы пережить перезапуск программы."""
    try:
        with open(PENDING_FILE, encoding="utf-8") as f:
            p = json.load(f)
        if time.time() - p.get("ts", 0) < CODE_TTL:
            return p
    except Exception:
        pass
    return None


def _set_pending(email):
    if email:
        ks._atomic_json_write(PENDING_FILE, {"email": email, "ts": time.time()})
    elif os.path.exists(PENDING_FILE):
        os.remove(PENDING_FILE)


class NeedCode(Exception):
    """Kaspi прислал код подтверждения на почту сотрудника."""


class NotConnected(Exception):
    pass


# ------------------------------------------------------------------ сессия
def _new_session():
    s = requests.Session()
    s.headers.update({"User-Agent": UA, "Accept": "application/json, text/plain, */*",
                      "Accept-Language": "ru-RU,ru;q=0.9"})
    return s


def _session():
    with _lock:
        if _state["session"] is None:
            s = _new_session()
            if os.path.exists(SESSION_FILE):
                try:
                    with open(SESSION_FILE, "rb") as f:
                        s.cookies.update(pickle.load(f))
                except Exception:
                    pass
            _state["session"] = s
        return _state["session"]


def _save_session():
    with _lock:
        s = _state["session"]
        if s is None:
            return
        tmp = SESSION_FILE + ".tmp"
        with open(tmp, "wb") as f:
            pickle.dump(s.cookies, f)
        os.replace(tmp, SESSION_FILE)


def merchant_id():
    return str(ks._config_value("kaspi_merchant_id", "")).strip()


def store_id():
    return str(ks._config_value("kaspi_store_id", "") or f"{merchant_id()}_PP1")


def store_city():
    return str(ks._config_value("kaspi_store_city", "") or "151010000")


def _creds():
    return (str(ks._config_value("kaspi_cab_login", "")).strip(),
            str(ks._config_value("kaspi_cab_password", "")))


def _log(event, **kw):
    try:
        with open(LOG_FILE, encoding="utf-8") as f:
            log = json.load(f)
    except Exception:
        log = []
    log.insert(0, {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "event": event, **kw})
    ks._atomic_json_write(LOG_FILE, log[:300])


def load_log(n=50):
    try:
        with open(LOG_FILE, encoding="utf-8") as f:
            return json.load(f)[:n]
    except Exception:
        return []


# ------------------------------------------------------------------ вход
def _xsrf_headers(s, origin):
    tok = s.cookies.get("XSRF-TOKEN", domain=None) or next(
        (c.value for c in s.cookies if c.name == "XSRF-TOKEN"), None)
    h = {"Origin": origin, "Referer": origin + "/login", "Content-Type": "application/json"}
    if tok:
        h["X-XSRF-TOKEN"] = tok
    return h


def _finish(s, data):
    url = (data or {}).get("redirectUrl")
    if url:
        url = urljoin(IDMC + "/", url)      # Kaspi отдаёт относительный адрес, например "/"
    _save_session()                          # вход уже подтверждён — сохраняем сразу
    hops = []
    if url:
        r = s.get(url, allow_redirects=True, timeout=30)
        hops = [h.url.split("?")[0] for h in r.history] + [r.url.split("?")[0]]
    if not is_logged_in(check_only=True):
        # вход в Kaspi (SSO) уже есть — повторяем передачу входа в кабинет, как делает браузер
        r = s.get(MC + "/oauth2/authorization/1", allow_redirects=True, timeout=30)
        hops += ["retry"] + [h.url.split("?")[0] for h in r.history] + [r.url.split("?")[0]]
    _save_session()
    _log("login_finish", redirect=bool(url), hops=hops[:12], keys=sorted((data or {}).keys()))
    if not is_logged_in(check_only=True):
        raise RuntimeError("Kaspi принял вход, но кабинет не открылся. Пришлите скрин — разберусь по журналу.")
    _log("login_ok")
    return {"ok": True}


def login(email=None, password=None, remember=True):
    """Вход сотрудника. Возвращает {"ok":True} или {"need_code":True,"email":...}."""
    if not email or not password:
        email, password = _creds()
    if not email or not password:
        raise NotConnected("Не указаны логин и пароль сотрудника Kaspi (Настройки → Подключение к кабинету Kaspi).")
    with _lock:
        s = _new_session()
        _state["session"] = s
        # начинаем как браузер: кабинет перенаправляет на страницу входа (ставит cookies, XSRF)
        s.get(MC + "/oauth2/authorization/1", allow_redirects=True, timeout=30)
        s.get(IDMC + "/login", timeout=30)
        r = s.post(IDMC + "/api/p/login", json={"_u": email, "_p": password, "_r_d": bool(remember)},
                   headers=_xsrf_headers(s, IDMC), timeout=30)
        data = _json(r)
        _log("login_response", http=r.status_code, keys=sorted(data.keys()), error=data.get("errorCode"))
        if r.status_code >= 400:
            raise RuntimeError(_login_error(data, r))
        if data.get("su"):
            raise RuntimeError("У этого логина несколько магазинов — пока поддерживается только один магазин.")
        if data.get("email"):
            _state["pending_email"] = data["email"]
            _set_pending(data["email"])
            _save_session()
            _log("login_need_code", email=data["email"])
            return {"need_code": True, "email": data["email"]}
        return _finish(s, data)


def resend_code(remember=True):
    """Повторно запросить код: Kaspi пришлёт новое письмо, старое сгорает. Нужен, если письмо не пришло."""
    email, password = _creds()
    return login(email, password, remember=remember)


def submit_code(code, remember=True):
    with _lock:
        s = _session()
        email = _state.get("pending_email") or (_pending() or {}).get("email") or _creds()[0]
        r = s.post(IDMC + "/api/p/login", json={"_m_c": str(code).strip(), "_r_d": bool(remember), "_u": email},
                   headers=_xsrf_headers(s, IDMC), timeout=30)
        data = _json(r)
        _log("code_response", http=r.status_code, keys=sorted(data.keys()), error=data.get("errorCode"))
        if r.status_code >= 400:
            raise RuntimeError(_login_error(data, r))
        _state["pending_email"] = None
        _set_pending(None)
        return _finish(s, data)


def _json(r):
    try:
        return r.json()
    except Exception:
        return {}


def _login_error(data, r):
    code = (data or {}).get("errorCode") or ""
    return {
        "CREDENTIALS_INVALID": "Неверный логин или пароль сотрудника.",
        "INSUFFICIENT_PERMISSIONS": "У сотрудника нет прав. Дайте ему право «Загрузка товаров».",
        "NO_MERCHANTS": "Этот пользователь не привязан ни к одному магазину.",
        "SECURITY_CODE_INVALID": "Неверный код из письма.",
        "MFA_CODE_INVALID": "Неверный код из письма.",
        "TIMEOUT_EXCEEDED": "Код устарел — запросите новый.",
        "MFA_CODE_ATTEMPT_LIMIT": "Слишком много попыток ввода кода, подождите.",
        "MFA_SEND_FLOOD": "Слишком часто запрашивали код, подождите.",
    }.get(code, f"Kaspi отказал во входе ({code or r.status_code}).")


def logout():
    with _lock:
        _state["session"] = None
        _set_pending(None)
        if os.path.exists(SESSION_FILE):
            os.remove(SESSION_FILE)


# ------------------------------------------------------------------ запросы к кабинету
def _get(path, params=None):
    r = _session().get(MC + path, params=params, timeout=30, allow_redirects=False)
    return r


def is_logged_in(check_only=False):
    mid = merchant_id()
    try:
        r = _get("/bff/offer-view/list", {"m": mid, "p": 0, "l": 1, "a": "true"})
    except Exception:
        return False
    return r.status_code == 200 and r.headers.get("content-type", "").startswith("application/json")


def list_page(page=0, limit=100, active=None):
    """Одна страница списка товаров кабинета (только чтение): цены, остатки, статусы пачкой, а не по одному товару."""
    _ensure()
    params = {"m": merchant_id(), "p": int(page), "l": max(1, min(int(limit), 200))}
    if active is not None:
        params["a"] = "true" if active else "false"
    r = _get("/bff/offer-view/list", params)
    if r.status_code != 200:
        raise RuntimeError("Kaspi не отдал список товаров (%s)." % r.status_code)
    return r.json()


_KA = {"t": None}


def keepalive():
    """Лёгкий запрос раз в ~20 минут, чтобы вход в кабинет не истекал. Сам вход заново НЕ делает (чтобы не слать письма с кодом)."""
    import threading

    def loop():
        while True:
            time.sleep(20 * 60)
            try:
                if _state.get("session") is not None or os.path.exists(SESSION_FILE):
                    if is_logged_in():
                        _save_session()
            except Exception:
                pass
    if _KA["t"] is None:
        t = threading.Thread(target=loop, daemon=True)
        _KA["t"] = t
        t.start()


def _auto_code(since_ts):
    """Если настроен Gmail — берём код из письма Kaspi и вводим сами. Иначе возвращает None."""
    try:
        from core import mail_code
        if not mail_code.configured():
            return None
        code = mail_code.fetch_code(since_ts, wait=90)
        if not code:
            _log("auto_code_not_found")
            return None
        res = submit_code(code)
        _log("auto_code_ok")
        if isinstance(res, dict):
            res["auto_code"] = True
        return res
    except Exception as e:
        _log("auto_code_error", error=str(e)[:150])
        return None


_ensure_lock = threading.RLock()   # один вход за раз: иначе два потока вводят один и тот же код, второй раз Kaspi отвечает FAILED


def _ensure(allow_login=True):
    """Проверяет вход; если сессия истекла — входит заново по сохранённому паролю.
    Код из письма вводится автоматически, если настроен Gmail (иначе — руками в Настройках).
    Если Kaspi уже ждёт код — НЕ запрашиваем новый (иначе старый код сгорает)."""
    with _ensure_lock:   # второй поток ждёт здесь и после ожидания видит уже выполненный вход
        if is_logged_in():
            return
        p = _pending()
        if p:
            if _auto_code(time.time() - 900) is not None and is_logged_in():
                return
            raise NeedCode(f"Kaspi ждёт код из письма на {p['email']}. Введите его в Настройках → Подключение к кабинету.")
        if not allow_login:
            raise NotConnected("Кабинет Kaspi не подключён.")
        started = time.time() - 30
        res = login()
        if res.get("need_code"):
            if _auto_code(started) is not None and is_logged_in():
                return
            raise NeedCode(f"Kaspi отправил код на {res['email']}. Введите его в программе (Настройки → Подключение к кабинету).")


def status():
    email, pwd = _creds()
    st = {"configured": bool(email and pwd), "login": email, "merchant_id": merchant_id(),
          "store_id": store_id()}
    p = _pending()
    st["pending_code"], st["pending_email"] = bool(p), (p or {}).get("email")
    st["connected"] = st["configured"] and is_logged_in()
    return st


def get_offer(sku):
    _ensure()
    r = _get("/bff/offer-view/details", {"m": merchant_id(), "s": sku})
    if r.status_code != 200:
        raise RuntimeError(f"Kaspi не отдал товар {sku} ({r.status_code}).")
    d = r.json()
    city = next((c for c in (d.get("cityInfo") or []) if c.get("id") == store_city()), None) or \
        ((d.get("cityInfo") or [None])[0] or {})
    points = city.get("pickupPoints") or []
    pt = next((x for x in points if x.get("name") == store_id()), points[0] if points else {})
    stock = (pt.get("stock") or {}).get("value")
    pt_av = pt.get("available") if isinstance(pt.get("available"), bool) else None
    return {
        "point": {k: v for k, v in pt.items() if not isinstance(v, (list, dict)) or k in ("stock", "preOrder", "preorder")},
        "point_available": pt_av,
        "stock": int(stock) if isinstance(stock, (int, float)) else None,
        "merchant_title": d.get("title"),
        "sku": sku, "card_code": d.get("masterSku"), "title": d.get("masterName") or d.get("title"),
        "available": bool(d.get("available")), "price": int(city.get("price") or 0),
        "category": d.get("masterCategory"), "pending": d.get("protocol"),
        "error": d.get("offerError"), "brand_code": d.get("brandCode"),
    }


def _delete_offers_permanently(skus):
    """!!! НЕ «снять с продажи». Это кнопка «Удалить» из архива кабинета: запись товара у продавца УДАЛЯЕТСЯ
    безвозвратно (проверено 07.11.2026 на тестовом товаре — после неё Kaspi отвечает 404, предложение
    пришлось создавать заново). Нигде в программе не используется."""
    _ensure()
    skus = [str(x) for x in skus]
    r = _session().post(MC + "/offers/api/v1/offer/delete", params={"m": merchant_id()},
                        json={"skusToRemove": skus}, timeout=60,
                        headers={"Origin": "https://kaspi.kz", "Referer": "https://kaspi.kz/mc/"})
    if r.status_code >= 400:
        msg = (_json(r).get("errorMessage") or _json(r).get("message") or r.text[:200])
        _log("remove_error", skus=skus[:5], http=r.status_code, error=msg)
        raise RuntimeError(f"Kaspi не снял товар с продажи ({r.status_code}): {msg}")
    _save_session()
    _log("delete_permanently", skus=skus[:20], count=len(skus))
    return {"ok": True, "removed": skus}


def set_offer(sku, price=None, preorder_days=None, available=True, stock=None, model=None, _protect=False):
    from core import license as _lic
    if not _protect:          # _protect=True: защитное снятие с продажи, работает и без лицензии
        _lic.require()
    """Цена / наличие / предзаказ одного товара — тот же запрос, что кнопка «Сохранить» в кабинете.
    preorder_days: None или 0 — без предзаказа. stock=None — сохраняем текущий остаток из кабинета
    (раньше ставилось 10 и затирало настоящий остаток). available=False — снять с продажи."""
    _ensure()
    cur = get_offer(sku)
    if stock is None:
        stock = cur.get("stock")
        if stock is None and available:
            raise RuntimeError("Товар снят с продажи, и Kaspi не отдаёт его остаток: укажите остаток явно, чтобы не поставить случайное число.")
        stock = stock or 10
    price = int(price or cur["price"] or 0)
    if available and price <= 0:
        raise RuntimeError("Нельзя выставить в продажу без цены.")
    if not available:
        # как «available="no"» в прайс-листе Kaspi: товар становится недоступным, запись НЕ удаляется,
        # потом возвращается тем же запросом с available=True
        avail = {"available": "no", "storeId": store_id()}
        price = int(price or cur["price"] or 0)
    else:
        avail = {"available": "yes", "storeId": store_id(), "stockCount": int(stock or 10)}
        if preorder_days:
            avail["preOrder"] = int(preorder_days)
    body = {"cityPrices": [{"cityId": store_city(), "value": price}] if price > 0 else [],
            "availabilities": [avail], "merchantUid": merchant_id(), "sku": sku,
            "model": model or cur.get("merchant_title") or cur["title"] or sku}
    if cur.get("brand_code"):
        body["brand"] = cur["brand_code"]
    r = _session().post(MC + "/pricefeed/upload/merchant/process", json=body, timeout=30,
                        headers={"Origin": "https://kaspi.kz", "Referer": "https://kaspi.kz/mc/"})
    data = _json(r)
    if r.status_code >= 400:
        msg = data.get("errorMessage") or data.get("message") or r.text[:200]
        _log("set_offer_error", sku=sku, error=msg)
        raise RuntimeError(f"Kaspi не принял изменение {sku}: {msg}")
    _save_session()
    _log("set_offer", sku=sku, price=price, preorder=preorder_days, available=available, request_id=data.get("id"))
    return {"ok": True, "request_id": data.get("id"), "sent": body}


def public_offer(card_code, city="750000000"):
    """Как товар видит покупатель на kaspi.kz (наш оффер): цена, предзаказ, дата доставки."""
    body = {"cityId": city, "id": str(card_code), "merchantUID": [], "limit": 64, "page": 0, "sort": True}
    r = requests.post(f"https://kaspi.kz/yml/offer-view/offers/{card_code}", json=body, timeout=20,
                      headers={"User-Agent": UA, "Referer": f"https://kaspi.kz/shop/p/-{card_code}/",
                               "Origin": "https://kaspi.kz", "Accept": "application/json, text/*"})
    if r.status_code != 200:
        return None
    for o in r.json().get("offers", []):
        if str(o.get("merchantId")) == merchant_id():
            return {"price": int(float(o.get("price") or 0)), "preorder": o.get("preorder"),
                    "delivery": o.get("delivery"), "title": o.get("title")}
    return None


def verify(sku):
    """Что применилось: кабинет + витрина kaspi.kz."""
    o = get_offer(sku)
    pub = public_offer(o["card_code"]) if o.get("card_code") else None
    return {"cabinet": o, "shop": pub,
            "applied": bool(pub) and not o.get("pending"),
            "in_queue": bool(o.get("pending"))}


# ------------------------------------------------------------------ выходные дни магазина (Расписание в праздники)
_MI = MC + "/merchant-info"
_HDR = {"Origin": "https://kaspi.kz", "Referer": "https://kaspi.kz/mc/"}


def list_special_days():
    """Особые дни: [{date, closed, openingTime, closingTime}], новые сверху. Только чтение."""
    _ensure()
    r = _session().get(_MI + f"/mc/special-days/{merchant_id()}", params={"_m": merchant_id()}, headers=_HDR, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"Kaspi не отдал выходные ({r.status_code}).")
    return sorted(r.json(), key=lambda x: x["date"], reverse=True)


def set_special_days(dates, closed=True, opening="09:00:00", closing="18:00:00"):
    from core import license as _lic
    _lic.require()
    """Выходные (closed=True) или особые часы сразу на несколько дат YYYY-MM-DD.
    Kaspi разрешает ставить не дальше чем на 60 дней вперёд. Проверено 07.11.2026 на живом Kaspi."""
    import datetime
    _ensure()
    dates = sorted({str(d) for d in dates})
    if not dates:
        raise RuntimeError("Не указаны даты.")
    today = datetime.date.today()
    for d in dates:
        dd = datetime.date.fromisoformat(d)
        if dd < today or (dd - today).days > 60:
            raise RuntimeError(f"Дата {d}: можно ставить только на ближайшие 60 дней.")
    q = ("mutation updateHoliday($input: SpecialDayInput!, $merchantUid: String!) "
         "{ specialDaysUpdate(input: $input, merchantId: $merchantUid) { void } }")
    r = _session().post(MC + "/mc/facade/graphql", params={"opName": "updateHoliday"}, timeout=30,
                        json={"operationName": "updateHoliday", "query": q,
                              "variables": {"input": {"dates": dates, "closed": bool(closed), "openingTime": opening,
                                                      "closingTime": closing}, "merchantUid": merchant_id()}},
                        headers=dict(_HDR, **{"Content-Type": "application/json"}))
    js = _json(r)
    if r.status_code >= 400 or js.get("errors"):
        _log("special_day_error", dates=dates[:5], http=r.status_code)
        raise RuntimeError(f"Kaspi не принял выходные: {str(js.get('errors') or r.text)[:200]}")
    _save_session()
    _log("special_days_set", dates=dates[:20], closed=bool(closed), count=len(dates))
    return {"ok": True, "dates": dates, "closed": bool(closed)}


def remove_special_day(date):
    """Убрать особый день (вернуть обычное расписание)."""
    _ensure()
    r = _session().delete(_MI + f"/mc/special-days/{merchant_id()}", params={"_m": merchant_id(), "date": date},
                          headers=_HDR, timeout=30)
    if r.status_code >= 400:
        _log("special_day_error", date=date, http=r.status_code)
        raise RuntimeError(f"Kaspi не убрал выходной {date} ({r.status_code}): {r.text[:150]}")
    _save_session()
    _log("special_day_removed", date=date)
    return {"ok": True, "date": date}
