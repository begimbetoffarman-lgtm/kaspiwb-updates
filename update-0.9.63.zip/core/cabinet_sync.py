"""Быстрая сверка со списком товаров кабинета Kaspi (только чтение, пачками по 100-200 товаров вместо запроса на каждый товар).
Из списка берём: код карточки, фото, цену, остаток, срок предзаказа, доступность. Всё кладём в data/cabinet_sync.json.
Коды карточек и фото сразу попадают в программу (экран «Мой магазин Kaspi»)."""
import json
import os
import threading
import time

from core import kaspi_cabinet as kc
from core import kaspi_store as ks

_FILE = os.path.join(ks.DATA_DIR, "cabinet_sync.json")
_LOCK = threading.RLock()
_ST = {"running": False, "page": 0, "total": 0, "done": 0, "error": "", "started": 0.0, "finished": 0.0}
IMG_BASE = "https://resources.cdn-kaspi.kz/img/m/p/"
GAP = 0.35


def _load():
    try:
        with open(_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def status():
    d = _load()
    return dict(_ST, items=len(d.get("items") or {}), at=d.get("at") or 0)


def _norm(o):
    """Одна запись списка кабинета -> короткий вид."""
    av = (o.get("availabilities") or [{}])[0] or {}
    cp = (o.get("cityPrices") or [{}])[0] or {}
    imgs = o.get("images") or []
    code = str(o.get("masterSku") or "")
    return {"code": code if code.isdigit() else "",
            "img": (IMG_BASE + imgs[0] + "?format=preview-medium") if imgs and isinstance(imgs[0], str) and "/" in imgs[0] else "",
            "price": int(cp.get("value") or o.get("minPrice") or 0),
            "stock": av.get("stockCount") if isinstance(av.get("stockCount"), int) else None,
            "pre": int(av.get("preOrder") or 0),
            "av": str(av.get("available") or "").lower() == "yes",
            "arch": bool(o.get("archivedAt"))}


def _page(page, size):
    """Одна страница с повторами при разовых ошибках Kaspi (до 4 попыток с паузой)."""
    last = None
    for i in range(4):
        try:
            return kc.list_page(page, size)
        except Exception as e:
            last = e
            with _LOCK:
                _ST["last_error"] = str(e)[:160]
            time.sleep(2 * (2 ** i))
    raise last


def _pass(active, items, size, base_done):
    """Один проход по списку (только активные или только остальные). Возвращает (всего, упёрлись_ли_в_лимит_Kaspi)."""
    page, total, n = 0, None, 0
    while True:
        try:
            d = _page2(page, size, active)
        except Exception as e:
            if n >= 500:                                    # Kaspi не отдаёт страницы глубже ~10 000 товаров: берём, что есть
                return total, True
            raise
        rows = d.get("data") or []
        total = d.get("total") if isinstance(d.get("total"), int) else total
        for o in rows:
            sku = str(o.get("sku") or "")
            if sku:
                items[sku] = _norm(o)
        n += len(rows)
        with _LOCK:
            _ST.update(page=page, total=_ST.get("total_all") or total or 0, done=len(items))
        page += 1
        if not rows or (total is not None and page * size >= total):
            return total, False
        time.sleep(GAP)


def _page2(page, size, active):
    last = None
    for i in range(3):
        try:
            return kc.list_page(page, size, active)
        except Exception as e:
            last = e
            with _LOCK:
                _ST["last_error"] = str(e)[:160]
            time.sleep(2 * (2 ** i))
    raise last


def _run():
    items, capped, err = {}, False, ""
    try:
        size = 100
        try:
            kc.list_page(0, 200)
            size = 200
        except Exception:
            pass
        grand = 0
        for active in (True, False):                        # два прохода: у каждого свой лимит глубины
            t, cp = _pass(active, items, size, len(items))
            grand += t or 0
            capped = capped or cp
            with _LOCK:
                _ST["total_all"] = grand
    except Exception as e:
        err = "Сверка прервана на %d товарах: %s" % (len(items), str(e)[:150])
    try:
        if items:
            _apply(items)
    except Exception as e:
        err = (err + " " if err else "") + "Не удалось сохранить: " + str(e)[:100]
    with _LOCK:
        _ST.update(error=err, finished=time.time(), capped=capped, running=False)


def _apply(items):
    """Сохраняем сверку, коды карточек (в программу) и фото (в кэш фото)."""
    os.makedirs(os.path.dirname(_FILE), exist_ok=True)
    tmp = _FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"at": time.time(), "items": items}, f, ensure_ascii=False)
    os.replace(tmp, _FILE)
    ov = ks.load_overrides()
    changed = False
    for sku, it in items.items():
        if it["code"] and (ov.get(sku) or {}).get("card_code") != it["code"]:
            ov.setdefault(sku, {})["card_code"] = it["code"]
            changed = True
    if changed:
        ks.save_overrides(ov)
    imgs = ks._img_load()
    now = time.time()
    for it in items.values():
        if it["code"] and it["img"]:
            imgs[it["code"]] = {"u": it["img"], "at": now, "v": 2}
    ks._img_save(imgs)


def start(force=False):
    """Запускает сверку в фоне (не чаще раза в 10 минут без force). Возвращает текущий статус."""
    with _LOCK:
        if _ST["running"]:
            return status()
        d = _load()
        if not force and time.time() - (d.get("at") or 0) < 600:
            return status()
        if not kc.status().get("connected"):
            _ST.update(error="Кабинет Kaspi не подключён (Настройки → Подключение магазина).")
            return status()
        _ST.update(running=True, page=0, total=0, done=0, error="", started=time.time())
    threading.Thread(target=_run, daemon=True).start()
    return status()


def diff(products, limit=200):
    """Что в программе не совпадает с Kaspi: цена, предзаказ, доступность."""
    items = _load().get("items") or {}
    out = []
    for p in products:
        k = items.get(str(p.get("sku")))
        if not k:
            continue
        prog_pre = int(p.get("preorder_days") or 0) if p.get("delivery_type") == "preorder" else 0
        diffs = []
        if int(float(p.get("sell_price") or 0)) and k["price"] and int(float(p["sell_price"])) != k["price"]:
            diffs.append("цена: в программе %d, на Kaspi %d" % (int(float(p["sell_price"])), k["price"]))
        if p.get("delivery_type") != "archive" and prog_pre != k["pre"]:
            diffs.append("предзаказ: в программе %s, на Kaspi %s" % (prog_pre or "нет", k["pre"] or "нет"))
        if p.get("delivery_type") == "archive" and k["av"]:
            diffs.append("в программе снят, на Kaspi в продаже")
        if p.get("delivery_type") != "archive" and not k["av"]:
            diffs.append("на Kaspi снят с продажи, в программе в продаже")
        if diffs:
            out.append({"sku": p.get("sku"), "title": str(p.get("title") or "")[:80], "diffs": diffs,
                        "img": k.get("img") or p.get("image") or p.get("img") or p.get("image_url") or ""})
            if len(out) >= limit:
                break
    return out
