"""Автопредзаказ: для товаров «в наличии» с известным остатком. Когда остаток доходит до порога (по умолчанию 1),
карточка не уходит с продажи, а переходит на предзаказ (по умолчанию 12 дней) с виртуальным остатком (по умолчанию 10).
Товары, которые и так на предзаказе, со своими сроками не затрагиваются.

Как считается остаток: программа запоминает остаток, который вы поставили (или который был в прайсе), и вычитает
проданное с этого момента по заказам Kaspi (отменённые не считаются). Если остаток в прайсе вы изменили вручную,
это считается пополнением: отсчёт начинается заново и товар возвращается на обычную продажу.

Настройки и отметки: data/auto_preorder.json. Сеть Kaspi используется только для чтения заказов."""
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from core import kaspi_store as ks

_FILE = os.path.join(ks.DATA_DIR, "auto_preorder.json")
_LOCK = threading.RLock()
DAY = 86400000
STATES = ("NEW", "SIGN_REQUIRED", "PICKUP", "DELIVERY", "KASPI_DELIVERY", "ARCHIVE")
BAD_STATUS = {"CANCELLED", "CANCELLING"}
CACHE_SEC = 180
DEFAULTS = {"enabled_all": True, "default_days": 12, "virtual_qty": 10, "threshold": 1}

_sales = {"at": 0.0, "orders": {}}          # id заказа -> {"ts": мс, "items": [(sku, qty)]}
_ent_cache = {}                             # id заказа -> позиции (чтобы не спрашивать Kaspi повторно)


# ---------------------------------------------------------------- хранение
def _now_ms():
    return int(time.time() * 1000)


def load():
    try:
        with open(_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        if not isinstance(d, dict):
            d = {}
    except (OSError, ValueError):
        d = {}
    for k, v in DEFAULTS.items():
        d.setdefault(k, v)
    if not isinstance(d.get("items"), dict):
        d["items"] = {}
    return d


def save(d):
    d = {k: v for k, v in d.items() if not str(k).startswith("_")}
    os.makedirs(os.path.dirname(_FILE), exist_ok=True)
    tmp = _FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(tmp, _FILE)


def _int(v, lo, hi, default):
    try:
        v = int(float(v))
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, v))


def public():
    d = load()
    return {k: d[k] for k in DEFAULTS} | {"tracked": sum(1 for i in d["items"].values() if i.get("on"))}


def set_global(data):
    with _LOCK:
        d = load()
        if "enabled_all" in data:
            d["enabled_all"] = bool(data["enabled_all"])
        d["default_days"] = _int(data.get("default_days", d["default_days"]), 1, 30, DEFAULTS["default_days"])
        d["virtual_qty"] = _int(data.get("virtual_qty", d["virtual_qty"]), 1, 1000, DEFAULTS["virtual_qty"])
        d["threshold"] = _int(data.get("threshold", d["threshold"]), 0, 5, DEFAULTS["threshold"])
        save(d)
    return public()


def set_item(sku, on=None, stock=None, days=None):
    sku = str(sku or "").strip()[:100]
    if not sku:
        raise ValueError("Не указан товар.")
    with _LOCK:
        d = load()
        it = d["items"].setdefault(sku, {})
        if on is not None:
            it["on"] = bool(on)
        if stock not in (None, ""):
            it["base"] = _int(stock, 0, 100000, 0)
            it["base_ts"] = _now_ms()
            it["seen"] = None               # подхватим текущий остаток прайса при следующем расчёте
            it.pop("pre", None)
            it.pop("pre_since", None)
        if days not in (None, ""):
            it["days"] = _int(days, 1, 30, DEFAULTS["default_days"])
        save(d)
    return it


# ---------------------------------------------------------------- продажи по заказам Kaspi (только чтение)
def refresh_sales(force=False):
    """Подтягивает заказы за последние недели (кэш 10 минут). Возвращает True, если данные свежие."""
    with _LOCK:
        if not force and _sales["orders"] and time.time() - _sales["at"] < CACHE_SEC:
            return True
        d = load()
        bases = [i.get("base_ts") for i in d["items"].values() if i.get("base_ts")]
        since = min(bases) if bases else _now_ms() - 14 * DAY
    windows = max(1, min(4, int((_now_ms() - since) // (14 * DAY)) + 1))
    try:
        from core import order_flow as of
        from core import orders_screen as osr
        orders = of._scan(list(STATES), windows)
        known = {}
        todo = []
        for o in orders:
            a = o.get("attributes") or {}
            if str(a.get("status") or "").upper() in BAD_STATUS:
                continue
            known[o["id"]] = {"ts": int(a.get("creationDate") or 0), "items": None}
            if o["id"] not in _ent_cache:
                todo.append(o["id"])
        if todo:
            with ThreadPoolExecutor(6) as ex:
                for oid, items in zip(todo, ex.map(osr._entries, todo)):
                    if items:
                        _ent_cache[oid] = [(str(i.get("sku") or ""), int(i.get("qty") or 1)) for i in items]
        for oid in list(known):
            if oid in _ent_cache:
                known[oid]["items"] = _ent_cache[oid]
            else:
                known.pop(oid)
        with _LOCK:
            _sales["orders"] = known
            _sales["at"] = time.time()
        return True
    except Exception:
        return False


def sold_since(sku, since_ms):
    n = 0
    for o in _sales["orders"].values():
        if o["ts"] >= since_ms:
            for s, q in o["items"] or []:
                if s == sku:
                    n += q
    return n


# ---------------------------------------------------------------- расчёт по товару
def effective(cfg, product):
    """Состояние автопредзаказа товара или None, если не отслеживается. Меняет cfg (флаг _dirty), сохраняет вызывающий."""
    sku = str(product.get("sku") or "").strip()
    if not sku:
        return None
    if product.get("delivery_type") in ("preorder", "archive"):   # предзаказ со своими сроками и снятые с продажи не трогаем
        return None
    it = cfg["items"].get(sku)
    on = it["on"] if (it and "on" in it) else cfg["enabled_all"]
    if not on:
        return None
    stock_now = int(product.get("stock") or 0)
    manual_base = bool(it and "base" in it)
    if product.get("stock_est") and not manual_base:
        return {"known": False, "on": True, "pre": False, "remaining": None}   # остаток неизвестен: нужно один раз указать
    if (it is None or "base" not in it) and stock_now <= 0 and not (it and it.get("on")):
        return None                         # товар уже на нуле до включения: сам в продажу не возвращаем (только если включить вручную)
    if it is None:
        it = cfg["items"][sku] = {}
    now = _now_ms()
    if "base" not in it:
        it.update(base=stock_now, base_ts=now, seen=stock_now)
        cfg["_dirty"] = True
    elif it.get("seen") is None:
        it["seen"] = stock_now
        cfg["_dirty"] = True
    elif it["seen"] != stock_now and not product.get("stock_est"):
        it.update(base=stock_now, base_ts=now, seen=stock_now)      # остаток изменили в прайсе: считаем пополнением
        it.pop("pre", None)
        it.pop("pre_since", None)
        cfg["_dirty"] = True
    sold = sold_since(sku, it["base_ts"])
    remaining = max(0, int(it["base"]) - sold)
    pre = remaining <= int(cfg["threshold"])
    days = int(it.get("days") or cfg["default_days"])
    if pre and not it.get("pre"):
        it["pre"] = True
        it["pre_since"] = now
        it["title"] = str(product.get("title") or product.get("name") or sku)[:120]
        cfg["_dirty"] = True
    elif not pre and it.get("pre"):
        it.pop("pre", None)
        it.pop("pre_since", None)
        cfg["_dirty"] = True
    return {"known": True, "on": True, "explicit": bool("on" in it), "pre": pre, "remaining": remaining, "base": int(it["base"]),
            "sold": sold, "days": days, "qty": int(cfg["virtual_qty"]), "threshold": int(cfg["threshold"])}


def status_many(products):
    """Состояния для списка товаров (для таблицы магазина). Без сети: используются уже загруженные продажи."""
    with _LOCK:
        cfg = load()
        out = {}
        for p in products:
            e = effective(cfg, p)
            sku = str(p.get("sku") or "")
            it = cfg["items"].get(sku) or {}
            if e is None:
                out[sku] = {"on": False, "explicit": "on" in it}
            else:
                e["explicit"] = "on" in it
                out[sku] = e
        if cfg.pop("_dirty", False):
            save(cfg)
    return out


def apply_to_feed(products):
    """Копии товаров для прайса Kaspi: у почти закончившихся — предзаказ и виртуальный остаток, у остальных — реальный остаток."""
    refresh_sales()
    with _LOCK:
        cfg = load()
        res = []
        for p in products:
            e = effective(cfg, p)
            if not e or not e.get("known"):
                res.append(p)
                continue
            q = dict(p)
            if e["pre"]:
                q.update(delivery_type="preorder", preorder_days=e["days"], stock=e["qty"])
            else:
                q["stock"] = e["remaining"]
            res.append(q)
        if cfg.pop("_dirty", False):
            save(cfg)
    return res


def alerts():
    """Товары, которые ушли в предзаказ: для предупреждения на Главной."""
    d = load()
    out = []
    for sku, it in d["items"].items():
        if it.get("pre"):
            out.append({"sku": sku, "title": it.get("title") or sku, "since": it.get("pre_since")})
    return sorted(out, key=lambda x: -(x["since"] or 0))
