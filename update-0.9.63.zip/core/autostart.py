"""Запуск программы вместе с Windows: ярлык в папке «Автозагрузка», окно сворачивается, браузер не открывается.
Только Windows. Ничего не меняет в системе, кроме одного ярлыка, который можно удалить кнопкой."""
import os
import subprocess
import sys

NAME = "Kaspi WB (автозапуск).lnk"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _folder():
    return os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs", "Startup")


def _lnk():
    return os.path.join(_folder(), NAME)


def supported():
    return sys.platform == "win32" and bool(os.environ.get("APPDATA")) and os.path.exists(os.path.join(ROOT, "start.bat"))


def status():
    return {"supported": supported(), "enabled": supported() and os.path.exists(_lnk())}


def _ps(script):
    return subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                          capture_output=True, text=True, timeout=30, creationflags=0x08000000)


def set_enabled(on):
    if not supported():
        raise ValueError("Автозапуск доступен только в Windows-версии, установленной через установщик.")
    if on:
        os.makedirs(_folder(), exist_ok=True)
        bat = os.path.join(ROOT, "start.bat")
        script = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');"
                  "$s.TargetPath='%s';$s.Arguments='autostart';$s.WorkingDirectory='%s';$s.WindowStyle=7;$s.Save()"
                  % (_lnk().replace("'", "''"), bat.replace("'", "''"), ROOT.replace("'", "''")))
        r = _ps(script)
        if r.returncode != 0 or not os.path.exists(_lnk()):
            raise ValueError("Не удалось создать ярлык автозапуска.")
    else:
        try:
            os.remove(_lnk())
        except FileNotFoundError:
            pass
    return status()
