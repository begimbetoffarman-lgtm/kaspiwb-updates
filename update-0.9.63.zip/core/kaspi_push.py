"""Безопасная отправка изменений одного товара из программы в кабинет Kaspi.

Правила защиты (главное: предзаказ не должен слететь случайно):
- перед отправкой читаем, что сейчас в кабинете и на витрине (цена, остаток, срок предзаказа);
- в Kaspi всегда уходят все три значения: изменённое вами и текущие для остального;
- если срок предзаказа прочитать не удалось, отправка блокируется;
- если отправка убирает или меняет предзаказ, это показывается как предупреждение и требует отдельной отметки;
- текущие значения сохраняются в data/push_backup.json, кнопка «Вернуть как было» отправляет их обратно;
- после отправки читаем кабинет ещё раз и сообщаем, что видно (Kaspi применяет изменения через очередь).
Удаление товаров здесь не используется."""
import json
import os
import threading
import time

from core import kaspi_cabinet as kc
from core import kaspi_store as ks

_FILE = os.path.join(ks.DATA_DIR, "push_backup.json")
_LOCK = threading.Lock()
KEEP = 50


def _load():
    try:
        with open(_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, list) else []
    except (OSError, ValueError):
        return []


def _save(d):
    os.makedirs(os.path.dirname(_FILE), exist_ok=True)
    tmp = _FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d[-KEEP:], f, ensure_ascii=False)
    os.replace(tmp, _FILE)


def current(sku):
    """Что сейчас на Kaspi: цена, остаток, предзаказ (срок берём с витрины), доступность. preorder=None: не удалось прочитать."""
    cab = kc.get_offer(sku)
    pre = None
    if cab.get("card_code"):
        try:
            pub = kc.public_offer(cab["card_code"])
        except Exception:
            pub = None
        if pub is not None:
            pre = int(pub.get("preorder") or 0)
        elif not cab.get("available"):
            pre = 0
    avail = bool(cab.get("available"))
    if cab.get("point_available") is False:
        avail = False
    try:                                                    # свежая сверка со списком кабинета знает, что товар снят
        from core import cabinet_sync
        it = (cabinet_sync._load().get("items") or {}).get(sku)
        if it and time.time() - (cabinet_sync._load().get("at") or 0) < 900 and it.get("av") is False:
            avail = False
    except Exception:
        pass
    return {"sku": sku, "price": int(cab.get("price") or 0), "stock": cab.get("stock"), "available": avail,
            "preorder": pre, "title": cab.get("merchant_title") or cab.get("title") or sku, "model": cab.get("merchant_title")}


def _plan(sku, ch):
    """Итог = текущее на Kaspi + то, что вы изменили. Возвращает (cur, new, diff, warnings, blocked)."""
    cur = current(sku)
    new = {"price": cur["price"], "stock": cur["stock"], "preorder": cur["preorder"], "available": cur["available"]}
    warnings, blocked = [], []
    mode = ch.get("mode")                                   # in_stock | preorder | archive | None (не менять)
    if ch.get("price") not in (None, ""):
        p = int(float(ch["price"]))
        if p <= 0:
            blocked.append("Цена должна быть больше нуля.")
        new["price"] = p
    if ch.get("stock") not in (None, ""):
        s = int(float(ch["stock"]))
        if s < 0:
            blocked.append("Остаток не может быть отрицательным.")
        new["stock"] = s
    if mode == "archive":
        new["available"] = False
    elif mode == "preorder":
        days = int(float(ch.get("preorder_days") or 0))
        if days <= 0 or days > 30:
            blocked.append("Срок предзаказа: от 1 до 30 дней.")
        new["preorder"], new["available"] = days, True
    elif mode == "in_stock":
        new["preorder"], new["available"] = 0, True
    if cur["preorder"] is None and mode in (None, "in_stock", "preorder") and new["available"]:
        if mode != "preorder":
            blocked.append("Не удалось прочитать текущий предзаказ на Kaspi: отправка остановлена, чтобы он не слетел.")
    if cur["preorder"] and new["available"] and new["preorder"] != cur["preorder"]:
        if new["preorder"] == 0:
            warnings.append("На Kaspi предзаказ %d дн. Отправка уберёт предзаказ и товар станет «в наличии»." % cur["preorder"])
        else:
            warnings.append("Срок предзаказа изменится: на Kaspi %d дн, будет %d дн." % (cur["preorder"], new["preorder"]))
    if not cur["preorder"] and new["preorder"]:
        warnings.append("Товар станет предзаказом на %d дн." % new["preorder"])
    if not new["available"] and cur["available"]:
        warnings.append("Товар будет снят с продажи (запись остаётся, вернуть можно).")
    if new["available"] and (new["stock"] is None or int(new["stock"] or 0) <= 0):
        new["stock"] = new["stock"] if new["stock"] else (cur["stock"] or 0)
        if not new["stock"]:
            blocked.append("Остаток 0: укажите остаток, иначе Kaspi не покажет товар.")
    diff = [k for k in ("price", "stock", "preorder", "available") if new[k] != cur[k]]
    if not diff and mode in ("in_stock", "preorder") and not blocked:
        diff = ["available"]            # статус «снят» кабинет по одному товару читает ненадёжно: явный выбор наличия отправляем повторно
        warnings.append("Значения на Kaspi уже такие же. Отправка повторно подтвердит товар в продаже с этими значениями (безопасно).")
    return cur, new, diff, warnings, blocked


def preview(sku, ch):
    sku = str(sku or "").strip()
    if not sku:
        raise ValueError("Не указан артикул.")
    cur, new, diff, warnings, blocked = _plan(sku, ch)
    return {"sku": sku, "current": cur, "new": new, "diff": diff, "warnings": warnings, "blocked": blocked,
            "needs_ack": bool(warnings), "nothing_to_do": not diff}


def apply(sku, ch, confirmed=False, ack=False):
    sku = str(sku or "").strip()
    if not confirmed:
        raise ValueError("Нужно подтверждение отправки.")
    cur, new, diff, warnings, blocked = _plan(sku, ch)
    if blocked:
        raise ValueError(" ".join(blocked))
    if not diff:
        return {"sent": False, "note": "На Kaspi уже так же, отправлять нечего."}
    if warnings and not ack:
        raise ValueError("Есть предупреждения: " + " ".join(warnings) + " Поставьте отметку «понимаю» и отправьте ещё раз.")
    bid = "%d-%s" % (time.time_ns() // 1000, sku)
    with _LOCK:
        d = _load()
        d.append({"id": bid, "sku": sku, "at": time.strftime("%Y-%m-%d %H:%M:%S"), "before": cur, "after": new})
        _save(d)
    if new["available"]:
        res = kc.set_offer(sku, price=new["price"], preorder_days=new["preorder"] or None, available=True,
                           stock=new["stock"], model=cur.get("model"))
    else:
        res = kc.set_offer(sku, available=False)
    # то же в программе, чтобы источники не расходились
    try:
        ks.update_product_price(sku, new["price"])
        ks.update_product_delivery(sku, "preorder" if new["preorder"] else ("in_stock" if new["available"] else "archive"), new["preorder"] or 7)
    except Exception:
        pass
    after = None
    try:
        after = current(sku)
    except Exception:
        pass
    return {"sent": True, "backup_id": bid, "request_id": (res or {}).get("request_id"), "diff": diff, "after": after,
            "note": "Kaspi применяет изменения через очередь, обычно до часа. Проверьте результат позже кнопкой «Сверить»."}


def rollback(backup_id, confirmed=False):
    if not confirmed:
        raise ValueError("Нужно подтверждение.")
    rec = next((r for r in _load() if r.get("id") == backup_id), None)
    if not rec:
        raise ValueError("Копия не найдена.")
    b = rec["before"]
    if b.get("preorder") is None and b.get("available"):
        raise ValueError("В копии не сохранён срок предзаказа, вернуть автоматически нельзя.")
    if b.get("available"):
        kc.set_offer(rec["sku"], price=b["price"], preorder_days=b.get("preorder") or None, available=True, stock=b.get("stock"),
                     model=b.get("model"))
    else:
        kc.set_offer(rec["sku"], available=False)
    try:
        ks.update_product_price(rec["sku"], b["price"])
        ks.update_product_delivery(rec["sku"], "preorder" if b.get("preorder") else "in_stock", b.get("preorder") or 7)
    except Exception:
        pass
    return {"restored": True, "sku": rec["sku"], "values": b}


def history(sku=None, n=10):
    d = [r for r in _load() if not sku or r.get("sku") == sku]
    return d[-n:][::-1]
