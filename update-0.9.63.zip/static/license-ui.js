// Баннеры лицензии: пробный период заканчивается или закончился. Сервер сам закрывает функции (код 402).
(function () {
  const ban = () => {
    let b = document.getElementById('licBanner');
    if (!b) {
      b = document.createElement('div'); b.id = 'licBanner'; b.style.display = 'none';
      const mc = document.querySelector('.main-content'); if (mc) mc.insertBefore(b, mc.firstChild);
    }
    return b;
  };
  async function check() {
    let s; try { s = await (await fetch('/api/license')).json(); } catch (e) { return; }
    const b = ban(); if (!b) return;
    const contact = ' Связь: +7 700 394 00 94 (WhatsApp / Telegram).';
    if (!s.is_active) {
      b.className = 'lic-banner bad';
      b.innerHTML = '<b>Пробный период закончился.</b> Доступны заказы и накладные, настройки и обновления; защита (снятие с продажи товара, которого нет на WB) продолжает работать. Остальное откроется после активации: <a href="#" id="licOpen">Активировать PRO</a>.' + contact;
    } else if (s.status === 'TRIAL' && s.days_left <= 2) {
      b.className = 'lic-banner warn';
      b.innerHTML = '<b>Пробный период заканчивается через ' + s.days_left + ' дн.</b> Чтобы продолжить, <a href="#" id="licOpen">активируйте PRO</a>.' + contact;
    } else if (s.status === 'PRO' && s.days_left <= 3) {
      b.className = 'lic-banner warn';
      b.innerHTML = '<b>Лицензия заканчивается через ' + s.days_left + ' дн.</b> Продлите ключ.' + contact;
    } else { b.style.display = 'none'; return; }
    b.style.display = '';
    const l = document.getElementById('licOpen');
    if (l) l.onclick = e => { e.preventDefault(); const a = document.getElementById('btnSidebarActivate'); if (a) a.click(); };
  }
  // обязательный телефон для связи (WhatsApp): окно без кнопки «закрыть», пока номер не введён
  async function phoneCheck() {
    let c; try { c = await (await fetch('/api/contact')).json(); } catch (e) { return; }
    if (!c || !c.success || c.phone || c.postponed || document.getElementById('phoneModal')) return;
    const m = document.createElement('div'); m.id = 'phoneModal';
    m.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99999;display:flex;align-items:center;justify-content:center;padding:16px';
    m.innerHTML = '<div style="background:#fff;color:#111;border-radius:12px;max-width:440px;width:100%;padding:22px;box-shadow:0 10px 40px rgba(0,0,0,.4)">' +
      '<h3 style="margin:0 0 8px">Ваше имя и номер для связи</h3>' +
      '<p style="margin:0 0 12px;font-size:14px">Укажите имя и номер WhatsApp. Мы напишем, когда пробный период или подписка будут заканчиваться, и поможем с вопросами. Номер видит только автор программы и ничего не рассылает.</p>' +
      '<input id="nameInp" type="text" maxlength="60" placeholder="Ваше имя" style="width:100%;padding:10px;font-size:16px;border:1px solid #bbb;border-radius:8px;box-sizing:border-box;margin-bottom:8px">' +
      '<input id="phoneInp" type="tel" placeholder="+7 700 123 45 67" style="width:100%;padding:10px;font-size:16px;border:1px solid #bbb;border-radius:8px;box-sizing:border-box">' +
      '<div id="phoneErr" style="color:#B91C1C;font-size:13px;min-height:18px;margin-top:6px"></div>' +
      '<button id="phoneOk" class="btn" style="margin-top:6px;width:100%">Сохранить</button>' +
      (c.can_postpone ? '<button id="phoneLater" class="btn" style="margin-top:6px;width:100%;opacity:.75">Позже (спросим через 3 дня)</button>' : '') + '</div>';
    document.body.appendChild(m);
    const inp = document.getElementById('phoneInp'), err = document.getElementById('phoneErr'), ok = document.getElementById('phoneOk');
    const save = async () => {
      ok.disabled = true; err.textContent = '';
      try {
        const r = await (await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: document.getElementById('nameInp').value, phone: inp.value }) })).json();
        if (r.success) { m.remove(); if (typeof showToast === 'function') showToast('✓ Номер сохранён'); return; }
        err.textContent = r.error || 'Не удалось сохранить';
      } catch (e) { err.textContent = 'Нет связи с программой, попробуйте ещё раз.'; }
      ok.disabled = false;
    };
    const later = document.getElementById('phoneLater');
    if (later) later.onclick = async () => { try { await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ later: true }) }); } catch (e) { } m.remove(); };
    ok.onclick = save; inp.onkeydown = e => { if (e.key === 'Enter') save(); };
    document.getElementById('nameInp').focus();
  }
  // сервер отвечает 402, когда функция закрыта: показываем причину и обновляем баннер
  const of = window.fetch; let last = 0;
  window.fetch = async function (...a) {
    const r = await of.apply(this, a);
    if (r.status === 402) {
      try { const d = await r.clone().json(); if (d.license_expired && Date.now() - last > 3000) { last = Date.now(); if (typeof showToast === 'function') showToast(d.error); check(); } } catch (e) { }
    }
    return r;
  };
  // после обновления старый код ещё работает в памяти: просим перезапустить программу
  async function vcheck() {
    let v; try { v = await (await fetch('/api/version')).json(); } catch (e) { return; }
    let b = document.getElementById('restartBanner');
    if (!v || !v.restart_needed) { if (b) b.style.display = 'none'; return; }
    if (!b) {
      b = document.createElement('div'); b.id = 'restartBanner'; b.className = 'lic-banner warn';
      const mc = document.querySelector('.main-content'); if (mc) mc.insertBefore(b, mc.firstChild);
    }
    b.innerHTML = '<b>Программа обновлена до версии ' + v.disk + ', но ещё работает старая (' + v.running + ').</b> Закройте чёрное окно программы и запустите её заново (start.bat), иначе часть функций, например код из почты и сохранение паролей, будет работать неверно.';
    b.style.display = '';
  }
  document.addEventListener('DOMContentLoaded', () => { setTimeout(check, 800); setTimeout(vcheck, 1500); setTimeout(phoneCheck, 2500); });
  setInterval(vcheck, 120000);
  setInterval(check, 300000);
  window.checkLicenseBanner = check;
})();
