// Калькулятор маржинальности. Данные карточки Kaspi приходят с /api/margin/inspect (только чтение),
// деньги считаются здесь, в браузере: любое поле пересчитывает всё сразу.
(function () {
  const $ = id => document.getElementById(id);
  if (!$('mcBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fmt = n => (n == null || !isFinite(n)) ? '—' : Math.round(n).toLocaleString('ru-RU');
  const pct = n => (n == null || !isFinite(n)) ? '—' : (Math.round(n * 10) / 10).toLocaleString('ru-RU') + '%';
  const num = id => { const v = parseFloat(String($(id).value).replace(',', '.')); return isFinite(v) ? v : 0; };

  // Настройки продавца: хранятся в config.json (ключи calc_*). У нового клиента курс и карго пустые: он вводит свои.
  const SET = [
    ['calc_cny', 'mcCny'], ['calc_cargo_hi', 'mcCargoHi'], ['calc_cargo_lo', 'mcCargoLo'], ['calc_commission', 'mcComm'],
    ['calc_tax', 'mcTax'], ['calc_returns', 'mcRet'], ['calc_pack', 'mcPack'], ['calc_ads', 'mcAds'],
    ['calc_review_bonus', 'mcRevBonus'], ['calc_seller_bonus', 'mcSelBonus'], ['calc_other', 'mcOther'],
    ['calc_min_margin', 'mcMinM'], ['calc_conv', 'mcConv'], ['calc_loss', 'mcLoss'], ['calc_k_lo', 'mcKlo'], ['calc_k_hi', 'mcKhi'], ['calc_share_best', 'mcShBest'],
    ['calc_share_near', 'mcShNear'], ['calc_share_low', 'mcShLow'], ['calc_max_months', 'mcMaxMon'], ['calc_threshold_kg', 'mcThr'],
  ];
  const DEFAULTS = { calc_commission: 12.5, calc_tax: 3, calc_returns: 5, calc_pack: 150, calc_conv: 3, calc_loss: 0, calc_ads: 0, calc_review_bonus: 0,
    calc_seller_bonus: 0, calc_other: 0, calc_min_margin: 15, calc_k_lo: 7, calc_k_hi: 10, calc_share_best: 40, calc_share_near: 25,
    calc_share_low: 10, calc_max_months: 2, calc_threshold_kg: 30 };
  // Вес позиции карточки в выдаче категории (оценка: люди смотрят в основном первые страницы; по 12 карточек на странице).
  const POS = [[12, 1.0], [24, 0.9], [36, 0.75], [60, 0.55], [120, 0.35]];
  const POS_FAR = 0.2;
  const posFactor = p => { if (!p) return POS_FAR; for (const [mx, f] of POS) if (p <= mx) return f; return POS_FAR; };

  let card = null;          // данные карточки Kaspi
  let saveT = null;
  let commManual = false;   // продавец сам ввёл комиссию: тогда таблица категорий не используется

  async function loadSettings() {
    let cfg = {};
    try { cfg = await (await fetch('/api/config')).json(); } catch (e) { }
    for (const [k, id] of SET) { const v = cfg[k] != null && cfg[k] !== '' ? cfg[k] : (DEFAULTS[k] != null ? DEFAULTS[k] : ''); $(id).value = v; }
    if (cfg.packaging_cost_kzt && (cfg.calc_pack == null || cfg.calc_pack === '')) $('mcPack').value = cfg.packaging_cost_kzt;
    if (cfg.calc_preorder_days) $('mcDays').value = cfg.calc_preorder_days;
    calc();
  }
  function saveSettings() {
    clearTimeout(saveT);
    saveT = setTimeout(() => {
      const body = {};
      for (const [k, id] of SET) body[k] = $(id).value === '' ? '' : parseFloat(String($(id).value).replace(',', '.'));
      body.calc_preorder_days = num('mcDays') || 14;
      fetch('/api/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).catch(() => { });
    }, 600);
  }

  const cfg = () => ({
    cny: num('mcCny'), cargoHi: num('mcCargoHi'), cargoLo: num('mcCargoLo') || num('mcCargoHi'), thr: num('mcThr') || 30,
    comm: ((card && card.commission && !commManual) ? card.commission.rate : num('mcComm')) / 100, tax: num('mcTax') / 100, ret: num('mcRet') / 100, pack: num('mcPack'), ads: num('mcAds') / 100,
    revBonus: num('mcRevBonus'), selBonus: num('mcSelBonus') / 100, other: num('mcOther'), minM: num('mcMinM') / 100, conv: num('mcConv') / 100, loss: Math.min(0.9, num('mcLoss') / 100), china: num('mcChinaShip'),
    kLo: num('mcKlo') || 7, kHi: num('mcKhi') || 10, shBest: num('mcShBest') / 100, shNear: num('mcShNear') / 100, shLow: num('mcShLow') / 100,
    maxMon: num('mcMaxMon') || 2,
  });

  function deliveryFee(price, weight) {
    const tier = weight > 15 ? '15_to_30kg' : (weight > 5 ? '5_to_15kg' : 'under_5kg');
    const mode = (window.appConfig && window.appConfig.kaspi_delivery_mode) || 'official_kz';
    if (mode === 'custom') return parseInt(window.appConfig.kaspi_delivery_cost_kzt) || 1507;
    const scope = mode === 'official_city' ? 'city' : (mode === 'official_express' ? 'express' : 'kz');
    return typeof getKaspiDeliveryFee === 'function' ? getKaspiDeliveryFee(price, scope, tier) : 0;
  }
  // Себестоимость штуки: закуп в ¥ по курсу + карго за вес (тариф зависит от веса всей партии) + прочее.
  function unitCost(c, cny, w, qty) {
    const total = w * qty;
    const rate = total >= c.thr ? c.cargoHi : c.cargoLo;
    const k = 1 / (1 - c.loss);                      // брак и потери: оплачены, но не проданы
    const base = cny * c.cny, china = c.china * c.cny / qty;
    return { goods: (base + china) * k, base, china, cargo: w * rate * k, rate, total, k };
  }
  function econ(c, P, cost, w) {
    const comm = P * c.comm, pay = P * 0.0095, tax = P * c.tax, ads = P * c.ads, sb = P * c.selBonus;
    const deliv = deliveryFee(P, w);
    const retLoss = c.ret * (deliv + c.pack);       // возвращённый товар вернётся на склад, теряем доставку и упаковку
    const costs = comm + pay + tax + ads + sb + c.revBonus + deliv + c.pack + retLoss + c.other;
    const profit = P - costs - cost;
    return { comm, pay, tax, ads, sb, deliv, retLoss, costs, profit, margin: P > 0 ? profit / P : 0, roi: cost > 0 ? profit / cost : 0 };
  }
  function minPrice(c, cost, w) {
    for (let P = Math.max(100, Math.ceil(cost / 10) * 10); P < cost * 6 + 20000; P += 10) if (econ(c, P, cost, w).margin >= c.minM) return P;
    return null;
  }
  // Спрос по карточке (шт/мес, все продавцы): отзывы за 30 дней × k; если новых отзывов нет, то все отзывы / возраст.
  function demand(k) {
    if (!card) return null;
    let perMonth = null;
    if (card.reviews_30d > 0) perMonth = card.reviews_30d;
    else if (card.reviews > 0 && card.age_days) perMonth = card.reviews / Math.max(1, card.age_days / 30);
    const manual = num('mcDemand');
    if (manual > 0) return manual;
    return perMonth == null ? null : perMonth * k;
  }
  function share(c, P, lowest) {
    if (!lowest || P <= lowest) return c.shBest;
    if (P <= lowest * 1.05) return c.shNear;
    return c.shLow;
  }

  const dmy = s => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? m[3] + '.' + m[2] : '—'; };
  function rowsTop() {
    if (!card || !card.top.length) return '<div class="help-text">Цены продавцов не получены.</div>';
    return '<table class="data-table" style="width:100%"><thead><tr><th>#</th><th>Продавец</th><th>Цена</th><th>Наличие</th><th>Доставка покупателю</th><th>Отправка</th><th>Рейтинг</th></tr></thead><tbody>' +
      card.top.map((o, i) => `<tr><td>${i + 1}</td><td>${esc(o.merchant)}</td><td><b>${fmt(o.price)} ₸</b></td>
        <td>${o.preorder ? `<b style="color:#b45309">Предзаказ ${o.preorder} дн</b>` : '<span style="color:#15803d">В наличии</span>'}</td>
        <td>${dmy(o.delivery)}${o.days != null ? ' (' + o.days + ' дн)' : ''}${o.kaspi_delivery ? ' · Kaspi Доставка' : ''}</td>
        <td>${o.inter_city == null ? '—' : (o.inter_city ? 'из другого города' : 'из вашего города')}</td>
        <td>${o.rating != null ? esc(o.rating) : '—'}${o.reviews ? ' (' + o.reviews + ')' : ''}</td></tr>`).join('') + '</tbody></table><div class="help-text">Доставка считается в город из настроек магазина. Kaspi не показывает название города продавца, только «ваш город» или «другой».</div>';
  }
  function showCard() {
    const el = $('mcCard');
    if (!card) { el.innerHTML = ''; return; }
    const pos = card.position ? `${card.position}-е место (страница ${Math.ceil(card.position / 12)})` : `дальше ${card.position_scanned || 120} места`;
    el.innerHTML = `<div style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap">
      ${card.img ? `<img src="${esc(card.img)}" style="width:110px;height:110px;object-fit:cover;border-radius:12px;border:1px solid #e6e7f4">` : ''}
      <div style="flex:1;min-width:240px"><div style="font-size:17px;font-weight:800">${esc(card.title)}</div>
      <div class="help-text">${esc(card.category || '')} · <a href="${esc(card.link)}" target="_blank" rel="noopener">открыть на Kaspi</a></div>
      <div style="margin-top:8px;display:flex;gap:18px;flex-wrap:wrap;font-size:14px">
        <span>Рейтинг <b>${card.rating != null ? esc(card.rating) : '—'}</b></span><span>Отзывов <b>${fmt(card.reviews)}</b></span>
        <span>За 30 дней <b>${fmt(card.reviews_30d)}</b></span><span>Возраст карточки <b>${card.age_days != null ? Math.round(card.age_days / 30 * 10) / 10 + ' мес' : '—'}</b></span>
        <span>Продавцов <b>${fmt(card.sellers)}</b></span><span>Комиссия Kaspi <b>${card.commission ? card.commission.rate.toLocaleString('ru-RU') + '%' : 'не найдена в таблице'}</b></span><span>Место в категории <b>${pos}</b></span></div></div></div>
      <div style="margin-top:12px"><b>Топ-5 продавцов по цене</b>${rowsTop()}</div>`;
  }

  function calc() {
    const out = $('mcResult');
    const c = cfg();
    const buy = num('mcBuy'), qty = Math.max(1, Math.round(num('mcQty'))), w = num('mcWeight');
    if (!c.cny || !c.cargoHi) { out.innerHTML = '<div class="cards-empty">Сначала заполните курс юаня и тариф карго в блоке «Мои настройки» ниже.</div>'; $('mcSettings').open = true; return; }
    if (!buy || !w) { out.innerHTML = '<div class="cards-empty">Введите закупочную цену в юанях, количество и вес одной штуки, остальное посчитается само.</div>'; return; }
    const prices = card && card.top.length ? card.top.map(o => o.price) : [];
    const lowest = prices[0] || null;
    let P = num('mcPrice');
    if (!P) P = lowest || 0;
    if (!P) { out.innerHTML = '<div class="cards-empty">Вставьте ссылку на карточку Kaspi или введите свою цену продажи.</div>'; return; }
    const uc = unitCost(c, buy, w, qty);
    const cost = uc.goods + uc.cargo;
    const e = econ(c, P, cost, w);
    const mp = minPrice(c, cost, w);
    const days = num('mcDays') || 14;

    // Спрос и сколько партия будет продаваться
    const pf = posFactor(card && card.position);
    const dLo = demand(c.kLo), dHi = demand(c.kHi);
    const sh = share(c, P, lowest);
    const mineLo = dLo != null ? dLo * pf * sh : null, mineHi = dHi != null ? dHi * pf * sh : null;
    const monthsLo = mineLo ? qty / mineLo : null, monthsHi = mineHi ? qty / mineHi : null;   // осторожно = дольше
    const frozen = qty * cost;
    const profitBatch = e.profit * qty;
    const cycle = monthsLo != null ? days / 30 + monthsLo : null;

    // Вердикт
    const reasons = []; let level = 'ok';
    const bad = (t) => { reasons.push('❌ ' + t); level = 'no'; }, warn = (t) => { reasons.push('⚠️ ' + t); if (level === 'ok') level = 'warn'; }, good = t => reasons.push('✅ ' + t);
    if (e.margin >= c.minM) good(`маржа ${pct(e.margin * 100)} при цене ${fmt(P)} ₸ (не ниже ${pct(c.minM * 100)})`); else bad(`маржа ${pct(e.margin * 100)} ниже ${pct(c.minM * 100)} при цене ${fmt(P)} ₸`);
    if (mp && lowest) { if (mp <= lowest) good(`можно держать цену до ${fmt(mp)} ₸ при минимальной марже, самый дешёвый продавец ${fmt(lowest)} ₸`); else warn(`для маржи ${pct(c.minM * 100)} нужна цена от ${fmt(mp)} ₸, а самый дешёвый продавец ${fmt(lowest)} ₸: при демпинге маржа упадёт`); }
    if (card) {
      if (!card.position || card.position > 36) warn(`карточка на ${card.position ? card.position + '-м месте' : 'месте дальше ' + (card.position_scanned || 120)} в категории: мало покупателей доходят до неё`);
      else good(`карточка на ${card.position}-м месте в категории`);
    }
    if (card && days > 3) {
      const near = card.top.filter(o => !o.preorder && o.price <= P * 1.1);
      if (near.length) warn(`у ${near.length} из топ-5 товар в наличии (доставка 1–3 дня) по цене до +10% к вашей, а ваш срок ${days} дн: часть покупателей не станет ждать`);
    }
    if (monthsLo == null) warn('нет данных о продажах карточки: введите ожидаемые продажи в месяц в «Допущениях»');
    else if (monthsLo > c.maxMon) warn(`партия ${qty} шт. продаётся около ${(Math.round(monthsLo * 10) / 10)} мес (осторожная оценка), это дольше ${c.maxMon} мес: деньги заморожены`);
    else good(`партия продаётся примерно за ${(Math.round(monthsHi * 10) / 10)}–${(Math.round(monthsLo * 10) / 10)} мес`);
    const cls = { ok: ['#15803d', '#ecfdf3', 'Стоит брать'], warn: ['#b45309', '#fff8e6', 'Брать осторожно'], no: ['#b91c1c', '#fef2f2', 'Не стоит'] }[level];

    // Сценарии цены
    const scen = [];
    if (lowest) scen.push(['По самому дешёвому −1 ₸', lowest - 1]);
    if (prices[1]) scen.push(['Как второй по цене', prices[1]]);
    if (prices.length > 2) scen.push(['Медиана топ-5', prices[Math.floor(prices.length / 2)]]);
    scen.push(['Ваша цена', P]);
    if (mp) scen.push(['Минимальная для маржи ' + pct(c.minM * 100), mp]);
    const scenRows = scen.map(([n, p]) => {
      const x = econ(c, p, cost, w), s = share(c, p, lowest), d = dLo != null ? dLo * pf * s : null;
      return `<tr><td>${esc(n)}</td><td><b>${fmt(p)} ₸</b></td><td style="color:${x.margin >= c.minM ? '#15803d' : '#b91c1c'}">${pct(x.margin * 100)}</td><td>${fmt(x.profit)} ₸</td><td>${d ? (Math.round(qty / d * 10) / 10) + ' мес' : '—'}</td><td>${d ? fmt(x.profit * qty) + ' ₸' : fmt(x.profit * qty) + ' ₸ (если всё продать)'}</td></tr>`;
    }).join('');

    // Сравнение партий: карго дешевле от порога веса, но большая партия дольше продаётся
    const sizes = [...new Set([5, 10, 20, 30, 50, 100, qty])].sort((a, b) => a - b);
    let best = null;
    const batchData = sizes.map(q => {
      const u = unitCost(c, buy, w, q), cs = u.goods + u.cargo, x = econ(c, P, cs, w);
      const mo = mineLo ? q / mineLo : null, cyc = mo != null ? days / 30 + mo : null;
      const tot = x.profit * q, fr = q * cs;
      const roiYear = cyc && fr > 0 ? tot / fr / cyc * 12 * 100 : null;
      const ok = mo != null && mo <= c.maxMon && x.margin >= c.minM;
      return { q, u, x, mo, cyc, tot, fr, roiYear, ok };
    });
    for (const b of batchData) if (b.ok && b.roiYear != null && (!best || b.roiYear > best.roiYear)) best = b;
    const batchRows = batchData.map(b => `<tr style="${best && b.q === best.q ? 'background:#ecfdf3;font-weight:700' : ''}${b.q === qty ? ';outline:2px solid #1f4bd8' : ''}"><td>${b.q} шт.${b.q === qty ? ' (ваша)' : ''}</td><td>${fmt(b.u.total)} кг · ${fmt(b.u.rate)} ₸/кг</td><td>${fmt(b.u.goods + b.u.cargo)} ₸</td><td>${pct(b.x.margin * 100)}</td><td>${fmt(b.fr)} ₸</td><td>${b.mo ? (Math.round(b.mo * 10) / 10) + ' мес' : '—'}</td><td>${fmt(b.tot)} ₸</td><td>${b.roiYear != null ? Math.round(b.roiYear) + '%' : '—'}</td></tr>`).join('');

    out.innerHTML = `
      <div style="border-radius:16px;padding:16px 20px;background:${cls[1]};border:1px solid ${cls[0]}33;margin-bottom:16px">
        <div style="font-size:22px;font-weight:800;color:${cls[0]}">${cls[2]}</div>
        <div style="margin-top:6px;line-height:1.7">${reasons.map(esc).join('<br>')}</div>
        <div style="margin-top:10px;font-size:15px">С партии ${qty} шт. при цене ${fmt(P)} ₸: <b>${fmt(profitBatch)} ₸ прибыли</b>${monthsLo ? ` за ${Math.round(monthsHi * 10) / 10} мес (оптимистично) – ${Math.round(monthsLo * 10) / 10} мес (осторожно)` : ''}. Вложите ${fmt(frozen)} ₸${cycle ? `, оборот партии ≈ ${(Math.round(cycle * 10) / 10)} мес с учётом ${days} дн доставки` : ''}.</div>
        <div style="margin-top:8px">${(() => { const cush = e.profit - c.minM * P; return cush > 0 && c.conv ? `Запас на рекламу и бонусы: до <b>${fmt(cush)} ₸</b> с проданной штуки, не опуская маржу ниже ${pct(c.minM * 100)}. При конверсии клика в покупку ${pct(c.conv * 100)} цена клика в рекламе Kaspi не должна быть выше <b>${fmt(cush * c.conv)} ₸</b> (минимум у Kaspi 3 ₸).` : 'Запаса на рекламу и бонусы нет: маржа уже на минимуме или ниже.'; })()}</div>
        ${best && best.q !== qty ? `<div style="margin-top:8px;font-weight:700">Выгоднее по оборачиваемости: партия ${best.q} шт. (доходность ≈ ${Math.round(best.roiYear)}% годовых).</div>` : (best ? '<div style="margin-top:8px;font-weight:700">Ваша партия оптимальная из сравниваемых.</div>' : '')}
      </div>
      <div class="cab-box" style="margin-bottom:16px"><b>С одной штуки (цена ${fmt(P)} ₸)</b>
        <table class="data-table" style="width:100%;margin-top:6px"><tbody>
          <tr><td>Закуп ${fmt(buy)} ¥ × ${c.cny}${c.china ? ' + доставка по Китаю' : ''}${c.loss ? ' + брак/потери ' + pct(c.loss * 100) : ''}</td><td style="text-align:right">${fmt(uc.goods)} ₸</td></tr>
          <tr><td>Карго ${w} кг × ${fmt(uc.rate)} ₸/кг (вес партии ${fmt(uc.total)} кг)</td><td style="text-align:right">${fmt(uc.cargo)} ₸</td></tr>
          <tr><td><b>Себестоимость</b></td><td style="text-align:right"><b>${fmt(cost)} ₸</b></td></tr>
          <tr><td>Комиссия Kaspi ${pct(c.comm * 100)}${card && card.commission && !commManual ? ' (по таблице Kaspi для категории' + (card.commission.ambiguous ? ', в категории бывают разные ставки: проверьте' : '') + ')' : ' (введена вручную)'}</td><td style="text-align:right">${fmt(e.comm)} ₸</td></tr>
          <tr><td>Kaspi Pay 0,95%</td><td style="text-align:right">${fmt(e.pay)} ₸</td></tr>
          <tr><td>Kaspi Доставка</td><td style="text-align:right">${fmt(e.deliv)} ₸</td></tr>
          <tr><td>Налог ${pct(c.tax * 100)}</td><td style="text-align:right">${fmt(e.tax)} ₸</td></tr>
          <tr><td>Упаковка</td><td style="text-align:right">${fmt(c.pack)} ₸</td></tr>
          <tr><td>Возвраты ${pct(c.ret * 100)} (теряем доставку и упаковку)</td><td style="text-align:right">${fmt(e.retLoss)} ₸</td></tr>
          ${e.ads ? `<tr><td>Реклама ${pct(c.ads * 100)}</td><td style="text-align:right">${fmt(e.ads)} ₸</td></tr>` : ''}
          ${e.sb ? `<tr><td>Бонус продавца ${pct(c.selBonus * 100)}</td><td style="text-align:right">${fmt(e.sb)} ₸</td></tr>` : ''}
          ${c.revBonus ? `<tr><td>Бонус за отзыв</td><td style="text-align:right">${fmt(c.revBonus)} ₸</td></tr>` : ''}
          ${c.other ? `<tr><td>Прочее</td><td style="text-align:right">${fmt(c.other)} ₸</td></tr>` : ''}
          <tr><td><b>Прибыль с штуки</b></td><td style="text-align:right;color:${e.profit >= 0 ? '#15803d' : '#b91c1c'}"><b>${fmt(e.profit)} ₸ · маржа ${pct(e.margin * 100)} · ROI ${pct(e.roi * 100)}</b></td></tr>
        </tbody></table></div>
      <div class="cab-box" style="margin-bottom:16px"><b>Если придётся снижать цену (демпинг)</b>
        <table class="data-table" style="width:100%;margin-top:6px"><thead><tr><th>Вариант</th><th>Цена</th><th>Маржа</th><th>С штуки</th><th>Продажа партии</th><th>С партии</th></tr></thead><tbody>${scenRows}</tbody></table></div>
      <div class="cab-box"><b>Какую партию возить</b> <span class="help-text">(карго от ${c.thr} кг дешевле, но большая партия дольше продаётся; зелёная строка — лучшая по годовой доходности в пределах ${c.maxMon} мес продажи)</span>
        <table class="data-table" style="width:100%;margin-top:6px"><thead><tr><th>Партия</th><th>Вес и тариф</th><th>Себестоимость</th><th>Маржа</th><th>Вложить</th><th>Продажа</th><th>Прибыль</th><th>Годовых</th></tr></thead><tbody>${batchRows}</tbody></table></div>
      <div class="help-text" style="margin-top:10px">Прогноз приблизительный: продажи оцениваются по отзывам (1 отзыв ≈ ${c.kLo}–${c.kHi} продаж), долей продавца и местом карточки в категории. Допущения можно поправить ниже и сверить с вашими реальными продажами.${card && card.reviews_30d === 0 ? ' За 30 дней новых отзывов нет, спрос взят по среднему за возраст карточки.' : ''}</div>`;
  }

  async function loadCard() {
    const link = $('mcLink').value.trim();
    if (!link) return;
    const b = $('mcLoad'); b.disabled = true; $('mcStatus').textContent = 'Читаю карточку, цены продавцов и место в категории (до 30 секунд)...';
    try {
      const d = await (await fetch('/api/margin/inspect', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ link }) })).json();
      if (!d.success) { $('mcStatus').textContent = d.error || 'Не удалось прочитать карточку.'; return; }
      card = d; $('mcStatus').textContent = '';
      if (!num('mcPrice') && d.top.length) $('mcPrice').placeholder = 'по умолчанию ' + d.top[0].price;
      showCard(); calc();
    } catch (e) { $('mcStatus').textContent = 'Нет связи с программой.'; } finally { b.disabled = false; }
  }
  async function loadCny() {
    $('mcCnyHint').textContent = 'запрашиваю...';
    try { const d = await (await fetch('/api/margin/cny')).json(); $('mcCnyHint').textContent = d.success ? 'НБ РК сегодня: ' + d.rate + ' ₸' : (d.error || 'нет данных'); } catch (e) { $('mcCnyHint').textContent = 'нет связи'; }
  }

  $('mcLoad').onclick = loadCard;
  $('mcLink').addEventListener('keydown', e => { if (e.key === 'Enter') loadCard(); });
  $('mcCnyBtn').onclick = loadCny;
  $('mcBox').addEventListener('input', e => { if (e.target.tagName === 'INPUT') { if (e.target.id === 'mcComm') commManual = true; calc(); if (e.target.closest('#mcSettings') || e.target.id === 'mcDays') saveSettings(); } });
  document.addEventListener('DOMContentLoaded', loadSettings);
  window.loadMarginTab = loadSettings;
})();
