// ⚡ Радар вилок (WB / Ozon → Kaspi): режим вкладки «Радар».
// Данные — /api/radar/forks, сохранение — /api/radar/save_to_found.
(function () {
  const $ = id => document.getElementById(id);
  const fmt = n => (n === null || n === undefined || n === '' || isNaN(n)) ? '—' : Math.round(n).toLocaleString('ru-RU') + ' ₸';
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const st = { source: 'all', mode: 'spread', margin: 20, items: [], selected: new Set(), busy: false, cats: null, query: 'органайзер для кухни', cat: '', pre: {} };
  const toast = msg => { if (typeof window.showToast === 'function') window.showToast(msg); };

  function setMode(mode) {
    const isForks = mode === 'forks';
    const vac = $('radarVacuumPanel'), fk = $('radarForksPanel');
    if (vac) vac.hidden = isForks;
    if (fk) fk.hidden = !isForks;
    document.querySelectorAll('.rms-btn').forEach(b => {
      const on = b.dataset.radarMode === mode;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    if (isForks) {
      document.querySelectorAll('#forksPills .pill-btn').forEach(p => p.classList.toggle('active', (p.dataset.query || '') === st.query));
      loadCategories();
      if (!st.items.length) {
        loadHistory().then(() => { if (st.history && st.history.length) restoreHistory(st.history[0].id); else runSearch(); });
      } else loadHistory();
    }
  }

  function status(msg, cls) {
    const el = $('forksStatus'); if (!el) return;
    el.innerHTML = msg || '';
    el.className = 'help-text' + (cls ? ' ' + cls : '');
  }

  function renderNotes(notes) {
    const el = $('forksNotes'); if (!el) return;
    const list = Object.values(notes || {}).filter(Boolean);
    el.innerHTML = list.length ? list.map(n => `<div class="forks-note">${esc(n)}</div>`).join('') : '';
  }

  async function runSearch(byCategory) {
    if (st.busy) { st.queued = Boolean(byCategory); return; }   // выбрали подраздел, пока шёл поиск по разделу — повторим сразу после него
    const q = ($('forksQuery').value || '').trim();
    if (byCategory && !st.cat) return;
    if (!byCategory && !q) { status('Введите запрос или выберите нишу.'); return; }
    st.query = byCategory ? st.cat : q;
    st.busy = true;
    const btn = $('forksGo'); const old = btn.textContent;
    btn.disabled = true; btn.textContent = '⏳ Сканирую…';
    status('Ищу связки на ' + (st.source === 'all' ? 'WB и Ozon' : st.source.toUpperCase()) + ' и сверяю с Kaspi…');
    const range = $('forksMargin');
    st.margin = Number(range.value);
    const url = '/api/radar/forks?query=' + encodeURIComponent(byCategory ? '' : q) +
      (byCategory ? '&category=' + encodeURIComponent(st.cat) : '') +
      '&source=' + encodeURIComponent(st.source) +
      '&mode=' + encodeURIComponent(st.mode) +
      '&min_margin=' + st.margin +
      '&live_kaspi=' + ($('forksLiveKaspi').checked ? '1' : '0') + '&lazy=1';
    const r = await apiGet(url);
    st.busy = false; btn.disabled = false; btn.textContent = old;
    if (st.queued !== undefined) {
      const again = st.queued; st.queued = undefined;
      if (again && st.cat && st.cat !== st.query) { setTimeout(() => runSearch(true), 0); return; }   // категория изменилась — этот результат устарел
    }
    if (!r.ok) {
      st.items = []; renderList();
      status(esc(r.error || 'Не удалось получить список товаров.'));
      return;
    }
    applyResult(r.data, q, false);
    loadHistory();
    if (r.data.pending && r.data.pending.length) startKaspiQueue(r.data.pending);
  }

  // Проверка Kaspi идёт уже после показа списка, по два товара одновременно; карточки обновляются по мере готовности.
  let renderTimer = null;
  function scheduleRender() { clearTimeout(renderTimer); renderTimer = setTimeout(renderList, 400); }
  async function startKaspiQueue(ids) {
    const token = (st.qtoken = (st.qtoken || 0) + 1);
    let next = 0, done = 0;
    const total = ids.length, base = $('forksStatus') ? $('forksStatus').innerHTML : '';
    const worker = async () => {
      while (next < ids.length && token === st.qtoken) {
        const id = ids[next++];
        const it = st.items.find(x => String(x.id) === String(id));
        if (!it || (it.kaspi && it.kaspi.checked)) { done++; continue; }
        try {
          const resp = await fetch('/api/radar/kaspi_check', { method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: it.name, kaspi_query: it.kaspi_query || '', image: it.image || '', hid: st.hid || '', id: it.id,
              buy_kzt: (it.economy || {}).buy_kzt || 0, rate: (it.economy || {}).rate || 0 }) });
          const r = await resp.json();
          if (resp.ok && r.success && token === st.qtoken) {
            it.kaspi = r.kaspi;
            if (r.economy) { it.economy = r.economy; it.sell_source = r.sell_source; it.price_risk = r.price_risk || ''; it.confidence = r.confidence; }
            scheduleRender();
          }
        } catch (e) { /* пропускаем: кнопка «Проверить продавцов» останется */ }
        done++;
        if (token === st.qtoken) status(base + ' · Kaspi проверено: ' + done + ' из ' + total);
      }
    };
    await Promise.all([worker(), worker()]);
    if (token === st.qtoken && st.mode !== 'vacuum') {           // после проверки Kaspi лучшие (с реальной ценой) поднимаем наверх
      const ord = { verified: 0, free: 1, estimate: 2 };
      const prof = x => (x.economy && x.economy.profit_kzt) || 0;
      st.items.sort((a, b) => (ord[a.confidence] ?? 2) - (ord[b.confidence] ?? 2) || prof(b) - prof(a));
      renderList();
    }
    if (token === st.qtoken) status(base);
  }

  function applyResult(d, q, restored) {
    st.items = d.items || [];
    st.hid = d.hid || '';
    st.selected.clear(); updateSel();
    renderNotes(d.notes);
    const modeName = { spread: 'Жирный спред', speed: 'Быстрый оборот', vacuum: 'Вакуум' }[d.mode] || '';
    const what = d.by_category ? `категория «${esc(d.category)}» → поиск «${esc(d.searched_as)}»`
      : `запрос «${esc(d.searched_as || q)}»`;
    status(`${d.total} связок · ${what} · ${modeName} · маржа от ${d.min_margin}% · ${restored ? 'из истории, сохранено' : 'обновлено'} ${esc(d.checked_at)}${d.live ? '' : ' · эталонные данные'}`);
    renderList();
    document.querySelectorAll('#forksPills .pill-btn').forEach(p => p.classList.toggle('active', !d.by_category && (p.dataset.query || '') === (q || d.query)));
  }

  async function loadHistory() {
    const r = await apiGet('/api/radar/forks_history');
    st.history = (r.ok && r.data.items) || [];
    const box = $('forksHistory'); if (!box) return;
    box.innerHTML = st.history.length ? '<span>Прошлые поиски:</span>' + st.history.map(h =>
      `<button type="button" class="pill-btn fk-hist" data-hid="${esc(h.id)}" title="${esc(h.at || '')}">${esc(h.label)} · ${esc(h.total)}</button>`).join('')
      + '<button type="button" class="pill-btn fk-hist-clear" id="forksHistClear" title="Удалить сохранённые поиски с этого компьютера">✕ Очистить список</button>' : '';
    const cl = $('forksHistClear');
    if (cl) cl.onclick = async () => {
      if (!confirm('Очистить список прошлых поисков? Сами товары в «Найденном» останутся.')) return;
      const r = await apiPost('/api/radar/forks_history/clear', {});
      if (r.ok) { st.history = []; box.innerHTML = ''; } else { status(esc(r.error || 'Не удалось очистить список.')); }
    };
  }

  async function restoreHistory(hid) {
    const r = await apiGet('/api/radar/forks_history/' + encodeURIComponent(hid));
    if (!r.ok) { status(esc(r.error || 'Не удалось открыть сохранённый поиск.')); return; }
    applyResult(r.data, r.data.query, true);
  }

  function clearCat() {
    st.cat = '';
    const path = $('forksCatPath'); if (path) path.textContent = '';
  }

  // ---------------- карточки
  function sideSource(it) {
    const src = it.source === 'ozon' ? 'Ozon' : 'WB';
    const rating = it.rating ? `<span class="fk-star">★ ${it.rating.toFixed(1)}</span>` : '<span class="fk-muted">рейтинг —</span>';
    const fb = it.feedbacks ? `<span class="fk-muted">${Number(it.feedbacks).toLocaleString('ru-RU')} отзывов</span>` : '';
    const img = it.image
      ? `<img class="fk-img" src="${esc(it.image)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">`
      : `<div class="fk-img fk-img-ph">${esc((it.name || '?')[0]).toUpperCase()}</div>`;
    return `<div class="fk-side">
      ${img}
      <div class="fk-side-main">
        <div class="fk-src">${src}${it.seed ? ' · эталон' : ''}</div>
        <div class="fk-name" title="${esc(it.name)}">${esc(it.name)}</div>
        <div class="fk-meta">${rating} ${fb}</div>
        <div class="fk-buy">Закупка <b>${fmt(it.economy.buy_kzt)}</b>
          <span class="fk-rub">${it.economy.buy_rub ? '≈ ' + it.economy.buy_rub.toLocaleString('ru-RU') + ' ₽' : ''}</span></div>
        ${it.url ? `<a class="fk-link" href="${esc(it.url)}" target="_blank" rel="noopener">Открыть на ${src} ↗</a>` : ''}
      </div>
    </div>`;
  }

  // Спрос на Kaspi: продаж Kaspi не публикует, смотрим отзывы точных карточек и их темп в месяц
  function demandLevel(ks) {
    const rpm = Number(ks && ks.reviews_per_month);
    if (!ks || ks.reviews_per_month == null || !(ks.exact_matches > 0)) return null;
    return rpm >= 3 ? { k: 'high', t: 'спрос хороший' } : rpm >= 0.7 ? { k: 'mid', t: 'спрос средний' } : { k: 'low', t: 'спрос слабый' };
  }
  function demandHtml(ks) {
    const d = demandLevel(ks);
    if (!d) return '';
    const col = d.k === 'high' ? '#7be3a3' : d.k === 'mid' ? '#f3d27a' : '#ff9b9b';
    return `<div class="fk-muted" style="color:${col};margin-top:4px" title="Продажи Kaspi не публикует: считаем отзывы точных карточек и сколько их приходит в месяц">📈 ${d.t}: ${ks.reviews_total} отзывов, ≈${ks.reviews_per_month} в мес.</div>`;
  }

  function kaspiSide(it) {
    const ks = it.kaspi || {};
    const price = it.economy.sell_kzt;
    const priceTag = it.sell_source === 'kaspi' ? '✓ Реальная цена: точная карточка на Kaspi' : 'Расчёт по формуле ×2,4 от закупки';
    const riskHtml = (it.price_risk ? `<div class="fk-muted" style="color:#ff9b9b;margin-top:4px">⚠ ${esc(it.price_risk)}</div>` : '')
      + (it.group_note ? `<div class="fk-muted" style="color:#f3d27a;margin-top:4px">❗ ${esc(it.group_note)}</div>` : '');
    let sellers;
    if (ks.sellers !== null && ks.sellers !== undefined) sellers = `${ks.sellers} продавцов`;
    else if (ks.checked) sellers = 'продавцов 0';
    else sellers = 'продавцы не проверены';
    const cls = ks.checked ? (ks.vacuum_status === 'saturated' ? 'is-busy' : 'is-free') : 'is-unknown';
    const vac = it.vacuum_level === 'free' ? '<span class="fk-vac fk-vac-free">🕳️ Вакуум: конкурентов нет</span>'
      : it.vacuum_level === 'weak' ? '<span class="fk-vac fk-vac-weak">🕳️ Почти вакуум</span>' : '';
    return `<div class="fk-side fk-kaspi">
      <div class="fk-side-main">
        <div class="fk-src">Kaspi.kz</div>
        <div class="fk-sell">${fmt(price)}</div>
        <div class="fk-muted">${priceTag}</div>
        ${riskHtml}
        <div class="fk-sellers ${cls}">${sellers}</div>
        ${demandHtml(ks)}
        ${vac}
        <div class="fk-muted fk-note" title="${esc(ks.note || '')}">${esc((ks.note || '').slice(0, 90))}</div>
        ${(ks.cards || []).filter(c => c.url).slice(0, 3).map((c, i) => `<div class="fk-kcard-row" style="display:flex;gap:6px;align-items:center;margin-top:4px"><a class="fk-link fk-kcard" href="${esc(c.url)}" target="_blank" rel="noopener" title="${esc(c.title)}" style="display:flex;gap:6px;align-items:center;flex:1;min-width:0">${c.img ? `<img src="${esc(c.img)}" alt="" width="34" height="34" style="border-radius:6px;object-fit:cover" referrerpolicy="no-referrer">` : ''}<span><b>${c.score}%</b> ${c.confirmed ? '✓ подтверждено вами' : c.exact ? 'точная' : 'похожая'}${c.price ? ' · ' + fmt(c.price) : ''}<br><small>${esc(c.title.slice(0, 40))}</small>${(c.specs_conflict || []).length ? `<br><small class="fk-conflict" title="${esc(c.specs_conflict.join('; '))}">⚠ ${esc(c.specs_conflict[0])}</small>` : (c.specs_match || []).length ? `<br><small class="fk-specs-ok" title="Совпали с названием: ${esc(c.specs_match.join(', '))}">✓ совпало: ${esc(c.specs_match.join(', '))}</small>` : ''}</span></a>${c.confirmed ? `<button type="button" class="btn btn-sm btn-secondary fk-kdec" data-d="reset" data-id="${esc(it.id)}" data-i="${i}" title="Забыть решение">↺</button>` : `<button type="button" class="btn btn-sm btn-secondary fk-kdec" data-d="yes" data-id="${esc(it.id)}" data-i="${i}" title="Да, это тот же товар">✓</button><button type="button" class="btn btn-sm btn-secondary fk-kdec" data-d="no" data-id="${esc(it.id)}" data-i="${i}" title="Нет, это другой товар">✕</button>`}</div>`).join('')}
        ${ks.checked ? '' : `<button type="button" class="btn btn-sm btn-secondary fk-kcheck" data-id="${esc(it.id)}">Проверить продавцов</button>`}
        ${ks.kaspi_url ? `<a class="fk-link" href="${esc(ks.kaspi_url)}" target="_blank" rel="noopener">Открыть поиск Kaspi ↗</a>` : ''}
      </div>
    </div>`;
  }

  function verdict(e) {
    if (e.status === 'LOSS') return 'fk-verdict-loss';
    if (e.margin_pct >= 25) return 'fk-verdict-super';
    if (e.margin_pct >= 12) return 'fk-verdict-ok';
    return 'fk-verdict-low';
  }


  // ---------------- «Сочность» связки: оценка 0–100 и причины (для поиска сильных карточек)
  // Маржа 30 + прибыль с штуки 15 + спрос 20 + рейтинг 5 + конкуренция на Kaspi 20 + надёжность цены 5 + остаток 5.
  // Пока цена продажи расчётная (Kaspi не проверен), выше 69 не поднимаем: «сочной» может быть только связка с реальной ценой Kaspi.
  function scoreItem(it) {
    const e = it.economy || {}, k = it.kaspi || {};
    const why = [];
    const add = (ok, t) => why.push({ ok: ok, t: t });
    let pts = 0;
    const margin = Number(e.margin_pct) || 0, profit = Number(e.profit_kzt) || 0;
    pts += Math.max(0, Math.min(30, margin * 0.75));
    add(margin >= 25, 'маржа ' + Math.round(margin) + '%');
    pts += Math.max(0, Math.min(15, profit / 4000 * 15));
    add(profit >= 1500, (profit > 0 ? '+' : '') + Math.round(profit).toLocaleString('ru-RU') + ' ₸ с штуки');
    const fb = Number(it.feedbacks) || 0;
    if (it.source === 'wb' || fb > 0) {
      pts += fb <= 0 ? 0 : Math.min(20, Math.log10(fb + 1) / Math.log10(2001) * 20);
      add(fb >= 300, fb ? fb.toLocaleString('ru-RU') + ' отзывов на WB' : 'на WB нет отзывов');
    } else { pts += 8; why.push({ ok: null, t: 'для Ozon спрос не виден' }); }
    const rt = Number(it.rating) || 0;
    if (rt) { pts += rt >= 4.7 ? 5 : rt >= 4.5 ? 3 : rt >= 4.3 ? 1 : 0; if (rt < 4.5) add(false, 'рейтинг ' + rt); }
    else pts += 2;
    const sellers = k.sellers, vs = k.vacuum_status;
    if (k.checked) {
      if (vs === 'vacuum_full') { pts += 20; add(true, 'на Kaspi такого нет'); }
      else if (vs === 'vacuum_low_competition') { pts += 14; add(true, 'на Kaspi мало продавцов' + (sellers != null ? ' (' + sellers + ')' : '')); }
      else { const n = sellers == null ? 9 : sellers; pts += n <= 5 ? 8 : n <= 10 ? 4 : 0; add(n <= 5, 'на Kaspi уже ' + (sellers == null ? 'есть продавцы' : n + ' продавц.')); }
    } else { pts += 6; why.push({ ok: null, t: 'Kaspi ещё не проверен' }); }
    const real = it.sell_source === 'kaspi';          // «сочная» (70+) — только с реальной ценой точной карточки Kaspi
    pts += real ? 5 : 1;
    if (!real) why.push({ ok: false, t: 'цена продажи расчётная' });
    const st0 = it.stock;
    if (st0 == null) pts += 2; else { pts += st0 >= 50 ? 5 : st0 >= 10 ? 3 : 0; if (st0 < 10) add(false, 'остаток на WB ' + st0); }
    let score = Math.round(Math.min(100, pts));
    if (profit <= 0 || e.status === 'LOSS') { score = Math.min(score, 20); why.unshift({ ok: false, t: 'убыток' }); }
    else if (it.price_risk) { score = Math.min(score, 45); why.unshift({ ok: false, t: 'похожие на Kaspi заметно дешевле' }); }
    else if (!real) score = Math.min(score, 69);
    else if (it.sell_source === 'kaspi') {
      const dl = demandLevel(k);
      if (dl && dl.k === 'low') { score = Math.min(score, 60); why.unshift({ ok: false, t: 'спрос на Kaspi слабый (мало отзывов)' }); }
      else { if (dl && dl.k === 'high') why.unshift({ ok: true, t: 'спрос на Kaspi хороший' }); why.unshift({ ok: true, t: 'прибыль по реальной цене Kaspi' }); }
    }
    const tier = score >= 85 ? 'top' : score >= 70 ? 'juicy' : score >= 50 ? 'ok' : 'low';
    return { score: score, tier: tier, why: why };
  }
  function scoreBadgeInline(it) { const r = scoreFor(it); return `<div class="fk-score fk-tier-${r.tier}" title="Оценка сочности 0–100: маржа, прибыль, спрос на WB, конкуренция на Kaspi, рейтинг, остаток"><b>${r.score}</b><small>${TIER_RU[r.tier]}</small></div>`; }
  function scoreWhy(it) { const r = scoreFor(it); return r.why.slice(0, 7).map(w => `<span class="fk-why ${w.ok === true ? 'ok' : w.ok === false ? 'bad' : 'neutral'}">${w.ok === true ? '✓' : w.ok === false ? '!' : '·'} ${esc(w.t)}</span>`).join(''); }
  function scoreFor(it) { return (it._sc = scoreItem(it)); }
  const TIER_RU = { top: '🔥 Топ', juicy: '💎 Сочная', ok: '👍 Нормальная', low: 'Слабая' };

  function card(it) {
    const e = it.economy || {};
    const id = esc(it.id);
    const sel = st.selected.has(it.id);
    const profit = e.profit_kzt || 0;
    const badge = e.status === 'ESTIMATE'
      ? `<div class="fk-badge fk-badge-est">оценка: цена продажи расчётная</div>`
      : `<div class="fk-badge">${profit > 0 ? '+' : ''}${Math.round(profit).toLocaleString('ru-RU')} ₸ чистыми <span>(${e.margin_pct}% маржа · ROI ${e.roi_pct}%)</span></div>`;
    // находка и мини-шкала маржи (50% и выше — полная шкала); для оценочных цен не показываем
    const mg = Number(e.margin_pct) || 0, real = e.status !== 'LOSS' && e.status !== 'ESTIMATE';
    const gem = real ? (mg >= 40 || profit >= 8000 ? '<span class="badge-gem badge-gold">★ Золотая находка</span>' : (mg >= 25 ? '<span class="badge-gem">Находка ×2</span>' : '')) : '';
    const bar = real ? `<div class="mbar ${mg >= 25 ? 'mbar-hi' : (mg >= 12 ? 'mbar-mid' : 'mbar-lo')}" title="Маржа ${mg}%"><i style="--m:${Math.max(2, Math.min(100, mg * 2))}%"></i></div>` : '';
    return `<article class="fk-card ${sel ? 'is-sel' : ''}" data-id="${id}">
      <header class="fk-head">
        <label class="fk-check"><input type="checkbox" class="fk-sel" data-id="${id}" ${sel ? 'checked' : ''}><span></span></label>
        <div class="fk-title">${esc(it.name)}${it.brand ? ` <span class="fk-muted">· ${esc(it.brand)}</span>` : ''}</div>
        ${scoreBadgeInline(it)}
      </header>
      <div class="fk-whys-row">${scoreWhy(it)}</div>
      <div class="fk-body">
        ${sideSource(it)}
        <div class="fk-middle ${verdict(e)}">
          <div class="fk-flow">Закуп <b>${fmt(e.buy_kzt)}</b> <span class="fk-arrow">➔</span> Kaspi <b>${fmt(e.sell_kzt)}</b></div>
          ${badge}${gem ? `<div class="fk-gem">${gem}</div>` : ''}${bar}
          <button type="button" class="fk-details-btn" data-details="${id}">Детализация расходов</button>
        </div>
        ${kaspiSide(it)}
      </div>
      <div class="fk-details" id="fk-det-${id}" hidden></div>
      <footer class="fk-actions">
        <button type="button" class="btn btn-sm btn-primary" data-to-store="${id}">В магазин</button>
        <button type="button" class="btn btn-sm" data-to-preorder="${id}">На предзаказ</button>
      </footer>
    </article>`;
  }

  function detailsHtml(it) {
    const e = it.economy || {};
    const rows = [
      ['Цена продажи Kaspi', e.sell_kzt, ''],
      ['Закупка на ' + (it.source === 'ozon' ? 'Ozon' : 'WB'), -e.buy_kzt, e.buy_rub ? '≈ ' + e.buy_rub.toLocaleString('ru-RU') + ' ₽ по курсу ' + e.rate : ''],
      ['Комиссия Kaspi (' + e.commission_rate + '%' + (e.commission_assumed ? ', ставка по умолчанию: категория не учтена' : '') + ')', -e.commission_kzt, ''],
      ['Эквайринг Kaspi Pay', -e.kaspi_pay_kzt, ''],
      ['Доставка Kaspi (' + esc(e.delivery_tier) + ')', -e.delivery_kzt, 'с НДС ' + fmt(e.delivery_vat_kzt)],
      ['Упаковка', -e.pack_kzt, ''],
      ['Налог ИП 3%', -e.tax_kzt, ''],
    ];
    return `<table class="fk-det-table">
      <tbody>${rows.map(([k, v, note]) => `<tr><td>${k}</td><td class="${v < 0 ? 'neg' : ''}">${v < 0 ? '−' : ''}${fmt(Math.abs(v))}</td><td class="fk-muted">${note}</td></tr>`).join('')}</tbody>
      <tfoot>
        <tr><td>На руки с продажи</td><td colspan="2"><b>${fmt(e.payout_kzt)}</b></td></tr>
        <tr class="fk-det-net"><td>Чистая прибыль</td><td>${(e.profit_kzt || 0) > 0 ? '+' : ''}${fmt(e.profit_kzt)}</td><td class="fk-muted">ROI ${e.roi_pct}% · маржа ${e.margin_pct}%</td></tr>
      </tfoot>
    </table>`;
  }

  function renderList() {
    const box = $('forksList'); if (!box) return;
    if (!st.items.length) {
      box.innerHTML = '<div class="forks-empty">Связок нет. Подвиньте «Мин. чистую маржу» влево (0% — показать все), смените источник или запрос.</div>';
      return;
    }
    st.items.forEach(it => { it._sc = scoreItem(it); });
    const juicyOnly = lsGet('fkJuicy') === '1', byScore = lsGet('fkSort') !== 'orig';
    let list = st.items.slice();
    if (byScore) list.sort((a, b) => b._sc.score - a._sc.score);
    const juicyN = st.items.filter(x => x._sc.score >= 70).length;
    if (juicyOnly) list = list.filter(x => x._sc.score >= 70);
    const bar = `<div class="fk-toolbar"><label><input type="checkbox" id="fkJuicyOnly" ${juicyOnly ? 'checked' : ''}> Только сочные (от 70 баллов)</label>` +
      `<label>Порядок: <select id="fkSortSel"><option value="score" ${byScore ? 'selected' : ''}>по сочности</option><option value="orig" ${byScore ? '' : 'selected'}>как нашёл поиск</option></select></label>` +
      `<span class="fk-juicy-n">Сочных: <b>${juicyN}</b> из ${st.items.length}</span></div>`;
    box.innerHTML = bar + (list.length ? list.map(card).join('') : '<div class="forks-empty">Сочных связок в этом поиске нет. Снимите галочку «Только сочные» или смените запрос и подвиньте маржу влево.</div>');
    const jo = $('fkJuicyOnly'); if (jo) jo.onchange = () => { lsSet('fkJuicy', jo.checked ? '1' : '0'); renderList(); };
    const ss = $('fkSortSel'); if (ss) ss.onchange = () => { lsSet('fkSort', ss.value); renderList(); };
  }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* без хранилища не запомним */ } }

  function updateSel() {
    const n = st.selected.size;
    const c = $('forksSelCount'); if (c) c.textContent = n;
    const b = $('forksSaveSel'); if (b) b.disabled = !n;
  }

  // ---------------- «Найденное»: выгрузка
  async function saveToFound(list) {
    if (!list.length) return false;
    const r = await apiPost('/api/radar/save_to_found', { items: list, query: st.query });
    if (r.ok) { toast('✓ ' + (r.data.message || 'Сохранено в «Найденное».')); return true; }
    toast('Не удалось сохранить: ' + r.error);
    return false;
  }

  function openPreorder() {
    const tab = document.querySelector('.nav-item[data-tab="tab-preorder"]');
    if (tab) tab.click();
    toast('Товар в «Найденном». В разделе «Предзаказ карточек» вставьте ссылку на такую же карточку Kaspi, чтобы присоединиться к ней.');
  }

  // Эталонные связки не имеют живых id WB/Ozon: сначала повторяю поиск по запросу,
  // затем беру живую связку с тем же товаром, иначе предлагаю найти товар в Радаре.
  async function resolveLive(it) {
    if (!it.seed) return it;
    if (st.pre[it.id]) return st.pre[it.id];
    status('Ищу этот товар в живой выдаче площадки…');
    const r = await apiGet('/api/radar/forks?query=' + encodeURIComponent(it.kaspi_query || it.name) +
      '&source=' + encodeURIComponent(it.source) + '&mode=spread&min_margin=0&live_kaspi=0&limit=60');
    const words = (it.name || '').toLowerCase().split(/\s+/).filter(w => w.length > 4);
    const hit = r.ok ? (r.data.items || []).find(x => !x.seed && words.filter(w => x.name.toLowerCase().includes(w)).length >= Math.min(2, words.length)) : null;
    if (hit) { st.pre[it.id] = hit; return hit; }
    status('');
    toast('Эталоны в «Найденное» не сохраняются: живой товар сейчас не нашёлся. Введите этот запрос в поиск Радара или откройте «Хиты Wildberries» — там живые ссылки.');
    return null;
  }

  async function toStoreOrPreorder(it, preorder) {
    const live = await resolveLive(it);
    if (!live) return;
    if (await saveToFound([live])) {
      const tab = document.querySelector('.nav-item[data-tab="' + (preorder ? 'tab-preorder' : 'tab-found') + '"]');
      if (tab) tab.click();
      if (preorder) openPreorder();
    }
  }

  async function refreshData(it, btn, id) {
    if (btn.dataset.busy) return;
    btn.dataset.busy = '1'; btn.disabled = true; btn.textContent = '⏳ Проверяю Kaspi…';
    const r = await apiGet('/api/radar/forks?query=' + encodeURIComponent(it.kaspi && it.kaspi.kaspi_url ? (it.kaspi_query || it.name) : st.query) +
      '&source=' + encodeURIComponent(it.source) + '&mode=spread&min_margin=0&live_kaspi=1');
    delete btn.dataset.busy;
    if (r.ok && (r.data.items || []).length) {
      const match = r.data.items.find(x => x.id === it.id) || r.data.items[0];
      const i = st.items.findIndex(x => x.id === it.id);
      if (i >= 0 && match) {
        const wasSel = st.selected.has(it.id);
        st.items[i] = match;
        st.selected.delete(it.id); if (wasSel) st.selected.add(match.id);
        updateSel();
        renderList();
        showToast('Данные обновлены.');
        return;
      }
    }
    btn.disabled = false; btn.textContent = 'Обновить данные';
    showToast('Не удалось обновить: ' + (r.error || 'повторите позже'));
  }

  // ---------------- категории
  async function loadCategories() {
    if (st.cats) return;
    const r = await apiGet('/api/radar/categories');
    st.cats = (r.ok && r.data.items) || [];
    try { st.tree = await (await fetch('/wb_categories.json')).json(); } catch (e) { st.tree = []; }
    st.path = [];
    renderTree();
  }

  function renderTree() {
    const box = $('forksCatSelects'); if (!box) return;
    box.innerHTML = '';
    let nodes = st.tree || [];
    for (let lvl = 0; lvl <= st.path.length && nodes && nodes.length; lvl++) {
      const levelNodes = nodes, sel = document.createElement('select');
      sel.style.minWidth = '200px';
      sel.innerHTML = '<option value="">' + (lvl === 0 ? 'Выберите раздел' : 'Все в разделе') + '</option>' +
        levelNodes.map((n, i) => `<option value="${i}">${esc(n.n)}</option>`).join('');
      const cur = st.path[lvl];
      if (cur) sel.value = String(levelNodes.indexOf(cur));
      sel.addEventListener('change', () => {
        st.path = st.path.slice(0, lvl);
        if (sel.value !== '') st.path.push(levelNodes[+sel.value]);
        renderTree();
        if (st.path.length) {
          st.cat = st.path.map(p => p.n).join(' / ');
          $('forksQuery').value = '';
          const path = $('forksCatPath');
          if (path) path.textContent = 'Выбрано: ' + st.cat + '. Можно выбрать подраздел глубже или нажать «Найти выгодные товары».';
          runSearch(true);
        }
      });
      box.appendChild(sel);
      nodes = cur ? cur.c : null;
    }
  }

  function renderCats(needle) {
    const box = $('forksCatList'); if (!box) return;
    const n = needle.trim().toLowerCase();
    const list = n ? st.cats.filter(c => c.name.toLowerCase().includes(n) || c.path.join(' ').toLowerCase().includes(n)) : [];
    box.innerHTML = list.slice(0, 8).map(c =>
      `<button type="button" class="forks-cat" data-cat="${esc(c.name)}" data-path="${esc(c.path.join(' / '))}"><b>${esc(c.name)}</b><span>${esc(c.path.slice(0, -1).join(' · '))}</span></button>`
    ).join('');
  }

  // ---------------- события
  function bind() {
    document.querySelectorAll('.rms-btn').forEach(b => b.addEventListener('click', () => setMode(b.dataset.radarMode)));

    const go = $('forksGo'); if (go) go.addEventListener('click', () => runSearch(Boolean(st.cat)));
    const q = $('forksQuery');
    if (q) q.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); clearCat(); runSearch(false); } });
    if (q) q.addEventListener('input', async () => {
      if (st.cat) clearCat();
      await loadCategories();
      renderCats(q.value.trim().length >= 3 ? q.value : '');
    });

    document.querySelectorAll('#forksSource .seg-btn').forEach(b => b.addEventListener('click', () => {
      st.source = b.dataset.v;
      document.querySelectorAll('#forksSource .seg-btn').forEach(x => x.classList.toggle('active', x === b));
      runSearch();
    }));

    const mode = $('forksMode'); if (mode) mode.addEventListener('change', () => { st.mode = mode.value; runSearch(); });
    document.querySelectorAll('#forksModeBtns .seg-btn').forEach(b => b.addEventListener('click', () => {
      document.querySelectorAll('#forksModeBtns .seg-btn').forEach(x => {
        const on = x === b;
        x.classList.toggle('active', on);
        x.setAttribute('aria-checked', on ? 'true' : 'false');
        x.textContent = x.textContent.replace(/^✓ /, '');
        if (on) x.textContent = '✓ ' + x.textContent;
      });
      if (mode) { mode.value = b.dataset.v; mode.dispatchEvent(new Event('change')); }
    }));

    const range = $('forksMargin'); if (range) range.addEventListener('input', () => { $('forksMarginVal').textContent = range.value + '%'; });
    if (range) range.addEventListener('change', () => { st.margin = Number(range.value); runSearch(); });

    document.addEventListener('click', e => {
      const h = e.target.closest('.fk-hist'); if (h) restoreHistory(h.dataset.hid);
    });
    document.addEventListener('click', async e => {
      const b = e.target.closest('.fk-kcheck'); if (!b || b.disabled) return;
      const it = st.items.find(x => String(x.id) === b.dataset.id); if (!it) return;
      b.disabled = true; b.textContent = 'Проверяю Kaspi…';
      try {
        const resp = await fetch('/api/radar/kaspi_check', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: it.name, kaspi_query: it.kaspi_query || '', image: it.image || '', hid: st.hid || '', id: it.id }) });
        const r = await resp.json();
        if (!resp.ok || !r.success) { b.disabled = false; b.textContent = 'Проверить продавцов'; status(esc(r.error || 'Kaspi не ответил.')); return; }
        it.kaspi = r.kaspi; renderList();
      } catch (err) { b.disabled = false; b.textContent = 'Проверить продавцов'; status('Не удалось связаться с Kaspi. Повторите.'); }
    });

    document.addEventListener('click', async e => {
      const b = e.target.closest('.fk-kdec'); if (!b || b.disabled) return;
      const it = st.items.find(x => String(x.id) === b.dataset.id); if (!it) return;
      const card = ((it.kaspi || {}).cards || []).filter(c => c.url).slice(0, 3)[Number(b.dataset.i)]; if (!card) return;
      b.disabled = true;
      try {
        const resp = await fetch('/api/radar/kaspi_confirm', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: it.id, decision: b.dataset.d, card, kaspi: it.kaspi, hid: st.hid || '' }) });
        const r = await resp.json();
        if (!resp.ok || !r.success) { b.disabled = false; status(esc(r.error || 'Не удалось сохранить решение.')); return; }
        it.kaspi = r.kaspi;
        if (b.dataset.d === 'no') it.kaspi.cards = (it.kaspi.cards || []).filter(c => c.url !== card.url);
        renderList();
      } catch (err) { b.disabled = false; status('Не удалось сохранить решение. Повторите.'); }
    });

    const live = $('forksLiveKaspi'); if (live) live.addEventListener('change', () => { if (live.checked) runSearch(); });

    document.querySelectorAll('#forksPills .pill-btn').forEach(p => p.addEventListener('click', () => {
      $('forksQuery').value = p.dataset.query || '';
      clearCat();
      runSearch(false);
    }));

    const cl = $('forksCatList');
    if (cl) cl.addEventListener('click', e => {
      const b = e.target.closest('.forks-cat'); if (!b) return;
      st.cat = b.dataset.path || b.dataset.cat;
      $('forksQuery').value = '';
      cl.innerHTML = '';
      const path = $('forksCatPath');
      if (path) path.textContent = 'Выбрано: ' + st.cat + '.';
      runSearch(true);
    });

    const saveBtn = $('forksSaveSel'); if (saveBtn) saveBtn.addEventListener('click', async () => {
      const list = st.items.filter(x => st.selected.has(x.id) && !x.seed);
      if (!list.length) { toast('Эталонные связки не сохраняются: они без живой ссылки. Выберите сканированные товары или нажмите «Обновить данные».'); return; }
      if (await saveToFound(list)) { st.selected.clear(); updateSel(); renderList(); }
    });

    const list = $('forksList');
    if (list) list.addEventListener('click', e => {
      const t = e.target;
      if (t.classList && t.classList.contains('fk-sel')) {
        const id = st.items.find(x => x.id === t.dataset.id)?.id;
        if (t.checked) st.selected.add(id); else st.selected.delete(id);
        const art = t.closest('.fk-card'); if (art) art.classList.toggle('is-sel', t.checked);
        updateSel();
        return;
      }
      const det = t.closest('[data-details]');
      if (det) {
        const it = st.items.find(x => x.id === det.dataset.details); if (!it) return;
        const box = $('fk-det-' + it.id); if (!box) return;
        if (box.hidden) { box.innerHTML = detailsHtml(it) + '<button type="button" class="btn btn-sm" data-refresh="1">Обновить данные</button>'; box.hidden = false; }
        else box.hidden = true;
        return;
      }
      const ref = t.closest('[data-refresh]');
      if (ref) {
        const art = ref.closest('.fk-card'); if (!art) return;
        const it = st.items.find(x => x.id === art.dataset.id);
        if (it) refreshData(it, ref, it.id);
        return;
      }
      const store = t.closest('[data-to-store]');
      if (store) {
        const it = st.items.find(x => x.id === store.dataset.toStore); if (!it) return;
        toStoreOrPreorder(it, false);
        return;
      }
      const pre = t.closest('[data-to-preorder]');
      if (pre) {
        const it = st.items.find(x => x.id === pre.dataset.toPreorder); if (!it) return;
        toStoreOrPreorder(it, true);
      }
    });
  }

  // Состояние экрана «Арбитраж» для ui-state.js: сохраняется и возвращается без запуска поиска.
  window.forksUiState = {
    get: () => ({ source: st.source, mode: st.mode }),
    set: s => {
      if (s.source && ['all', 'wb', 'ozon'].indexOf(s.source) >= 0) {
        st.source = s.source;
        document.querySelectorAll('#forksSource .seg-btn').forEach(x => x.classList.toggle('active', x.dataset.v === s.source));
      }
      if (s.mode && ['spread', 'speed', 'vacuum'].indexOf(s.mode) >= 0) {
        st.mode = s.mode;
        const sel = $('forksMode'); if (sel) sel.value = s.mode;
        document.querySelectorAll('#forksModeBtns .seg-btn').forEach(x => {
          const on = x.dataset.v === s.mode;
          x.classList.toggle('active', on); x.setAttribute('aria-checked', on ? 'true' : 'false');
          x.textContent = x.textContent.replace(/^✓ /, ''); if (on) x.textContent = '✓ ' + x.textContent;
        });
      }
    }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind);
  else bind();
})();