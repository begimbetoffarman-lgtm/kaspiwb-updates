// Баннер «Вышло обновление»: появляется сверху, когда есть новая версия; плюс одно уведомление браузера на версию.
(function () {
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const LS = 'kwUpdSeen';
  let bar = null;

  const getSeen = () => { try { return localStorage.getItem(LS) || ''; } catch (e) { return ''; } };
  const setSeen = v => { try { localStorage.setItem(LS, v); } catch (e) { /* без хранилища баннер просто покажется снова */ } };

  function remove() { if (bar) { bar.classList.add('uvb-out'); const b = bar; setTimeout(() => b.remove(), 350); bar = null; } }

  function show(html, actions) {
    if (bar) bar.remove();
    bar = document.createElement('div');
    bar.className = 'upd-banner';
    bar.setAttribute('role', 'status');
    bar.innerHTML = `<div class="uvb-ico">🚀</div><div class="uvb-text">${html}</div><div class="uvb-btns"></div>`;
    const box = bar.querySelector('.uvb-btns');
    actions.forEach(a => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'uvb-btn' + (a.primary ? ' uvb-primary' : '');
      b.textContent = a.label;
      b.onclick = () => a.run(b);
      box.appendChild(b);
    });
    document.body.appendChild(bar);
  }

  function notify(latest) {
    try {
      if (!('Notification' in window) || Notification.permission !== 'granted') return;
      if (getSeen() === 'n' + latest) return;
      new Notification('Kaspi WB: вышло обновление ' + latest, { body: 'Не забудьте обновить программу: Настройки → Обновления.' });
      setSeen('n' + latest);
    } catch (e) { /* уведомления недоступны: остаётся баннер */ }
  }

  async function install(btn) {
    btn.disabled = true; btn.textContent = 'Устанавливаю…';
    try {
      const r = await fetch('/api/update/apply', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }).then(x => x.json());
      if (r.success && r.ok) {
        show('<b>Обновление установлено.</b> Закройте программу и запустите её снова, чтобы изменения заработали. Ваши данные не изменились.', [{ label: 'Понятно', primary: true, run: remove }]);
      } else {
        show('<b>Не удалось установить.</b> ' + esc(r.error || 'Попробуйте позже в Настройках → Обновления.'), [{ label: 'Закрыть', run: remove }]);
      }
    } catch (e) { btn.disabled = false; btn.textContent = 'Обновить сейчас'; }
  }

  async function check() {
    try {
      const r = await fetch('/api/update/check', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }).then(x => x.json());
      if (!r || !r.success) return;
      if (r.available && r.latest) {
        if (getSeen() === 'd' + r.latest) return;             // уже закрывали баннер для этой версии
        const notes = r.notes ? '<div class="uvb-notes">' + esc(String(r.notes).slice(0, 160)) + '</div>' : '';
        show('<b>Вышло обновление ' + esc(r.latest) + '</b> (у вас ' + esc(r.current || '') + '). Не забудьте обновить.' + notes, [
          { label: 'Обновить сейчас', primary: true, run: install },
          { label: 'Позже', run: () => { setSeen('d' + r.latest); remove(); } },
        ]);
        notify(r.latest);
        return;
      }
      const v = await fetch('/api/version').then(x => x.json()).catch(() => null);
      if (v && v.success && v.restart_needed && getSeen() !== 'r' + v.disk) {
        show('<b>Обновление установлено.</b> Перезапустите программу, чтобы оно заработало.', [{ label: 'Понятно', primary: true, run: () => { setSeen('r' + v.disk); remove(); } }]);
      }
    } catch (e) { /* без связи проверим в следующий раз */ }
  }

  setTimeout(check, 4000);
  setInterval(check, 30 * 60 * 1000);
})();
