/* Лёгкая «моторика» интерфейса: скользящий индикатор меню, капсула в сегментах, вспышка подтверждения на кнопке.
   Ничего не меняет в логике программы; без этого файла интерфейс работает так же, только без плавных переездов. */
(function () {
  'use strict';
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function moveNavIndicator() {
    const menu = document.querySelector('.sidebar .nav-menu');
    if (!menu) return;
    let ind = menu.querySelector('.nav-ind');
    if (!ind) { ind = document.createElement('i'); ind.className = 'nav-ind'; ind.setAttribute('aria-hidden', 'true'); menu.insertBefore(ind, menu.firstChild); }
    const a = menu.querySelector('.nav-item.active:not(.nav-sub)');
    if (!a || a.offsetParent === null) { ind.classList.remove('on'); return; }
    const h = Math.round(a.offsetHeight * 0.52);
    ind.style.height = h + 'px';
    ind.style.transform = 'translateY(' + Math.round(a.offsetTop + (a.offsetHeight - h) / 2) + 'px)';
    ind.classList.add('on');
  }

  function moveSegs() {
    document.querySelectorAll('.seg').forEach(seg => {
      if (seg.offsetParent === null) return;
      const on = seg.querySelector('button.on');
      if (!on) return;
      seg.style.setProperty('--x', on.offsetLeft + 'px');
      seg.style.setProperty('--w', on.offsetWidth + 'px');
      if (!seg.classList.contains('slide')) {
        // первый показ без анимации, потом включаем плавность
        seg.style.setProperty('--x', on.offsetLeft + 'px');
        requestAnimationFrame(() => seg.classList.add('slide'));
      }
    });
  }

  function refresh() { moveNavIndicator(); moveSegs(); }
  document.addEventListener('click', e => {
    if (e.target.closest && e.target.closest('.nav-item, [data-seg], .nav-group-toggle, .wz-go')) {
      setTimeout(refresh, 20); setTimeout(refresh, 320);
    }
  });
  window.addEventListener('resize', refresh);
  window.addEventListener('load', () => { refresh(); setTimeout(refresh, 400); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(refresh);
  document.addEventListener('DOMContentLoaded', () => setTimeout(refresh, 60));

  // плавный счёт чисел в чипах шапки («Товаров в базе», «Средний ROI»): главные KPI на главной считает home.js
  function watchCounters() {
    if (reduce) return;
    document.querySelectorAll('.kpi-val').forEach(el => {
      if (el.__cu) return; el.__cu = true;
      let busy = false, last = parseFloat(String(el.textContent).replace(/[^\d.-]/g, ''));
      new MutationObserver(() => {
        if (busy) return;
        const raw = String(el.textContent), to = parseFloat(raw.replace(/[^\d.-]/g, ''));
        if (!isFinite(to) || !isFinite(last) || to === last) { last = to; return; }
        const from = last, pre = /^[+-]/.test(raw) && to >= 0 ? '+' : '', suf = raw.replace(/^[^\d]*[\d\s.,]+/, '');
        const t0 = performance.now(), dur = 600; busy = true;
        (function step(t) {
          const k = Math.min(1, (t - t0) / dur), v = from + (to - from) * (1 - Math.pow(1 - k, 3));
          el.textContent = pre + Math.round(v).toLocaleString('ru-RU') + suf;
          if (k < 1) requestAnimationFrame(step); else { el.textContent = raw; busy = false; last = to; }
        })(t0);
      }).observe(el, { childList: true, characterData: true, subtree: true });
    });
  }
  document.addEventListener('DOMContentLoaded', () => setTimeout(watchCounters, 100));
  window.addEventListener('load', watchCounters);

  // подтверждение: после «✓ …/сохранено/готово» на нажатой кнопке вспыхивает изумрудное кольцо
  let lastBtn = null, lastAt = 0;
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('.btn, button'); if (b) { lastBtn = b; lastAt = Date.now(); } }, true);
  function pulse() {
    if (reduce || !lastBtn || Date.now() - lastAt > 8000) return;
    const b = lastBtn; b.classList.remove('pulse-ok'); void b.offsetWidth; b.classList.add('pulse-ok');
    setTimeout(() => b.classList.remove('pulse-ok'), 900);
  }
  function wrapToast() {
    const orig = window.showToast;
    if (typeof orig !== 'function' || orig.__ux) return;
    const w = function (msg) { try { if (/^\s*(✓|✔)|сохранен|сохранён|готов|отправлен|применен|применён|подключен|подключён|обновлен|обновлён/i.test(String(msg))) pulse(); } catch (e) { /* ignore */ } return orig.apply(this, arguments); };
    w.__ux = true; window.showToast = w;
  }
  document.addEventListener('DOMContentLoaded', () => setTimeout(wrapToast, 0));
  window.addEventListener('load', wrapToast);
})();
