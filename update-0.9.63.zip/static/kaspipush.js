// «Отправить в Kaspi»: окно сверки и отправки одного товара. Ничего не уходит без вашего нажатия и подтверждения.
(function () {
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fmt = n => Math.round(n || 0).toLocaleString('ru-RU');
  let box = null, cur = null, timer = null;

  async function post(url, body) {
    try {
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      return await r.json();
    } catch (e) { return { success: false, error: e.message }; }
  }

  function args() {
    const mode = box.querySelector('#kpMode').value;
    const a = { sku: cur.sku, mode: mode === 'keep' ? null : mode };
    const price = box.querySelector('#kpPrice').value;
    const stock = box.querySelector('#kpStock').value;
    if (price !== '' && Number(price) !== Number(cur.kaspiPrice)) a.price = price;
    if (stock !== '' && Number(stock) !== Number(cur.kaspiStock)) a.stock = stock;
    if (mode === 'preorder') a.preorder_days = box.querySelector('#kpDays').value;
    return a;
  }

  function show() {
    if (box) box.remove();
    box = document.createElement('div');
    box.className = 'kp-back';
    box.innerHTML = `<div class="kp-modal" role="dialog">
      <button class="kp-x" type="button" aria-label="Закрыть">×</button>
      <h3>Отправить в Kaspi</h3>
      <div class="kp-title">${esc(cur.title)} <span class="kp-sku">${esc(cur.sku)}</span></div>
      <div class="kp-now" id="kpNow">Читаю, что сейчас на Kaspi…</div>
      <div class="kp-form">
        <label>Цена, ₸ <input type="number" id="kpPrice" min="1" value="${esc(cur.price || '')}"></label>
        <label>Остаток, шт <input type="number" id="kpStock" min="0" placeholder="не менять"></label>
        <label>Наличие
          <select id="kpMode"><option value="keep">Не менять (оставить как на Kaspi)</option><option value="in_stock">В наличии</option><option value="preorder">Предзаказ</option><option value="archive">Снять с продажи</option></select>
        </label>
        <label id="kpDaysWrap" style="display:none">Срок, дней <input type="number" id="kpDays" min="1" max="30" value="${esc(cur.days || 12)}"></label>
      </div>
      <div id="kpDiff" class="kp-diff"></div>
      <label class="kp-ack" id="kpAckWrap" style="display:none"><input type="checkbox" id="kpAck"> Понимаю, что это изменит товар на Kaspi</label>
      <div class="kp-actions">
        <button type="button" class="btn btn-primary" id="kpSend" disabled>Отправить в Kaspi</button>
        <button type="button" class="btn btn-secondary" id="kpClose">Закрыть</button>
      </div>
      <div id="kpMsg" class="kp-msg"></div>
    </div>`;
    document.body.appendChild(box);
    box.querySelector('.kp-x').onclick = box.querySelector('#kpClose').onclick = () => box.remove();
    box.addEventListener('click', e => { if (e.target === box) box.remove(); });
    const re = () => { clearTimeout(timer); timer = setTimeout(refresh, 350); };
    ['kpPrice', 'kpStock', 'kpDays'].forEach(id => box.querySelector('#' + id).addEventListener('input', re));
    box.querySelector('#kpMode').onchange = () => { box.querySelector('#kpDaysWrap').style.display = box.querySelector('#kpMode').value === 'preorder' ? '' : 'none'; refresh(); };
    box.querySelector('#kpAck').onchange = updateSend;
    box.querySelector('#kpSend').onclick = send;
    refresh();
  }

  let last = null;
  function updateSend() {
    const b = box.querySelector('#kpSend');
    const ackOk = !last || !last.needs_ack || box.querySelector('#kpAck').checked;
    b.disabled = !last || last.nothing_to_do || (last.blocked && last.blocked.length > 0) || !ackOk;
  }

  async function refresh() {
    if (!box) return;
    const msg = box.querySelector('#kpMsg'); msg.textContent = '';
    const r = await post('/api/kaspi/push/preview', args());
    if (!box) return;
    if (!r.success) { box.querySelector('#kpNow').textContent = 'Не удалось прочитать, что сейчас на Kaspi. Отправка недоступна.'; box.querySelector('#kpDiff').innerHTML = `<div class="kp-bad">${esc(r.error || 'Не удалось прочитать Kaspi')}</div>`; last = null; updateSend(); return; }
    last = r;
    const c = r.current, n = r.new;
    cur.kaspiPrice = c.price; cur.kaspiStock = c.stock;
    const preTxt = x => (x.available === false ? 'снят с продажи' : (x.preorder ? 'предзаказ ' + x.preorder + ' дн' : (x.preorder === 0 ? 'в наличии' : 'не удалось прочитать')));
    box.querySelector('#kpNow').innerHTML = `Сейчас на Kaspi: <b>${fmt(c.price)} ₸</b> · остаток <b>${c.stock == null ? '?' : c.stock}</b> · <b>${preTxt(c)}</b>`;
    if (!box.querySelector('#kpStock').value && !box.querySelector('#kpStock').dataset.set) { box.querySelector('#kpStock').placeholder = c.stock == null ? 'не менять' : 'сейчас ' + c.stock; }
    let h = '';
    if (r.nothing_to_do) h += '<div class="kp-ok">Изменений нет: на Kaspi уже так же.</div>';
    else {
      h += '<table><tr><th></th><th>Было</th><th>Станет</th></tr>';
      if (r.diff.includes('price')) h += `<tr><td>Цена</td><td>${fmt(c.price)} ₸</td><td><b>${fmt(n.price)} ₸</b></td></tr>`;
      if (r.diff.includes('stock')) h += `<tr><td>Остаток</td><td>${c.stock == null ? '?' : c.stock}</td><td><b>${n.stock}</b></td></tr>`;
      if (r.diff.includes('preorder') || r.diff.includes('available')) h += `<tr><td>Наличие</td><td>${preTxt(c)}</td><td><b>${preTxt(n)}</b></td></tr>`;
      h += '</table>';
      if (!r.diff.includes('preorder') && c.preorder) h += `<div class="kp-ok">Предзаказ ${c.preorder} дн сохраняется.</div>`;
    }
    (r.warnings || []).forEach(w => { h += `<div class="kp-warn">⚠ ${esc(w)}</div>`; });
    (r.blocked || []).forEach(w => { h += `<div class="kp-bad">⛔ ${esc(w)}</div>`; });
    box.querySelector('#kpDiff').innerHTML = h;
    box.querySelector('#kpAckWrap').style.display = r.needs_ack && !r.nothing_to_do ? '' : 'none';
    if (!r.needs_ack) box.querySelector('#kpAck').checked = false;
    updateSend();
  }

  async function send() {
    const b = box.querySelector('#kpSend'); b.disabled = true;
    const msg = box.querySelector('#kpMsg'); msg.className = 'kp-msg'; msg.textContent = 'Отправляю…';
    const a = Object.assign(args(), { confirmed: true, ack: box.querySelector('#kpAck').checked });
    const r = await post('/api/kaspi/push/apply', a);
    if (!r.success) { msg.className = 'kp-msg kp-bad'; msg.textContent = r.error || 'Не удалось отправить.'; updateSend(); return; }
    if (!r.sent) { msg.textContent = r.note || 'Отправлять нечего.'; return; }
    const af = r.after;
    if (a.mode !== 'archive') startWatch(cur.sku, cur.title, a);      // снятие с продажи кабинет по одному товару читает ненадёжно: смотрите «Сверку с Kaspi»
    msg.className = 'kp-msg kp-ok';
    msg.innerHTML = `Отправлено. ${esc(r.note)}<br>Сейчас в кабинете: ${af ? fmt(af.price) + ' ₸, остаток ' + (af.stock == null ? '?' : af.stock) + ', ' + (af.preorder ? 'предзаказ ' + af.preorder + ' дн' : 'в наличии') : 'не удалось перечитать'}.<br><button type="button" class="btn btn-secondary btn-sm" id="kpUndo">Вернуть как было</button>`;
    box.querySelector('#kpUndo').onclick = async () => {
      if (!confirm('Вернуть значения, которые были на Kaspi до этой отправки?')) return;
      const u = await post('/api/kaspi/push/rollback', { id: r.backup_id, confirmed: true });
      msg.textContent = u.success ? 'Возврат отправлен в Kaspi.' : (u.error || 'Не удалось вернуть.');
      if (typeof window.loadKaspiStore === 'function') window.loadKaspiStore();
    };
    if (typeof window.loadKaspiStore === 'function') window.loadKaspiStore();
  }

  // ---- автопроверка после отправки: раз в 45 секунд смотрим кабинет до часа и сообщаем «применено» ----
  const WKEY = 'kwPushWatch';
  const loadW = () => { try { return JSON.parse(localStorage.getItem(WKEY) || '[]'); } catch (e) { return []; } };
  const saveW = l => { try { localStorage.setItem(WKEY, JSON.stringify(l)); } catch (e) { /* без хранилища следим только до перезагрузки */ } };
  let watching = false;

  function toast(text, bad) {
    const t = document.createElement('div');
    t.className = 'kp-toast' + (bad ? ' kp-toast-bad' : '');
    t.textContent = text;
    document.body.appendChild(t);
    setTimeout(() => t.classList.add('kp-toast-out'), 9000);
    setTimeout(() => t.remove(), 9600);
  }

  async function tickWatch() {
    let list = loadW();
    if (!list.length) { watching = false; return; }
    const keep = [];
    for (const w of list) {
      if (Date.now() > w.until) { toast('Kaspi пока не применил изменения для ' + w.title + '. Проверьте позже.', true); continue; }
      const r = await post('/api/kaspi/push/preview', w.args);
      if (r && r.success && r.nothing_to_do) {
        toast('✅ Kaspi применил: ' + w.title);
        if (typeof window.loadKaspiStore === 'function') window.loadKaspiStore();
        continue;
      }
      keep.push(w);
    }
    saveW(keep);
    if (keep.length) setTimeout(tickWatch, 45000); else watching = false;
  }

  function startWatch(sku, title, args) {
    const clean = Object.assign({}, args); delete clean.confirmed; delete clean.ack;
    const l = loadW().filter(w => w.args.sku !== sku);
    l.push({ args: clean, title: title || sku, until: Date.now() + 65 * 60 * 1000 });
    saveW(l);
    if (!watching) { watching = true; setTimeout(tickWatch, 30000); }
  }
  if (loadW().length) { watching = true; setTimeout(tickWatch, 8000); }

  // кнопка в строке товара (таблица перерисовывается, поэтому делегирование)
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('.kp-open');
    if (!b) return;
    const tr = b.closest('tr');
    cur = { sku: b.dataset.sku, title: (tr && tr.querySelector('.prod-title, .p-title, td b, td strong') || {}).textContent || b.dataset.sku,
            price: (tr && tr.querySelector('.price-input-inline') || {}).value, days: b.dataset.days };
    show();
  });

  // «Найти поставщика 1688 по фото»: фото карточки Kaspi уходит в готовый поиск на вкладке 1688
  document.addEventListener('click', async e => {
    const b = e.target.closest && e.target.closest('.kp-photo');
    if (!b) return;
    const u = b.dataset.img;
    b.disabled = true;
    try {
      const r = await fetch('/api/kaspi/img_proxy?u=' + encodeURIComponent(u));
      if (!r.ok) throw new Error('Фото не загрузилось');
      const blob = await r.blob();
      const file = new File([blob], 'kaspi-' + (b.dataset.sku || 'photo') + '.jpg', { type: blob.type || 'image/jpeg' });
      const inp = document.getElementById('cnPhoto');
      const tab = document.querySelector('[data-tab="tab-1688"]');
      if (!inp || !tab) throw new Error('Вкладка 1688 недоступна');
      const dt = new DataTransfer(); dt.items.add(file); inp.files = dt.files;
      tab.click();
      inp.dispatchEvent(new Event('change', { bubbles: true }));
      setTimeout(() => { const f = document.getElementById('cnPhotoForm'); if (f && f.scrollIntoView) f.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 300);
      toast('Фото загружено на вкладку 1688: обведите сам товар и нажмите «Найти поставщиков по фото».');
    } catch (err) { toast('Не удалось передать фото: ' + err.message, true); }
    finally { b.disabled = false; }
  });

  window.kpBtnHtml = p => `<button type="button" class="btn btn-secondary btn-sm kp-open" data-sku="${esc(p.sku)}" data-days="${esc(p.preorder_days || '')}" title="Сверить с Kaspi и отправить изменения этого товара. Без вашего подтверждения ничего не уходит.">⬆ Сверить и отправить в Kaspi</button>${/^https:\/\/resources\.cdn-kaspi\.kz\//.test(String(p.img || '')) ? `<button type="button" class="btn btn-secondary btn-sm kp-photo" data-sku="${esc(p.sku)}" data-img="${esc(p.img)}" title="Передать фото товара в поиск поставщиков на 1688">🔎 Поставщик 1688 по фото</button>` : ''}`;
})();
