// История цен конкурентов: мини-график в строке товара («Мой магазин Kaspi»).
(function () {
  const fmt = n => Math.round(n || 0).toLocaleString('ru-RU');
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const day = ts => new Date(ts * 1000).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' });

  function spark(pts) {
    const W = 150, H = 34, P = 3;
    const vals = [];
    pts.forEach(p => { if (p[1] != null) vals.push(p[1]); if (p[2] != null) vals.push(p[2]); });
    const lo = Math.min(...vals), hi = Math.max(...vals);
    const t0 = pts[0][0], t1 = pts[pts.length - 1][0] || t0 + 1;
    const x = t => P + ((t - t0) / Math.max(1, t1 - t0)) * (W - 2 * P);
    const y = v => H - P - ((v - lo) / Math.max(1, hi - lo)) * (H - 2 * P);
    const line = (i, cls) => {
      const a = pts.filter(p => p[i] != null);
      if (a.length < 2) return '';
      return `<polyline class="${cls}" fill="none" stroke-width="1.8" points="${a.map(p => x(p[0]).toFixed(1) + ',' + y(p[i]).toFixed(1)).join(' ')}"/>`;
    };
    return `<svg class="ph-svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${line(1, 'ph-c')}${line(2, 'ph-m')}</svg>`;
  }

  function html(pts) {
    if (!pts || !pts.length) return '<div class="ph-note">История цен копится: первая точка появится после проверки продавцов.</div>';
    const last = pts[pts.length - 1];
    const cur = last[1] != null ? `конкурент ${fmt(last[1])} ₸` : 'конкурентов нет';
    const place = last[3] ? `, вы на ${last[3]} месте из ${last[4]}` : '';
    if (pts.length < 2) return `<div class="ph-note">📈 Сейчас: ${cur}${place}. История копится с ${day(last[0])}.</div>`;
    // самое заметное изменение цены конкурента за период
    const cs = pts.filter(p => p[1] != null);
    let chg = '';
    if (cs.length >= 2) {
      const first = cs[0][1], now = cs[cs.length - 1][1];
      const dlt = now - first;
      chg = dlt === 0 ? ' · без изменений' : ` · с ${day(cs[0][0])}: ${fmt(first)} → ${fmt(now)} (${dlt > 0 ? '+' : ''}${fmt(dlt)})`;
    }
    const tip = pts.slice(-8).map(p => `${day(p[0])}: конкурент ${p[1] != null ? fmt(p[1]) : '—'}, вы ${p[2] != null ? fmt(p[2]) : '—'}, место ${p[3] || '—'}`).join('\n');
    return `<div class="ph-box" title="${esc(tip)}">${spark(pts)}<div class="ph-txt">📈 ${cur}${place}${chg}</div></div>`;
  }

  window.phRender = async function (items) {
    try {
      const withCode = (items || []).filter(p => /^[0-9]+$/.test(String(p.card_code || '')));
      if (!withCode.length) return;
      const codes = [...new Set(withCode.map(p => String(p.card_code)))].slice(0, 60);
      const r = await fetch('/api/kaspi/price_history', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ codes }) }).then(x => x.json());
      if (!r || !r.success) return;
      withCode.forEach(p => {
        const inp = document.querySelector('.price-input-inline[data-sku="' + (window.CSS && CSS.escape ? CSS.escape(String(p.sku)) : String(p.sku)) + '"]');
        const tr = inp && inp.closest('tr');
        const t5 = tr && tr.querySelector('.t5');
        if (!t5) return;
        let box = tr.querySelector('.ph-wrap');
        if (!box) { box = document.createElement('div'); box.className = 'ph-wrap'; t5.insertAdjacentElement('afterend', box); }
        box.innerHTML = html(r.series[String(p.card_code)]);
      });
    } catch (e) { /* график не критичен: без него таблица работает */ }
  };
})();
