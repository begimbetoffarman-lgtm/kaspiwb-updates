@echo off
chcp 65001 > nul
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1
title Kaspi WB
cd /d "%~dp0"

if not exist "%~dp0run.py" goto from_archive

set "PY_CMD="
if exist "%~dp0runtime\python.exe" set "PY_CMD=%~dp0runtime\python.exe"
if defined PY_CMD goto run
where python >nul 2>nul
if not errorlevel 1 set "PY_CMD=python"
if defined PY_CMD goto run
where py >nul 2>nul
if not errorlevel 1 set "PY_CMD=py"
if defined PY_CMD goto run
goto no_python

:run
if /i "%~1"=="autostart" set "KWB_NO_BROWSER=1"
cls
echo ========================================================
echo   Kaspi WB: запуск локального сервера...
echo   Программа сейчас откроется в вашем браузере.
echo   Это окно не закрывайте, пока работаете.
echo ========================================================
"%PY_CMD%" "%~dp0run.py"
echo.
echo Программа остановлена. Если это ошибка, сделайте фото этого окна и отправьте автору.
pause
exit /b

:from_archive
cls
echo ========================================================
echo   ВЫ ЗАПУСТИЛИ ПРОГРАММУ ПРЯМО ИЗ АРХИВА
echo ========================================================
echo.
echo   Так запускать нельзя. Как правильно:
echo   1. Закройте это окно.
echo   2. Правой кнопкой по файлу архива ZIP - Извлечь все.
echo   3. Откройте созданную папку и запустите start.bat из неё.
echo   Или проще: установите программу через KaspiWB-Setup.exe.
echo.
pause
exit /b

:no_python
cls
echo ========================================================
echo   Не найден Python. В этой сборке он должен лежать в папке runtime.
echo   Распакуйте архив целиком и запустите start.bat из папки,
echo   либо установите программу через KaspiWB-Setup.exe.
echo ========================================================
pause
exit /b