import os
import sys

# Ensure UTF-8 console output on any Windows PC without charmap crashes
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

import json
import re
import time
import webbrowser
import threading
import urllib.request
import ssl
from flask import Flask, request, jsonify, send_file, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)

from core.wb_parser import parse_wb_search_sync, round_kaspi_price
from core.nanobanana import check_account, generate_product_photo, download_file
from core.infographics import apply_apple_infographics
from core.exporter import export_to_excel
from core.license import init_or_load_license, activate_license, generate_key_for_client
from core.kaspi_store import (
    fetch_kaspi_store_data, 
    update_product_cost, 
    update_product_price, 
    update_product_delivery, 
    add_product_from_kaspi, 
    add_product_from_wb,
    refresh_competitors_async,
    import_price_file,
    import_costs_file,
    fetch_competitor_prices,
    load_live_products,
    clear_imported_products,
    export_kaspi_price_update_excel,
    import_kaspi_excel_catalog,
    load_custom_products,
    _rows_from_file,
    load_repricer_config,
    save_repricer_config,
    run_auto_repricer_cycle,
    check_kaspi_vacuum
)

from core import secrets as _secrets
from core import autopilot
from core import kaspi_content
from core import kaspi_cabinet
from core import waybills
from core import orders_screen
from core import order_flow
from core import profit as profit_mod
from core import backup as backup_mod
from core import reminders as reminders_mod
from core import auto_preorder as auto_pre_mod
from core import wb_tracker
import traceback

app = Flask(__name__, static_folder="static")
from core import suppliers
suppliers.register(app)
from core import found as found_base
found_base.register(app)
from core import fork_radar
fork_radar.register(app)
from core import niche_scanner
niche_scanner.register(app)
from core import ui_state as _ui_state
_ui_state.register(app)
from core import speed as _speed
_speed.register(app)

DATA_DIR = os.path.join(BASE_DIR, "data")
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
CATALOG_FILE = os.path.join(DATA_DIR, "catalog.json")
# Товары, найденные до версии 0.9.37, не знают своего поискового запроса.
# Показываем их в радаре отдельной вкладкой, чтобы не пропали молча.
PAST_QUERY = "__past__"
IMAGES_DIR = os.path.join(DATA_DIR, "images")
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(IMAGES_DIR, exist_ok=True)

CTX = ssl._create_unverified_context()
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

def load_config():
    default_cfg = {
        "royaltech_api_key": "",
        "kaspi_merchant_id": "",
        "kaspi_api_token": "",
        "margin_multiplier": 2.4,
        "rub_to_kzt_rate": 5.1,
        "kaspi_city": "750000000",
        "packaging_cost_kzt": 150,
        "kaspi_delivery_mode": "official_kz",
        "kaspi_delivery_vat": True,
        "kaspi_delivery_cost_kzt": 1299,
        "preorder_days": 7,
        "port": 8790
    }
    if os.path.exists(CONFIG_FILE):
        try:
            default_cfg.update(_secrets.read_config(CONFIG_FILE))      # секреты берутся из защищённого хранилища
            return default_cfg
        except Exception:
            pass
    return default_cfg

def save_config(cfg):
    _secrets.write_config(cfg, CONFIG_FILE)          # секреты уходят в хранилище, в config.json остаются обычные настройки

_CATALOG_CACHE = {"mtime": None, "size": None, "items": None}
_CATALOG_LOCK = threading.Lock()

def load_catalog():
    """Каталог радара. Кэш в памяти: файл перечитывается только если изменился на диске.
    При большой базе (тысячи товаров) это экономит разбор JSON на каждый запрос."""
    if not os.path.exists(CATALOG_FILE):
        return []
    try:
        st = os.stat(CATALOG_FILE)
        mtime, size = st.st_mtime_ns, st.st_size
    except OSError:
        return _CATALOG_CACHE["items"] if _CATALOG_CACHE["items"] is not None else []
    with _CATALOG_LOCK:
        if (_CATALOG_CACHE["items"] is not None
                and _CATALOG_CACHE["mtime"] == mtime
                and _CATALOG_CACHE["size"] == size):
            return _CATALOG_CACHE["items"]
    try:
        with open(CATALOG_FILE, "r", encoding="utf-8") as f:
            items = json.load(f)
    except Exception:
        cached = _CATALOG_CACHE["items"]
        return cached if cached is not None else []
    if not isinstance(items, list):
        items = []
    with _CATALOG_LOCK:
        _CATALOG_CACHE["mtime"], _CATALOG_CACHE["size"], _CATALOG_CACHE["items"] = mtime, size, items
    return items

def save_catalog(items):
    """Запись каталога через временный файл + подмена: файл не побьётся, если
    программа закроется в момент сохранения. После записи обновляем кэш."""
    tmp = CATALOG_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CATALOG_FILE)
    try:
        st = os.stat(CATALOG_FILE)
        with _CATALOG_LOCK:
            _CATALOG_CACHE["mtime"], _CATALOG_CACHE["size"], _CATALOG_CACHE["items"] = st.st_mtime_ns, st.st_size, items
    except OSError:
        with _CATALOG_LOCK:
            _CATALOG_CACHE["mtime"] = _CATALOG_CACHE["size"] = None
            _CATALOG_CACHE["items"] = items

def _as_int(value, default=0):
    """Безопасно привести значение из запроса к int. Пустое/битое -> default."""
    try:
        if value is None or value == "":
            return default
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, (int, float)):
            return int(value)
        # строку вида "12 500", "12500₸", "1,5" аккуратно очищаем
        text = str(value).strip().replace(" ", "").replace(" ", "").replace("₸", "").replace(",", ".")
        if not text:
            return default
        return int(float(text))
    except (TypeError, ValueError):
        return default

def _as_float(value, default=0.0):
    """Безопасно привести значение из запроса к float. Пустое/битое -> default."""
    try:
        if value is None or value == "":
            return default
        if isinstance(value, bool):
            return float(value)
        if isinstance(value, (int, float)):
            return float(value)
        text = str(value).strip().replace(" ", "").replace(" ", "").replace("₸", "").replace(",", ".")
        if not text:
            return default
        return float(text)
    except (TypeError, ValueError):
        return default

# Любая необработанная ошибка отдаётся как JSON, а не HTML-страница Flask:
# иначе фронт на (await r.json()) получает SyntaxError и «молча» ломается.
@app.errorhandler(Exception)
def _json_error(err):
    from werkzeug.exceptions import HTTPException
    if isinstance(err, HTTPException):
        code = err.code or 500
        if request.path.startswith("/api/") or request.path.startswith("/feed/"):
            return jsonify({"success": False, "error": err.description or err.name}), code
        return err
    traceback.print_exc()
    return jsonify({"success": False, "error": "Внутренняя ошибка: " + str(err)}), 500

@app.errorhandler(404)
def _json_404(err):
    if request.path.startswith("/api/") or request.path.startswith("/feed/"):
        return jsonify({"success": False, "error": "Не найдено: " + request.path}), 404
    return err

@app.after_request
def _no_cache(resp):
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp

# Без активной лицензии (пробный период закончился) открыты только: окно активации, обновление, самопроверка,
# настройки и подключение, просмотр заказов и печать накладных. Всё, что ищет, создаёт или меняет в Kaspi, закрыто.
_LIC_ALLOW = ("/api/license", "/api/update/", "/api/selfcheck/", "/api/setup/", "/api/mail/", "/api/config", "/api/account",
              "/api/orders/", "/api/backup/", "/api/reminders/", "/api/waybills/", "/api/data/", "/api/version", "/api/payment/", "/api/cabinet/status", "/api/cabinet/login", "/api/cabinet/code",
              "/api/cabinet/logout", "/api/cabinet/verify")

# ---- Защита от обращений с чужих сайтов (DNS-подмена, чужие страницы) ----
import secrets as _pysecrets
_SESSION_TOKEN = _pysecrets.token_urlsafe(32)          # случайный на каждый запуск
_COOKIE_FREE = ("/api/license",)                         # проверка «уже запущено» при старте идёт без cookie

def _server_port():
    try:
        return int(request.environ.get("SERVER_PORT") or 0)
    except Exception:
        return 0

def _allowed_host_names():
    names = {"127.0.0.1", "localhost", "[::1]"}
    try:
        extra = load_config().get("allowed_hosts") or []
        if isinstance(extra, str):
            extra = [x.strip() for x in extra.split(",")]
        names.update(str(x).strip().lower() for x in extra if str(x).strip())
    except Exception:
        pass
    return names

def _host_ok(host):
    host = (host or "").strip().lower()
    if not host:
        return False
    name, _, port = host.rpartition(":") if (":" in host and not host.endswith("]")) else (host, "", "")
    if host in _allowed_host_names():
        return True
    if name in _allowed_host_names() and port.isdigit() and int(port) == _server_port():
        return True
    return False

def _cookie_name():
    return "kwb_s_%d" % _server_port()

@app.before_request
def _web_guard():
    # 1. Host: только свои адреса (иначе подмена DNS даёт чужому сайту доступ). Публичная лента для Kaspi идёт через туннель с чужим Host.
    if request.path.startswith("/feed/"):
        return None
    if not _host_ok(request.host):
        return ("Недопустимый адрес (Host).", 400)
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        # 2. Origin / Referer должны совпадать с Host
        from urllib.parse import urlparse
        for hname in ("Origin", "Referer"):
            v = request.headers.get(hname)
            if v:
                if v.strip().lower() == "null" or urlparse(v).netloc.lower() != request.host.lower():
                    return jsonify({"success": False, "error": "Запрос с чужой страницы отклонён."}), 403
    # 3. Секретная cookie сессии для /api/*
    p = request.path
    if p.startswith("/api/") and p not in _COOKIE_FREE:
        got = request.cookies.get(_cookie_name(), "")
        if not _pysecrets.compare_digest(got, _SESSION_TOKEN):
            return jsonify({"success": False, "session_expired": True,
                            "error": "Сессия устарела. Обновите страницу программы (F5)."}), 403
    return None

@app.before_request
def _license_gate():
    p = request.path
    if not (p.startswith("/api/") or p.startswith("/feed/")):
        return None
    if p.startswith(_LIC_ALLOW):
        return None
    from core import license as _lic
    if _lic.is_active():
        return None
    return jsonify({"success": False, "license_expired": True, "error": _lic.EXPIRED_MSG}), 402

# Routes
@app.route("/")
def index():
    resp = send_from_directory("static", "index.html")
    resp.set_cookie(_cookie_name(), _SESSION_TOKEN, httponly=True, samesite="Strict", path="/")
    return resp

# License & Trial endpoints
@app.route("/api/license", methods=["GET"])
def api_license_status():
    st = dict(init_or_load_license())
    k = st.get("license_key") or ""
    if k:
        st["license_key"] = k[:8] + "…"      # ключ целиком наружу не отдаём
    return jsonify(st)

@app.route("/api/license/activate", methods=["POST"])
def api_license_activate():
    data = request.json or {}
    key = data.get("key", "").strip()
    res = activate_license(key)
    return jsonify(res)

@app.route("/api/referral", methods=["GET"])
def api_referral_info():
    from core import referral
    return jsonify(referral.info())

@app.route("/api/referral/stats", methods=["GET"])
def api_referral_stats():
    from core import referral
    return jsonify(referral.stats())

@app.route("/api/referral/apply", methods=["POST"])
def api_referral_apply():
    from core import referral
    res = referral.apply_friend_code((request.json or {}).get("code", ""))
    return jsonify(res), (200 if res.get("success") else 400)


# Kaspi Store & Unit Economics endpoints
@app.route("/api/autostart", methods=["GET", "POST"])
def api_autostart():
    from core import autostart as _au
    if request.method == "GET":
        return jsonify(success=True, **_au.status())
    try:
        return jsonify(success=True, **_au.set_enabled(bool((request.json or {}).get("on"))))
    except Exception as e:
        return jsonify(success=False, error=str(e)), 400

@app.route("/api/autopreorder", methods=["GET"])
def api_autopreorder_get():
    return _cards_ok(lambda: auto_pre_mod.public())

@app.route("/api/autopreorder/global", methods=["POST"])
def api_autopreorder_global():
    return _cards_ok(lambda: auto_pre_mod.set_global(request.json or {}))

@app.route("/api/autopreorder/item", methods=["POST"])
def api_autopreorder_item():
    d = request.json or {}
    return _cards_ok(lambda: {"item": auto_pre_mod.set_item(d.get("sku"), d.get("on"), d.get("stock"), d.get("days"))})

def _push_args(d):
    return {k: d.get(k) for k in ("mode", "price", "stock", "preorder_days")}

@app.route("/api/kaspi/push/preview", methods=["POST"])
def api_push_preview():
    """Что изменится на Kaspi у одного товара (только чтение)."""
    from core import kaspi_push
    d = request.json or {}
    return _cards_ok(lambda: kaspi_push.preview(d.get("sku"), _push_args(d)))

@app.route("/api/kaspi/push/apply", methods=["POST"])
def api_push_apply():
    """Отправка в кабинет Kaspi одного товара после явного подтверждения."""
    from core import kaspi_push
    d = request.json or {}
    return _cards_ok(lambda: kaspi_push.apply(d.get("sku"), _push_args(d), confirmed=d.get("confirmed") is True, ack=d.get("ack") is True))

@app.route("/api/kaspi/push/rollback", methods=["POST"])
def api_push_rollback():
    from core import kaspi_push
    d = request.json or {}
    return _cards_ok(lambda: kaspi_push.rollback(str(d.get("id") or ""), confirmed=d.get("confirmed") is True))

@app.route("/api/kaspi/push/history", methods=["GET"])
def api_push_history():
    from core import kaspi_push
    return _cards_ok(lambda: {"history": kaspi_push.history(request.args.get("sku") or None)})

@app.route("/api/kaspi/img_proxy", methods=["GET"])
def api_kaspi_img_proxy():
    """Отдаёт фото карточки Kaspi (только с resources.cdn-kaspi.kz) браузеру, чтобы передать его в поиск по фото на 1688."""
    import urllib.parse as _up
    import requests as _rq
    u = request.args.get("u", "")
    p = _up.urlsplit(u)
    if p.scheme != "https" or p.hostname != "resources.cdn-kaspi.kz" or p.username or p.password or p.port not in (None, 443):
        return jsonify(success=False, error="Разрешены только фото с resources.cdn-kaspi.kz."), 400
    try:
        r = _rq.get(u, timeout=15, stream=True, allow_redirects=False, headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code != 200:
            return jsonify(success=False, error="Kaspi не отдал фото."), 502
        body = r.raw.read(8_000_001)
        if not body or len(body) > 8_000_000:
            return jsonify(success=False, error="Фото слишком большое."), 413
        ct = r.headers.get("content-type", "image/jpeg")
        return app.response_class(body, mimetype=ct if ct.startswith("image/") else "image/jpeg")
    except Exception:
        return jsonify(success=False, error="Не удалось получить фото."), 502

@app.route("/api/kaspi/price_history", methods=["POST"])
def api_kaspi_price_history():
    """История цен конкурентов по кодам карточек (только чтение записанных наблюдений)."""
    codes = (request.json or {}).get("codes") or []
    if not isinstance(codes, list):
        return jsonify(success=False, error="Ожидается список кодов."), 400
    from core import price_history
    return _cards_ok(lambda: {"series": price_history.series(codes[:60])})

@app.route("/api/cabinet/sync/start", methods=["POST"])
def api_cabsync_start():
    from core import cabinet_sync
    return _cards_ok(lambda: cabinet_sync.start(force=bool((request.json or {}).get("force"))))

@app.route("/api/cabinet/sync/status", methods=["GET"])
def api_cabsync_status():
    from core import cabinet_sync
    return _cards_ok(lambda: cabinet_sync.status())

@app.route("/api/cabinet/sync/diff", methods=["GET"])
def api_cabsync_diff():
    from core import cabinet_sync
    def go():
        prods = ((api_kaspi_store().get_json() or {}).get("data") or {}).get("products", [])
        return {"diff": cabinet_sync.diff(prods), "status": cabinet_sync.status()}
    return _cards_ok(go)

@app.route("/api/cabinet/list_probe", methods=["GET"])
def api_cabinet_list_probe():
    """Только чтение: какие поля отдаёт список товаров кабинета (для сверки пачкой)."""
    def go():
        d = kaspi_cabinet.list_page(_as_int(request.args.get("p"), 0), min(_as_int(request.args.get("l"), 2), 5), None)
        items = d.get("offers") or d.get("items") or d.get("content") or d.get("data") or (d if isinstance(d, list) else [])
        return {"top_keys": sorted(d.keys()) if isinstance(d, dict) else "list", "count": len(items) if isinstance(items, list) else None,
                "sample": items[:2] if isinstance(items, list) else None}
    return _cards_ok(go)

@app.route("/api/kaspi/prefetch_prices", methods=["POST"])
def api_kaspi_prefetch_prices():
    """Подгрузка цен конкурентов для товаров страницы (только чтение): код карточки берём из кабинета, цены с витрины, кэш 30 минут."""
    skus = (request.json or {}).get("skus") or []
    if not isinstance(skus, list):
        return jsonify(success=False, error="Ожидается список артикулов."), 400
    def go():
        ks = __import__("core.kaspi_store", fromlist=["fetch_competitor_prices"])
        ov = ks.load_overrides()
        have_cab = bool(kaspi_cabinet.status().get("connected"))
        done = fresh = 0
        for sku in [str(s) for s in skus][:30]:
            code = str((ov.get(sku) or {}).get("card_code") or "")
            if not code.isdigit() and have_cab:
                try:
                    code = str((kaspi_cabinet.get_offer(sku) or {}).get("card_code") or "")
                    if code.isdigit():
                        ks.set_product_card_code(sku, code)
                except Exception:
                    code = ""
            if not code.isdigit():
                continue
            r = ks.fetch_competitor_prices(code, max_age_sec=1800)
            done += 1
            if r.get("ok") and not r.get("cached"):
                fresh += 1
        return {"checked": done, "fresh": fresh}
    return _cards_ok(go)

@app.route("/api/kaspi/resolve_images", methods=["POST"])
def api_kaspi_resolve_images():
    """Для товаров без кода карточки: код берём из кабинета по артикулу (только чтение), сохраняем и отдаём фото."""
    skus = (request.json or {}).get("skus") or []
    if not isinstance(skus, list):
        return jsonify(success=False, error="Ожидается список артикулов."), 400
    def go():
        ks = __import__("core.kaspi_store", fromlist=["card_images"])
        if not kaspi_cabinet.status().get("connected"):
            return {"images": {}, "codes": {}}
        codes = {}
        for sku in [str(s) for s in skus][:8]:
            try:
                code = str((kaspi_cabinet.get_offer(sku) or {}).get("card_code") or "")
                if code.isdigit():
                    ks.set_product_card_code(sku, code)
                    codes[sku] = code
            except Exception:
                continue
        imgs = ks.card_images(list(codes.values())) if codes else {}
        return {"codes": codes, "images": {s: imgs[c] for s, c in codes.items() if c in imgs}}
    return _cards_ok(go)

@app.route("/api/kaspi/card_images", methods=["POST"])
def api_kaspi_card_images():
    codes = (request.json or {}).get("codes") or []
    if not isinstance(codes, list):
        return jsonify(success=False, error="Ожидается список кодов карточек."), 400
    try:
        return jsonify(success=True, images=__import__("core.kaspi_store", fromlist=["card_images"]).card_images(codes[:60]))
    except Exception as e:
        return jsonify(success=False, error="Фото сейчас не загрузились: %s" % e), 503

@app.route("/api/kaspi/store", methods=["GET"])
def api_kaspi_store():
    cfg = load_config()
    token = cfg.get("kaspi_api_token", "")                      # токен только из настроек, не из строки запроса (иначе попадает в журналы)
    merchant_id = cfg.get("kaspi_merchant_id", "")
    delivery_mode = cfg.get("kaspi_delivery_mode", "official_kz")
    delivery_scope = "city" if delivery_mode == "official_city" else "kz"
    include_vat = cfg.get("kaspi_delivery_vat", True)
    if delivery_mode == "custom":
        delivery_kzt = float(cfg.get("kaspi_delivery_cost_kzt", 1299))
    else:
        delivery_kzt = None
        
    pack_kzt = float(cfg.get("packaging_cost_kzt", 150))
    
    data = fetch_kaspi_store_data(
        api_token=token,
        merchant_id=merchant_id,
        delivery_kzt=delivery_kzt,
        pack_kzt=pack_kzt,
        delivery_scope=delivery_scope,
        include_vat=include_vat
    )
    return jsonify({"success": True, "data": data})

@app.route("/api/kaspi/import_file", methods=["GET", "POST"])
def api_kaspi_import_file():
    if request.method == "GET":
        return jsonify({"info": "Используйте POST для загрузки файла (Excel/CSV/XML)"})
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"success": False, "error": "Файл не выбран"})
    try:
        content = f.read()
        n = import_price_file(f.filename, content)
        return jsonify({"success": True, "count": n, "imported_count": n})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/kaspi/import_costs", methods=["GET", "POST"])
def api_kaspi_import_costs():
    if request.method == "GET":
        return jsonify({"info": "Используйте POST: файл Excel/CSV с колонками «Артикул» и «Себестоимость»"})
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"success": False, "error": "Файл не выбран"})
    try:
        n = import_costs_file(f.filename, f.read())
        return jsonify({"success": True, "count": n})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/kaspi/import_clear", methods=["POST"])
def api_kaspi_import_clear():
    clear_imported_products()
    return jsonify({"success": True})

@app.route("/api/kaspi/competitors", methods=["GET"])
def api_kaspi_competitors():
    sku = request.args.get("sku", "")
    code = request.args.get("code", "")
    if not code:
        for p in load_live_products():
            if str(p.get("sku")) == sku:
                code = p.get("card_code", "")
                break
    res = fetch_competitor_prices(code)
    res["card_code"] = code
    return jsonify(res)

@app.route("/api/kaspi/update_limits", methods=["POST"])
def api_kaspi_update_limits():
    """Мин. и макс. цена товара для робота-демпинга. Только в программе, в Kaspi ничего не отправляется."""
    from core.kaspi_store import update_product_limits
    d = request.get_json(silent=True) or {}
    sku = str(d.get("sku") or "").strip()
    if not sku:
        return jsonify({"success": False, "error": "Не указан артикул"})
    try:
        return jsonify({"success": True, "sku": sku, **update_product_limits(sku, d.get("min_price"), d.get("max_price"))})
    except (ValueError, TypeError) as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/kaspi/resolve_card", methods=["POST"])
def api_kaspi_resolve_card():
    """Находит код карточки Kaspi по вашему артикулу (чтение из кабинета, ничего не меняет) и подтягивает продавцов."""
    from core.kaspi_store import set_product_card_code, fetch_competitor_prices
    d = request.get_json(silent=True) or {}
    sku = str(d.get("sku") or "").strip()
    if not sku:
        return jsonify({"success": False, "error": "Не указан артикул"})
    def go():
        code = str(d.get("card_code") or "").strip()
        if not code:
            code = str((kaspi_cabinet.get_offer(sku) or {}).get("card_code") or "")
        if not code.isdigit():
            raise RuntimeError("Kaspi не показал код карточки для этого артикула. Проверьте подключение кабинета в Настройках.")
        set_product_card_code(sku, code)
        r = fetch_competitor_prices(code, max_age_sec=300)
        return {"card_code": code, "offers": len(r.get("offers", [])), "error": r.get("error", "")}
    return _cards_ok(go)

@app.route("/api/kaspi/update_cost", methods=["POST"])
def api_kaspi_update_cost():
    data = request.json or {}
    sku = data.get("sku")
    cost = data.get("cost_price")
    if not sku or cost is None:
        return jsonify({"success": False, "error": "Не указан SKU или себестоимость"})
    try:
        update_product_cost(sku, cost)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)})
    return jsonify({"success": True, "sku": sku, "cost_price": cost})

@app.route("/api/kaspi/update_price", methods=["POST"])
def api_kaspi_update_price():
    data = request.json or {}
    sku = data.get("sku")
    sell_price = data.get("sell_price")
    if not sku or sell_price is None:
        return jsonify({"success": False, "error": "Не указан SKU или цена продажи"})
    try:
        update_product_price(sku, sell_price)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)})
    return jsonify({"success": True, "sku": sku, "sell_price": sell_price})

@app.route("/api/kaspi/update_delivery", methods=["POST"])
def api_kaspi_update_delivery():
    data = request.json or {}
    sku = data.get("sku")
    delivery_type = data.get("delivery_type", "in_stock")
    preorder_days = _as_int(data.get("preorder_days"), 7)
    if not sku:
        return jsonify({"success": False, "error": "Не указан SKU"})
    try:
        update_product_delivery(sku, delivery_type, preorder_days)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)})
    return jsonify({"success": True, "sku": sku, "delivery_type": delivery_type, "preorder_days": preorder_days})

@app.route("/api/kaspi/add_by_url", methods=["POST"])
def api_kaspi_add_by_url():
    data = request.json or {}
    url = data.get("url", "").strip()
    if not url:
        return jsonify({"success": False, "error": "Введите ссылку или артикул Kaspi"})
    delivery_type = data.get("delivery_type", "preorder")
    preorder_days = _as_int(data.get("preorder_days"), 7)
    custom_cost = data.get("cost_price")
    custom_price = data.get("sell_price")
    try:
        prod = add_product_from_kaspi(
            url,
            delivery_type=delivery_type,
            preorder_days=preorder_days,
            custom_cost=custom_cost,
            custom_price=custom_price
        )
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)})
    return jsonify({"success": True, "product": prod})

@app.route("/api/kaspi/add_from_wb", methods=["POST"])
def api_kaspi_add_from_wb():
    data = request.json or {}
    item_id = _as_int(data.get("item_id"), 0)
    preorder_days = _as_int(data.get("preorder_days"), 7)
    
    target_item = data.get("item")
    if not target_item:
        catalog = load_catalog()
        for it in catalog:
            if it.get("id") == item_id:
                target_item = it
                break
            
    if not target_item:
        if "id" in data or "name" in data or "kaspi_name" in data:
            target_item = data
        else:
            return jsonify({"success": False, "error": "Товар не найден в радаре"})
            
    try:
        prod = add_product_from_wb(target_item, preorder_days=preorder_days)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)})
    return jsonify({"success": True, "product": prod})

@app.route("/api/kaspi/refresh_competitors", methods=["GET", "POST"])
def api_kaspi_refresh_competitors():
    refresh_competitors_async(max_items=50)
    return jsonify({"success": True, "message": "Фоновое сканирование цен конкурентов запущено"})

@app.route("/api/kaspi/competitors_detail", methods=["GET"])
def api_kaspi_competitors_detail():
    card_code = request.args.get("card_code", "").strip()
    sku = request.args.get("sku", "").strip()
    if not card_code and sku:
        for p in load_live_products():
            if str(p.get("sku")) == sku:
                card_code = str(p.get("card_code", ""))
                break
    if not card_code:
        return jsonify({"success": False, "error": "Код карточки не указан"})
    res = fetch_competitor_prices(card_code, max_age_sec=300)
    return jsonify({"success": res.get("ok", False), "offers": res.get("offers", []), "error": res.get("error", "")})

@app.route("/api/kaspi/export_prices", methods=["GET"])
def api_kaspi_export_prices():
    out_file = os.path.join(DATA_DIR, "Kaspi_Prices_Update.xlsx")
    try:
        export_kaspi_price_update_excel(out_file)
    except Exception as error:
        return jsonify({"success": False, "error": str(error) or "Не удалось собрать прайс-лист."}), 400
    return send_file(out_file, as_attachment=True, download_name="Kaspi_Prices_Update.xlsx")

@app.route("/api/kaspi/export_xml", methods=["GET"])
def api_kaspi_export_xml():
    out_file = os.path.join(DATA_DIR, "Kaspi_ACTIVE_Catalog.xml")
    from core.kaspi_store import export_kaspi_xml_feed
    try:
        export_kaspi_xml_feed(out_file)
    except Exception as error:
        return jsonify({"success": False, "error": str(error) or "Не удалось собрать выгрузку."}), 400
    return send_file(out_file, as_attachment=True, download_name="Kaspi_ACTIVE_Catalog.xml", mimetype="application/xml")


@app.route("/api/kaspi/upload_excel", methods=["GET", "POST"])
def api_kaspi_upload_excel():
    if request.method == "GET":
        return jsonify({"info": "Используйте POST для загрузки файла (Excel/CSV/XML)"})
    if "file" not in request.files:
        return jsonify({"success": False, "error": "Файл не выбран"}), 400
    file = request.files["file"]
    if not file.filename:
        return jsonify({"success": False, "error": "Файл не выбран"}), 400
    
    file_bytes = file.read()
    if not file_bytes:
        return jsonify({"success": False, "error": "Файл пуст"}), 400

    replace_requested = str(request.form.get("replace") or "").lower() in ("1", "true", "yes", "on")
    confirmed = str(request.form.get("confirm") or "").lower() in ("1", "true", "yes", "on")

    # Distinguish this Kaspi price list from a generic file, so replace only touches price lists.
    is_price_list = bool(re.search(r"price|прайс|kaspi", (file.filename or "").lower()))
    temp_path = os.path.join(DATA_DIR, f"temp_upload_{int(time.time())}.xlsx")
    try:
        with open(temp_path, "wb") as f:
            f.write(file_bytes)
        with open(temp_path, "rb") as f:
            _rows_probe = None
            try:
                import openpyxl
                _wb = openpyxl.load_workbook(f, data_only=True)
                _rows_probe = list(_wb.active.iter_rows(values_only=True))
            except Exception:
                _rows_probe = None
        if _rows_probe is not None:
            _hdr = " ".join(str(c or "").lower() for c in (_rows_probe[0] if _rows_probe else []))
            for _row in _rows_probe[:10]:
                _hdr = " ".join(str(c or "").lower() for c in _row)
                if any(k in _hdr for k in ("артикул", "sku", "код", "цена", "прайс")):
                    is_price_list = True
                    break
    except Exception:
        pass

    # Replace mode: warn before a price list shrinks the active list. Nothing is removed until confirmed.
    if is_price_list and not replace_requested and not confirmed:
        old_active = {str(p.get("sku")) for p in load_custom_products() if p.get("delivery_type") != "archive"}
        new_skus = {str(r.get("sku") or "") for r in _rows_from_file(file.filename, file_bytes)}
        new_skus.discard("")
        if old_active and new_skus:
            dropping = len(old_active - new_skus)
            if dropping:
                try:
                    os.remove(temp_path)
                except Exception:
                    pass
                return jsonify({"success": False, "need_confirm": True,
                                "would_archive": dropping, "old_count": len(old_active), "new_count": len(new_skus),
                                "error": f"Новый прайс короче текущего: {dropping} товаров уйдут в архив (нет в загруженном файле). Подтвердите замену или загрузите полный прайс."})

    # Confirmation means the seller accepted replacing the complete price list.
    # Limit this behavior to a recognized price list; generic imports remain additive.
    replace = bool(is_price_list and (replace_requested or confirmed))

    price_import_count = 0
    try:
        price_import_count = import_price_file(file.filename, file_bytes)
    except Exception:
        pass

    res = {}
    try:
        res = import_kaspi_excel_catalog(temp_path, replace=replace)
    except Exception as e:
        res = {"success": False, "error": str(e)}
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception:
                pass

    if not res.get("success") and price_import_count > 0:
        res = {"success": True, "imported_count": price_import_count, "total_products": price_import_count}
    elif res.get("success"):
        cnt = res.get("imported_count", price_import_count)
        if cnt == 0 and price_import_count > 0:
            cnt = price_import_count
        res["imported_count"] = cnt
        res["count"] = cnt

    return jsonify(res)

@app.route("/api/kaspi/repricer", methods=["GET", "POST"])
def api_kaspi_repricer():
    if request.method == "POST":
        data = request.json or {}
        cfg = load_repricer_config()
        if "enabled" in data:
            cfg["enabled"] = bool(data["enabled"])
        if "strategy" in data:
            cfg["strategy"] = str(data["strategy"])
        if "min_margin_pct" in data:
            cfg["min_margin_pct"] = float(data["min_margin_pct"])
        if "undercut_kzt" in data:
            cfg["undercut_kzt"] = _as_int(data.get("undercut_kzt"), 0)
        if "interval_min" in data:
            cfg["interval_min"] = max(autopilot.MIN_INTERVAL_MIN, _as_int(data.get("interval_min"), autopilot.MIN_INTERVAL_MIN))
        save_repricer_config(cfg)
        
        cycle_result = None
        if data.get("run_now"):
            cycle_result = autopilot.run_once(reason="manual").get("cycle")
            
        return jsonify({"success": True, "config": cfg, "cycle": cycle_result})
        
    return jsonify({"success": True, "config": load_repricer_config()})

@app.route("/api/kaspi/repricer/run", methods=["POST"])
def api_kaspi_repricer_run():
    res = autopilot.run_once(reason="manual")
    return jsonify(res.get("cycle") or res)

def _feed_token():
    cfg = load_config()
    tok = str(cfg.get("feed_token") or "")
    if len(tok) < 16:
        import secrets
        tok = secrets.token_urlsafe(18)
        cfg["feed_token"] = tok
        save_config(cfg)
    return tok

@app.route("/api/autopilot", methods=["GET"])
def api_autopilot():
    cfg = load_repricer_config()
    st = autopilot.load_status()
    tg = autopilot.targets()
    with_comp = sum(1 for p in tg if p.get("comp_source") == "real" and int(p.get("competitors_count", 0) or 0) > 1)
    nxt = None
    if cfg.get("enabled") and st.get("last_run_ts"):
        nxt = time.strftime("%H:%M", time.localtime(st["last_run_ts"] + autopilot.interval_min(cfg) * 60))
    return jsonify({
        "success": True,
        "enabled": bool(cfg.get("enabled")),
        "interval_min": autopilot.interval_min(cfg),
        "status": st,
        "next_run": nxt,
        "ready_count": len(tg),
        "ready_with_competitors": with_comp,
        "feed_path": f"/feed/{_feed_token()}.xml",
    })

@app.route("/feed/<token>.xml", methods=["GET"])
def feed_xml(token):
    import hmac as _h
    if not _h.compare_digest(str(token), _feed_token()):
        return ("Not found", 404)
    path = autopilot.feed_path()
    return send_file(path, mimetype="application/xml", max_age=0)

# ---------------- Карточки Kaspi из WB (официальный API Kaspi) ----------------
def _cards_ok(fn):
    try:
        return jsonify({"success": True, **fn()})
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/cards", methods=["GET"])
def api_cards():
    return _cards_ok(lambda: {"drafts": kaspi_content.load_drafts()})

@app.route("/api/cards/draft", methods=["POST"])
def api_cards_draft():
    """Массово: {"wb_ids": [..]} — черновики из товаров радара. Ошибки по отдельным товарам не роняют пачку."""
    ids = [_as_int(x) for x in ((request.json or {}).get("wb_ids") or []) if _as_int(x) > 0][:200]
    by_id = {int(it.get("id")): it for it in load_catalog() if it.get("id")}
    made, failed = [], []
    for i in ids:
        try:
            made.append(kaspi_content.make_draft(by_id.get(i) or {"id": i}))
        except Exception as e:
            failed.append({"wb_id": i, "error": str(e)})
    return jsonify({"success": bool(made) or not failed, "drafts": made, "failed": failed,
                    "error": failed[0]["error"] if failed and not made else None})

@app.route("/api/cards/prefs", methods=["GET", "POST"])
def api_cards_prefs():
    if request.method == "POST":
        kaspi_content.save_prefs({"no_brand": bool((request.json or {}).get("no_brand"))})
    return jsonify({"success": True, **kaspi_content.load_prefs()})

@app.route("/api/cards/categories", methods=["GET"])
def api_cards_categories():
    return _cards_ok(lambda: {"categories": kaspi_content.search_categories(request.args.get("q", ""))})

@app.route("/api/cards/attributes", methods=["GET"])
def api_cards_attributes():
    return _cards_ok(lambda: {"attributes": kaspi_content.attributes(request.args.get("c", ""))})

@app.route("/api/cards/category", methods=["POST"])
def api_cards_set_category():
    d = request.json or {}
    return _cards_ok(lambda: {"draft": kaspi_content.set_category(d.get("sku"), d.get("category"))})

@app.route("/api/cards/photo/<name>", methods=["GET"])
def api_cards_photo(name):
    from core import supplier_photos
    if not re.fullmatch(r"[0-9a-f]{24}\.(jpg|png|webp)", name):
        return jsonify(success=False, error="Нет такого фото"), 404
    return send_from_directory(supplier_photos.folder(), name, max_age=86400)

@app.route("/api/cards/sync_group", methods=["POST"])
def api_cards_sync_group():
    d = request.json or {}
    return _cards_ok(lambda: kaspi_content.sync_group(d.get("sku")))

@app.route("/api/cards/update", methods=["POST"])
def api_cards_update():
    d = request.json or {}
    return _cards_ok(lambda: {"draft": kaspi_content.update_draft(d.get("sku"), d.get("fields") or {})})

@app.route("/api/cards/delete", methods=["POST"])
def api_cards_delete():
    d = request.json or {}
    return _cards_ok(lambda: (kaspi_content.delete_draft(d.get("sku")), {})[1])

@app.route("/api/cards/send", methods=["POST"])
def api_cards_send():
    skus = (request.json or {}).get("skus", [])
    try:
        return jsonify(kaspi_content.send(skus))
    except Exception as e:
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/cards/gen_text", methods=["POST"])
def api_cards_gen_text():
    d = request.json or {}
    return _cards_ok(lambda: {"draft": kaspi_content.gen_text(d.get("sku"))})

@app.route("/api/cards/ai_photo", methods=["POST"])
def api_cards_ai_photo():
    d = request.json or {}
    return _cards_ok(lambda: {"draft": kaspi_content.ai_photo(d.get("sku"))})

@app.route("/api/wbtrack", methods=["GET", "POST"])
def api_wbtrack():
    if request.method == "POST":
        d = request.json or {}
        cfg = load_config()
        for k in ("wb_min_margin_pct", "wb_tracking_hours", "wb_tracking_enabled"):
            if k in d:
                cfg[k] = d[k]
        save_config(cfg)
    st = wb_tracker.load_state()
    cfg = load_config()
    return jsonify({"success": True, "state": st, "settings": {
        "wb_min_margin_pct": cfg.get("wb_min_margin_pct", 15), "wb_tracking_hours": cfg.get("wb_tracking_hours", 6),
        "wb_tracking_enabled": cfg.get("wb_tracking_enabled", True)}})

@app.route("/api/wbtrack/run", methods=["POST"])
def api_wbtrack_run():
    return _cards_ok(lambda: {"report": wb_tracker.run(apply=True), "state": wb_tracker.load_state()})

@app.route("/api/cards/autosale", methods=["POST"])
def api_cards_autosale():
    return _cards_ok(lambda: {"report": kaspi_content.autosale(), "drafts": kaspi_content.load_drafts()})

@app.route("/api/cards/status", methods=["POST"])
def api_cards_status():
    return _cards_ok(lambda: {"report": kaspi_content.refresh_status(), "drafts": kaspi_content.load_drafts()})


@app.route("/api/preorder/cards", methods=["GET"])
def api_preorder_cards():
    def go():
        from core import wb_tracker
        st = wb_tracker.load_state().get("items", {})
        out = []
        for d in kaspi_content.load_drafts():
            if d.get("status") in ("on_sale", "selling") and d.get("wb_id"):
                t = st.get(d["sku"], {})
                out.append({"sku": d["sku"], "title": d.get("kaspi_title") or d.get("title"), "price": d.get("price"),
                            "days": d.get("preorder_days"), "wb_days": t.get("preorder_days"),
                            "wb_delivery_h": t.get("delivery_h"), "img": (d.get("images") or [None])[0],
                            "card_code": d.get("card_code"), "checked": t.get("checked_at")})
        return {"cards": out}
    return _cards_ok(go)

@app.route("/api/selfcheck/run", methods=["POST"])
def api_selfcheck_run():
    from core import selfcheck
    return _cards_ok(lambda: selfcheck.run())

@app.route("/api/selfcheck/last", methods=["GET"])
def api_selfcheck_last():
    from core import selfcheck
    return _cards_ok(lambda: {"last": selfcheck.last()})

@app.route("/api/update/check", methods=["POST"])
def api_update_check():
    from core import updater
    return _cards_ok(lambda: updater.check())

@app.route("/api/update/apply", methods=["POST"])
def api_update_apply():
    from core import updater
    return _cards_ok(lambda: updater.apply())

@app.route("/api/setup/status", methods=["GET"])
def api_setup_status():
    from core import setup_wizard
    return _cards_ok(lambda: setup_wizard.status())

@app.route("/api/setup/city", methods=["POST"])
def api_setup_city():
    from core import setup_wizard
    d = request.get_json(silent=True) or {}
    return _cards_ok(lambda: setup_wizard.set_city(d.get("city", "")))

@app.route("/api/setup/detect", methods=["POST"])
def api_setup_detect():
    from core import setup_wizard
    d = request.get_json(silent=True) or {}
    return _cards_ok(lambda: setup_wizard.detect(d.get("point_id")))

@app.route("/api/mail/save", methods=["POST"])
def api_mail_save():
    d = request.get_json(silent=True) or {}
    cfg = load_config()
    cfg["gmail_address"] = (d.get("address") or "").strip()
    cfg["mail_server"] = (d.get("server") or "").strip()
    if d.get("password"):
        cfg["gmail_app_password"] = d["password"].replace(" ", "")
    save_config(cfg)
    return jsonify({"success": True})

@app.route("/api/mail/test", methods=["POST"])
def api_mail_test():
    from core import mail_code
    return _cards_ok(lambda: mail_code.test())

@app.route("/api/mail/status", methods=["GET"])
def api_mail_status():
    cfg = load_config()
    return jsonify({"success": True, "address": cfg.get("gmail_address", ""), "server": cfg.get("mail_server", ""), "has_password": bool(cfg.get("gmail_app_password"))})

@app.route("/api/days/list", methods=["GET"])
def api_days_list():
    import datetime
    def go():
        t = datetime.date.today().isoformat()
        return {"days": [x for x in kaspi_cabinet.list_special_days() if x["date"] >= t][::-1]}
    return _cards_ok(go)

@app.route("/api/days/check", methods=["GET"])
def api_days_check():
    """Сверка с Kaspi: закрыты ли все даты в диапазоне (по умолчанию — все ближайшие 60 дней)."""
    import datetime
    def go():
        today = datetime.date.today()
        a = datetime.date.fromisoformat(request.args.get("from") or today.isoformat())
        b = datetime.date.fromisoformat(request.args.get("to") or (today + datetime.timedelta(60)).isoformat())
        closed = {x["date"] for x in kaspi_cabinet.list_special_days() if x["closed"]}
        want = [(a + datetime.timedelta(n)).isoformat() for n in range((b - a).days + 1)]
        missing = [d for d in want if d not in closed]
        return {"ok": not missing, "total": len(want), "closed": len(want) - len(missing), "missing": missing,
                "from": a.isoformat(), "to": b.isoformat()}
    return _cards_ok(go)

@app.route("/api/days/set", methods=["POST"])
def api_days_set():
    import datetime
    d = request.get_json(silent=True) or {}
    def go():
        a = datetime.date.fromisoformat(d["from"]); b = datetime.date.fromisoformat(d.get("to") or d["from"])
        if b < a or (b - a).days > 60:
            raise RuntimeError("Неверный диапазон дат.")
        dates = [(a + datetime.timedelta(n)).isoformat() for n in range((b - a).days + 1)]
        if d.get("action") == "open":
            for x in dates:
                kaspi_cabinet.remove_special_day(x)
            return {"opened": len(dates)}
        kaspi_cabinet.set_special_days(dates, closed=True)
        return {"closed": len(dates)}
    return _cards_ok(go)

@app.route("/api/link/preview", methods=["POST"])
def api_link_preview():
    from core import kaspi_link
    d = request.get_json(silent=True) or {}
    return _cards_ok(lambda: {"card": kaspi_link.preview(d.get("code") or d.get("url"))})

@app.route("/api/link/apply", methods=["POST"])
def api_link_apply():
    """Пишет в живой Kaspi: только при confirm=true (пользователь подтвердил в окне)."""
    from core import kaspi_link
    d = request.get_json(silent=True) or {}
    if d.get("confirm") is not True:
        return jsonify({"success": False, "error": "Нужно подтверждение."})
    def go():
        days = d.get("days")
        return kaspi_link.link(d.get("code") or d.get("url"), price=d.get("price"),
                               preorder_days=int(days) if str(days or "").isdigit() else None)
    return _cards_ok(go)

@app.route("/api/profit", methods=["GET"])
def api_profit():
    return _cards_ok(lambda: profit_mod.report(_as_int(request.args.get("days")) or 28))

@app.route("/api/home/deadlines", methods=["GET"])
def api_home_deadlines():
    return _cards_ok(lambda: order_flow.deadlines())

@app.route("/api/home/tracker", methods=["GET"])
def api_home_tracker():
    def go():
        from core import wb_tracker
        st = wb_tracker.load_state()
        items = list((st.get("items") or {}).values())
        return {"last_run": st.get("last_run"), "tracked": len(items),
                "problems": [{"sku": i.get("sku"), "title": i.get("title"), "action": i.get("action")} for i in items
                             if i.get("action") and not str(i["action"]).startswith("OK")][:6],
                "log": (st.get("log") or [])[:5]}
    return _cards_ok(go)

@app.route("/api/home/rejects", methods=["GET"])
def api_home_rejects():
    return _cards_ok(lambda: {"items": kaspi_content.reject_stats()})

@app.route("/api/backup/export", methods=["GET"])
def api_backup_export():
    from flask import Response
    blob, _names = backup_mod.export_bytes()
    return Response(blob, mimetype="application/zip",
                    headers={"Content-Disposition": "attachment; filename=kaspi-wb-backup-%s.zip" % time.strftime("%Y%m%d-%H%M")})

@app.route("/api/backup/import", methods=["POST"])
def api_backup_import():
    return _cards_ok(lambda: {"restored": backup_mod.restore(request.get_data())})

@app.route("/api/reminders/paid", methods=["GET"])
def api_reminders_paid_get():
    return _cards_ok(lambda: reminders_mod.get(request.args.get("start")))

@app.route("/api/reminders/paid", methods=["POST"])
def api_reminders_paid_set():
    d = request.json or {}
    if isinstance(d.get("import"), dict):
        return _cards_ok(lambda: {"imported": reminders_mod.import_many(d["import"])})
    return _cards_ok(lambda: reminders_mod.mark(d.get("id"), d.get("paid", True)))

@app.route("/api/orders/transit", methods=["GET"])
def api_orders_transit():
    return _cards_ok(lambda: order_flow.transit())

@app.route("/api/orders/returns", methods=["GET"])
def api_orders_returns():
    return _cards_ok(lambda: order_flow.returns())

@app.route("/api/orders/returns/mark", methods=["POST"])
def api_orders_returns_mark():
    d = request.json or {}
    return _cards_ok(lambda: {"item": order_flow.mark(d.get("code"), d.get("got"))})

@app.route("/api/orders/digest", methods=["GET"])
def api_orders_digest():
    return _cards_ok(lambda: order_flow.digest())

@app.route("/api/orders/active", methods=["GET"])
def api_orders_active():
    return _cards_ok(lambda: {"orders": orders_screen.active_orders()})

# ---------------- Калькулятор маржинальности (только чтение публичной витрины Kaspi) ----------------
@app.route("/api/margin/inspect", methods=["POST"])
def api_margin_inspect():
    from core import margin_calc
    link = (request.json or {}).get("link", "")
    return _cards_ok(lambda: margin_calc.inspect(link, str(load_config().get("kaspi_city") or "750000000")))

@app.route("/api/margin/cny", methods=["GET"])
def api_margin_cny():
    from core import margin_calc
    return _cards_ok(lambda: {"rate": margin_calc.cny_rate()})

# ---------------- Накладные Kaspi Доставки (печать на термопринтер / А4) ----------------
@app.route("/api/waybills/orders", methods=["GET"])
def api_waybills_orders():
    return _cards_ok(lambda: {"orders": waybills.list_orders(), "layouts": waybills.LAYOUTS})

@app.route("/api/waybills/make", methods=["POST"])
def api_waybills_make():
    d = request.get_json(silent=True) or {}
    codes = [str(c) for c in (d.get("codes") or []) if str(c).isdigit()]
    if not codes:
        return jsonify({"success": False, "error": "Не выбраны заказы."})
    def run():
        r = waybills.make(codes, d.get("layout", "thermal"), float(d.get("scale") or 0.67))
        return {"file": os.path.basename(r["path"]), "orders": r["orders"], "layout": r["layout"]}
    return _cards_ok(run)

@app.route("/api/waybills/file/<name>", methods=["GET"])
def api_waybills_file(name):
    return send_from_directory(waybills.OUT_DIR, os.path.basename(name), mimetype="application/pdf")

# ---------------- Кабинет Kaspi через сотрудника (цена / предзаказ / снятие с продажи) ----------------
@app.route("/api/cabinet/status", methods=["GET"])
def api_cabinet_status():
    return _cards_ok(lambda: {"status": kaspi_cabinet.status(), "log": kaspi_cabinet.load_log(15)})

@app.route("/api/cabinet/login", methods=["POST"])
def api_cabinet_login():
    d = request.json or {}
    def go():
        email, pwd = (d.get("login") or "").strip(), d.get("password") or ""
        if email and pwd:
            cfg = load_config(); cfg["kaspi_cab_login"] = email; cfg["kaspi_cab_password"] = pwd; save_config(cfg)
        started = time.time() - 30
        res = kaspi_cabinet.login(remember=True)
        if res.get("need_code"):
            # почта подключена: берём код из письма Kaspi и вводим сами (ждём до 90 секунд); иначе просим ввести руками
            auto = kaspi_cabinet._auto_code(started)
            if auto and auto.get("ok"):
                return auto
        return res
    return _cards_ok(go)

@app.route("/api/cabinet/code", methods=["POST"])
def api_cabinet_code():
    d = request.json or {}
    return _cards_ok(lambda: kaspi_cabinet.submit_code(d.get("code", "")))

@app.route("/api/cabinet/resend", methods=["POST"])
def api_cabinet_resend():
    """Повторный запрос кода из письма Kaspi (старое письмо перестаёт действовать)."""
    def go():
        started = time.time() - 30
        res = kaspi_cabinet.resend_code()
        if res.get("need_code"):
            auto = kaspi_cabinet._auto_code(started)
            if auto and auto.get("ok"):
                return auto
        return res
    return _cards_ok(go)

@app.route("/api/cabinet/logout", methods=["POST"])
def api_cabinet_logout():
    def go():
        kaspi_cabinet.logout()
        cfg = load_config(); cfg.pop("kaspi_cab_password", None); save_config(cfg)
        return {}
    return _cards_ok(go)

@app.route("/api/cabinet/offer", methods=["POST"])
def api_cabinet_offer():
    """Применить в Kaspi цену/наличие/предзаказ одного товара (и сохранить то же в программе)."""
    d = request.json or {}
    def go():
        sku = str(d.get("sku") or "").strip()
        if not sku:
            raise RuntimeError("Не указан артикул")
        mode = d.get("mode", "preorder")          # preorder | in_stock | archive
        price = _as_int(d.get("price"), 0) or None
        days = _as_int(d.get("preorder_days"), 0) or None
        if mode == "archive":
            res = kaspi_cabinet.set_offer(sku, available=False)
        else:
            res = kaspi_cabinet.set_offer(sku, price=price, preorder_days=days if mode == "preorder" else None,
                                          available=True, model=d.get("model"))
        # то же самое — в программу (прайс, репрайсер), чтобы источники не расходились
        if price:
            update_product_price(sku, price)
        update_product_delivery(sku, mode, days or 7)
        return {"result": res, "note": "Kaspi применяет изменения через очередь — обычно до часа."}
    return _cards_ok(go)

@app.route("/api/cabinet/verify", methods=["GET"])
def api_cabinet_verify():
    return _cards_ok(lambda: kaspi_cabinet.verify(request.args.get("sku", "")))

@app.route("/api/contact", methods=["GET", "POST"])
def api_contact():
    """Телефон клиента для связи (WhatsApp): хранится локально, уходит автору в отчёте."""
    from core import telemetry
    if request.method == "POST":
        body = request.get_json(silent=True) or {}
        if body.get("later"):
            return jsonify({"success": bool(telemetry.postpone())})
        nm = telemetry.clean_name(body.get("name"))
        if not nm:
            return jsonify({"success": False, "error": "Укажите ваше имя."})
        p = telemetry.set_phone(body.get("phone"), nm)
        if not p:
            return jsonify({"success": False, "error": "Введите номер в формате +7 700 123 45 67."})
        return jsonify({"success": True, "phone": p, "name": nm})
    return jsonify({"success": True, "phone": telemetry.get_phone(), "postponed": telemetry.postponed(),
                    "can_postpone": telemetry.can_postpone()})

_PAY_LAST = [0.0]

@app.route("/api/payment/claim", methods=["POST"])
def api_payment_claim():
    """Клиент нажал «Я оплатил»: заявка с номером компьютера уходит в таблицу автора. Не чаще раза в минуту."""
    from core import telemetry
    if time.time() - _PAY_LAST[0] < 60:
        return jsonify({"success": False, "error": "Заявка уже отправлена, подождите минуту."})
    d = request.get_json(silent=True) or {}
    ok = telemetry.payment_claim(str(d.get("contact") or "")[:80])
    if ok:
        _PAY_LAST[0] = time.time()
    return jsonify({"success": bool(ok), "error": "" if ok else "Не удалось отправить заявку автоматически."})

@app.route("/api/version", methods=["GET"])
def api_version():
    """Запущенная версия и версия файлов на диске: если они разные, программу нужно перезапустить."""
    from core import updater as _upd
    run, disk = _upd.RUNNING_VERSION, _upd.current_version()
    return jsonify({"success": True, "running": run, "disk": disk, "restart_needed": run != disk})

@app.route("/api/data/info", methods=["GET"])
def api_data_info():
    return jsonify({"success": True, "backend": _secrets.backend_name()})

@app.route("/api/data/wipe", methods=["POST"])
def api_data_wipe():
    """Удалить данные этого компьютера (секреты, настройки магазина, data/). Лицензия остаётся."""
    d = request.get_json(silent=True) or {}
    if d.get("confirm") != "УДАЛИТЬ":
        return jsonify({"success": False, "error": "Нужно подтверждение."}), 400
    try:
        kaspi_cabinet.logout()
    except Exception:
        pass
    res = _secrets.wipe_all()
    return jsonify({"success": not res["errors"], "removed": res["removed"], "error": "; ".join(res["errors"][:3])})

def _public_config(cfg):
    """Настройки для интерфейса: секреты наружу не отдаются, вместо них метка «есть/нет»."""
    out = {k: v for k, v in cfg.items() if k not in _secrets.SECRET_KEYS}
    for k in _secrets.SECRET_KEYS:
        out[k] = "••••" if cfg.get(k) else ""
    return out

@app.route("/api/config", methods=["GET", "POST"])
def api_config():
    if request.method == "POST":
        data = request.json or {}
        data.pop("kaspi_cab_password", None); data.pop("gmail_app_password", None)      # пароль сотрудника меняется только через «Подключить»
        for k in ("update_url", "report_url", "allowed_hosts", "feed_token"):          # чувствительные адреса и токен интерфейс менять не может (только файл config.json)
            data.pop(k, None)
        for k in ("kaspi_api_token", "royaltech_api_key"):
            if k in data and "•" in str(data[k]):
                data.pop(k)                  # форма вернула маску вместо значения: ключ не менять
        cfg = load_config()
        cfg.update(data)
        save_config(cfg)
        return jsonify({"success": True, "config": _public_config(cfg)})
    return jsonify(_public_config(load_config()))

@app.route("/api/account", methods=["GET"])
def api_account():
    cfg = load_config()
    key = cfg.get("royaltech_api_key", "").strip()
    if not key:
        return jsonify({"success": False, "error": "API ключ RoyalTech не указан"})
    try:
        acc = check_account(key)
        return jsonify({"success": True, "account": acc})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route("/api/items", methods=["GET"])
def api_items():
    """Список для «Радара вакуума». По умолчанию — только последний поиск.

    Раньше отдавали весь catalog.json, и в выдачу попадали товары всех прошлых
    поисков — продавцы принимали это за мусор. Теперь история лежит в /api/history,
    а радар показывает один выбранный запрос.
    """
    query = (request.args.get("query") or "").strip()
    limit = _as_int(request.args.get("limit"), 0)
    catalog = load_catalog()
    if query == PAST_QUERY:                 # «прошлые находки» — товары из старых версий
        items = [it for it in catalog if not str(it.get("query") or "").strip()]
    elif query:
        items = [it for it in catalog if str(it.get("query") or "").strip() == query]
    else:
        last = str(catalog[0].get("query") or "").strip() if catalog else ""
        items = [it for it in catalog if str(it.get("query") or "").strip() == last] if last else []
    if limit > 0:
        items = items[:limit]
    return jsonify({"success": True, "count": len(items), "items": items, "query": query})


@app.route("/api/history", methods=["GET"])
def api_history():
    """Запросы прошлых поисков с числом товаров — для выбора в радаре."""
    counts = {}
    for it in load_catalog():
        q = str(it.get("query") or "").strip()
        if q:
            counts[q] = counts.get(q, 0) + 1
    items = [{"query": q, "count": n} for q, n in counts.items()]
    items.sort(key=lambda x: x["count"], reverse=True)
    old = sum(1 for it in load_catalog() if not str(it.get("query") or "").strip())
    if old:                                  # товары, найденные до этой версии
        items.append({"query": PAST_QUERY, "count": old, "old": True})
    return jsonify({"success": True, "items": items[:100]})


@app.route("/api/items/clear", methods=["POST"])
def api_items_clear():
    """Стереть из каталога товары одного запроса (пустой query — весь каталог).

    Накопительная база «Найденное» (data/found.json) не трогается.
    """
    data = request.json or {}
    query = (data.get("query") or "").strip()
    catalog = load_catalog()
    if not query:
        left = len(catalog)
        save_catalog([])
        return jsonify({"success": True, "removed": left, "left": 0})
    kept = [it for it in catalog if str(it.get("query") or "").strip() != query]
    removed = len(catalog) - len(kept)
    save_catalog(kept)
    return jsonify({"success": True, "removed": removed, "left": len(kept)})

@app.route("/api/check_vacuum", methods=["GET", "POST"])
def api_check_vacuum():
    if request.method == "POST":
        data = request.json or {}
    else:
        data = request.args.to_dict()
    title = data.get("title", "").strip()
    query = data.get("query", "").strip()
    imgs = data.get("images") or []
    if not isinstance(imgs, list):
        imgs = []
    res = check_kaspi_vacuum(title, query, img_urls=imgs)
    return jsonify({"success": True, "result": res})

@app.route("/api/scan", methods=["GET", "POST"])
def api_scan():
    if request.method == "POST":
        data = request.json or {}
    else:
        data = request.args.to_dict()
    query = data.get("query", "органайзер для кухни").strip()
    limit = _as_int(data.get("limit"), 50)
    min_feedbacks = _as_int(data.get("min_feedbacks"), 100)
    cfg = load_config()
    
    new_items = parse_wb_search_sync(query, limit=limit * 2, config=cfg)
    filtered = [it for it in new_items if it.get("feedbacks", 0) >= min_feedbacks][:limit]
    if not new_items:
        import core.wb_parser as _wb
        return jsonify({"success": False, "error": _wb.LAST_ERROR or "По этому запросу Wildberries ничего не вернул.", "count": len(load_catalog())})

    # В копилку уходит всё, что вернул WB, включая товары ниже порога отзывав.
    # Порог влияет только на то, что показать сейчас: из базы товар не пропадает.
    found_stat = None
    try:
        from core import found as _found
        found_stat = dict(zip(("added", "updated", "total"), _found.add_many("wb", new_items, query)))
    except Exception:
        found_stat = None      # копилка не должна ломать сам поиск

    catalog = load_catalog()
    existing_ids = {it["id"] for it in catalog}
    added_count = 0
    for it in filtered:
        if it["id"] not in existing_ids:
            it["query"] = query          # чтобы радар мог показать только этот запрос
            catalog.insert(0, it)
            existing_ids.add(it["id"])
            added_count += 1
        else:
            # товар уже был найден раньше — запоминаем, что он подходит и к этому запросу
            for old in catalog:
                if old["id"] == it["id"]:
                    old["query"] = query
                    break

    save_catalog(catalog)
    # Показываем ровно то, что нашлось сейчас. Всё остальное осталось в каталоге
    # и в накопительной базе «Найденное», но в выдачу радара не подмешивается.
    shown_items = [it for it in catalog if str(it.get("query") or "").strip() == query][:limit]
    return jsonify({"success": True, "count": len(catalog), "items": shown_items,
                    "added": added_count, "found": found_stat,
                    "scanned": len(new_items), "shown": len(shown_items)})

@app.route("/api/generate_ai", methods=["POST"])
def api_generate_ai():
    lic = init_or_load_license()
    if not lic.get("is_active"):
        return jsonify({"success": False, "error": "Срок тест-драйва истёк. Активируйте PRO лицензию"})

    data = request.json or {}
    item_id = _as_int(data.get("item_id"), 0)
    mode = data.get("mode", "infographic") # "ai_studio" or "infographic"
    cfg = load_config()
    key = cfg.get("royaltech_api_key", "").strip()

    catalog = load_catalog()
    target_item = data.get("item")
    if not target_item:
        for it in catalog:
            if it.get("id") == item_id:
                target_item = it
                break

    if not target_item:
        return jsonify({"success": False, "error": "Товар не найден"})

    ref_img = target_item.get("img_main") or target_item.get("img_url") or ""
    title = target_item.get("kaspi_name") or target_item.get("name", "Товар")

    local_name = f"ai_{item_id}.jpg"
    local_path = os.path.join(IMAGES_DIR, local_name)
    info_name = f"info_{item_id}.jpg"
    info_path = os.path.join(IMAGES_DIR, info_name)

    used_nanobanana = False
    if key:
        try:
            prompt = (
                f"Commercial professional product photography of {title}. "
                f"Placed on an ultra-clean warm-white minimalist stone podium with soft natural daylight, "
                f"gentle studio shadow, crisp sharp focus, luxury Scandinavian aesthetic, 8k resolution, e-commerce catalog ready"
            )
            res = generate_product_photo(key, reference_image_url=ref_img, prompt_text=prompt, aspect_ratio="portrait")
            if res.get("success"):
                gen_url = res.get("url")
                download_file(gen_url, local_path)
                target_item["ai_image"] = f"/data/images/{local_name}"
                target_item["ai_cdn_url"] = gen_url
                used_nanobanana = True
        except Exception:
            pass

    # Fallback to downloading reference image directly if NanoBanana was not used or failed
    if not used_nanobanana and ref_img and ref_img.startswith("http"):
        try:
            download_file(ref_img, local_path)
            target_item["ai_image"] = f"/data/images/{local_name}"
        except Exception:
            pass

    try:
        if os.path.exists(local_path):
            apply_apple_infographics(local_path, info_path, title_text=title, category=target_item.get("category", ""))
            target_item["infographic_image"] = f"/data/images/{info_name}"
    except Exception as e:
        print("apply_apple_infographics error:", e)

    # Сохраняем изменения в радаре. Если товара там не было (пришёл прямо в запросе) — добавляем его.
    try:
        found = False
        for i, it in enumerate(catalog):
            if it.get("id") == target_item.get("id"):
                catalog[i] = target_item
                found = True
                break
        if not found:
            catalog.insert(0, target_item)
        save_catalog(catalog)
    except Exception as e:
        print("save_catalog error:", e)

    final_img = target_item.get("infographic_image") if mode == "infographic" else (target_item.get("ai_image") or target_item.get("infographic_image"))
    if not final_img:
        final_img = ref_img

    return jsonify({
        "success": True,
        "item": target_item,
        "ai_image": final_img,
        "used_api": used_nanobanana,
        "message": "AI студийный рендер готов" if used_nanobanana else "Инфографика Apple УТП сформирована"
    })

@app.route("/api/sync_wb_prices", methods=["GET", "POST"])
def api_sync_wb_prices():
    """Обновляет цены радара: цена WB для вашего города в тенге (доставка до ПВЗ включена) и наличие."""
    catalog = load_catalog()
    if not catalog:
        return jsonify({"success": False, "error": "Каталог пуст"})
    cfg = load_config()
    mult = cfg.get("margin_multiplier", 2.4)
    pkg = cfg.get("packaging_cost_kzt", 150)
    try:
        prices = wb_tracker.fetch_wb([it["id"] for it in catalog[:300] if it.get("id")])
    except Exception as e:
        return jsonify({"success": False, "error": f"WB: {e}"})
    updated = out_of_stock = 0
    for it in catalog:
        w = prices.get(int(it.get("id") or 0))
        if w is None:
            continue
        it["in_stock"] = bool(w.get("qty"))
        it["wb_qty"] = w.get("qty")
        if w.get("price"):
            from core import setup_wizard as _sw0
            it["price_checked_at"] = int(time.time())          # цена только что проверена, даже если не изменилась
            it["price_source"] = f"WB {_sw0.city_name()}, ₸"
        if not w.get("qty"):
            out_of_stock += 1
            continue
        if w.get("price") and w["price"] != it.get("price_kzt"):
            it["price_kzt"] = int(w["price"])
            from core import setup_wizard as _sw; it["price_source"] = f"WB {_sw.city_name()}, ₸"
            it["cost_total"] = it["price_kzt"] + pkg
            it["kaspi_price"] = round_kaspi_price(it["cost_total"] * mult)
            for k in ("profit", "roi", "margin_pct", "payout", "total_fees"):
                it.pop(k, None)                  # пересчитаются по новой цене
            updated += 1
    save_catalog(catalog)
    return jsonify({"success": True, "updated_prices": updated, "out_of_stock": out_of_stock, "items": catalog})

@app.route("/data/images/<filename>")
def serve_image(filename):
    return send_from_directory(IMAGES_DIR, filename)

@app.route("/api/export", methods=["GET"])
def api_export():
    # Check license status
    lic = init_or_load_license()
    if not lic.get("is_active"):
        return jsonify({"success": False, "error": "Тест-драйв завершён. Активируйте ключ PRO для экспорта файлов."}), 403

    catalog = load_catalog()
    if not catalog:
        return jsonify({"success": False, "error": "Каталог пуст"})
        
    cfg = load_config()
    preorder_days = request.args.get("preorder_days", cfg.get("preorder_days", 7))
    photo_mode = request.args.get("photo_mode", "ai_studio")
    desc_mode = request.args.get("desc_mode", "ai_copywriter")
    
    out_file = os.path.join(BASE_DIR, "data", "Kaspi_Pay_Upload.xlsx")
    export_to_excel(catalog, out_file, options={
        "preorder_days": preorder_days,
        "photo_mode": photo_mode,
        "desc_mode": desc_mode
    })
    return send_file(out_file, as_attachment=True, download_name=f"Kaspi_Pay_Upload_{preorder_days}d.xlsx")

@app.route("/<path:path>")
def static_proxy(path):
    return send_from_directory("static", path)

def check_already_running(port):
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{port}/api/license", headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=1.2) as resp:
            if resp.getcode() == 200:
                return True
    except Exception:
        pass
    return False

def find_available_port(start_port=8790, max_attempts=10):
    import socket
    for p in range(start_port, start_port + max_attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("0.0.0.0", p))
                return p
            except OSError:
                continue
    return start_port

def open_browser(port):
    if os.environ.get("KWB_NO_BROWSER"):          # для автотестов сборки: не открывать вкладки
        return
    time.sleep(1.2)
    url = f"http://127.0.0.1:{port}"
    try:
        if sys.platform == "win32":
            import subprocess
            subprocess.Popen(f'start "" "{url}"', shell=True)
        else:
            webbrowser.open(url)
    except Exception:
        try:
            webbrowser.open(url)
        except Exception:
            pass

if __name__ == "__main__":
    cfg = load_config()
    target_port = cfg.get("port", 8790)

    # 1. Защита от двойного клика: если сервер уже работает, просто открываем браузер
    if check_already_running(target_port):
        print("==================================================")
        print("  KASPI ARBITRAGE PRO УЖЕ ЗАПУЩЕН!")
        print(f"  Программа уже активна: http://127.0.0.1:{target_port}")
        print("  Открываем дашборд в вашем браузере...")
        print("==================================================")
        open_browser(target_port)
        time.sleep(1.5)
        sys.exit(0)

    # 2. Защита от конфликта портов: если 8790 занят чужой программой, берем следующий свободный
    port = find_available_port(target_port)
    if port != target_port:
        print(f"  [Инфо] Порт {target_port} занят другой программой. Используем порт {port}.")

    print(f"==================================================")
    print(f"  KASPI ARBITRAGE PRO & AI STUDIO (NanoBanana)")
    print(f"  Лицензия: {init_or_load_license().get('status_label')}")
    try:
        from core import selfcheck as _sc
        _sc.PORT = port
    except Exception:
        pass
    print(f"  Сервер запущен: http://127.0.0.1:{port}")
    print(f"==================================================")
    try:
        _secrets.migrate()          # старые открытые пароли -> защищённое хранилище
    except Exception:
        pass
    autopilot.start()
    kaspi_content.start_watcher()
    wb_tracker.start()
    try:
        kaspi_cabinet.keepalive()
    except Exception:
        pass
    threading.Thread(target=open_browser, args=(port,), daemon=True).start()
    # Только этот компьютер. Для Kaspi наружу открывается одна ссылка на прайс через туннель.
    app.run(host="127.0.0.1", port=port, debug=False, threaded=True)
