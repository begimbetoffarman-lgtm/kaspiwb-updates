"""Обновления без своего сервера: файл version.json + zip на любом бесплатном хостинге (например GitHub).
Безопасность: обновление подписано закрытым ключом владельца (Ed25519); без верной подписи и совпадения sha256 оно
НЕ устанавливается. Устанавливаются только файлы кода; data/, config.json, runtime/ не трогаются. Перед заменой —
резервная копия кода (папка backups/), при сбое — автоматический откат."""
import base64
import hashlib
import json
import os
import py_compile
import shutil
import tempfile
import threading
import time
import urllib.request
import zipfile

from core import ed25519
from core.license import PUBLIC_KEY

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(BASE, "data")
ALLOWED_TOP = {"run.py", "start.bat", "requirements.txt", "ИНСТРУКЦИЯ.md", "version.txt"}
ALLOWED_DIRS = ("core/", "static/", "vendor/", "tools/")
STATE = {"available": None, "checked": None, "error": None}


def _cfg():
    try:
        return json.load(open(os.path.join(BASE, "config.json"), encoding="utf-8"))
    except Exception:
        return {}


def current_version():
    try:
        return open(os.path.join(BASE, "version.txt"), encoding="utf-8").read().strip()
    except Exception:
        return "0"


def _vt(v):
    return tuple(int(x) for x in str(v).split(".") if x.isdigit())


def _url():
    try:
        from core import endpoints
        default = endpoints.UPDATE_URL
    except Exception:
        default = ""
    return (_cfg().get("update_url") or default or "").strip()


def _b64d(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _fetch(url, timeout=30):
    return urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "KaspiWB-updater"}), timeout=timeout).read()


def _verify_manifest(m):
    msg = f"KWBUPD1|{m['version']}|{m['sha256']}".encode()
    return ed25519.verify(PUBLIC_KEY, msg, _b64d(m["sig"]))


def check():
    """Есть ли новая версия. Возвращает словарь; ничего не устанавливает."""
    url = _url()
    STATE["checked"] = time.strftime("%Y-%m-%d %H:%M:%S")
    if not url:
        STATE.update(error="Адрес обновлений не настроен.", available=None)
        return {"current": current_version(), "available": None, "error": STATE["error"]}
    try:
        m = json.loads(_fetch(url).decode("utf-8"))
        if not _verify_manifest(m):
            raise RuntimeError("Подпись обновления неверна. Установка отклонена.")
        _save_blocked(m.get("blocked") or [])
        newer = _vt(m["version"]) > _vt(current_version())
        STATE.update(error=None, available=m if newer else None)
        return {"current": current_version(), "latest": m["version"], "available": newer, "notes": m.get("notes", ""),
                "error": None}
    except Exception as e:
        STATE.update(error=str(e)[:200], available=None)
        return {"current": current_version(), "available": None, "error": STATE["error"]}


def _save_blocked(lst):
    """Отозванные ключи (sha256 первых 16 символов ключа) — действует после проверки подписи списка."""
    try:
        os.makedirs(DATA, exist_ok=True)
        json.dump(list(lst), open(os.path.join(DATA, ".blocked.json"), "w"))
    except Exception:
        pass


def _is_allowed(name):
    return name in ALLOWED_TOP or name.startswith(ALLOWED_DIRS)


def apply():
    """Скачивает, проверяет, ставит обновление. Нужна предварительная check(). Потом — перезапуск программы."""
    m = STATE.get("available") or (check() and STATE.get("available"))
    if not m:
        return {"ok": False, "error": "Новых версий нет."}
    tmp = tempfile.mkdtemp(prefix="kwb_upd_")
    try:
        raw = _fetch(m["url"], timeout=120)
        if hashlib.sha256(raw).hexdigest() != m["sha256"]:
            raise RuntimeError("Файл обновления повреждён (sha256 не совпал). Установка отклонена.")
        zp = os.path.join(tmp, "u.zip")
        open(zp, "wb").write(raw)
        new = os.path.join(tmp, "new")
        with zipfile.ZipFile(zp) as z:
            for info in z.infolist():
                n = info.filename.replace("\\", "/")
                if info.is_dir():
                    continue
                if n.startswith("/") or ".." in n.split("/") or not _is_allowed(n):
                    raise RuntimeError(f"В обновлении недопустимый файл: {n}")
                dst = os.path.join(new, *n.split("/"))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                open(dst, "wb").write(z.read(info))
        for base, _, names in os.walk(new):                       # код должен хотя бы компилироваться
            for f in names:
                if f.endswith(".py"):
                    py_compile.compile(os.path.join(base, f), cfile=os.path.join(tmp, "x.pyc"), doraise=True)
        # резервная копия текущего кода
        os.makedirs(os.path.join(BASE, "backups"), exist_ok=True)
        bk = os.path.join(BASE, "backups", f"before-{current_version()}-{time.strftime('%Y%m%d-%H%M%S')}.zip")
        copied = []
        with zipfile.ZipFile(bk, "w", zipfile.ZIP_DEFLATED) as z:
            for base, dirs, names in os.walk(BASE):
                rel_base = os.path.relpath(base, BASE).replace("\\", "/")
                if rel_base.split("/")[0] in ("data", "runtime", "backups", "__pycache__", ".git"):
                    dirs[:] = []
                    continue
                for f in names:
                    rel = (f if rel_base == "." else rel_base + "/" + f)
                    if _is_allowed(rel):
                        z.write(os.path.join(base, f), rel)
        try:
            for base, _, names in os.walk(new):
                for f in names:
                    src = os.path.join(base, f)
                    rel = os.path.relpath(src, new).replace("\\", "/")
                    dst = os.path.join(BASE, *rel.split("/"))
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(src, dst)
                    copied.append(rel)
        except Exception as e:                                    # откат из резервной копии
            with zipfile.ZipFile(bk) as z:
                z.extractall(BASE)
            raise RuntimeError(f"Сбой установки, выполнен откат: {e}")
        STATE["available"] = None
        return {"ok": True, "version": m["version"], "files": len(copied), "backup": os.path.basename(bk),
                "note": "Обновлено. Закройте программу и запустите start.bat заново."}
    except Exception as e:
        return {"ok": False, "error": str(e)[:250]}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


_started = False


def start():
    """Раз в сутки: проверка обновлений (сама не ставит) и отчёт об использовании."""
    global _started
    if _started:
        return
    _started = True

    def loop():
        time.sleep(90)
        while True:
            try:
                check()
                from core import telemetry
                telemetry.report("daily")
            except Exception:
                pass
            time.sleep(24 * 3600)
    threading.Thread(target=loop, daemon=True).start()
