// Баннеры лицензии: пробный период заканчивается или закончился. Сервер сам закрывает функции (код 402).
(function () {
  const ban = () => {
    let b = document.getElementById('licBanner');
    if (!b) {
      b = document.createElement('div'); b.id = 'licBanner'; b.style.display = 'none';
      const mc = document.querySelector('.main-content'); if (mc) mc.insertBefore(b, mc.firstChild);
    }
    return b;
  };
  async function check() {
    let s; try { s = await (await fetch('/api/license')).json(); } catch (e) { return; }
    const b = ban(); if (!b) return;
    const contact = ' Связь: +7 700 394 00 94 (WhatsApp / Telegram).';
    if (!s.is_active) {
      b.className = 'lic-banner bad';
      b.innerHTML = '<b>Пробный период закончился.</b> Сейчас доступны заказы и накладные, настройки и обновления. Остальное откроется после активации: <a href="#" id="licOpen">Активировать PRO</a>.' + contact;
    } else if (s.status === 'TRIAL' && s.days_left <= 2) {
      b.className = 'lic-banner warn';
      b.innerHTML = '<b>Пробный период заканчивается через ' + s.days_left + ' дн.</b> Чтобы продолжить, <a href="#" id="licOpen">активируйте PRO</a>.' + contact;
    } else if (s.status === 'PRO' && s.days_left <= 3) {
      b.className = 'lic-banner warn';
      b.innerHTML = '<b>Лицензия заканчивается через ' + s.days_left + ' дн.</b> Продлите ключ.' + contact;
    } else { b.style.display = 'none'; return; }
    b.style.display = '';
    const l = document.getElementById('licOpen');
    if (l) l.onclick = e => { e.preventDefault(); const a = document.getElementById('btnSidebarActivate'); if (a) a.click(); };
  }
  // сервер отвечает 402, когда функция закрыта: показываем причину и обновляем баннер
  const of = window.fetch; let last = 0;
  window.fetch = async function (...a) {
    const r = await of.apply(this, a);
    if (r.status === 402) {
      try { const d = await r.clone().json(); if (d.license_expired && Date.now() - last > 3000) { last = Date.now(); if (typeof showToast === 'function') showToast(d.error); check(); } } catch (e) { }
    }
    return r;
  };
  document.addEventListener('DOMContentLoaded', () => setTimeout(check, 800));
  setInterval(check, 300000);
  window.checkLicenseBanner = check;
})();
