"""
Слежение за ценой и наличием на Wildberries для товаров, которые продаются в Kaspi на предзаказ.

Цена берётся так же, как её видит покупатель WB в Актобе: через окно браузера WB (WB блокирует прямые
запросы программ), регион доставки Актобе (dest=269), в тенге. В цене WB для Казахстана уже есть доставка
до пункта выдачи (поле logistics).

Правила (применяются в Kaspi через сотрудника кабинета):
  • товар закончился на WB            -> снять с продажи в Kaspi
  • товар снова появился на WB          -> вернуть в продажу с предзаказом
  • WB подорожал и маржа < минимальной  -> поднять цену в Kaspi до минимальной маржи
Цену в Kaspi программа сама НЕ снижает — только сообщает, что можно дешевле.
"""
import json
import os
import threading
import time
import urllib.parse
import urllib.request

from core import kaspi_store as ks
from core import wb_browser as wb

STATE_FILE = os.path.join(ks.DATA_DIR, "wb_tracking.json")
_lock = threading.Lock()


def _cfg(key, default):
    v = ks._config_value(key, default)
    return default if v in ("", None) else v


def load_state():
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"items": {}, "last_run": None, "log": []}


def _save(st):
    ks._atomic_json_write(STATE_FILE, st)


# ------------------------------------------------------------------ цены WB через браузер
_JS = r"""(async(ids, dest)=>{
  const dev=(Object.values(localStorage).map(String).join(' ').match(/site_[0-9a-f]{32}/)||document.cookie.match(/site_[0-9a-f]{32}/)||[''])[0];
  const out={};
  for(let i=0;i<ids.length;i+=50){
    const chunk=ids.slice(i,i+50).join(';');
    const r=await fetch('/__internal/u-card/cards/v4/detail?appType=1&curr=kzt&dest='+dest+'&spp=30&hide_vflags=4294967296&mtype=257&lang=ru&ab_testing=false&nm='+chunk,
      {credentials:'include',headers:{'deviceid':dev,'x-requested-with':'XMLHttpRequest','x-spa-version':'14.31.5'}});
    if(r.status!==200) return JSON.stringify({error:'WB ответил '+r.status});
    const d=await r.json();
    for(const p of (d.products||(d.data||{}).products||[])){
      const s=(p.sizes||[]).find(z=>z.price)||{}; const pr=s.price||{};
      out[p.id]={price:Math.round((pr.product||0)/100), basic:Math.round((pr.basic||0)/100), logistics:Math.round((pr.logistics||0)/100),
                 qty:p.totalQuantity||0, t1:s.time1||null, t2:s.time2||null, name:p.name||''};
    }
  }
  return JSON.stringify({items:out});
})(%s, %s)"""


def fetch_wb(ids):
    """{wb_id: {price, qty, ...}} для Актобе. Товар, которого нет в ответе WB, — снят/нет в наличии."""
    ids = [int(i) for i in ids]
    if not ids:
        return {}
    err = wb._ensure_browser()
    if err:
        raise RuntimeError(err)
    url = f"https://www.wildberries.ru/catalog/{ids[0]}/detail.aspx"
    tgt = wb._http_json("http://127.0.0.1:%d/json/new?%s" % (wb.PORT, urllib.parse.quote(url, safe=":/?=&%")), method="PUT")
    ws = wb._WS(tgt["webSocketDebuggerUrl"])
    try:
        ws.call("Page.enable")
        for _ in range(45):                      # ждём, пока WB пропустит браузер и загрузит страницу
            time.sleep(2)
            try:
                if ws.eval("(document.body&&document.body.innerText.includes('₽'))?1:0"):
                    break
            except Exception:
                continue
        else:
            raise RuntimeError("Wildberries не открылся в браузере (проверка не пройдена). Откройте окно браузера WB и повторите.")
        raw = ws.eval(_JS % (json.dumps(ids), json.dumps(str(_cfg("wb_dest", "269")))), timeout=90)
        data = json.loads(raw or "{}")
        if data.get("error"):
            raise RuntimeError(data["error"])
        return {int(k): v for k, v in data.get("items", {}).items()}
    finally:
        ws.close()
        try:
            urllib.request.urlopen("http://127.0.0.1:%d/json/close/%s" % (wb.PORT, tgt["id"]), timeout=3)
        except Exception:
            pass


# ------------------------------------------------------------------ что отслеживаем
def tracked():
    """Товары с WB, которые реально продаются (или выставляются) в Kaspi — созданные через «Карточки Kaspi из WB»."""
    from core import kaspi_content as kc
    out = {}
    for d in kc.load_drafts():
        if d.get("status") in ("selling", "on_sale") and d.get("wb_id"):
            out[d["sku"]] = {"sku": d["sku"], "wb_id": int(d["wb_id"]), "title": d.get("title", ""),
                             "price": int(d.get("price") or 0), "preorder_days": int(d.get("preorder_days") or 7)}
    return list(out.values())


def _days_from_hours(t2):
    """Срок предзаказа по реальной доставке WB до Актобе: верхняя граница в днях (вверх) + запас (по умолчанию 3 дня)."""
    try:
        t2 = float(t2)
    except Exception:
        return None
    if t2 <= 0:
        return None
    buf = int(_cfg("preorder_buffer_days", 3) or 3)
    return max(1, min(30, int(-(-t2 // 24)) + max(0, buf)))


def wb_preorder_days(wb_id):
    """Срок предзаказа для одного товара WB (None — не удалось узнать, тогда остаётся прежний)."""
    try:
        w = fetch_wb([int(wb_id)]).get(int(wb_id))
        return _days_from_hours(w["t2"]) if w else None
    except Exception:
        return None


def _round_up(p):
    return int(-(-int(p) // 100) * 100 - 10)      # 4 532 -> 4 590


def run(apply=True):
    """Проверка WB и применение правил. apply=False — только отчёт, без изменений в Kaspi."""
    from core import kaspi_cabinet as kcab
    from core import kaspi_content as kc
    if not _lock.acquire(blocking=False):
        return {"busy": True}
    try:
        items = tracked()
        st = load_state()
        rep = {"checked": len(items), "removed": [], "restored": [], "repriced": [], "cheaper": [], "errors": []}
        if not items:
            st["last_run"] = time.strftime("%Y-%m-%d %H:%M:%S")
            _save(st)
            return rep
        wbd = fetch_wb([i["wb_id"] for i in items])
        min_margin = float(_cfg("wb_min_margin_pct", 15))
        connected = apply and kcab.status().get("connected")
        if apply and not connected:
            rep["errors"].append("Кабинет Kaspi не подключён — изменения в Kaspi не отправлены (только проверка).")
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for it in items:
            sku, w = it["sku"], wbd.get(it["wb_id"])
            old_days = it["preorder_days"]
            days = _days_from_hours(w["t2"]) if w else None
            it["preorder_days"] = days or old_days
            prev = st["items"].get(sku, {})
            in_stock = bool(w and w["qty"] > 0 and w["price"] > 0)
            rec = {"sku": sku, "wb_id": it["wb_id"], "title": it["title"], "checked_at": now,
                   "wb_price": w["price"] if w else None, "wb_prev": prev.get("wb_price"),
                   "qty": w["qty"] if w else 0, "delivery_h": [w["t1"], w["t2"]] if w else None,
                   "kaspi_price": it["price"], "removed_by_tracker": prev.get("removed_by_tracker", False),
                   "action": prev.get("action", "")}
            try:
                if not in_stock:
                    if not prev.get("removed_by_tracker"):
                        if connected:
                            kcab.set_offer(sku, available=False)
                            ks.update_product_delivery(sku, "archive")
                            o = ks.load_overrides(); o.setdefault(sku, {})["wb_auto_archived"] = True; ks.save_overrides(o)
                            rec["removed_by_tracker"] = True
                        rec["action"] = "Нет на WB → снят с продажи в Kaspi" if connected else "Нет на WB → нужно снять с продажи"
                        rep["removed"].append(sku)
                else:
                    cost = int(w["price"])
                    ks.update_product_cost(sku, cost)
                    econ = ks.calculate_product_economics(it["price"], cost)
                    margin = float(econ.get("margin_pct") or 0)
                    rec.update({"cost": cost, "margin_pct": margin})
                    new_price = it["price"]
                    if margin < min_margin:
                        new_price = _round_up(ks.calculate_min_price_floor(cost, min_margin_pct=min_margin))
                    if prev.get("removed_by_tracker"):
                        if connected:
                            kcab.set_offer(sku, price=new_price, preorder_days=it["preorder_days"], available=True, stock=10)
                            ks.update_product_delivery(sku, "preorder", it["preorder_days"])
                            rec["removed_by_tracker"] = False
                        rec["action"] = f"Снова есть на WB → возвращён в продажу ({new_price} ₸)"
                        rep["restored"].append(sku)
                    elif new_price > it["price"]:
                        if connected:
                            kcab.set_offer(sku, price=new_price, preorder_days=it["preorder_days"], available=True, stock=10)
                        rec["action"] = f"WB подорожал до {cost} ₸ → цена в Kaspi {it['price']} → {new_price} ₸"
                        rep["repriced"].append(sku)
                    else:
                        floor = _round_up(ks.calculate_min_price_floor(cost, min_margin_pct=min_margin))
                        rec["action"] = f"OK, маржа {margin:.0f}%"
                        if floor < it["price"] * 0.85:
                            rec["action"] += f" · можно дешевле: от {floor} ₸ при марже {min_margin:.0f}%"
                            rep["cheaper"].append(sku)
                    if new_price != it["price"] and connected:
                        ks.update_product_price(sku, new_price)
                        ds = kc.load_drafts(); d = kc._find(ds, sku)
                        if d:
                            d["price"] = new_price; d["cost"] = cost; kc.save_drafts(ds)
                        rec["kaspi_price"] = new_price
                    if connected and days and days != old_days:
                        kcab.set_offer(sku, price=new_price, preorder_days=days, available=True, stock=10)
                        ks.update_product_delivery(sku, "preorder", days)
                        ds = kc.load_drafts(); d = kc._find(ds, sku)
                        if d:
                            d["preorder_days"] = days; kc.save_drafts(ds)
                        rec["action"] = (rec.get("action") or "") + f" · предзаказ {old_days} → {days} дн (доставка WB)"
                    rec["preorder_days"] = it["preorder_days"]
            except Exception as e:
                rec["action"] = f"Ошибка: {e}"[:200]
                rep["errors"].append(f"{sku}: {e}")
            st["items"][sku] = rec
            if rec["action"] and rec["action"] != prev.get("action"):
                st.setdefault("log", []).insert(0, {"ts": now, "sku": sku, "msg": rec["action"]})
        st["log"] = st.get("log", [])[:200]
        st["last_run"] = now
        st["last_report"] = rep
        _save(st)
        return rep
    finally:
        _lock.release()


_started = False


def start():
    """Фоновая проверка раз в N часов (по умолчанию 6), пока запущена программа."""
    global _started
    if _started:
        return
    _started = True

    def loop():
        time.sleep(300)
        while True:
            try:
                from core import license as _lic
                if not _lic.is_active():
                    time.sleep(600)
                    continue
                if _cfg("wb_tracking_enabled", True) not in (False, "false", 0):
                    st = load_state()
                    last = st.get("last_run_ts", 0)
                    hours = float(_cfg("wb_tracking_hours", 6))
                    if time.time() - last >= hours * 3600:
                        st["last_run_ts"] = time.time(); _save(st)
                        run(apply=True)
            except Exception as e:
                print("wb tracker:", e)
            time.sleep(600)
    threading.Thread(target=loop, daemon=True, name="wb-tracker").start()
