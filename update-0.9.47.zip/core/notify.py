"""Уведомления в Telegram: новый заказ, срок передачи, новый возврат, действия слежения за WB.
Настройка: бот от @BotFather (токен) + ваш chat id. Всё хранится только на вашем компьютере (data/notify.json).
Первый запуск только запоминает текущие заказы и возвраты, чтобы не засыпать вас старыми."""
import json
import os
import threading
import time
import urllib.parse
import urllib.request

from core import kaspi_store as ks
from core import order_flow as of
from core import orders_screen as osr

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_SET = os.path.join(ROOT, "data", "notify.json")
_STATE = os.path.join(ROOT, "data", "notify_state.json")
_LOCK = threading.Lock()
_started = False


def _load(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, type(default)) else default
    except (OSError, ValueError):
        return default


def settings(masked=True):
    s = _load(_SET, {})
    s.setdefault("enabled", False)
    s.setdefault("token", "")
    s.setdefault("chat_id", "")
    if masked and s["token"]:
        s = dict(s, token="••••" + s["token"][-4:], has_token=True)
    else:
        s["has_token"] = bool(s["token"])
    return s


def save_settings(data):
    cur = _load(_SET, {})
    tok = str(data.get("token") or "").strip()
    if tok and not tok.startswith("••••"):
        if ":" not in tok or len(tok) < 20:
            raise ValueError("Токен бота выглядит неверно. Он выдаётся в @BotFather и содержит двоеточие.")
        cur["token"] = tok
    if "chat_id" in data:
        cid = str(data.get("chat_id") or "").strip()
        if cid and not cid.lstrip("-").isdigit():
            raise ValueError("Chat id — это число (например 123456789).")
        cur["chat_id"] = cid
    if "enabled" in data:
        cur["enabled"] = bool(data["enabled"])
    os.makedirs(os.path.dirname(_SET), exist_ok=True)
    ks._atomic_json_write(_SET, cur)
    return settings()


def _api(method, params, timeout=15):
    tok = settings(masked=False)["token"]
    if not tok:
        raise ValueError("Сначала укажите токен бота.")
    req = urllib.request.Request("https://api.telegram.org/bot%s/%s" % (tok, method),
                                 data=urllib.parse.urlencode(params).encode(), method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def send(text):
    s = settings(masked=False)
    if not s["token"] or not s["chat_id"]:
        raise ValueError("Укажите токен бота и chat id.")
    r = _api("sendMessage", {"chat_id": s["chat_id"], "text": text[:3500], "disable_web_page_preview": "true"})
    if not r.get("ok"):
        raise RuntimeError(str(r.get("description") or "Telegram не принял сообщение"))
    return True


def detect_chat():
    """Находит ваш chat id: напишите боту любое сообщение, затем нажмите «Найти chat id»."""
    r = _api("getUpdates", {"limit": "20"})
    for u in reversed(r.get("result") or []):
        m = u.get("message") or u.get("channel_post") or {}
        c = m.get("chat") or {}
        if c.get("id"):
            return {"chat_id": str(c["id"]), "name": c.get("first_name") or c.get("title") or ""}
    raise ValueError("Бот пока ничего не получил. Откройте бота в Telegram, нажмите Start, напишите ему любое слово и повторите.")


def _items_txt(items):
    return ", ".join("%s × %s" % ((i.get("name") or i.get("sku") or "")[:40], i.get("qty")) for i in items[:3])


def _money(n):
    return "{:,.0f}".format(float(n or 0)).replace(",", " ") + " ₸"


def check_events(send_fn=None):
    """Один проход: ищет новое и отправляет. Возвращает список отправленных сообщений."""
    send_fn = send_fn or send
    with _LOCK:
        st = _load(_STATE, {})
        first = not st.get("init")
        seen_orders = set(st.get("orders") or [])
        seen_ret = set(st.get("returns") or [])
        due_sent = set(st.get("due") or [])
        last_log = st.get("log_ts") or ""
        sent = []

        def push(msg):
            sent.append(msg)
            if not first:
                send_fn(msg)

        now = int(time.time() * 1000)
        live = of._scan(["NEW", "KASPI_DELIVERY", "DELIVERY", "PICKUP"])
        for o in live:
            a = o["attributes"]
            code = str(a.get("code"))
            if a.get("status") in osr.DONE:
                continue
            if code not in seen_orders:
                seen_orders.add(code)
                push("🛒 Новый заказ %s на %s, %s" % (code, _money(a.get("totalPrice")), (a.get("deliveryAddress") or {}).get("town") or ""))
            kd = a.get("kaspiDelivery") or {}
            plan = kd.get("courierTransmissionPlanningDate")
            if plan and not kd.get("courierTransmissionDate") and not a.get("assembled") and 0 < plan - now < 12 * 3600000 and code not in due_sent:
                due_sent.add(code)
                push("⏰ Заказ %s: передать курьеру до %s, а он ещё не собран" % (code, osr._day(plan)))
        # возвраты проверяем реже (запрос тяжёлый)
        if st.get("ret_ts", 0) < time.time() - 1800 or first:
            try:
                r = of.returns()
                for row in r["rows"]:
                    if row["code"] not in seen_ret:
                        seen_ret.add(row["code"])
                        push("↩️ Возврат по заказу %s на %s (%s). Когда заберёте, отметьте в программе." % (row["code"], _money(row["total"]), row.get("status_ru")))
                st["ret_ts"] = time.time()
            except Exception:
                pass
        try:
            from core import wb_tracker
            for e in reversed((wb_tracker.load_state().get("log") or [])[:20]):
                if e.get("ts", "") > last_log:
                    last_log = e["ts"]
                    push("👁 WB: %s — %s" % (e.get("sku"), e.get("msg")))
        except Exception:
            pass
        if first and not last_log:
            last_log = time.strftime("%Y-%m-%d %H:%M:%S")
        st.update({"init": True, "orders": sorted(seen_orders)[-500:], "returns": sorted(seen_ret), "due": sorted(due_sent)[-500:],
                   "log_ts": last_log})
        ks._atomic_json_write(_STATE, st)
        return [] if first else sent


def start():
    global _started
    if _started:
        return
    _started = True

    def loop():
        time.sleep(90)
        while True:
            try:
                if settings(masked=False).get("enabled") and settings(masked=False).get("token") and settings(masked=False).get("chat_id"):
                    check_events()
            except Exception as e:
                print("notify error:", e)
            time.sleep(600)

    threading.Thread(target=loop, daemon=True).start()
