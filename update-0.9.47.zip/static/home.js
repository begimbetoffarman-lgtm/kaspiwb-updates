// Главная: сводка, ближайшие сроки, прибыль, слежение за WB, причины отказов. Плюс Telegram и резервная копия в настройках.
(function () {
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const money = n => (Number(n) || 0).toLocaleString('ru-RU') + ' ₸';
  let loadedAt = 0;

  function tile(value, label, warn) { return `<div class="home-tile${warn ? ' warn' : ''}"><b>${value}</b><span>${label}</span></div>`; }

  async function loadHome() {
    if (!$('homeBox')) return;
    if (Date.now() - loadedAt < 20000) return;          // не дёргаем Kaspi при каждом переключении вкладок
    loadedAt = Date.now();
    apiGet('/api/orders/digest').then(r => {
      const d = r.ok ? r.data : null;
      $('homeDigest').innerHTML = d
        ? tile(d.to_collect, 'собрать сейчас', d.to_collect > 0) + tile(d.in_transit, 'в пути к покупателю') +
          tile(d.returns_open, 'возвратов не забрано', d.returns_open > 0) + tile(money(d.returns_open_sum), 'сумма возвратов', d.returns_open_sum > 0)
        : '<div class="help-text">Подключите Kaspi в «Первом запуске», чтобы видеть заказы. ' + esc(r.error || '') + '</div>';
    });
    apiGet('/api/home/deadlines').then(r => {
      const it = r.ok ? r.data.items : [];
      $('homeDeadlines').innerHTML = it.length ? it.map(x => `<div class="home-row ${esc(x.level)}">${x.level === 'late' ? '⚠️ ' : x.level === 'soon' ? '⏰ ' : ''}${esc(x.text)}</div>`).join('')
        : (r.ok ? 'Срочных дел нет.' : esc(r.error));
    });
    apiGet('/api/profit?days=28').then(r => {
      if (!r.ok) { $('homeProfit').textContent = r.error; return; }
      const d = r.data;
      const losers = (d.losers || []).map(p => `${esc(p.sku)} — ${esc((p.name || '').slice(0, 45))}: <b style="color:#B91C1C">${money(p.profit)}</b>`).join('<br>');
      const top = (d.top || []).slice(0, 3).map(p => `${esc(p.sku)} — ${esc((p.name || '').slice(0, 45))}: <b>${money(p.profit)}</b>`).join('<br>');
      $('homeProfit').innerHTML = `<div class="home-grid">${tile(money(d.today.profit), 'чистая за сегодня · заказов ' + d.today.orders)}${tile(money(d.week.profit), 'за 7 дней · заказов ' + d.week.orders)}${tile(money(d.period.profit), 'за 28 дней · выручка ' + money(d.period.revenue))}</div>` +
        (top ? `<div style="margin-top:8px;"><b>Больше всего приносят:</b><br>${top}</div>` : '') +
        (losers ? `<div style="margin-top:8px;"><b>В минусе:</b><br>${losers}</div>` : '') +
        (d.no_cost_orders ? `<div style="margin-top:8px;">Для ${d.no_cost_orders} заказов не указана себестоимость, прибыль по ним не посчитана.</div>` : '') +
        '<div style="margin-top:6px;opacity:.7;">Прибыль: цена продажи минус себестоимость, комиссия Kaspi, доставка и налог. Возвраты считаются отдельно.</div>';
    });
    apiGet('/api/home/tracker').then(r => {
      if (!r.ok) { $('homeTracker').textContent = r.error; return; }
      const d = r.data;
      $('homeTracker').innerHTML = d.tracked
        ? `Слежу за ${d.tracked} товарами WB. Последняя проверка: ${esc(d.last_run || '—')}.` +
          (d.problems.length ? '<br>' + d.problems.map(p => `⚠️ ${esc(p.sku)}: ${esc(p.action)}`).join('<br>') : '<br>Всё в порядке.') +
          (d.log.length ? '<br><span style="opacity:.7;">Последние действия: ' + d.log.map(l => esc(l.msg)).join(' · ') + '</span>' : '')
        : 'Нет товаров, выставленных из WB: слежение начнётся после первой продажи из «Карточки Kaspi».';
    });
    apiGet('/api/home/rejects').then(r => {
      const it = r.ok ? r.data.items : [];
      $('homeRejects').innerHTML = it.length ? it.slice(0, 5).map(x => `${esc(x.example)} — <b>${x.count}</b> раз, исправлено автоматически: ${x.fixed}`).join('<br>') : 'Отказов Kaspi пока не было.';
    });
  }
  window.loadHome = loadHome;

  // ---- Telegram
  async function tgLoad() {
    if (!$('tgToken')) return;
    const r = await apiGet('/api/notify');
    if (!r.ok) return;
    const s = r.data.settings;
    $('tgToken').value = s.has_token ? s.token : '';
    $('tgChat').value = s.chat_id || '';
    $('tgOn').checked = !!s.enabled;
  }
  function tgMsg(t, bad) { $('tgStatus').textContent = t; $('tgStatus').style.color = bad ? '#B91C1C' : ''; }
  if ($('tgSave')) {
    $('tgSave').onclick = async () => {
      const r = await apiPost('/api/notify', { token: $('tgToken').value, chat_id: $('tgChat').value, enabled: $('tgOn').checked });
      tgMsg(r.ok ? 'Сохранено.' : r.error, !r.ok);
    };
    $('tgDetect').onclick = async () => {
      await apiPost('/api/notify', { token: $('tgToken').value });
      tgMsg('Ищу…');
      const r = await apiPost('/api/notify/detect', {});
      if (r.ok) { $('tgChat').value = r.data.chat_id; tgMsg('Найдено: ' + (r.data.name || r.data.chat_id) + '. Нажмите «Проверить».'); } else tgMsg(r.error, true);
    };
    $('tgTest').onclick = async () => {
      await apiPost('/api/notify', { token: $('tgToken').value, chat_id: $('tgChat').value });
      tgMsg('Отправляю…');
      const r = await apiPost('/api/notify/test', {});
      tgMsg(r.ok ? 'Сообщение отправлено, проверьте Telegram. Не забудьте включить уведомления и сохранить.' : r.error, !r.ok);
    };
    tgLoad();
  }

  // ---- резервная копия
  if ($('bkImport')) {
    $('bkImport').addEventListener('change', async e => {
      const f = e.target.files[0]; if (!f) return;
      if (!confirm('Восстановить данные из файла «' + f.name + '»? Текущие файлы будут заменены (старые сохранятся рядом с пометкой .before-restore).')) { e.target.value = ''; return; }
      $('bkStatus').textContent = 'Восстанавливаю…';
      try {
        const r = await fetch('/api/backup/import', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: await f.arrayBuffer() });
        const j = await r.json();
        $('bkStatus').textContent = j.success ? 'Восстановлено файлов: ' + j.restored.length + '. Перезапустите программу.' : (j.error || 'Не удалось восстановить.');
      } catch (err) { $('bkStatus').textContent = 'Ошибка: ' + err.message; }
      e.target.value = '';
    });
  }

  // главная открывается первой
  setTimeout(() => { const a = document.querySelector('.nav-item.active'); if (a && a.dataset.tab === 'tab-home') loadHome(); }, 600);
})();
