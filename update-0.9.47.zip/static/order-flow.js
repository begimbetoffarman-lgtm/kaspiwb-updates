// «В пути» и «Возвраты» в разделе «Заказы и накладные».
(function () {
  const $ = id => document.getElementById(id);
  if (!$('transitBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const money = n => (Number(n) || 0).toLocaleString('ru-RU') + ' ₸';
  const box = 'border:1px solid #ddd;border-radius:8px;padding:8px;margin-bottom:6px;';
  const items = list => (list || []).map(i => esc(i.sku) + ' × ' + esc(i.qty) + ' — ' + esc(i.name)).join('<br>');

  async function digest() {
    const el = $('flowDigest'); if (!el) return;
    const r = await apiGet('/api/orders/digest');
    if (!r.ok) { el.textContent = ''; return; }
    const d = r.data;
    el.innerHTML = `<b>Сводка:</b> собрать ${d.to_collect} · в пути ${d.in_transit} · возвратов не забрано ${d.returns_open}` +
      (d.returns_open ? ` на <b style="color:#B91C1C">${money(d.returns_open_sum)}</b>` : '');
  }

  async function loadTransit() {
    const el = $('transitList'); el.textContent = 'Загружаю…';
    const r = await apiGet('/api/orders/transit');
    if (!r.ok) { el.textContent = r.error; return; }
    const d = r.data;
    el.innerHTML = `<div class="help-text" style="margin-bottom:6px;">В пути: <b>${d.in_transit}</b> · ждут передачи курьеру: <b>${d.waiting}</b>` +
      (d.late ? ` · <b style="color:#B91C1C">просрочена доставка: ${d.late}</b>` : '') + '</div>' +
      (d.rows.map(o => `<div style="${box}${o.done ? 'opacity:.7' : ''}"><b>${esc(o.code)}</b> · ` +
        (o.done ? '✅ доставлен ' + esc(o.completed || '') : (o.late ? '⚠️ доставка задерживается' : '🚚 в пути')) +
        `${o.city ? ' · ' + esc(o.city) : ''}<br>${items(o.items)}<br>` +
        `<span class="help-text">Передан: ${esc(o.handed || '—')}${o.done ? '' : ' · доставить до: ' + esc(o.planned || '—')} · сумма ${money(o.total)}</span></div>`).join('') || 'Пока ничего нет.');
  }

  async function loadReturns() {
    const el = $('returnsList'); el.textContent = 'Загружаю возвраты (до 15 секунд)…';
    $('returnsSum').textContent = ''; $('returnsTop').textContent = '';
    const r = await apiGet('/api/orders/returns');
    if (!r.ok) { el.textContent = r.error; return; }
    const d = r.data;
    $('returnsSum').innerHTML = `Всего возвратов: ${d.count} на ${money(d.total)} · <span style="color:#B91C1C">не забрано: ${d.open_count} на ${money(d.open_sum)}</span>`;
    el.innerHTML = d.rows.map(o => `<div style="${box}${o.got ? 'opacity:.65' : ''}"><b>${esc(o.code)}</b> · ${esc(o.status_ru)} · ${esc(o.state)}` +
      ` · <b>${money(o.total)}</b>${o.city ? ' · ' + esc(o.city) : ''}<br>${items(o.items)}<br>` +
      `<span class="help-text">Передан: ${esc(o.handed || '—')} · найден: ${esc(o.first_seen || '')}${o.reason ? ' · причина: ' + esc(o.reason) : ''}${o.got_at ? ' · забрал: ' + esc(o.got_at) : ''}</span> ` +
      `<button type="button" class="btn btn-sm ${o.got ? 'btn-secondary' : 'btn-accent'}" data-ret="${esc(o.code)}" data-got="${o.got ? 0 : 1}">${o.got ? 'Вернуть в «не забрано»' : '✓ Забрал'}</button></div>`).join('') || 'Возвратов за этот период нет.';
    $('returnsTop').innerHTML = (d.top || []).length ? '<div class="help-text"><b>Чаще всего возвращают:</b><br>' +
      d.top.map(s => `${esc(s.sku)} — ${esc(s.name)}: возвратов ${s.returns}` + (s.rate != null ? ` (${s.rate}% от продаж и возвратов)` : '')).join('<br>') + '</div>' : '';
  }

  $('transitLoad').onclick = loadTransit;
  $('returnsLoad').onclick = loadReturns;
  $('returnsList').addEventListener('click', async e => {
    const b = e.target.closest && e.target.closest('button[data-ret]'); if (!b) return;
    b.disabled = true;
    const r = await apiPost('/api/orders/returns/mark', { code: b.dataset.ret, got: b.dataset.got === '1' });
    if (!r.ok) { b.disabled = false; if (window.showToast) showToast('Не удалось сохранить: ' + r.error); return; }
    loadReturns(); digest();
  });

  const prev = window.loadOrdersTab;
  window.loadOrdersTab = function () { if (prev) prev(); digest(); };
})();
