// Вкладка «Финансы»: прибыль, структура расходов, прогноз, таблица по товарам, выгрузка в Excel (CSV).
(function () {
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = n => (Math.round(Number(n) || 0)).toLocaleString('ru-RU') + ' ₸';
  let rep = null, sortKey = 'profit', sortDir = -1, loadedAt = 0, loadedDays = 0;

  function kpi(label, value, sub, cls) {
    return '<div class="fin-k"><span>' + label + '</span><b class="' + (cls || '') + '">' + value + '</b>' + (sub ? '<em>' + sub + '</em>' : '') + '</div>';
  }

  function render() {
    if (!rep) return;
    const p = rep.period, days = rep.period_days;
    $('finKpi').innerHTML =
      kpi('Прибыль с продаж', money(p.profit), 'заказов ' + p.orders + ', выручка ' + money(p.revenue), p.profit < 0 ? 'neg' : '') +
      (p.known_revenue > 0 ? kpi('Чистыми после возвратов и расходов', money(p.net), 'возвраты ' + p.ret_count + ' шт −' + money(p.ret_loss) + ', расходы −' + money(p.expenses), p.net < 0 ? 'neg' : '') : kpi('Чистыми после возвратов и расходов', '—', 'нужна закупка у проданных товаров', '')) +
      kpi('Маржа', p.margin_pct != null ? p.margin_pct + '%' : '—', 'по заказам с закупкой') +
      kpi('Прогноз на 30 дней', rep.forecast_30 != null ? money(rep.forecast_30) : '—', rep.forecast_30 != null ? 'чистыми, при таком темпе' : 'нужна закупка и 5+ заказов', rep.forecast_30 != null && rep.forecast_30 < 0 ? 'neg' : '');

    const st = rep.structure;
    $('finStruct').innerHTML = st
      ? '<table class="fin-t">' + st.map(x => '<tr class="' + (x.total ? 'tot' : '') + '"><td>' + esc(x.name) + '</td><td class="' + (x.sum < 0 ? 'neg' : '') + '">' + (x.sum > 0 && !x.total && x.name.indexOf('Выручка') < 0 ? '+' : '') + money(x.sum) + '</td></tr>').join('') + '</table>'
      : '<div class="dash-empty">Появится, когда у проданных товаров будет указана закупка.</div>';

    $('finForecast').innerHTML = rep.forecast_30 != null
      ? '<b class="' + (rep.forecast_30 < 0 ? 'neg' : '') + '">' + money(rep.forecast_30) + '</b><span>за 30 дней чистыми, если продажи и расходы останутся как за последние ' + days + ' дн. Это оценка, не обещание.</span>'
      : '<span>Нужна закупка у проданных товаров и хотя бы 5 завершённых заказов за период.</span>';

    const list = (rep.products || []).slice();
    // товары без закупки (нет прибыли и маржи) всегда внизу, куда бы ни шла сортировка
    list.sort((a, b) => {
      const na = sortKey !== 'qty' && sortKey !== 'revenue' && !a.known, nb = sortKey !== 'qty' && sortKey !== 'revenue' && !b.known;
      if (na !== nb) return na ? 1 : -1;
      return ((Number(a[sortKey]) || 0) - (Number(b[sortKey]) || 0)) * sortDir;
    });
    const th = (k, t) => '<th class="sortable' + (sortKey === k ? ' on' : '') + '" data-sort="' + k + '">' + t + (sortKey === k ? (sortDir < 0 ? ' ▼' : ' ▲') : '') + '</th>';
    $('finProducts').innerHTML = list.length
      ? '<table class="fin-t fin-prod"><thead><tr><th>Товар</th>' + th('qty', 'Продано') + th('revenue', 'Выручка') + th('profit', 'Прибыль') + th('margin_pct', 'Маржа') + '</tr></thead><tbody>' +
        list.map(x => '<tr><td><b>' + esc(x.sku) + '</b><span>' + esc((x.name || '').slice(0, 60)) + '</span></td><td>' + x.qty + ' шт</td><td>' + money(x.revenue) + '</td>' +
          (x.known ? '<td class="' + (x.profit < 0 ? 'neg' : '') + '">' + money(x.profit) + '</td><td>' + (x.margin_pct != null ? x.margin_pct + '%' : '—') + '</td>'
            : '<td colspan="2" class="nocost">нет закупки <a href="#" class="wz-go" data-go="tab-my-store">указать</a></td>') + '</tr>').join('') + '</tbody></table>'
      : '<div class="dash-empty">За этот период нет завершённых заказов.</div>';
    $('finNote').textContent = 'Реклама и прочие траты вне Kaspi учитываются только если вы добавили их на Главной («Мои расходы в месяц»). Возврат оценивается как потеря доставки и упаковки.';
    const d = $('finDays').value;
    $('finExpP').href = '/api/finance/export?kind=products&days=' + d;
    $('finExpD').href = '/api/finance/export?kind=days&days=' + d;
  }

  async function loadFinance(force) {
    if (!$('finKpi')) return;
    const days = parseInt($('finDays').value, 10) || 28;
    if (!force && rep && loadedDays === days && Date.now() - loadedAt < 20000) return;
    $('finKpi').textContent = 'Считаю по завершённым заказам…';
    const r = await apiGet('/api/profit?days=' + days);
    if (!r.ok) { $('finKpi').textContent = 'Данные появятся после подключения Kaspi («Подключение магазина»). ' + (r.error || ''); return; }
    rep = r.data; loadedAt = Date.now(); loadedDays = days;
    render();
  }
  window.loadFinance = loadFinance;

  document.addEventListener('change', e => { if (e.target && e.target.id === 'finDays') loadFinance(true); });
  document.addEventListener('click', e => {
    const th = e.target.closest && e.target.closest('#finProducts th[data-sort]');
    if (th) { const k = th.dataset.sort; if (sortKey === k) sortDir = -sortDir; else { sortKey = k; sortDir = -1; } render(); }
  });
})();
