import os
import json
import re
import urllib.request
import urllib.error
import ssl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
OVERRIDES_FILE = os.path.join(DATA_DIR, "my_store_overrides.json")
CUSTOM_PRODUCTS_FILE = os.path.join(DATA_DIR, "my_store_custom.json")
LIVE_PRODUCTS_FILE = os.path.join(DATA_DIR, "my_store_live_products.json")

KASPI_API_BASE = "https://kaspi.kz/shop/api/v2"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
CTX = ssl._create_unverified_context()
_VERIFIED = ssl.create_default_context()


def _urlopen(req, timeout):
    """Сначала обычное соединение с проверкой сертификата. Если на компьютере проверка невозможна
    (антивирус подменяет сертификаты, нет корневых), повторяем без проверки, как раньше."""
    try:
        return urllib.request.urlopen(req, context=_VERIFIED, timeout=timeout)
    except urllib.error.URLError as e:
        if isinstance(getattr(e, "reason", None), ssl.SSLError):
            return urllib.request.urlopen(req, context=CTX, timeout=timeout)
        raise


def _city_headers(city):
    """Город витрины Kaspi: так делает браузер. Без него цены и наличие могут прийти по другому городу."""
    city = str(city or "750000000")
    return {"X-KS-City": city, "Cookie": "kaspi.storefront.cookie.city=" + city}

# Realistic Products with 5-20 competing sellers and both In-Stock & Pre-order
DEMO_PRODUCTS = [
    {
        "sku": "109283748",
        "title": "Органайзер для специй вращающийся 360° двухуровневый",
        "category": "Кухонные принадлежности",
        "stock": 42,
        "delivery_type": "in_stock", # В наличии
        "preorder_days": 0,
        "sell_price": 5490,
        "default_cost": 2100,
        "commission_rate": 12.0,
        "competitors_count": 14, # 14 продавцов на карточке!
        "competitor_prices": [5190, 5290, 5490, 5690, 5990],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h88/h52/64402687131678.jpg"
    },
    {
        "sku": "108571129",
        "title": "Массажный воротник для шеи и плеч с 3D-массажем",
        "category": "Электрические массажеры",
        "stock": 25,
        "delivery_type": "preorder", # Под заказ
        "preorder_days": 7,
        "sell_price": 19900,
        "default_cost": 7200,
        "commission_rate": 11.0,
        "competitors_count": 18, # 18 продавцов
        "competitor_prices": [18900, 19490, 19900, 20500, 21900],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h49/h4c/85160142831646.jpg"
    },
    {
        "sku": "114743448",
        "title": "Шляпа демисезонная классическая, регулируемый размер",
        "category": "Головные уборы",
        "stock": 30,
        "delivery_type": "in_stock", # В наличии
        "preorder_days": 0,
        "sell_price": 3939,
        "default_cost": 1500,
        "commission_rate": 15.0,
        "competitors_count": 9,
        "competitor_prices": [3890, 3939, 4190, 4490, 4990],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h45/h26/84536977195038.jpg"
    },
    {
        "sku": "204918392",
        "title": "Держатель для телефона в авто MagSafe на решетку воздуховода",
        "category": "Автоаксессуары",
        "stock": 28,
        "delivery_type": "preorder", # Под заказ
        "preorder_days": 7,
        "sell_price": 4890,
        "default_cost": 1750,
        "commission_rate": 12.5,
        "competitors_count": 16, # 16 продавцов
        "competitor_prices": [4490, 4790, 4890, 5190, 5490],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h91/h3c/84920194830366.jpg"
    },
    {
        "sku": "339201948",
        "title": "Полка для ванной комнаты угловая без сверления черная матовая",
        "category": "Сантехника и аксессуары",
        "stock": 19,
        "delivery_type": "in_stock", # В наличии
        "preorder_days": 0,
        "sell_price": 6290,
        "default_cost": 2350,
        "commission_rate": 11.5,
        "competitors_count": 12,
        "competitor_prices": [5890, 5990, 6190, 6490, 6990], # Seller is 4th -> Outside top-3!
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h14/h99/85210928374814.jpg"
    },
    {
        "sku": "449102834",
        "title": "Беспроводной микрофон петличка K9 Lightning/Type-C для телефона",
        "category": "Аудиотехника",
        "stock": 35,
        "delivery_type": "preorder", # Под заказ
        "preorder_days": 5,
        "sell_price": 3890,
        "default_cost": 1500,
        "commission_rate": 10.0,
        "competitors_count": 20, # 20 продавцов
        "competitor_prices": [3690, 3790, 3890, 4100, 4490],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h55/h07/64389102938472.jpg"
    },
    {
        "sku": "512039485",
        "title": "Набор прецизионных отверток 24 в 1 магнитный алюминиевый кейс",
        "category": "Ручной инструмент",
        "stock": 15,
        "delivery_type": "in_stock", # В наличии
        "preorder_days": 0,
        "sell_price": 4490,
        "default_cost": 1650,
        "commission_rate": 11.0,
        "competitors_count": 8,
        "competitor_prices": [4490, 4690, 4790, 4990, 5290],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h72/h41/64019284910293.jpg"
    },
    {
        "sku": "628104928",
        "title": "Автоматическая поилка-фонтан для кошек и собак 2.5 л с фильтром",
        "category": "Зоотовары",
        "stock": 11,
        "delivery_type": "preorder", # Под заказ
        "preorder_days": 7,
        "sell_price": 8990,
        "default_cost": 3600,
        "commission_rate": 12.0,
        "competitors_count": 7,
        "competitor_prices": [8690, 8890, 8990, 9290, 9590],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h38/h19/84729103948572.jpg"
    },
    {
        "sku": "771920394",
        "title": "Капучинатор электрический ручной венчик для молока и кофе",
        "category": "Кухонные приборы",
        "stock": 50,
        "delivery_type": "in_stock",
        "preorder_days": 0,
        "sell_price": 1990,
        "default_cost": 950,
        "commission_rate": 13.0,
        "competitors_count": 19, # 19 продавцов
        "competitor_prices": [1790, 1890, 1990, 2190, 2490],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h09/h78/64291029485738.jpg"
    },
    {
        "sku": "882019483",
        "title": "Электрическая щетка для уборки беспроводная 5 насадок Magic Brush",
        "category": "Умный дом и уборка",
        "stock": 24,
        "delivery_type": "preorder", # Под заказ
        "preorder_days": 7,
        "sell_price": 5790,
        "default_cost": 2100,
        "commission_rate": 12.5,
        "competitors_count": 11,
        "competitor_prices": [5490, 5690, 5790, 5990, 6290],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h61/h22/85102938475819.jpg"
    },
    {
        "sku": "993012948",
        "title": "Настольная лампа трансформер LED с беспроводной зарядкой 15W",
        "category": "Освещение",
        "stock": 18,
        "delivery_type": "in_stock",
        "preorder_days": 0,
        "sell_price": 7990,
        "default_cost": 2900,
        "commission_rate": 11.0,
        "competitors_count": 6,
        "competitor_prices": [7990, 8190, 8490, 8890, 9190],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h44/h90/84910293847581.jpg"
    },
    {
        "sku": "130958291",
        "title": "Чехол силиконовый противоударный прозрачный",
        "category": "Чехлы для телефонов",
        "stock": 80,
        "delivery_type": "in_stock",
        "preorder_days": 0,
        "sell_price": 1490,
        "default_cost": 650,
        "commission_rate": 15.0,
        "competitors_count": 22, # 22 продавца, сильный демпинг
        "competitor_prices": [1290, 1350, 1390, 1450, 1490], # Seller is 5th!
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h19/h82/64091827364519.jpg"
    }
]

def load_overrides():
    if os.path.exists(OVERRIDES_FILE):
        for _ in range(3):
            try:
                with open(OVERRIDES_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                time.sleep(0.1)
        # файл есть, но не читается: не возвращаем {} — иначе следующая запись сотрёт все данные
        raise RuntimeError("Не удалось прочитать data/my_store_overrides.json")
    return {}

def save_overrides(overrides):
    # атомарно: при сбое записи старый файл с вашей себестоимостью остаётся целым
    _atomic_json_write(OVERRIDES_FILE, overrides)

def load_custom_products():
    if os.path.exists(CUSTOM_PRODUCTS_FILE):
        try:
            with open(CUSTOM_PRODUCTS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return []

def save_custom_products(prods):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(CUSTOM_PRODUCTS_FILE, "w", encoding="utf-8") as f:
        json.dump(prods, f, ensure_ascii=False, indent=2)

IMPORTED_PRODUCTS_FILE = os.path.join(DATA_DIR, "my_store_import.json")
DEFAULT_IMG = "https://resources.cdn-kaspi.kz/img/m/p/h88/h52/64402687131678.jpg"

def load_imported_products():
    if os.path.exists(IMPORTED_PRODUCTS_FILE):
        try:
            with open(IMPORTED_PRODUCTS_FILE, "r", encoding="utf-8") as f:
                return [dict(p, no_comp=True) for p in json.load(f)]
        except Exception:
            pass
    return []

def clear_imported_products():
    if os.path.exists(IMPORTED_PRODUCTS_FILE):
        os.remove(IMPORTED_PRODUCTS_FILE)

def _num(v, default=0.0):
    if v is None:
        return default
    s = re.sub(r"[^\d,.\-]", "", str(v)).replace(",", ".")
    try:
        return float(s) if s not in ("", "-", ".") else default
    except ValueError:
        return default

def _rows_from_file(filename, data):
    """Возвращает список словарей {sku,title,price,stock,preorder_days} из xlsx/csv/xml."""
    import io
    name = (filename or "").lower()
    out = []
    if name.endswith(".xml"):
        import xml.etree.ElementTree as ET
        root = ET.fromstring(data)
        for off in root.iter():
            if off.tag.split("}")[-1] != "offer":
                continue
            def sub(tag):
                for ch in off:
                    if ch.tag.split("}")[-1] == tag:
                        return (ch.text or "").strip()
                return ""
            stock, pre = 0, 0
            for av in off.iter():
                if av.tag.split("}")[-1] == "availability":
                    if str(av.get("available", "")).lower() in ("yes", "true", "1"):
                        stock = max(stock, int(_num(av.get("stockCount"), 10)))
                    pre = max(pre, int(_num(av.get("preOrder"), 0)))
            price = _num(sub("price"))
            if price <= 0:
                # в прайс-листах Kaspi цена лежит в <cityprices><cityprice cityId="...">цена</cityprice>
                cps = [_num(cp.text) for cp in off.iter() if cp.tag.split("}")[-1] == "cityprice" and _num(cp.text) > 0]
                price = min(cps) if cps else 0.0
            out.append({"sku": off.get("sku") or sub("sku"), "title": sub("model") or sub("name") or off.get("sku", ""),
                        "price": price, "stock": stock, "preorder_days": pre, "brand": sub("brand")})
        return out
    if name.endswith(".csv"):
        import csv
        text = None
        for enc in ("utf-8-sig", "cp1251"):
            try:
                text = data.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        if text is None:
            raise ValueError("Не удалось прочитать CSV (кодировка).")
        try:
            dialect = csv.Sniffer().sniff(text[:2000], delimiters=";,\t")
        except Exception:
            dialect = csv.excel
        table = [r for r in csv.reader(io.StringIO(text), dialect)]
    else:
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        ws = wb.active
        table = [list(r) for r in ws.iter_rows(values_only=True)]
    # ищем строку заголовков в первых 15 строках
    keys = {
        "sku": ("артикул", "sku", "код товара"),
        "title": ("название", "наименование", "модель", "товар", "title", "name"),
        "price": ("цена", "price"),
        "stock": ("остаток", "наличие", "количество", "stock", "кол-во"),
        "pre": ("предзаказ", "срок", "preorder", "под заказ"),
    }
    hdr_i, col = None, {}
    for i, row in enumerate(table[:15]):
        cells = [str(c or "").strip().lower() for c in row]
        found = {}
        for k, words in keys.items():
            for j, c in enumerate(cells):
                if c and any(c == w or c.startswith(w) or w in c for w in words) and j not in found.values():
                    found[k] = j
                    break
        if "price" in found and ("title" in found or "sku" in found):
            hdr_i, col = i, found
            break
    if hdr_i is None:
        raise ValueError("Не нашёл колонки «Название» и «Цена». Скачайте прайс-лист из кабинета Kaspi (Товары → Экспорт) и загрузите его без изменений.")
    for row in table[hdr_i + 1:]:
        g = lambda k: row[col[k]] if k in col and col[k] < len(row) else None
        title = str(g("title") or "").strip()
        sku = str(g("sku") or "").strip()
        price = _num(g("price"))
        if not (title or sku) or price <= 0:
            continue
        out.append({"sku": sku, "title": title or sku, "price": price,
                    "stock": int(_num(g("stock"), 10)), "preorder_days": int(_num(g("pre"), 0))})
    return out

def import_price_file(filename, data):
    rows = _rows_from_file(filename, data)
    if not rows:
        raise ValueError("В файле не найдено ни одного товара с ценой.")
    prods, seen = [], set()
    for n, r in enumerate(rows):
        sku = r["sku"] or f"IMP{n+1}"
        if sku in seen:
            continue
        seen.add(sku)
        price = float(r["price"])
        pre = int(r["preorder_days"] or 0)
        prods.append({
            "sku": sku, "title": r["title"], "category": "Мои товары",
            "stock": int(r["stock"]) if r["stock"] else (0 if pre else 10),
            "delivery_type": "preorder" if pre else "in_stock", "preorder_days": pre,
            "sell_price": price, "default_cost": 0,   # закупку не выдумываем: пользователь вводит сам
            "commission_rate": 12.5, "competitors_count": 1, "no_comp": True,
            "competitor_prices": [price], "img": DEFAULT_IMG,
            "brand": r.get("brand") or "",
        })
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(IMPORTED_PRODUCTS_FILE, "w", encoding="utf-8") as f:
        json.dump(prods, f, ensure_ascii=False, indent=2)
    return len(prods)

# Официальная сетка тарифов сервиса «Kaspi Доставка» (с НДС 16%)
KASPI_DELIVERY_RATES = {
    "under_10k": [
        {"max_price": 1000, "city": 57, "kz": 57, "express": 57, "tier": "до 1 000 ₸"},
        {"max_price": 3000, "city": 173, "kz": 173, "express": 173, "tier": "1 000 – 3 000 ₸"},
        {"max_price": 5000, "city": 231, "kz": 231, "express": 231, "tier": "3 000 – 5 000 ₸"},
        {"max_price": 10000, "city": 811, "kz": 927, "express": 927, "tier": "5 000 – 10 000 ₸"},
    ],
    "over_10k_by_weight": {
        "under_5kg": {"city": 1275, "kz": 1507, "express": 1971, "tier": "от 10 000 ₸ (до 5 кг)"},
        "5_to_15kg": {"city": 1565, "kz": 1971, "express": 2145, "tier": "от 10 000 ₸ (5–15 кг)"},
        "15_to_30kg": {"city": 2667, "kz": 4175, "express": 3653, "tier": "от 10 000 ₸ (15–30 кг)"},
    }
}

def get_kaspi_delivery_details(sell_price, scope="kz", weight_tier="under_5kg", include_vat=True):
    """
    Точный расчёт тарифа Kaspi Доставки по официальной сетке (с НДС 16%):
    - До 1 000 ₸: 57 ₸ (город и Казахстан)
    - 1 000 – 3 000 ₸: 173 ₸ (город и Казахстан)
    - 3 000 – 5 000 ₸: 231 ₸ (город и Казахстан)
    - 5 000 – 10 000 ₸: 927 ₸ (По Казахстану) / 811 ₸ (По городу)
    - Свыше 10 000 ₸ (до 5 кг): 1 507 ₸ (По Казахстану) / 1 275 ₸ (По городу)
    """
    p = float(sell_price or 0)
    key = "kz" if scope in ("kz", "kazakhstan") else ("express" if scope == "express" else "city")
    
    if p < 10000:
        target_r = None
        for r in KASPI_DELIVERY_RATES["under_10k"]:
            if p <= r["max_price"]:
                target_r = r
                break
        if not target_r:
            target_r = KASPI_DELIVERY_RATES["under_10k"][-1]
            
        fee_raw = target_r[key]
        tier = target_r["tier"]
    else:
        w_rates = KASPI_DELIVERY_RATES["over_10k_by_weight"].get(weight_tier, KASPI_DELIVERY_RATES["over_10k_by_weight"]["under_5kg"])
        fee_raw = w_rates[key]
        tier = w_rates["tier"]

    fee = fee_raw if include_vat else round(fee_raw / 1.16)
    base = round(fee / 1.16) if include_vat else fee
    vat = fee - base if include_vat else 0
    
    return {
        "fee": fee,
        "base": base,
        "vat": vat,
        "tier": tier,
        "scope": "По Казахстану" if key == "kz" else ("Express" if key == "express" else "По городу"),
        "official": True,
        "vat_rate": "16%"
    }

def get_kaspi_delivery_fee(sell_price, scope="kz", weight_tier="under_5kg", include_vat=True):
    return get_kaspi_delivery_details(sell_price, scope=scope, weight_tier=weight_tier, include_vat=include_vat)["fee"]

def category_commission(category, default=12.5):
    """Реальная ставка Kaspi по категории товара; неизвестная категория -> default."""
    try:
        from core.fork_radar import _commission_rate
        r = _commission_rate(category or '')
        return default if r is None else r
    except Exception:
        return default


def calculate_product_economics(sell_price, cost_price, comm_rate=12.5, pay_rate=0.95, tax_rate=3.0, delivery_kzt=None, pack_kzt=150, delivery_scope="kz", include_vat=True):
    sell_price = float(sell_price or 0)
    cost_price = float(cost_price or 0)
    has_cost = cost_price > 0
    
    deliv_info = get_kaspi_delivery_details(sell_price, scope=delivery_scope, include_vat=include_vat)
    if delivery_kzt is None:
        delivery_kzt = deliv_info["fee"]
        delivery_tier = deliv_info["tier"]
    else:
        delivery_kzt = int(delivery_kzt)
        delivery_tier = "Фиксированный тариф"

    comm_kzt = round(sell_price * (comm_rate / 100))
    pay_kzt = round(sell_price * (pay_rate / 100))
    tax_kzt = round(sell_price * (tax_rate / 100))
    kaspi_deductions = comm_kzt + pay_kzt + tax_kzt + delivery_kzt + pack_kzt
    kaspi_payout = round(sell_price - kaspi_deductions)
    
    if has_cost:
        total_deductions = cost_price + kaspi_deductions
        net_profit = round(sell_price - total_deductions)
        margin_pct = round((net_profit / sell_price) * 100, 1) if sell_price > 0 else 0
        roi_pct = round((net_profit / cost_price) * 100, 1) if cost_price > 0 else 0
        
        if net_profit < 0:
            status = "LOSS"
            badge = "🔴 В УБЫТОК"
            badge_class = "danger"
        elif margin_pct < 12.0:
            status = "LOW_MARGIN"
            badge = "⚠️ НИЗКАЯ МАРЖА"
            badge_class = "warning"
        elif margin_pct >= 25.0:
            status = "HIGH_PROFIT"
            badge = "🟢 СУПЕР-МАРЖА"
            badge_class = "success"
        else:
            status = "NORMAL"
            badge = "🟡 СТАБИЛЬНО"
            badge_class = "info"
    else:
        total_deductions = kaspi_deductions
        net_profit = None
        margin_pct = None
        roi_pct = None
        status = "NO_COST"
        badge = "⚪ НЕ УКАЗАНА"
        badge_class = "neutral"
        
    return {
        "has_cost": has_cost,
        "sell_price": int(sell_price),
        "cost_price": int(cost_price) if has_cost else 0,
        "comm_rate": comm_rate,
        "comm_kzt": comm_kzt,
        "pay_kzt": pay_kzt,
        "tax_kzt": tax_kzt,
        "delivery_kzt": delivery_kzt,
        "delivery_tier": delivery_tier,
        "delivery_base": deliv_info["base"],
        "delivery_vat": deliv_info["vat"],
        "pack_kzt": pack_kzt,
        "kaspi_deductions": kaspi_deductions,
        "kaspi_payout": kaspi_payout,
        "total_deductions": total_deductions,
        "net_profit": net_profit,
        "margin_pct": margin_pct,
        "roi_pct": roi_pct,
        "verdict_status": status,
        "verdict_badge": badge,
        "badge_class": badge_class
    }

def calculate_buybox_rank(my_price, competitor_prices, competitors_count):
    """
    Computes exact position in BuyBox (1st, 2nd, 3rd, or 4+) amongst 5-20 sellers.
    """
    sorted_prices = sorted(competitor_prices or [])
    if not sorted_prices:
        sorted_prices = [my_price]          # конкурентов нет (новая карточка): вы единственный продавец, не падаем
    p1 = sorted_prices[0]
    p2 = sorted_prices[1] if len(sorted_prices) > 1 else p1
    p3 = sorted_prices[2] if len(sorted_prices) > 2 else p2
    
    if my_price <= p1:
        rank = 1
        label = f"🏆 Топ-1 (Лидер корзины)"
        badge_class = "buybox-top1"
        is_in_buybox = True
        headroom = p2 - my_price if p2 > my_price else 0
        if headroom > 0:
            advice = f"Вы на #1 месте среди {competitors_count} продавцов! Можно поднять цену на +{headroom} ₸ без потери лидерства."
        else:
            advice = f"Вы держите #1 место по лучшей цене ({my_price:,} ₸). Забираете до 85% всех заказов карточки!"
    elif my_price <= p2:
        rank = 2
        label = f"🥈 Топ-2 (В корзине)"
        badge_class = "buybox-top2"
        is_in_buybox = True
        diff_top1 = my_price - p1
        advice = f"Вы на 2-м месте. Чтобы забрать 1-е место, снизьте цену на {diff_top1} ₸ (до {p1:,} ₸)."
    elif my_price <= p3:
        rank = 3
        label = f"🥉 Топ-3 (В корзине)"
        badge_class = "buybox-top3"
        is_in_buybox = True
        diff_top1 = my_price - p1
        advice = f"Вы на 3-м месте. Получаете часть заказов. До 1 места: -{diff_top1} ₸."
    else:
        # Rank 4 or worse
        rank = 4
        diff_top3 = my_price - p3
        label = f"⚠️ Вне корзины (#{rank}+)"
        badge_class = "buybox-out"
        is_in_buybox = False
        advice = f"Внимание: Вы вне тройки (среди {competitors_count} продавцов)! Заказов нет. Снизьте цену минимум на {diff_top3} ₸ (до {p3:,} ₸) для входа в Топ-3."
        
    return {
        "rank": rank,
        "is_in_buybox": is_in_buybox,
        "label": label,
        "badge_class": badge_class,
        "advice": advice,
        "top1_price": p1,
        "top2_price": p2,
        "top3_price": p3,
        "target_top1": p1,
        "target_top2": p2,
        "target_top3": p3,
        "competitors_count": competitors_count
    }

def load_live_products():
    if os.path.exists(LIVE_PRODUCTS_FILE):
        try:
            with open(LIVE_PRODUCTS_FILE, "r", encoding="utf-8") as f:
                items = json.load(f)
            for p in items:   # старый кэш: остаток был выдуман из числа заказов, картинка — одна и та же заглушка
                if "stock_est" not in p:
                    p["stock_est"] = True
                    p["stock"] = 1
                if "64402687131678" in str(p.get("img", "")):
                    p["img"] = ""
            return items
        except Exception:
            pass
    return []

def save_live_products(prods):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(LIVE_PRODUCTS_FILE, "w", encoding="utf-8") as f:
        json.dump(prods, f, ensure_ascii=False, indent=2)

def fetch_kaspi_api_orders_products(api_token, days_back=180, max_orders=3000):
    """Kaspi API не отдаёт каталог, только заказы. Собираем товары из заказов за days_back дней:
    окнами по 14 дней (лимит Kaspi), со всеми страницами, позиции заказов читаем параллельно."""
    import time
    from concurrent.futures import ThreadPoolExecutor
    if not api_token or not api_token.strip():
        return []
    headers = {
        "X-Auth-Token": api_token.strip(),
        "Accept": "application/vnd.api+json;charset=UTF-8",
        "User-Agent": USER_AGENT
    }

    def get_json(url, timeout=15):
        for attempt in range(2):
            try:
                req = urllib.request.Request(url, headers=headers)
                with _urlopen(req, timeout) as resp:
                    return json.loads(resp.read().decode("utf-8"))
            except Exception as e:
                last = e
        print("Kaspi API error:", last)
        return None

    now_ms = int(time.time() * 1000)
    day = 24 * 3600 * 1000
    order_ids = []
    for w in range(max(1, days_back // 14)):
        end = now_ms - w * 14 * day
        start = end - 14 * day + 1
        page = 0
        while len(order_ids) < max_orders:
            url = (f"{KASPI_API_BASE}/orders?page[number]={page}&page[size]=100"
                   f"&filter[orders][creationDate][$ge]={start}&filter[orders][creationDate][$le]={end}")
            data = get_json(url)
            if not data:
                break
            batch = data.get("data", [])
            order_ids += [o.get("id") for o in batch if o.get("id")]
            if len(batch) < 100:
                break
            page += 1

    def entries(oid):
        d = get_json(f"{KASPI_API_BASE}/orders/{oid}/entries", timeout=10)
        return (d or {}).get("data", [])

    prods_map = {}
    if order_ids:
        with ThreadPoolExecutor(max_workers=8) as ex:
            for entry_list in ex.map(entries, order_ids):
                for entry in entry_list:
                    attr = entry.get("attributes", {})
                    offer = attr.get("offer", {}) or {}
                    cat = attr.get("category", {}) or {}
                    sku = str(offer.get("code") or attr.get("entryNumber") or "")
                    if not sku:
                        continue
                    base_price = float(attr.get("basePrice") or 0)
                    qty = int(attr.get("quantity") or 1)
                    card_code = ""
                    try:
                        import base64
                        pid = (((entry.get("relationships") or {}).get("product") or {}).get("data") or {}).get("id", "")
                        card_code = base64.b64decode(pid + "=" * (-len(pid) % 4)).decode("ascii") if pid else ""
                        if not card_code.isdigit():
                            card_code = ""
                    except Exception:
                        card_code = ""
                    if sku in prods_map:
                        prods_map[sku]["orders_sold"] += qty
                        if card_code and not prods_map[sku].get("card_code"):
                            prods_map[sku]["card_code"] = card_code
                        continue
                    prods_map[sku] = {
                        "sku": sku,
                        "title": offer.get("name") or f"Товар {sku}",
                        "category": cat.get("title") or "Каталог Kaspi",
                        "stock": 1,
                        "stock_est": True,
                        "delivery_type": "in_stock",
                        "preorder_days": 0,
                        "sell_price": int(base_price),
                        "default_cost": 0,
                        "commission_rate": 12.5,
                        "competitors_count": 8,
                        "competitor_prices": [round(base_price * 0.98), round(base_price), round(base_price * 1.05), round(base_price * 1.10)],
                        "img": "",
                        "orders_sold": qty,
                        "card_code": card_code
                    }
    return list(prods_map.values())


def _fetch_kaspi_api_orders_products_old(api_token):
    if not api_token or not api_token.strip():
        return []

    headers = {
        "X-Auth-Token": api_token.strip(),
        "Accept": "application/vnd.api+json;charset=UTF-8",
        "User-Agent": USER_AGENT
    }
    
    now_ms = int(time.time() * 1000)
    start_ms = now_ms - (14 * 24 * 3600 * 1000)
    url = f"{KASPI_API_BASE}/orders?page[number]=0&page[size]=50&filter[orders][creationDate][$ge]={start_ms}&filter[orders][creationDate][$le]={now_ms}"
    
    prods_map = {}
    
    try:
        req = urllib.request.Request(url, headers=headers)
        with _urlopen(req, 10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            orders = data.get("data", [])
            
            for o in orders:
                oid = o.get("id")
                eurl = f"{KASPI_API_BASE}/orders/{oid}/entries"
                try:
                    ereq = urllib.request.Request(eurl, headers=headers)
                    with _urlopen(ereq, 5) as eresp:
                        edata = json.loads(eresp.read().decode("utf-8"))
                        for entry in edata.get("data", []):
                            attr = entry.get("attributes", {})
                            offer = attr.get("offer", {}) or {}
                            cat = attr.get("category", {}) or {}
                            sku = str(offer.get("code") or attr.get("entryNumber") or "")
                            title = offer.get("name") or f"Товар {sku}"
                            cat_title = cat.get("title") or "Каталог Kaspi"
                            base_price = float(attr.get("basePrice") or 0)
                            qty = int(attr.get("quantity") or 1)
                            
                            if sku and sku not in prods_map:
                                p1 = round(base_price * 0.98)
                                p2 = round(base_price)
                                p3 = round(base_price * 1.05)
                                p4 = round(base_price * 1.10)
                                prods_map[sku] = {
                                    "sku": sku,
                                    "title": title,
                                    "category": cat_title,
                                    "stock": 10 + qty * 2,
                                    "delivery_type": "in_stock",
                                    "preorder_days": 0,
                                    "sell_price": int(base_price),
                                    "default_cost": 0,
                                    "commission_rate": 12.5,
                                    "competitors_count": 8,
                                    "competitor_prices": [p1, p2, p3, p4],
                                    "img": "https://resources.cdn-kaspi.kz/img/m/p/h88/h52/64402687131678.jpg",
                                    "orders_sold": qty
                                }
                            elif sku in prods_map:
                                prods_map[sku]["orders_sold"] += qty
                except Exception:
                    continue
    except Exception as e:
        print("Kaspi API order entries fetch error:", e)
        
    return list(prods_map.values())

_refresh_lock = None

def _refresh_live_async(api_token, days_back):
    """Догружает товары из заказов в фоне и сливает с уже известными (ничего не теряем)."""
    import threading
    global _refresh_lock
    if _refresh_lock is None:
        _refresh_lock = threading.Lock()
    if not _refresh_lock.acquire(blocking=False):
        return
    def work():
        try:
            got = fetch_kaspi_api_orders_products(api_token, days_back=days_back)
            merged = {str(p["sku"]): p for p in got}
            for old in load_live_products():
                merged.setdefault(str(old["sku"]), old)
            if merged:
                save_live_products(list(merged.values()))
        except Exception as e:
            print("Kaspi background refresh error:", e)
        finally:
            _refresh_lock.release()
    threading.Thread(target=work, daemon=True).start()


COMPETITOR_CACHE_FILE = os.path.join(DATA_DIR, "competitor_cache.json")
_comp_last_call = [0.0]

def _store_id():
    """Склад (storeId) из настроек: определяется мастером первого запуска из кабинета Kaspi."""
    mid = str(_config_value("kaspi_merchant_id", "")).strip()
    return str(_config_value("kaspi_store_id", "") or (mid + "_PP1"))


def _config_value(key, default=""):
    try:
        from core import secrets as _sec
        v = _sec.read_config().get(key)
        return default if v in (None, "") else v
    except Exception:
        return default

# ---------------------------------------------------------------- фото карточек Kaspi по коду карточки
import threading
import time
_IMG_FILE = os.path.join(DATA_DIR, "card_images.json")
_IMG_LOCK = threading.Lock()
_IMG_SEM = threading.Semaphore(3)
_IMG_TTL_OK = 30 * 86400          # найденное фото помним 30 дней
_IMG_TTL_NO = 86400               # «не нашли» помним сутки, чтобы не долбить Kaspi


def _img_load():
    try:
        with open(_IMG_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _img_save(d):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        if len(d) > 3000:                                  # не раздуваем файл
            for k, _ in sorted(d.items(), key=lambda kv: kv[1].get("at", 0))[:500]:
                d.pop(k, None)
        tmp = _IMG_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False)
        os.replace(tmp, _IMG_FILE)
    except OSError:
        pass


def cached_card_images(codes):
    """Только из кэша, без сети: код -> адрес фото."""
    d = _img_load()
    now = time.time()
    out = {}
    for c in codes:
        e = d.get(str(c))
        if e and e.get("u") and now - e.get("at", 0) < _IMG_TTL_OK:
            out[str(c)] = e["u"]
    return out


_SPECS_CACHE = {}


def fetch_card_specs(card_code, city_id=None, max_age_sec=86400):
    """Характеристики карточки Kaspi {название: значение} из публичного адреса /yml/content/item/product/<код>.
    Нужны для точной сверки с товаром WB (цвет, объём, мощность). Кэш на сутки; при ошибке вернёт {}."""
    import time as _t
    code = str(card_code or "").strip()
    if not code.isdigit():
        return {}
    hit = _SPECS_CACHE.get(code)
    if hit and _t.time() - hit[0] < max_age_sec:
        return hit[1]
    city = str(city_id or _config_value("kaspi_city", "750000000"))
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json, text/*",
               "Referer": f"https://kaspi.kz/shop/p/-{code}/?c={city}"}
    headers.update(_city_headers(city))
    try:
        from core import ratelimit as _rl
        _rl.hit('kaspi.kz')
        req = urllib.request.Request(f"https://kaspi.kz/yml/content/item/product/{code}?c={city}", headers=headers)
        with _urlopen(req, 10) as resp:
            j = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return {}
    specs = {}
    for group in (j.get("specifications") or []) if isinstance(j, dict) else []:
        for f in (group.get("features") or []):
            if f.get("visible") is False or not f.get("name"):
                continue
            vals = [str(v.get("value")) for v in (f.get("featureValues") or []) if v.get("value") is not None]
            if vals:
                specs[str(f["name"])] = "; ".join(vals)
    if specs:
        _SPECS_CACHE[code] = (_t.time(), specs)
    return specs


def _fetch_card_image(code):
    """Фото карточки Kaspi по её коду: публичный поиск Kaspi по коду отдаёт именно эту карточку."""
    import ssl
    import urllib.parse
    url = ("https://kaspi.kz/yml/product-view/pl/results?page=0&q=%s&text=%s" % (code, code))
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json, text/plain, */*", "Referer": "https://kaspi.kz/shop/search/"}
    headers.update(_city_headers(_config_value("kaspi_city", "750000000")))
    with _IMG_SEM:
        req = urllib.request.Request(url, headers=headers)
        with _urlopen(req, 8) as r:
            data = json.loads(r.read().decode("utf-8")).get("data") or []
    for c in data:
        if str(c.get("id")) == str(code):
            pi = (c.get("previewImages") or [{}])[0] or {}
            u = str(pi.get("medium") or pi.get("small") or pi.get("large") or "")
            if u.startswith("https://resources.cdn-kaspi.kz/"):
                return u
    # запасной путь: страница самой карточки (поиск находит не все карточки, например совсем новые)
    try:
        import re
        preq = urllib.request.Request("https://kaspi.kz/shop/p/-%s/" % code, headers={"User-Agent": USER_AGENT, "Accept": "text/html"})
        with _IMG_SEM:
            with _urlopen(preq, 10) as r:
                html = r.read(600000).decode("utf-8", "ignore")
        m = re.search(r'og:image"\s+content="([^"]+)', html) or re.search(r'content="([^"]+)"\s+property="og:image', html)
        if m and m.group(1).startswith("https://resources.cdn-kaspi.kz/"):
            return m.group(1).replace("format=gallery-large", "format=preview-medium")
    except Exception:
        pass
    return ""


def card_images(codes, limit=40):
    """Код карточки -> адрес фото. Берём из кэша, недостающее докачиваем параллельно (до limit штук за вызов)."""
    from concurrent.futures import ThreadPoolExecutor
    codes = [str(c) for c in dict.fromkeys(codes) if str(c).isdigit()][:limit]
    out = cached_card_images(codes)
    d = _img_load()
    now = time.time()
    todo = [c for c in codes if c not in out and not (d.get(c) and not d[c].get("u") and d[c].get("v") == 2 and now - d[c].get("at", 0) < _IMG_TTL_NO)]
    if todo:
        def one(c):
            try:
                return c, _fetch_card_image(c), True
            except Exception:
                return c, "", False                       # сеть не ответила: не запоминаем «нет фото»
        with ThreadPoolExecutor(max_workers=3) as ex:
            res = list(ex.map(one, todo))
        with _IMG_LOCK:
            d = _img_load()
            for c, u, ok in res:
                if u:
                    out[c] = u
                if ok:
                    d[c] = {"u": u, "at": time.time(), "v": 2}
            _img_save(d)
    return out


def fetch_competitor_prices(card_code, city_id=None, max_age_sec=1800, min_gap_sec=0.8):
    # Город, в котором смотрим конкурентов (настройка kaspi_city; Алматы — крупнейший рынок при продажах по всему РК)
    city_id = str(city_id or _config_value("kaspi_city", "750000000"))
    """Цены продавцов на карточке Kaspi. Публичная витрина, неофициальный адрес: ходим редко,
    с паузой между запросами и кэшем на 30 минут. Возвращает {"ok":bool,"offers":[{"merchant","price"}],"error":str}."""
    import time
    card_code = str(card_code or "").strip()
    if not card_code.isdigit():
        return {"ok": False, "offers": [], "error": "Неизвестен код карточки (товар не встречался в заказах)."}
    cache = {}
    try:
        with open(COMPETITOR_CACHE_FILE, "r", encoding="utf-8") as f:
            cache = json.load(f)
    except Exception:
        pass
    hit = cache.get(card_code)
    if hit and time.time() - hit.get("ts", 0) < max_age_sec:
        return {"ok": True, "offers": hit["offers"], "cached": True, "error": ""}
    with _GAP_LOCK:                         # общая очередь: запросы идут не чаще одного в min_gap_sec, даже из нескольких потоков
        now = time.time()
        slot = max(now, _comp_last_call[0] + min_gap_sec)
        _comp_last_call[0] = slot
    if slot > now:
        time.sleep(slot - now)
    body = json.dumps({"cityId": city_id, "id": card_code, "merchantUID": [], "limit": 64, "page": 0, "sort": True}).encode()
    headers = {"Content-Type": "application/json; charset=UTF-8", "Accept": "application/json, text/*",
               "User-Agent": USER_AGENT, "Referer": f"https://kaspi.kz/shop/p/-{card_code}/?c={city_id}", "Origin": "https://kaspi.kz"}
    headers.update(_city_headers(city_id))
    try:
        from core import ratelimit as _rl
        _rl.hit('kaspi.kz')
        req = urllib.request.Request(f"https://kaspi.kz/yml/offer-view/offers/{card_code}", headers=headers, data=body, method="POST")
        with _urlopen(req, 20) as resp:
            j = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return {"ok": False, "offers": [], "error": f"Kaspi ответил {e.code}. Возможно, ограничение частоты запросов."}
    except Exception as e:
        return {"ok": False, "offers": [], "error": f"Нет связи с Kaspi: {type(e).__name__}"}
    offers = []
    for o in j.get("offers", []):
        try:
            offers.append({"merchant": o.get("merchantName") or "", "merchant_id": str(o.get("merchantId") or ""),
                           "price": int(float(o.get("price"))),
                           "kaspi_delivery": bool(o.get("kaspiDelivery")),
                           "preorder": int(o.get("preorder") or 0),            # 0 = в наличии, иначе срок предзаказа в днях
                           "rating": o.get("merchantRating"), "reviews": o.get("merchantReviewsQuantity"),
                           "delivery_type": o.get("deliveryType") or ""})
        except Exception:
            continue
    offers.sort(key=lambda x: x["price"])
    # Запись под замком: перечитываем свежий файл и дописываем одну карточку, затем атомарная замена.
    # Раньше параллельные потоки затирали кэш целиком (215 карточек -> 3).
    with _CACHE_WRITE_LOCK:
        fresh = _competitor_cache()
        fresh[card_code] = {"ts": time.time(), "offers": offers}
        try:
            _atomic_json_write(COMPETITOR_CACHE_FILE, fresh)
        except Exception as e:
            print("competitor cache write error:", e)
    try:
        from core import price_history
        price_history.record(card_code, offers, _my_merchant_id())
    except Exception:
        pass
    return {"ok": True, "offers": offers, "cached": False, "error": ""}


import threading as _threading
_CACHE_WRITE_LOCK = _threading.RLock()
_GAP_LOCK = _threading.Lock()

def _atomic_json_write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.{os.getpid()}.{_threading.get_ident()}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    for _ in range(5):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:      # Windows: файл на миг занят читателем
            time.sleep(0.1)
    os.replace(tmp, path)


def _my_merchant_id():
    return str(_config_value("kaspi_merchant_id", "")).strip()

def _competitor_cache():
    if not os.path.exists(COMPETITOR_CACHE_FILE):
        return {}
    for _ in range(3):
        try:
            with open(COMPETITOR_CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            time.sleep(0.1)
    return {}

LISTING_FILE = os.path.join(DATA_DIR, "my_listing.json")
_LISTING_TTL = 24 * 3600
_OFFERS_LIMIT = 64          # столько предложений мы забираем с карточки: если их ровно 64, ваше могло не попасть в список


def _listing_cache():
    try:
        with open(LISTING_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _is_mine(o, my_id):
    return str(o.get("merchant_id", "")) == str(my_id) or o.get("merchant") == "White hill market"


def listing_state(card_code, ccache, lcache, my_id):
    """Продаётся ли ваше предложение на витрине Kaspi: True / False / None (не знаем). Только чтение сохранённого, без сети."""
    if not card_code or not my_id:
        return None
    now = time.time()
    hit = (ccache or {}).get(str(card_code))
    if hit and now - hit.get("ts", 0) < _LISTING_TTL:
        offers = hit.get("offers") or []
        if any(_is_mine(o, my_id) for o in offers):
            return True
        if len(offers) < _OFFERS_LIMIT:
            return False                        # список полный, вас в нём нет
    rec = (lcache or {}).get(str(card_code))
    if rec and now - rec.get("ts", 0) < _LISTING_TTL:
        return bool(rec.get("on"))
    return None


def check_my_listing(card_code):
    """Точечный запрос витрины: есть ли на карточке предложение именно вашего магазина (фильтр по merchantUID). Результат в data/my_listing.json."""
    my_id = _my_merchant_id()
    card_code = str(card_code or "").strip()
    if not my_id or not card_code.isdigit():
        return None
    city_id = str(_config_value("kaspi_city", "750000000"))
    with _GAP_LOCK:
        now = time.time()
        slot = max(now, _comp_last_call[0] + 0.8)
        _comp_last_call[0] = slot
    if slot > now:
        time.sleep(slot - now)
    body = json.dumps({"cityId": city_id, "id": card_code, "merchantUID": [str(my_id)], "limit": 1, "page": 0, "sort": True}).encode()
    headers = {"Content-Type": "application/json; charset=UTF-8", "Accept": "application/json, text/*", "User-Agent": USER_AGENT,
               "Referer": f"https://kaspi.kz/shop/p/-{card_code}/?c={city_id}", "Origin": "https://kaspi.kz"}
    headers.update(_city_headers(city_id))
    try:
        from core import ratelimit as _rl
        _rl.hit('kaspi.kz')
        req = urllib.request.Request(f"https://kaspi.kz/yml/offer-view/offers/{card_code}", headers=headers, data=body, method="POST")
        with _urlopen(req, 20) as resp:
            j = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None                              # нет связи или ограничение: оставляем «не знаем», товар не прячем
    on = any(str(o.get("merchantId")) == str(my_id) for o in j.get("offers", []))
    with _CACHE_WRITE_LOCK:
        d = _listing_cache()
        d[card_code] = {"ts": time.time(), "on": on}
        try:
            _atomic_json_write(LISTING_FILE, d)
        except Exception:
            pass
    return on


def real_competitor_prices(card_code, cache, my_id):
    """Цены конкурентов из кэша (без обращения к сети), без ваших собственных предложений. None, если данных нет."""
    hit = cache.get(str(card_code))
    if not hit:
        return None
    mine = {my_id, "White hill market"} if my_id else set()
    return sorted(o["price"] for o in hit["offers"]
                  if str(o.get("merchant_id", "")) not in mine and o.get("merchant") not in mine)

def top_competitor_offers(card_code, cache, my_id, n=5):
    """Первые n других продавцов карточки по цене: цена, магазин, способ продажи (в наличии / предзаказ), доставка, рейтинг."""
    hit = cache.get(str(card_code or ""))
    if not hit:
        return []
    mine = {my_id, "White hill market"} if my_id else set()
    out = []
    for o in hit.get("offers", []):
        if str(o.get("merchant_id", "")) in mine or o.get("merchant") in mine:
            continue
        out.append({"merchant": o.get("merchant") or "Продавец Kaspi", "price": o.get("price"),
                    "preorder": o.get("preorder"),         # None: старый кэш, способ пока неизвестен; 0 = в наличии
                    "kaspi_delivery": bool(o.get("kaspi_delivery")), "rating": o.get("rating"), "reviews": o.get("reviews")})
        if len(out) >= n:
            break
    return out


_comp_thread_lock = None

def refresh_competitors_async(max_items=400):
    """Фоном обновляет цены конкурентов по карточкам (пауза 2 сек между запросами, кэш 30 мин)."""
    import threading, time
    global _comp_thread_lock
    if _comp_thread_lock is None:
        _comp_thread_lock = threading.Lock()
    if not _comp_thread_lock.acquire(blocking=False):
        return
    def work():
        try:
            cache = _competitor_cache()
            codes = []
            ovs = load_overrides()
            srcs = [str(p.get("card_code") or "") for p in load_live_products()] + [str(v.get("card_code") or "") for v in ovs.values()]
            for c in srcs:
                if c.isdigit() and c not in codes:
                    h = cache.get(c)
                    if not h or time.time() - h.get("ts", 0) > 1800:
                        codes.append(c)
            from concurrent.futures import ThreadPoolExecutor
            stop = [False]
            def one(c):
                if stop[0]:
                    return
                r = fetch_competitor_prices(c)
                if not r["ok"] and "429" in r["error"]:
                    stop[0] = True
            with ThreadPoolExecutor(max_workers=3) as ex:
                list(ex.map(one, codes[:max_items]))
            # неясные карточки: на карточке 64+ предложений, вас в списке нет, значит, нужен точечный запрос
            my_id = _my_merchant_id()
            if my_id:
                cache2, lc = _competitor_cache(), _listing_cache()
                todo = []
                for c in dict.fromkeys(srcs):
                    if c.isdigit() and listing_state(c, cache2, lc, my_id) is None and c in cache2:
                        todo.append(c)
                for c in todo[:150]:
                    if stop[0]:
                        break
                    check_my_listing(c)
        except Exception as e:
            print("competitor refresh error:", e)
        finally:
            _comp_thread_lock.release()
    threading.Thread(target=work, daemon=True).start()

def fetch_kaspi_store_data(api_token="", merchant_id="", delivery_kzt=None, pack_kzt=150, delivery_scope="kz", include_vat=True):
    overrides = load_overrides()
    custom_products = load_custom_products()
    raw_products = []
    is_live = False
    
    if api_token and api_token.strip():
        cached_now = load_live_products()
        stale = (not cached_now) or (time.time() - os.path.getmtime(LIVE_PRODUCTS_FILE) > 1800)
        if cached_now and stale:
            _refresh_live_async(api_token, 14)          # быстрое обновление в фоне
        elif not cached_now:
            quick = fetch_kaspi_api_orders_products(api_token, days_back=14)   # ~5 сек, чтобы сразу что-то показать
            if quick:
                save_live_products(quick)
                _refresh_live_async(api_token, 180)     # полный период (до 6 мес.) догружается в фоне
        api_prods = load_live_products()
        if api_prods:
            is_live = True
            raw_products = api_prods + custom_products
        else:
            cached = load_live_products()
            if cached:
                is_live = True
                raw_products = cached + custom_products
            else:
                is_live = False
                raw_products = DEMO_PRODUCTS + custom_products
    else:
        cached = load_live_products()
        if cached:
            is_live = True
            raw_products = cached + custom_products
        else:
            raw_products = DEMO_PRODUCTS + custom_products
        
    # Загруженный прайс-лист = весь каталог. Данные заказов (сколько продано) добавляем к нему.
    imported = load_imported_products()
    if imported:
        by_sku = {str(p["sku"]): dict(p) for p in imported}
        for lp in raw_products:
            k = str(lp.get("sku"))
            if k in by_sku:
                if lp.get("orders_sold"):
                    by_sku[k]["orders_sold"] = lp["orders_sold"]
                if lp.get("card_code") and not by_sku[k].get("card_code"):
                    by_sku[k]["card_code"] = lp["card_code"]      # код карточки известен из заказов: нужен для цен конкурентов
            elif is_live:
                by_sku[k] = lp
        raw_products = list(by_sku.values()) + [c for c in custom_products if str(c.get("sku")) not in by_sku]
        is_live = True

    enriched_products = []
    total_revenue = 0
    total_profit = 0
    total_cost = 0
    buybox_wins = 0
    top3_count = 0
    comp_known = 0
    _ccache = _competitor_cache()
    _my_id = _my_merchant_id()
    _lcache = _listing_cache()
    try:
        _IMG_FROM_CACHE = cached_card_images([str(p.get("card_code") or (overrides.get(str(p.get("sku") or ""), {}) or {}).get("card_code") or "") for p in raw_products if (not p.get("img")) or "64402687131678" in str(p.get("img"))])
    except Exception:
        _IMG_FROM_CACHE = {}
    if any(p.get("card_code") for p in raw_products) or any(v.get("card_code") for v in overrides.values()):
        refresh_competitors_async()
    danger_items = 0
    items_with_cost = 0
    stock_est_count = 0
    alone_count = 0
    in_stock_count = 0
    preorder_count = 0
    archive_count = 0
    total_revenue = 0
    total_profit = 0
    total_cost = 0
    total_rev_with_cost = 0
    
    for prod in raw_products:
        sku = str(prod["sku"])
        ov = overrides.get(sku, {})
        
        if not prod.get("card_code") and str(ov.get("card_code") or "").isdigit():
            prod = dict(prod, card_code=str(ov["card_code"]))      # карточка найдена через кабинет по артикулу
        # Apply overrides if modified by user
        cost_val = ov.get("cost_price", 0)      # только введённая закупка: оценки (45% цены) не подставляем, в том числе сохранённые раньше
        cost = float(cost_val) if cost_val else 0.0
        sell_price = float(ov.get("sell_price", prod["sell_price"]))
        delivery_type = ov.get("delivery_type", prod.get("delivery_type", "in_stock"))
        preorder_days = ov.get("preorder_days", prod.get("preorder_days", 7 if delivery_type == "preorder" else 0))
        stock = prod.get("stock", 10)
        stock_est = bool(prod.get("stock_est"))
        if stock_est:
            stock_est_count += 1
        calc_qty = 1 if stock_est else stock
        
        comp_count = prod.get("competitors_count", 8)
        comp_prices = prod.get("competitor_prices", [sell_price])
        has_real = False
        if prod.get("card_code"):
            rc = real_competitor_prices(prod["card_code"], _ccache, _my_id)
            if rc is not None:
                has_real = True
                comp_prices = rc if rc else [sell_price]
                comp_count = len(rc) + 1
        
        # Economics
        econ = calculate_product_economics(
            sell_price=sell_price,
            cost_price=cost,
            comm_rate=category_commission(prod.get("category"), prod.get("commission_rate", 12.5)),
            delivery_kzt=delivery_kzt,
            pack_kzt=pack_kzt,
            delivery_scope=delivery_scope,
            include_vat=include_vat
        )
        
        if econ["has_cost"]:
            items_with_cost += 1
            total_profit += econ["net_profit"] * calc_qty
            total_cost += cost * calc_qty
            total_rev_with_cost += sell_price * calc_qty
            if econ["net_profit"] < 0 or (econ["margin_pct"] is not None and econ["margin_pct"] < 10.0):
                danger_items += 1
                
        total_revenue += sell_price * calc_qty
        
        # BuyBox & Rank
        bb = calculate_buybox_rank(sell_price, comp_prices, comp_count)
        alone = bool(has_real and comp_count <= 1)
        if alone:
            alone_count += 1
            bb = dict(bb, label="Единственный продавец", badge_class="buybox-alone",
                      advice="На карточке нет других продавцов: цену можно держать выше, демпинг не нужен.")
        if (has_real and not alone) or (not has_real and not prod.get("card_code") and not prod.get("no_comp")):
            comp_known += 1
            if bb["rank"] == 1:
                buybox_wins += 1
            if bb["is_in_buybox"]:
                top3_count += 1

        if delivery_type == "in_stock":
            in_stock_count += 1
        elif delivery_type == "archive":
            archive_count += 1
        else:
            preorder_count += 1
            
        advice = bb["advice"]
        if econ["has_cost"] and econ["net_profit"] < 0:
            rec_min_price = int(cost + econ["comm_kzt"] + econ["delivery_kzt"] + econ["tax_kzt"] + 500)
            advice = f"🔴 ОПАСНО: Продажа в МИНУС ({econ['net_profit']} ₸)! Вы демпингуете ниже себестоимости. Поднимите цену минимум до {rec_min_price:,} ₸!"
        
        floor_price = calculate_min_price_floor(cost, min_margin_pct=15.0, comm_rate=category_commission(prod.get("category"), prod.get("commission_rate", 12.5)), delivery_kzt=delivery_kzt, delivery_scope=delivery_scope, include_vat=include_vat) if econ["has_cost"] else 0
        sup_links = get_supplier_links(prod["title"], prod.get("category", ""))
        
        top_offers = top_competitor_offers(prod.get("card_code"), _ccache, _my_id, 5)
        _on_shelf = listing_state(prod.get("card_code"), _ccache, _lcache, _my_id)
        enriched_products.append({
            "storefront_missing": _on_shelf is False,       # свежая проверка: вашего предложения на витрине Kaspi нет (товар снят)
            "top_offers": top_offers,
            "min_price": int(float(ov.get("min_price") or 0)),
            "max_price": int(float(ov.get("max_price") or 0)),
            "sku": sku,
            "title": prod["title"],
            "category": prod["category"],
            "stock": stock,
            "stock_est": stock_est,
            "cost_est": False,
            "alone": alone,
            "delivery_type": delivery_type,
            "delivery_label": "В наличии" if delivery_type == "in_stock" else f"Под заказ ({preorder_days}д)",
            "preorder_days": preorder_days,
            "sell_price": sell_price,
            "cost_price": cost,
            "floor_min_price": floor_price,
            "supplier_links": sup_links,
            "img": (("" if "64402687131678" in str(prod.get("img", "")) else prod.get("img", "")) or _IMG_FROM_CACHE.get(str(prod.get("card_code") or ""), "")),
            "competitors_count": comp_count,
            "competitor_prices": comp_prices,
            "comp_source": "real" if has_real else ("demo" if not prod.get("card_code") and not prod.get("no_comp") else "none"),
            "card_code": str(prod.get("card_code") or ""),
            # True только если себестоимость ввёл пользователь (вручную или файлом), а не оценка программы
            "cost_real": bool(float(ov.get("cost_price") or 0) > 0),
            "buybox": bb,
            "advice": advice,
            "economics": econ
        })
        
    try:                                   # автопредзаказ: состояние каждого товара для таблицы (без сети)
        from core import auto_preorder as _ap
        _st = _ap.status_many(enriched_products)
        for _p in enriched_products:
            _p["auto_pre"] = _st.get(str(_p.get("sku")), {"on": False})
    except Exception as _e:
        print("auto_preorder status error:", _e)
    avg_margin = round((total_profit / total_rev_with_cost * 100), 1) if (items_with_cost > 0 and total_rev_with_cost > 0) else None
    top3_pct = round((top3_count / comp_known) * 100) if comp_known else 0
    
    return {
        "is_live_api": is_live,
        "mode_label": f"🟢 Живой Kaspi API ({len(enriched_products)} товаров)" if is_live else "🧪 Демо-магазин (Тест-драйв)",
        "products_count": len(enriched_products),
        "imported_count": len(imported),
        "items_with_cost": items_with_cost,
        "in_stock_count": in_stock_count,
        "preorder_count": preorder_count,
        "archive_count": archive_count,
        "total_revenue": int(total_revenue),
        "total_profit": int(total_profit) if items_with_cost > 0 else None,
        "total_cost": int(total_cost) if items_with_cost > 0 else 0,
        "avg_margin_pct": avg_margin,
        "buybox_wins": buybox_wins,
        "top3_count": top3_count,
        "top3_pct": top3_pct,
        "comp_known": comp_known,
        "alone_count": alone_count,
        "cost_est_count": 0,
        "stock_est_count": stock_est_count,
        "danger_items": danger_items,
        "products": enriched_products
    }


def import_costs_file(filename, data):
    """Загрузка себестоимости: Excel/CSV с колонками «Артикул» и «Себестоимость». Возвращает число обновлённых товаров."""
    import io
    name = (filename or "").lower()
    if name.endswith(".csv"):
        import csv
        text = None
        for enc in ("utf-8-sig", "cp1251"):
            try:
                text = data.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        if text is None:
            raise ValueError("Не удалось прочитать CSV (кодировка).")
        try:
            dialect = csv.Sniffer().sniff(text[:2000], delimiters=";,\t")
        except Exception:
            dialect = csv.excel
        table = [r for r in csv.reader(io.StringIO(text), dialect)]
    elif name.endswith(".xlsx") or name.endswith(".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        table = [list(r) for r in wb.active.iter_rows(values_only=True)]
    else:
        raise ValueError("Нужен файл Excel (.xlsx) или CSV с колонками «Артикул» и «Себестоимость».")
    sku_words = ("артикул", "sku", "код")
    cost_words = ("себестоим", "закуп", "cost")
    hdr_i = sku_c = cost_c = None
    for i, row in enumerate(table[:15]):
        cells = [str(c or "").strip().lower() for c in row]
        sc = next((j for j, c in enumerate(cells) if c and any(w in c for w in sku_words)), None)
        cc = next((j for j, c in enumerate(cells) if c and any(w in c for w in cost_words)), None)
        if sc is not None and cc is not None:
            hdr_i, sku_c, cost_c = i, sc, cc
            break
    if hdr_i is None:
        raise ValueError("Не нашёл колонки «Артикул» и «Себестоимость» в первых строках файла.")
    overrides = load_overrides()
    n = 0
    for row in table[hdr_i + 1:]:
        if sku_c >= len(row) or cost_c >= len(row):
            continue
        sku = str(row[sku_c] or "").strip()
        if sku.endswith(".0") and sku[:-2].isdigit():
            sku = sku[:-2]
        cost = _num(row[cost_c])
        if not sku or cost <= 0:
            continue
        overrides.setdefault(sku, {})["cost_price"] = float(cost)
        n += 1
    if n == 0:
        raise ValueError("В файле нет строк с артикулом и положительной себестоимостью.")
    save_overrides(overrides)
    return n

def update_product_price(sku, new_price):
    sku = str(sku).strip()
    overrides = load_overrides()
    if sku not in overrides:
        overrides[sku] = {}
    overrides[sku]["sell_price"] = float(new_price)
    save_overrides(overrides)
    return True

def update_product_cost(sku, new_cost):
    sku = str(sku).strip()
    overrides = load_overrides()
    if sku not in overrides:
        overrides[sku] = {}
    overrides[sku]["cost_price"] = float(new_cost)
    save_overrides(overrides)
    return True

def update_product_limits(sku, min_price=None, max_price=None):
    """Границы цены для робота: не ниже min и не выше max (0 или пусто: граница не задана)."""
    sku = str(sku).strip()
    lo = int(float(min_price or 0))
    hi = int(float(max_price or 0))
    if lo < 0 or hi < 0:
        raise ValueError("Цена не может быть отрицательной.")
    if lo and hi and lo > hi:
        raise ValueError("Минимальная цена не может быть больше максимальной.")
    overrides = load_overrides()
    ov = overrides.setdefault(sku, {})
    for k, v in (("min_price", lo), ("max_price", hi)):
        if v:
            ov[k] = v
        else:
            ov.pop(k, None)
    save_overrides(overrides)
    return {"min_price": lo, "max_price": hi}


def set_product_card_code(sku, card_code):
    sku = str(sku).strip()
    card_code = str(card_code or "").strip()
    if not card_code.isdigit():
        raise ValueError("Код карточки должен состоять из цифр.")
    overrides = load_overrides()
    overrides.setdefault(sku, {})["card_code"] = card_code
    save_overrides(overrides)
    return card_code


def update_product_delivery(sku, delivery_type, preorder_days=7):
    sku = str(sku).strip()
    overrides = load_overrides()
    if sku not in overrides:
        overrides[sku] = {}
    overrides[sku]["delivery_type"] = delivery_type
    overrides[sku]["preorder_days"] = int(preorder_days)
    save_overrides(overrides)
    return True

def parse_kaspi_url_or_sku(input_str):
    """
    Extracts SKU and product details from Kaspi link or direct SKU.
    """
    input_str = input_str.strip()
    # Try finding 7-12 digits
    m = re.search(r'(\d{7,12})', input_str)
    sku = m.group(1) if m else "100" + str(abs(hash(input_str)))[:6]
    
    # Try extracting slug/name from link
    title_match = re.search(r'/shop/p/([^/]+?)-?\d{7,12}', input_str)
    if title_match:
        slug = title_match.group(1).replace('-', ' ').strip().capitalize()
        title = f"Товар Kaspi: {slug}"
    else:
        title = f"Товар Kaspi (Арт. {sku})"
        
    return {
        "sku": sku,
        "title": title,
        "category": "Каталог Kaspi",
        "stock": 20,
        "sell_price": 5990,
        "default_cost": 0,
        "commission_rate": 12.5,
        "competitors_count": 10,
        "competitor_prices": [5490, 5690, 5990, 6290, 6590],
        "img": "https://resources.cdn-kaspi.kz/img/m/p/h88/h52/64402687131678.jpg"
    }

def add_product_from_kaspi(input_str, delivery_type="preorder", preorder_days=7, custom_cost=None, custom_price=None):
    parsed = parse_kaspi_url_or_sku(input_str)
    sku = parsed["sku"]
    
    if custom_cost:
        parsed["default_cost"] = float(custom_cost)
    if custom_price:
        parsed["sell_price"] = float(custom_price)
        
    parsed["delivery_type"] = delivery_type
    parsed["preorder_days"] = int(preorder_days)
    
    customs = load_custom_products()
    # Check if already exists
    existing = [p for p in customs if p["sku"] == sku]
    if not existing:
        customs.insert(0, parsed)
        save_custom_products(customs)
        
    # Also save overrides
    overrides = load_overrides()
    overrides[sku] = {
        "sell_price": parsed["sell_price"],
        "cost_price": parsed["default_cost"],
        "delivery_type": delivery_type,
        "preorder_days": preorder_days
    }
    save_overrides(overrides)
    return parsed

def add_product_from_wb(wb_item, preorder_days=7):
    """
    Transfers an item found in WB Radar directly into seller's store with preorder.
    """
    wb_id = str(wb_item.get("id") or wb_item.get("wb_id") or "").strip()
    sku = f"WB{wb_id}" if wb_id else f"PRE{int(time.time())}"
    title = wb_item.get("kaspi_name") or wb_item.get("name") or f"Товар {sku}"
    cost = float(wb_item.get("cost_total") or (float(wb_item.get("price_kzt", 2000)) + 150))
    sell_price = float(wb_item.get("kaspi_price") or round(cost * 2.4))
    img = wb_item.get("infographic_image") or wb_item.get("ai_image") or wb_item.get("img_main") or wb_item.get("img_url") or ""
    
    prod = {
        "sku": sku,
        "title": title,
        "category": wb_item.get("category") or "Товары под заказ (WB)",
        "brand": wb_item.get("brand") or "",
        "stock": 25,
        "delivery_type": "preorder",
        "preorder_days": int(preorder_days),
        "sell_price": int(sell_price),
        "default_cost": int(cost),
        "commission_rate": 12.5,
        "competitors_count": 1,
        "no_comp": True,
        "competitor_prices": [int(sell_price)],
        "img": img,
        "wb_id": wb_id,
        "wb_url": wb_item.get("wb_url", f"https://www.wildberries.ru/catalog/{wb_id}/detail.aspx" if wb_id else "")
    }
    
    customs = load_custom_products()
    existing = [p for p in customs if str(p.get("sku")) == sku]
    if not existing:
        customs.insert(0, prod)
    else:
        for idx, cp in enumerate(customs):
            if str(cp.get("sku")) == sku:
                customs[idx].update(prod)
                break
    save_custom_products(customs)
    
    overrides = load_overrides()
    overrides[sku] = {
        "sell_price": int(sell_price),
        "cost_price": int(cost),
        "delivery_type": "preorder",
        "preorder_days": int(preorder_days)
    }
    save_overrides(overrides)
    return prod

def add_product_from_supplier(draft):
    """Local price-feed entry after the user submits a reviewed supplier draft."""
    sku = draft['sku']
    prod = {'sku': sku, 'title': draft['title'], 'category': draft.get('category_title') or '',
            'brand': draft.get('brand') or '', 'stock': 1, 'delivery_type': 'preorder',
            'preorder_days': int(draft['preorder_days']), 'sell_price': int(draft['price']),
            'default_cost': int(draft['cost']), 'commission_rate': category_commission(draft.get('category_title')),
            'competitors_count': 0, 'no_comp': True, 'competitor_prices': [],
            'img': next(iter(draft.get('images') or []), ''),
            'source': draft['source'], 'source_url': draft.get('source_url') or ''}
    customs = [p for p in load_custom_products() if p.get('sku') != sku]
    save_custom_products([prod] + customs)
    overrides = load_overrides()
    overrides[sku] = {'sell_price': prod['sell_price'], 'cost_price': prod['default_cost'],
                      'delivery_type': 'preorder', 'preorder_days': prod['preorder_days']}
    save_overrides(overrides)
    return prod


def import_kaspi_excel_catalog(file_path, replace=False):
    """
    Imports seller's complete product catalog from Kaspi Pay Excel price list.
    replace=True: uploaded list becomes the whole list; SKUs missing from the file go to archive.
    """
    import openpyxl
    try:
        wb = openpyxl.load_workbook(file_path, data_only=True)
        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
    except Exception as e:
        return {"success": False, "error": f"Ошибка чтения Excel: {str(e)}"}
        
    if not rows:
        return {"success": False, "error": "Файл пуст"}
        
    header_idx = 0
    for i, r in enumerate(rows[:10]):
        row_str = " ".join([str(c or "").lower() for c in r])
        if any(k in row_str for k in ["артикул", "sku", "код товара", "название", "модель"]):
            header_idx = i
            break
            
    headers = [str(c or "").strip().lower() for c in rows[header_idx]]
    
    sku_col = 0
    title_col = None
    price_col = None
    stock_col = None
    preorder_col = None
    
    for idx, h in enumerate(headers):
        if any(k in h for k in ["артикул", "sku", "код"]):
            sku_col = idx
        elif any(k in h for k in ["название", "товар", "модель", "наименование"]):
            title_col = idx
        elif any(k in h for k in ["цена", "стоимость", "price"]):
            price_col = idx
        elif any(k in h for k in ["наличие", "остаток", "кол-во", "доступно", "склад"]):
            stock_col = idx
        elif any(k in h for k in ["предзаказ", "срок", "доставка"]):
            preorder_col = idx
            
    if title_col is None:
        title_col = 1 if len(headers) > 1 else 0
    if price_col is None:
        price_col = 2 if len(headers) > 2 else 1
        
    imported = []
    customs = load_custom_products()
    existing_skus = {str(p["sku"]) for p in customs}
    
    for r in rows[header_idx + 1:]:
        if not r or all(c is None for c in r):
            continue
        raw_sku = r[sku_col] if sku_col < len(r) else None
        raw_title = r[title_col] if title_col < len(r) else None
        raw_price = r[price_col] if price_col < len(r) else None
        
        if not raw_title and not raw_sku:
            continue
            
        sku = str(raw_sku or abs(hash(str(raw_title))) % 100000000).strip()
        title = str(raw_title or f"Товар {sku}").strip()
        try:
            price = float(raw_price or 0)
        except Exception:
            price = 5000.0
            
        stock = 15
        if stock_col is not None and stock_col < len(r):
            raw_stock = str(r[stock_col] or "").lower()
            if "нет" in raw_stock or "0" in raw_stock:
                stock = 0
            elif "да" in raw_stock or "есть" in raw_stock:
                stock = 15
            else:
                try:
                    stock = int(float(raw_stock))
                except Exception:
                    stock = 15
                    
        delivery_type = "in_stock"
        preorder_days = 0
        if preorder_col is not None and preorder_col < len(r):
            val = str(r[preorder_col] or "").lower()
            if "заказ" in val or any(ch.isdigit() for ch in val):
                delivery_type = "preorder"
                m = re.search(r'(\d+)', val)
                preorder_days = int(m.group(1)) if m else 7
                
        p1 = round(price * 0.98)
        p2 = round(price)
        p3 = round(price * 1.05)
        
        prod_obj = {
            "sku": sku,
            "title": title,
            "category": "Каталог Kaspi",
            "stock": stock,
            "delivery_type": delivery_type,
            "preorder_days": preorder_days,
            "sell_price": int(price),
            "default_cost": 0,
            "commission_rate": 12.5,
            "competitors_count": 8,
            "competitor_prices": [p1, p2, p3],
            "img": "https://resources.cdn-kaspi.kz/img/m/p/h88/h52/64402687131678.jpg"
        }
        
        if sku not in existing_skus:
            customs.append(prod_obj)
            existing_skus.add(sku)
            imported.append(prod_obj)
        else:
            for idx_c, c_prod in enumerate(customs):
                if str(c_prod["sku"]) == sku:
                    customs[idx_c].update({
                        "title": title,
                        "sell_price": int(price),
                        "stock": stock,
                        "delivery_type": delivery_type,
                        "preorder_days": preorder_days
                    })
                    imported.append(customs[idx_c])
                    break

    archived = 0
    if replace:
        # The uploaded price list is the whole list: SKUs absent from it are no longer sold.
        # Move them to archive so they stop appearing as active products.
        keep = {str(p["sku"]) for p in imported}
        for c_prod in customs:
            if str(c_prod["sku"]) not in keep and c_prod.get("delivery_type") != "archive":
                c_prod["delivery_type"] = "archive"
                c_prod["stock"] = 0
                archived += 1

    save_custom_products(customs)
    return {"success": True, "imported_count": len(imported), "total_products": len(customs), "archived_count": archived}

def export_kaspi_price_update_excel(out_path):
    """
    Exports official Kaspi Pay price & delivery update Excel template.
    """
    store_data = fetch_kaspi_store_data()
    products = store_data.get("products", [])
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Прайс-лист Kaspi"
    
    # Headers
    headers = [
        "Артикул (SKU)",
        "Название товара",
        "Цена продажи (₸)",
        "Наличие",
        "Тип поставки",
        "Срок предзаказа (дней)",
        "Позиция в корзине",
        "Лучшая цена конкурента",
        "Чистая прибыль (₸)",
        "Маржа %"
    ]
    
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
    center = Alignment(horizontal="center", vertical="center")
    
    ws.append(headers)
    for col_num in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_num)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center
        
    for p in products:
        econ = p["economics"]
        ws.append([
            p["sku"],
            p["title"],
            p["sell_price"],
            "Нет" if (p["delivery_type"] == "archive" or p["stock"] <= 0) else "Да",
            "Снят с продажи" if p["delivery_type"] == "archive" else ("В наличии" if p["delivery_type"] == "in_stock" else f"Под заказ ({p['preorder_days']}д)"),
            p["preorder_days"],
            p["buybox"]["label"],
            p["buybox"]["top1_price"],
            econ["net_profit"],
            f"{econ['margin_pct']}%"
        ])
        
    # Adjust column widths
    for col in ws.columns:
        max_len = max(len(str(cell.value or '')) for cell in col)
        col_letter = col[0].column_letter
        ws.column_dimensions[col_letter].width = max(max_len + 3, 14)
        
    wb.save(out_path)
    return out_path


def export_kaspi_xml_feed(out_path):
    """
    Exports official Kaspi Shopping XML catalog with current prices and delivery status.
    """
    store_data = fetch_kaspi_store_data()
    products = store_data.get("products", [])
    # В прайс идут только товары вашего прайс-листа из кабинета + добавленные вами в программе.
    # Товары, которые встречались лишь в старых заказах, НЕ выставляем (иначе Kaspi вернёт их в продажу).
    _imported = load_imported_products()
    if _imported:
        allowed = {str(x.get("sku")) for x in _imported} | {str(x.get("sku")) for x in load_custom_products()}
        products = [p for p in products if str(p.get("sku")) in allowed]
    elif not store_data.get("is_live_api") or not products:
        raise RuntimeError("Нет прайс-листа: загрузите прайс из кабинета Kaspi, иначе выгружать нечего.")
    
    try:                                   # автопредзаказ: почти закончившиеся товары остаются в продаже
        from core import auto_preorder as _ap
        products = _ap.apply_to_feed(products)
    except Exception as _e:
        print("auto_preorder feed error:", _e)

    # Защита каталога: Kaspi считает файл полным списком товаров, всё, чего в нём нет или что с ценой 0, снимается с продажи.
    # Лучше не выгрузить совсем (Kaspi останется со старыми ценами), чем выгрузить с дырами.
    def _price_of(p):
        try:
            return int(float(p.get("sell_price") or 0))
        except (TypeError, ValueError):
            return 0

    # цена нужна у каждого товара, даже без остатка: Kaspi не принимает предложение без цены
    _no_price = [str(p.get("sku", "")).strip() for p in products
                 if str(p.get("sku", "")).strip() and _price_of(p) <= 0]
    if _no_price:
        raise RuntimeError("Выгрузка остановлена: у %d товаров не указана цена (%s%s). С нулевой ценой Kaspi снимет их с продажи. "
                           "Укажите цену и повторите." % (len(_no_price), ", ".join(_no_price[:5]), " и др." if len(_no_price) > 5 else ""))
    if _imported:
        _want = {str(x.get("sku")).strip() for x in _imported if str(x.get("sku") or "").strip()}
        _have = {str(p.get("sku", "")).strip() for p in products}
        _lost = _want - _have
        if len(_want) >= 10 and len(_lost) > max(3, int(len(_want) * 0.2)):
            raise RuntimeError("Выгрузка остановлена: в файл попало бы %d из %d товаров вашего прайса (не хватает %s и др.). "
                               "Kaspi снимет отсутствующие с продажи. Обновите данные магазина и повторите." % (len(_have & _want), len(_want), ", ".join(sorted(_lost)[:5])))
    _spaced = [str(p.get("sku", "")).strip() for p in products if re.search(r"\s", str(p.get("sku", "")).strip())]
    if _spaced:
        print("Внимание: артикулы с пробелами или табами внутри (Kaspi их меняет и может заархивировать товар):", _spaced[:5])

    from xml.etree.ElementTree import Element, SubElement, tostring
    from xml.dom import minidom
    import datetime

    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    root = Element("kaspi_catalog", {
        "date": date_str,
        "xmlns": "kaspiShopping",
        "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
        "xsi:schemaLocation": "http://kaspi.kz/kaspishopping.xsd"
    })
    
    _mid = str(_config_value("kaspi_merchant_id", ""))
    company = SubElement(root, "company")
    company.text = _mid          # как в прайсе из кабинета Kaspi
    merchantid = SubElement(root, "merchantid")
    merchantid.text = _mid
    
    offers_el = SubElement(root, "offers")
    
    # бренд — как в исходном прайсе из кабинета / как в созданной карточке (иначе Kaspi видит расхождение)
    _brands = {str(x.get("sku")): x.get("brand") for x in (load_imported_products() + load_custom_products()) if x.get("brand")}
    for p in products:
        sku = str(p.get("sku", "")).strip()
        if not sku:
            continue
        if not p.get("brand") and _brands.get(sku):
            p = dict(p, brand=_brands[sku])
        offer = SubElement(offers_el, "offer", {"sku": sku})
        model = SubElement(offer, "model")
        model.text = str(p.get("title", ""))
        brand = SubElement(offer, "brand")
        brand.text = str(p.get("brand", "Без бренда") or "Без бренда")
        
        avs = SubElement(offer, "availabilities")
        is_archived = p.get("delivery_type") == "archive" or p.get("stock", 0) <= 0
        pre_days = min(30, int(p.get("preorder_days", 0) or 0)) if p.get("delivery_type") == "preorder" else 0   # по правилам Kaspi предзаказ не больше 30 дней
        if is_archived:
            av_attribs = {
                "available": "no",
                "storeId": _store_id()
            }
        elif pre_days > 0:
            av_attribs = {
                "available": "yes",
                "storeId": _store_id(),
                "preOrder": str(pre_days),
                "stockCount": str(float(p.get("stock", 5.0) or 5.0))
            }
        else:
            av_attribs = {
                "available": "yes",
                "storeId": _store_id(),
                "stockCount": str(float(p.get("stock", 5.0) or 5.0))
            }
        SubElement(avs, "availability", av_attribs)
        
        cps = SubElement(offer, "cityprices")
        cp = SubElement(cps, "cityprice", {"cityId": "151010000"})
        cp.text = str(_price_of(p))
        
    xml_str = minidom.parseString(tostring(root, encoding="utf-8")).toprettyxml(indent="  ", encoding="utf-8")
    with open(out_path, "wb") as f:
        f.write(xml_str)
    return out_path



# ==========================================================
# Supplier Hunter (1688 China & Ozon Wholesale)
# ==========================================================
import time
import urllib.parse

REPRICER_CONFIG_FILE = os.path.join(DATA_DIR, "repricer_config.json")

KEYWORD_MAP_CN = [
    ("органайзер", "收纳盒"),
    ("хранени", "收纳"),
    ("специ", "调料盒"),
    ("кухн", "厨房"),
    ("ванн", "浴室"),
    ("полка", "置物架"),
    ("массажер", "按摩器"),
    ("воротник", "颈椎按摩"),
    ("шляпа", "帽子"),
    ("кепка", "帽子"),
    ("докер", "地主帽"),
    ("держатель", "支架"),
    ("авто", "车载"),
    ("magsafe", "磁吸支架"),
    ("микрофон", "麦克风"),
    ("петличк", "领夹麦"),
    ("отвертк", "螺丝刀"),
    ("поилка", "宠物饮水机"),
    ("фонтан", "饮水机"),
    ("капучинатор", "打蛋器 奶泡器"),
    ("венчик", "打蛋器"),
    ("щетка", "清洁刷"),
    ("уборк", "打扫"),
    ("лампа", "台灯"),
    ("светильник", "灯"),
    ("беспроводн", "无线"),
    ("чехол", "手机壳"),
    ("вакуум", "真空封口机"),
    ("сумка", "旅行包 包"),
    ("рюкзак", "双肩包"),
    ("доильн", "挤奶机"),
    ("сушилк", "烘鞋器"),
    ("сифон", "奶油发泡枪"),
    ("дивандек", "沙发垫"),
]

def get_supplier_links(title, category=""):
    t_lower = (title + " " + category).lower()
    cn_terms = []
    for ru_kw, cn_term in KEYWORD_MAP_CN:
        if ru_kw in t_lower:
            cn_terms.append(cn_term)
            if len(cn_terms) >= 3:
                break
    
    if not cn_terms:
        search_query_cn = "日用品 批发"
    else:
        search_query_cn = " ".join(cn_terms)
        
    url_1688 = f"https://s.1688.com/selloffer/offer_search.htm?keywords={urllib.parse.quote(search_query_cn)}"
    url_ozon = f"https://www.ozon.ru/search/?text={urllib.parse.quote(title)}+оптом&from_global=true"
    url_wb = f"https://www.wildberries.ru/catalog/0/search.aspx?search={urllib.parse.quote(title)}"
    
    return {
        "query_cn": search_query_cn,
        "url_1688": url_1688,
        "url_ozon": url_ozon,
        "url_wb": url_wb
    }

def calculate_min_price_floor(cost_price, min_margin_pct=15.0, comm_rate=12.5, pay_rate=0.95, tax_rate=3.0, delivery_kzt=None, pack_kzt=150, delivery_scope="kz", include_vat=True):
    cost_price = float(cost_price or 0)
    if cost_price <= 0:
        return 0
    fees_pct = (comm_rate + pay_rate + tax_rate) / 100.0 # ~0.1645
    denom = 1.0 - fees_pct - (min_margin_pct / 100.0)
    if denom <= 0.05:
        denom = 0.05
    if delivery_kzt is None:
        curr_deliv = get_kaspi_delivery_fee(cost_price * 1.5, scope=delivery_scope, include_vat=include_vat)
        for _ in range(3):
            est_p = (cost_price + curr_deliv + pack_kzt) / denom
            curr_deliv = get_kaspi_delivery_fee(est_p, scope=delivery_scope, include_vat=include_vat)
        delivery_kzt = curr_deliv
    fixed_costs = cost_price + delivery_kzt + pack_kzt
    min_price = fixed_costs / denom
    return int(min_price)

# ==========================================================
# Auto-Repricer Engine (Safe BuyBox Top-1..3 Bot)
# ==========================================================
def load_repricer_config():
    if os.path.exists(REPRICER_CONFIG_FILE):
        try:
            with open(REPRICER_CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "enabled": False,
        "strategy": "top1",
        "min_margin_pct": 15.0,
        "undercut_kzt": 10,
        "last_run": None,
        "last_logs": []
    }

def save_repricer_config(cfg):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(REPRICER_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

def run_auto_repricer_cycle():
    cfg = load_repricer_config()
    strategy = cfg.get("strategy", "top1")
    min_margin = float(cfg.get("min_margin_pct", 15.0))
    undercut = int(cfg.get("undercut_kzt", 10))
    
    store_data = fetch_kaspi_store_data()
    products = store_data.get("products", [])
    overrides = load_overrides()
    
    logs = []
    repriced_count = 0
    shielded_count = 0
    unchanged_count = 0
    skipped = {"no_comp_data": 0, "alone": 0, "no_cost": 0}
    now_str = time.strftime("%H:%M:%S")
    
    for p in products:
        sku = p["sku"]
        cost = p["cost_price"]
        current_sell = p["sell_price"]
        # Демпингуем только при РЕАЛЬНЫХ ценах конкурентов и РЕАЛЬНОЙ себестоимости (введённой вами).
        # Без себестоимости защитный порог не посчитать честно, поэтому цену не трогаем.
        if p.get("comp_source") != "real":
            skipped["no_comp_data"] += 1
            continue
        if int(p.get("competitors_count", 0) or 0) <= 1:
            skipped["alone"] += 1
            continue
        user_min = int(p.get("min_price") or 0)
        user_max = int(p.get("max_price") or 0)
        if not user_min and (not p.get("cost_real") or float(cost or 0) <= 0):
            skipped["no_cost"] += 1          # нет ни себестоимости, ни вашей минимальной цены: нижнюю границу посчитать нечем
            continue
        comp_prices = sorted(p.get("competitor_prices", [current_sell]))
        p1 = comp_prices[0]
        p2 = comp_prices[1] if len(comp_prices) > 1 else p1
        p3 = comp_prices[2] if len(comp_prices) > 2 else p2
        
        if strategy == "top1":
            target = p1 - undercut if p1 > 1000 else p1
        elif strategy == "top2":
            target = p2 - undercut if p2 > 1000 else p2
        else:
            target = p3 - undercut if p3 > 1000 else p3
            
        # нижняя граница: ваша минимальная цена, а если её нет, то порог минимальной маржи
        floor_price = user_min if user_min else calculate_min_price_floor(cost, min_margin_pct=min_margin)
        floor_label = "ваша мин. цена" if user_min else f"мин. маржа {min_margin}%"
        if user_max and target > user_max:
            target = user_max                # выше вашей максимальной цены не поднимаем
        
        is_shielded = False
        final_price = target
        if target < floor_price:
            final_price = floor_price
            is_shielded = True
            shielded_count += 1
            log_msg = f"🛡 {sku}: Защита! Конкурент демпингует до {p1:,}₸. Робот зафиксировал цену на безопасных {floor_price:,}₸ ({floor_label})."
        elif int(final_price) == int(current_sell):
            unchanged_count += 1
            log_msg = f"= {sku}: цена {final_price:,}₸ уже на нужной позиции."
        else:
            repriced_count += 1
            log_msg = f"⚡️ {sku}: {int(current_sell):,}₸ → {final_price:,}₸ ({strategy.upper()}, порог {floor_price:,}₸)."

        if int(final_price) != int(current_sell):
            if sku not in overrides:
                overrides[sku] = {}
            overrides[sku]["sell_price"] = final_price
            
        logs.append({
            "sku": sku,
            "title": p["title"],
            "old_price": current_sell,
            "new_price": final_price,
            "floor_price": floor_price,
            "is_shielded": is_shielded,
            "message": log_msg,
            "time": now_str
        })
        
    save_overrides(overrides)
    cfg["last_run"] = time.strftime("%Y-%m-%d %H:%M:%S")
    cfg["last_logs"] = logs[:20]
    save_repricer_config(cfg)
    
    return {
        "success": True,
        "total_checked": len(products),
        "repriced_count": repriced_count,
        "shielded_count": shielded_count,
        "unchanged_count": unchanged_count,
        "skipped": skipped,
        "logs": logs
    }

_MATCH_STOP = set("для без набор комплект детский детская детское детские игрушка игрушки подарок мальчика девочки мальчиков девочек "
                  "взрослых большая большой большие маленький маленькая новый новая новинка товар штук шт".split())


def _match_tokens(text):
    return re.findall(r"[a-zа-яё0-9]+", str(text or "").lower().replace("ё", "е"))


_TRANSLIT = [("shch", "щ"), ("sch", "щ"), ("sh", "ш"), ("ch", "ч"), ("zh", "ж"), ("kh", "х"), ("ts", "ц"), ("ya", "я"), ("yu", "ю"),
             ("yo", "е"), ("ph", "ф"), ("ck", "к"), ("a", "а"), ("b", "б"), ("c", "к"), ("d", "д"), ("e", "е"), ("f", "ф"), ("g", "г"),
             ("h", "х"), ("i", "и"), ("j", "дж"), ("k", "к"), ("l", "л"), ("m", "м"), ("n", "н"), ("o", "о"), ("p", "п"), ("q", "к"),
             ("r", "р"), ("s", "с"), ("t", "т"), ("u", "у"), ("v", "в"), ("w", "в"), ("x", "кс"), ("y", "и"), ("z", "з")]


def _translit(word):
    out, i = "", 0
    while i < len(word):
        for lat, cyr in _TRANSLIT:
            if word.startswith(lat, i):
                out += cyr
                i += len(lat)
                break
        else:
            out += word[i]
            i += 1
    return out


def _has_brand(ct, word):
    """Латинский бренд/модель есть в названии карточки: как есть или кириллицей (Bruder = Брудер)."""
    if word in ct:
        return True
    tr = _translit(word)
    return len(tr) >= 4 and tr[:4] in ct.replace("и", "и")


_UNIT_RE = re.compile(r"(\d+)\s*(шт|штук|мл|л|г|кг|см|мм)(?![а-яa-z])")


def _unit_values(text):
    out = {}
    for n, u in _UNIT_RE.findall(str(text or "").lower()):
        out.setdefault("шт" if u == "штук" else u, set()).add(int(n))
    return out


def _strict_title_match(target_title, card_title, distinct=()):
    """Точное совпадение: бренд/модель (латиница, в т.ч. кириллицей), имена с заглавной буквы (персонаж, бренд),
    слова в кавычках, одинаковые количество/объём; остальное — большинство значимых слов."""
    tw = _match_tokens(target_title)
    ct = " ".join(_match_tokens(card_title))
    latin = [w for w in tw if re.search(r"[a-z]", w) and len(w) >= 3 and w not in ("for", "the", "and")]
    if latin and not all(_has_brand(ct, w) for w in latin):
        return False
    # имена и бренды кириллицей: слова с заглавной буквы не в начале названия («Баки», «Лева», КАМАЗ, «Автоград»)
    caps = re.findall(r"(?<!^)(?<![.!?] )\b([А-ЯЁ][а-яё]{2,}|[А-ЯЁ]{3,})\b", str(target_title or ""))
    names = []
    for w in caps:
        w = w.lower().replace("ё", "е")
        if w not in _MATCH_STOP:
            names.append(w[:5])
    if any(n not in ct for n in dict.fromkeys(names)):
        return False
    tu, cu = _unit_values(target_title), _unit_values(card_title)
    if any(u in cu and not (tu[u] & cu[u]) for u in tu):           # «2 шт» против «3 шт», «500 мл» против «250 мл»
        return False
    stems = list(dict.fromkeys(w[:5] for w in tw if re.fullmatch(r"[а-я]+", w) and len(w) > 3 and w not in _MATCH_STOP))
    if not stems:
        return bool(latin)
    if any(st not in ct for st in distinct):
        return False
    hits = [st for st in stems if st in ct]
    if latin:                                                       # бренд совпал: достаточно двух общих слов
        return len(hits) >= min(2, len(stems))
    need = max(2, -(-len(stems) * 6 // 10)) if len(stems) > 1 else 1
    return stems[0] in ct and len(hits) >= need


def _kaspi_card_url(card):
    link = str(card.get("shopLink") or "")
    if link.startswith("/"):
        link = "https://kaspi.kz" + link
    link = link.replace("https://kaspi.kz/p/", "https://kaspi.kz/shop/p/", 1)   # адрес вида /p/… даёт «страница не найдена», рабочий — /shop/p/…
    return link if link.startswith("https://kaspi.kz/") else ""


def _confidence(card, is_exact, photo_ids, target_title):
    """Уверенность в совпадении, %: фото — самый сильный признак, затем строгое название + бренд, затем общие слова."""
    if id(card) in photo_ids:
        return 97 if is_exact else 90
    if is_exact:
        brand = str(card.get("brand") or "").lower()
        bonus = 6 if brand and any(_has_brand(brand, w) for w in _match_tokens(target_title) if re.search(r"[a-z]", w)) else 0
        return 76 + bonus
    stems = [w[:5] for w in _match_tokens(target_title) if re.fullmatch(r"[а-я]+", w) and len(w) > 3 and w not in _MATCH_STOP]
    ct = " ".join(_match_tokens(card.get("title", "")))
    return min(55, 15 + int(40 * (sum(1 for st in stems if st in ct) / max(1, len(stems)))))


# единицы измерения → (группа, множитель к базовой единице группы): так «500 мл» и «0,5 л» считаются одним и тем же
_UNITS = {"мл": ("vol", 1), "л": ("vol", 1000), "г": ("mass", 1), "кг": ("mass", 1000), "мм": ("len", 1), "см": ("len", 10), "м": ("len", 1000),
          "вт": ("pow", 1), "квт": ("pow", 1000), "мач": ("cap", 1), "mah": ("cap", 1), "ач": ("cap", 1000), "мб": ("mem", 1), "mb": ("mem", 1),
          "гб": ("mem", 1024), "gb": ("mem", 1024), "тб": ("mem", 1048576), "tb": ("mem", 1048576), "дюйм": ("inch", 1), "дюймов": ("inch", 1)}
_QTY_RE = re.compile(r"(\d+(?:[.,]\d+)?)\s*(мл|квт|вт|кг|мм|см|мач|mah|ач|мб|mb|гб|gb|тб|tb|дюймов|дюйм|л|г|м)(?![а-яa-z])", re.I)


def _quantities(text):
    """Все величины с единицами из текста: {группа: {значения в базовой единице}}. «0,5 л» и «500 мл» дадут одно значение."""
    out = {}
    for num, unit in _QTY_RE.findall(str(text or "").lower()):
        grp, mul = _UNITS[unit.lower()]
        try:
            out.setdefault(grp, set()).add(round(float(num.replace(",", ".")) * mul, 3))
        except ValueError:
            pass
    return out


def _specs_bonus(card, target_title):
    """Сверка характеристик карточки Kaspi с названием товара WB.
    Возвращает (прибавка к уверенности, названия совпавших характеристик, список расхождений).
    Расхождение: у характеристики и в названии есть величина одного типа (объём, мощность, память), но значения разные."""
    try:
        specs = fetch_card_specs(card.get("id"))
    except Exception:
        return 0, [], []
    if not specs:
        return 0, [], []
    title_tokens = set(_match_tokens(target_title))
    title_q = _quantities(target_title)
    hit, conflicts = [], []
    for name, val in specs.items():
        toks = [t for t in _match_tokens(val) if len(t) >= 2]
        if toks and len(val) <= 30 and all(t in title_tokens for t in toks):
            hit.append(name)
        vq = _quantities(val) if len(val) <= 40 else {}
        for grp, vals in vq.items():
            tv = title_q.get(grp)
            if tv and not (vals & tv):
                conflicts.append("%s: у Kaspi %s, в названии WB %s" % (
                    name, val.strip(), ", ".join(sorted(m.group(0) for m in _QTY_RE.finditer(str(target_title).lower()) if _UNITS[m.group(2).lower()][0] == grp))))
                break
    return min(8, 3 * len(hit)), hit[:3], conflicts[:3]


def _cards_out(exact, similar, photo_ids=frozenset(), target_title=""):
    from core import ratelimit as _rl
    out = []
    spec_calls = 0
    for c, is_exact in [(c, True) for c in exact[:3]] + [(c, False) for c in similar[:4]]:
        if len(out) >= 5:
            break
        pi = (c.get("previewImages") or [{}])[0] or {}
        score = _confidence(c, is_exact, photo_ids, target_title)
        why, conflicts = [], []
        # характеристики только у «не по фото» точных совпадений, максимум 2 запроса на товар и не в режиме сканера
        if is_exact and id(c) not in photo_ids and spec_calls < 2 and not _rl.is_enforced():
            spec_calls += 1
            bonus, why, conflicts = _specs_bonus(c, target_title)
            score = min(89, score + bonus)
            if conflicts:
                score = max(30, score - 15 * len(conflicts))      # величины не сходятся: вероятно другая модификация товара
        out.append({"title": str(c.get("title") or "")[:90], "price": c.get("unitPrice") or 0,
                    "url": _kaspi_card_url(c), "exact": is_exact, "brand": str(c.get("brand") or "")[:40],
                    "img": str(pi.get("small") or pi.get("medium") or ""),
                    "score": score, "specs_match": why, "specs_conflict": conflicts})
    return out


def check_kaspi_vacuum(target_title: str, search_query: str = "", img_urls=None) -> dict:
    """
    Real-time Kaspi Search Analyzer:
    Detects whether a product is in a true vacuum (0 exact offers),
    has low competition, or is saturated.
    Identifies when Kaspi returns irrelevant fallback cards ('лажу')
    because the product doesn't exist on Kaspi at all.
    """
    import urllib.request
    import urllib.parse
    import ssl

    clean_q = search_query.strip() if search_query else ""
    if not clean_q:
        words = [w for w in re.sub(r'[^\w\s]', ' ', target_title).split() if len(w) > 3][:3]
        clean_q = " ".join(words)

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://kaspi.kz/shop/search/'
    }
    _city = str(_config_value("kaspi_city", "750000000"))
    headers.update(_city_headers(_city))

    def _page_url(q, page):
        return (f'https://kaspi.kz/yml/product-view/pl/results?page={page}&q={urllib.parse.quote(q)}'
                f'&text={urllib.parse.quote(q)}&c={_city}')

    from core import ratelimit as _rl
    _rl_on = _rl.is_enforced()                      # режим сканера (паузы) нужно передать в рабочие потоки

    def _fetch_page(q, page, timeout=6):
        _rl.hit('kaspi.kz', on=_rl_on)
        with _urlopen(urllib.request.Request(_page_url(q, page), headers=headers), timeout) as r:
            return json.loads(r.read().decode('utf-8')).get('data') or []

    try:
        cards = _fetch_page(clean_q, 0)
    except Exception as e:
        return {
            "vacuum_status": "unknown",
            "is_vacuum": None,
            "badge": "⚠️ Kaspi проверка: тайм-аут",
            "search_query": clean_q,
            "explanation": f"Kaspi временно ограничил автоматический запрос ({e}). Проверьте через поиск по фото (Lens) или наведите камеру в приложении."
        }

    # Несколько формулировок запроса (название целиком, бренд+модель, ключевые слова) и 2 страницы каждой:
    # так карточка находится, даже если Kaspi называет товар по-другому.
    words = _match_tokens(target_title)
    latin = [w for w in words if re.search(r"[a-z]", w) and len(w) >= 3]
    cyr = [w for w in words if re.fullmatch(r"[а-я]+", w) and len(w) > 3 and w not in _MATCH_STOP]
    variants = []
    for q in (clean_q, " ".join(words[:8]), " ".join(latin[:2] + cyr[:2]), " ".join(cyr[:3])):
        q = q.strip()
        if q and q.lower() not in [v.lower() for v in variants]:
            variants.append(q)
    jobs = [(q, pg) for q in variants[:4] for pg in (0, 1) if not (q == clean_q and pg == 0)]

    def _safe(job):
        try:
            return _fetch_page(job[0], job[1], 5)
        except Exception:
            return []
    try:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=6) as ex:
            extra = list(ex.map(_safe, jobs))
    except Exception:
        extra = []
    seen = set()
    merged = []
    for chunk in [cards] + extra:
        for c in chunk:
            key = str(c.get('id') or c.get('shopLink') or c.get('title'))
            if key not in seen:
                seen.add(key)
                merged.append(c)
    cards = merged

    if not cards:
        return {
            "vacuum_status": "vacuum_full",
            "is_vacuum": True,
            "badge": "🟢 100% ВАКУУМ (0 товаров на Kaspi)",
            "exact_matches": 0,
            "search_query": clean_q,
            "explanation": "На Kaspi.kz нет ни одного товара по данному запросу! Ниша абсолютно свободна."
        }

    # Сравнение по фото: картинка товара с WB против картинок карточек Kaspi из выдачи (до 24 штук)
    photo_matches, photo_checked = [], False
    img_urls = [u for u in (img_urls or []) if isinstance(u, str) and u.startswith("http")][:3]
    if img_urls:
        try:
            from core import imghash
            wb_h = [h for h in imghash.hash_urls(img_urls) if h is not None]
            if wb_h:
                pool = cards[:60]
                urls = []
                for c in pool:
                    pi = (c.get('previewImages') or [{}])[0]
                    urls.append(pi.get('medium') or pi.get('small') or "")
                kh = imghash.hash_urls(urls)
                photo_checked = any(h is not None for h in kh)
                for c, h in zip(pool, kh):
                    d = imghash.same_photo(h, wb_h)
                    if d is not None and d <= imghash.SAME_MAX_DIST:
                        photo_matches.append(c)
        except Exception as e:
            print("photo compare error:", e)

    # Точная карточка: то же фото ИЛИ строгое совпадение названия (бренд/модель + основные слова).
    # Остальные похожие по словам карточки показываем отдельно как «похожие», в точные они не попадают.
    target_words = [w.lower().strip(".,:;!-_()[]\"'") for w in target_title.split() if len(w) > 3]
    exact_matches, similar_loose = [], []
    _titles = [" ".join(_match_tokens(c.get('title', ''))) for c in cards[:60]]
    _tstems = list(dict.fromkeys(w[:5] for w in _match_tokens(target_title)
                                 if re.fullmatch(r"[а-я]+", w) and len(w) > 3 and w not in _MATCH_STOP))
    # слово, которое есть лишь у части карточек выдачи, отличает наш товар от соседних (например «транспорт» среди «мемо»)
    distinct = set()                                  # обязательные слова: только в кавычках (см. ниже)
    for qt in re.findall(r'"([^"]+)"|«([^»]+)»', target_title):       # слово в кавычках — название варианта, оно обязательно
        for w in _match_tokens(" ".join(qt)):
            if re.fullmatch(r"[а-я]+", w) and len(w) > 3 and w not in _MATCH_STOP:
                distinct.add(w[:5])
    q_stems = [w.lower()[:5] for w in re.sub(r'[^\w\s]', ' ', clean_q).split() if len(w) > 3]
    for c in cards[:60]:
        c_title = c.get('title', '').lower()
        if _strict_title_match(target_title, (c.get('title', '') + ' ' + str(c.get('brand') or '')), distinct):
            exact_matches.append(c)
            continue
        matched = [w for w in target_words if w in c_title]
        q_hits = [st for st in q_stems if st in c_title]
        noun_ok = bool(q_stems) and q_stems[0] in c_title and (len(q_stems) < 3 or len(q_hits) >= 2)
        if len(matched) >= 2 or noun_ok:
            similar_loose.append(c)

    title_ids = {id(c) for c in exact_matches}
    photo_only = [c for c in photo_matches if id(c) not in title_ids]
    exact_matches = photo_matches + [c for c in exact_matches if id(c) not in {id(x) for x in photo_matches}]
    similar_loose = [c for c in similar_loose if id(c) not in {id(x) for x in exact_matches}]
    photo_n = len(photo_matches)

    if len(exact_matches) == 0:
        first_c = cards[0]
        rep_title = first_c.get('title', 'Неизвестный товар')
        rep_price = first_c.get('unitPrice', 0)
        return {
            "vacuum_status": "vacuum_full",
            "is_vacuum": True,
            "badge": "🟢 Похожих карточек не найдено",
            "exact_matches": 0,
            "photo_matches": 0, "photo_checked": photo_checked,
            "sellers": 0,
            "search_query": clean_q,
            "similar_count": len(similar_loose), "cards": _cards_out([], similar_loose or cards[:3], frozenset(), target_title),
            "replacement_title": rep_title,
            "replacement_price": rep_price,
            "explanation": f"Kaspi подставил другие товары: «{rep_title[:40]}...» за {rep_price:,} ₸. Похоже, такого товара там нет. " + ("Фото товара сравнили с картинками " + str(min(len(cards), 24)) + " карточек Kaspi из выдачи: такой же картинки нет. Если товар продают под другим названием, поиск выдачи его мог не показать: можно сверить через «По фото»." if photo_checked else "Фото не сравнивали (картинка товара не загрузилась): сверьте через «По фото», карточки с другим названием и той же картинкой поиск по словам не видит.")
        }

    # Сколько РЕАЛЬНЫХ продавцов у найденных карточек (до 4 карточек; остальные считаем минимум по одному)
    sellers, checked = 0, 0
    for c in exact_matches[:4]:
        m = re.search(r"-(\d{5,})/", str(c.get('shopLink') or ""))
        if not m:
            continue
        try:
            r = fetch_competitor_prices(m.group(1), max_age_sec=1800, min_gap_sec=0.3)
        except Exception:
            r = {}
        if r.get("ok"):
            sellers += len(r.get("offers", []))
            checked += 1
    extra = max(0, len(exact_matches) - 4)
    sellers += extra
    approx = (checked < min(4, len(exact_matches))) or extra > 0
    n = len(exact_matches)
    top = min(exact_matches, key=lambda x: x.get('unitPrice') or 10 ** 9)
    price = top.get('unitPrice') or 0
    plus = "+" if approx else ""
    def _pl(k, one, few, many):
        return one if k % 10 == 1 and k % 100 != 11 else (few if 2 <= k % 10 <= 4 and not 12 <= k % 100 <= 14 else many)
    cards_txt = f"{n} " + _pl(n, "похожая карточка", "похожие карточки", "похожих карточек")
    photo_txt = ""
    if photo_n:
        photo_txt = f" Такое же фото у {photo_n} " + _pl(photo_n, "карточки", "карточек", "карточек") + (f", из них {len(photo_only)} под другим названием" if photo_only else "") + "."
    elif photo_checked:
        photo_txt = " Совпадений по фото нет."
    # Спрос: публичных продаж Kaspi не отдаёт, поэтому считаем отзывы точных карточек и их темп в месяц (чем больше, тем лучше берут)
    from datetime import datetime

    def _rev_per_month(c):
        try:
            created = datetime.fromisoformat(str(c.get("createdTime") or "")[:19])
            months = max(1.0, (datetime.now() - created).days / 30.0)
        except Exception:
            months = 12.0
        return (c.get("reviewsQuantity") or 0) / months
    reviews_total = sum(int(c.get("reviewsQuantity") or 0) for c in exact_matches[:6])
    rpm = round(sum(_rev_per_month(c) for c in exact_matches[:6]), 1)
    common = {"reviews_total": reviews_total, "reviews_per_month": rpm,
              "exact_matches": n, "sellers": sellers, "search_query": clean_q, "photo_matches": photo_n, "photo_checked": photo_checked,
              "photo_titles": [(c.get('title') or "")[:70] for c in photo_matches[:3]],
              "competitor_title": top.get('title'), "competitor_price": price,
              "competitor_url": _kaspi_card_url(top), "similar_count": len(similar_loose),
              "cards": _cards_out(exact_matches, similar_loose, {id(c) for c in photo_matches}, target_title)}
    if n <= 2 and sellers <= 3:
        return dict(common, vacuum_status="vacuum_low_competition", is_vacuum=True,
                    badge=f"🟡 Слабая конкуренция ({cards_txt}, продавцов: {sellers}{plus})",
                    explanation=f"На Kaspi {cards_txt}, у них продавцов: {sellers}{plus}. Самая низкая цена {price:,} ₸.{photo_txt}")
    return dict(common, vacuum_status="saturated", is_vacuum=False,
                badge=f"🔴 Конкурентная ниша ({cards_txt}, продавцов: {sellers}{plus})",
                explanation=f"На Kaspi уже есть {cards_txt}, у них продавцов: {sellers}{plus} (цена от {price:,} ₸).{photo_txt} Лучше искать другой товар или заходить с отличием.")


