"""Что убирать из клиентского релиза, пока раздел «Аналитика» в него не входит (для KWB_WITH_MARKET=1 не применяется)."""
import re

# модули данных рынка и источника, интерфейс аналитики
FILES = {"market_cats.py", "market_analytics.py", "market_docs.py", "redstat.py", "import_market.py",
         "index_market_docs.py", "redstat_pull.py", "analytics.js", "analytics.css", "analytics-guide.md"}


def strip_index(html):
    """index.html без кнопки меню, вкладки и подключений аналитики. Ошибка, если разметка не та, что ожидается."""
    n = html.replace("\r\n", "\n")
    out, c1 = re.subn(r'\n[^\n]*<link rel="stylesheet" href="analytics\.css[^\n]*', "", n)
    out, c2 = re.subn(r'\n[^\n]*<script src="analytics\.js[^\n]*', "", out)
    out, c3 = re.subn(r'\n[^\n]*data-tab="tab-analytics"[^\n]*', "", out)
    out, c4 = re.subn(r'\n      <section class="tab-pane" id="tab-analytics">.*?\n      </section>', "", out, flags=re.S)
    if (c1, c2, c3, c4) != (1, 1, 1, 1) or "tab-analytics" in out or "analytics.js" in out or "catCard" in out:
        raise SystemExit("index.html: не удалось убрать аналитику, проверьте разметку (счётчики %s)" % ((c1, c2, c3, c4),))
    return out.replace("\n", "\r\n") if "\r\n" in html else out
