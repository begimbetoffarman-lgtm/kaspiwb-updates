// Выбор любой категории Wildberries (дерево из публичного меню WB, ~3 100 категорий) для поиска товаров.
(function () {
  const $ = id => document.getElementById(id);
  if (!$('catBrowser')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let tree = null, flat = [], path = [];          // path: выбранные узлы сверху вниз
  const GENERIC = new Set(['прочее', 'другое', 'аксессуары', 'комплектующие', 'для дома', 'для женщин', 'для мужчин', 'для детей', 'товары', 'товары для']);

  async function load() {
    if (tree) return;
    try { tree = await (await fetch('/wb_categories.json')).json(); } catch (e) { tree = []; }
    const seen = new Set();
    const walk = (nodes, trail) => nodes.forEach(n => { const p = trail.concat(n); const key = p.map(x => x.n).join('>'); if (!seen.has(key)) { seen.add(key); flat.push({ n: n.n, path: p, leaf: !n.c }); } if (n.c) walk(n.c, p); });
    walk(tree, []);
    render();
  }
  function levelOptions(nodes, sel) {
    return '<option value="">' + (sel === 0 ? 'Выберите раздел' : 'Все в разделе') + '</option>' + nodes.map((n, i) => `<option value="${i}">${esc(n.n)}</option>`).join('');
  }
  function render() {
    const box = $('catSelects'); box.innerHTML = '';
    let nodes = tree;
    for (let lvl = 0; lvl <= path.length && nodes && nodes.length; lvl++) {
      const s = document.createElement('select'); s.style.minWidth = '200px'; s.dataset.lvl = lvl;
      const levelNodes = nodes;                       // свой список на каждый уровень (nodes дальше меняется)
      s.innerHTML = levelOptions(levelNodes, lvl);
      const cur = path[lvl];
      if (cur) s.value = String(levelNodes.indexOf(cur));
      s.onchange = () => {
        const i = s.value;
        path = path.slice(0, lvl);
        if (i !== '') path.push(levelNodes[+i]);
        render();
        const sel = path[path.length - 1];
        if (sel) {
          $('scanQuery').value = clean(queryFor(path));
          if (!sel.c || !sel.c.length) {
            go(path);
          }
        }
      };
      box.appendChild(s);
      nodes = cur ? cur.c : null;
    }
    const sel = path[path.length - 1];
    if ($('catGo')) $('catGo').disabled = !sel;
    $('catPath').textContent = sel ? 'Выбрана категория: ' + path.map(p => p.n).join(' → ') : '';
  }
  function queryFor(p) {
    const last = p[p.length - 1].n;
    if (p.length > 1 && (GENERIC.has(last.toLowerCase()) || last.length < 5 || /^для\s/i.test(last))) return p[p.length - 2].n + ' ' + last;
    return last;
  }
  const clean = s => s.replace(/\s*,\s*/g, ' ').replace(/\s+/g, ' ').trim();
  function go(p) {
    $('scanQuery').value = clean(queryFor(p));
    document.querySelectorAll('.pill-btn').forEach(x => x.classList.remove('active'));
    $('btnStartScan').click();
  }
  if ($('catGo')) $('catGo').onclick = () => { if (path.length) go(path); };
  $('catBrowser').addEventListener('toggle', () => { if ($('catBrowser').open) load(); });
  $('catFind').addEventListener('input', async () => {
    await load();
    const q = $('catFind').value.trim().toLowerCase(), out = $('catFindList');
    if (q.length < 2) { out.innerHTML = ''; return; }
    const hits = flat.filter(f => f.n.toLowerCase().includes(q)).slice(0, 25);
    out.innerHTML = hits.length ? hits.map((f, i) => `<button type="button" class="pill-btn" data-i="${i}" style="margin:2px 4px 2px 0">${esc(f.path.map(p => p.n).join(' → '))}</button>`).join('') : '<span class="help-text">Ничего не найдено</span>';
    out.querySelectorAll('button').forEach(b => b.onclick = e => { e.stopPropagation(); const f = hits[+b.dataset.i]; path = f.path.slice(); render(); go(f.path); });
  });
})();
