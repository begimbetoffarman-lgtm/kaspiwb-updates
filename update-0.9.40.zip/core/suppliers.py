"""Read-only supplier search in the installed browser; no Kaspi operations."""
import datetime
import json
import math
import os
import re
import threading
import time
import urllib.parse
import uuid
import io

from core import wb_browser

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LOCK = threading.Lock()
_TABS = {}
_LAST_READ = 0.0
_PRODUCTS = {}
_CATALOG_LOCK = threading.Lock()
_CN = [('обув', '鞋子收纳盒'), ('органайзер', '收纳盒'), ('полка', '置物架'),
       ('кухн', '厨房'), ('держатель', '支架'), ('лампа', '台灯'), ('сумка', '包'), ('рюкзак', '双肩包')]


class SupplierError(RuntimeError):
    """Only deliberate, safe messages for the seller; no raw browser exceptions."""


class _SupplierWS(wb_browser._WS):
    """Bound total command time, including a stream of browser events."""
    def call(self, method, params=None, timeout=8):
        self._id += 1
        mid = self._id
        self._send(json.dumps({'id': mid, 'method': method, 'params': params or {}}))
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Supplier browser command timed out')
            self.sock.settimeout(remaining)
            msg = json.loads(self._recv())
            if msg.get('id') == mid:
                if 'error' in msg:
                    raise RuntimeError('Supplier browser command failed')
                return msg.get('result', {})

    def eval(self, expr, timeout=8):
        return super().eval(expr, timeout=timeout)


def source_name(source):
    if source not in ('1688', 'ozon'):
        raise ValueError('Выберите 1688 или Ozon.')
    return source


def product_url(source, value):
    source_name(source)
    try:
        u = urllib.parse.urlsplit(str(value).strip())
        hosts = ('detail.1688.com',) if source == '1688' else ('ozon.kz', 'www.ozon.kz', 'ozon.ru', 'www.ozon.ru')
        pattern = r'/offer/\d{5,20}\.html' if source == '1688' else r'/product/(?:[^/]*-)?\d{5,20}/?'
        if u.scheme not in ('https', 'http') or u.hostname not in hosts or u.username or u.password or u.port not in (None, 80, 443) or not re.fullmatch(pattern, u.path):
            raise ValueError()
    except (TypeError, ValueError):
        raise ValueError('Вставьте полную ссылку на товар выбранного сайта.') from None
    return ('https://detail.1688.com' if source == '1688' else 'https://ozon.kz') + u.path



# --- Автоматический переводчик для 1688 (Китайский <-> Русский) ---
_CN_CATEGORIES = {
    '女装': 'Женская одежда',
    '男装': 'Мужская одежда',
    '配饰': 'Аксессуары и украшения',
    '运动户外': 'Спорт и туризм',
    '办公文化': 'Канцтовары и офис',
    '美妆个护': 'Косметика и уход',
    '食品酒水': 'Продукты и напитки',
    '日用餐厨': 'Посуда и кухня',
    '家用电器': 'Бытовая техника',
    '家装灯饰': 'Освещение и интерьер',
    '汽车用品': 'Автотовары и аксессуары',
    '童装玩具': 'Детская одежда и игрушки',
    '鞋靴箱包': 'Обувь, сумки и чемоданы',
    '家纺家饰': 'Домашний текстиль и декор',
    '数码电脑': 'Электроника и компьютеры',
    '电工电气': 'Электрика и освещение',
    '机械五金': 'Инструменты и скобяные изделия',
    '母婴用品': 'Товары для мам и малышей',
    '宠物用品': 'Товары для животных (зоотовары)',
    '内衣家居': 'Нижнее белье и домашняя одежда',
    '百货日化': 'Хозтовары и бытовая химия',
    '包装印刷': 'Упаковка и полиграфия',
    '五金工具': 'Инструменты и крепеж',
    '安防劳保': 'Спецодежда и безопасность',
    '医疗健康': 'Медицина и здоровье',
    '工艺礼品': 'Подарки и сувениры',
    '个护家清': 'Уход за собой и уборка',
    '箱包皮具': 'Сумки и кожгалантерея',
    '钟表眼镜': 'Часы и оптика',
    '收纳整理': 'Органайзеры и хранение',
    '玩具': 'Игрушки',
    '童装': 'Детская одежда',
    '童鞋': 'Детская обувь',
    '女鞋': 'Женская обувь',
    '男鞋': 'Мужская обувь',
    '厨房用品': 'Товары для кухни',
    '卫浴用品': 'Товары для ванной',
    '清洁用品': 'Товары для уборки',
}

_RU_TO_ZH_DICT = {
    'игрушк': '玩具',
    'игрушка': '玩具',
    'кукл': '娃娃',
    'конструктор': '积木玩具',
    'машинк': '玩具车',
    'робот': '机器人玩具',
    'органайзер': '收纳盒',
    'коробк': '收纳箱',
    'полк': '置物架',
    'подставк': '支架',
    'держател': '支架',
    'чехол': '手机壳',
    'наушник': '蓝牙耳机',
    'зарядк': '充电器',
    'кабел': '数据线',
    'пылесос': '吸尘器',
    'автопылесос': '车载吸尘器',
    'чайник': '电热水壶',
    'термос': '保温杯',
    'бутылк': '水杯',
    'лампа': '台灯',
    'светильник': '小夜灯',
    'ночник': '小夜灯',
    'гирлянд': '彩灯串',
    'сумк': '女包',
    'рюкзак': '双肩包',
    'кошелек': '钱包',
    'часы': '手表',
    'смарт часы': '智能手表',
    'массажер': '按摩仪',
    'фен': '电吹风',
    'утюг': '电熨斗',
    'отпариватель': '挂烫机',
    'увлажнитель': '加湿器',
    'диффузор': '香薰机',
    'автотовар': '汽车用品',
    'видеорегистратор': '行车记录仪',
    'ароматизатор': '车载香薰',
    'держатель в авто': '车载支架',
    'кухн': '厨房用品',
    'нож': '菜刀',
    'сковород': '平底锅',
    'кастрюл': '汤锅',
    'посуд': '餐具',
    'коврик': '地垫',
    'плед': '毛毯',
    'подушк': '枕头',
    'одеял': '被子',
    'полотенц': '毛巾',
    'носк': '袜子',
    'футболк': 'T恤',
    'худи': '卫衣',
    'куртк': '外套',
    'обув': '鞋子',
    'кроссовк': '运动鞋',
    'косметик': '化妆品',
    'помад': '口红',
    'крем': '面霜',
    'маск': '面膜',
    'сыворотк': '精华液',
    'зоотовар': '宠物用品',
    'ошейник': '宠物项圈',
    'поводок': '宠物牵引绳',
    'лежанк': '宠物窝',
    'когтеточк': '猫抓板',
}

def translate_zh_to_ru(text):
    if not text:
        return ''
    s = str(text).strip()
    if s in _CN_CATEGORIES:
        return _CN_CATEGORIES[s]
    for cn, ru in _CN_CATEGORIES.items():
        if cn in s:
            return s.replace(cn, ru)
    # Онлайн-перевод для остальных подкатегорий
    if re.search(r'[一-鿿]', s):
        try:
            q = urllib.parse.quote(s)
            u = f'https://translate.googleapis.com/translate_a/single?client=gtx&sl=zh-CN&tl=ru&dt=t&q={q}'
            req = urllib.request.Request(u, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=3) as r:
                res = json.loads(r.read().decode('utf-8'))
                translated = ''.join([part[0] for part in res[0] if part and part[0]]).strip()
                if translated:
                    _CN_CATEGORIES[s] = translated
                    return translated
        except Exception:
            pass
    return s

def translate_ru_to_zh(text):
    if not text:
        return ''
    s = str(text).strip().lower()
    for ru, zh in _RU_TO_ZH_DICT.items():
        if ru in s:
            return zh
    # Онлайн переводчик для любых других запросов
    try:
        q = urllib.parse.quote(text)
        u = f'https://translate.googleapis.com/translate_a/single?client=gtx&sl=ru&tl=zh-CN&dt=t&q={q}'
        req = urllib.request.Request(u, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=4) as r:
            res = json.loads(r.read().decode('utf-8'))
            zh_trans = ''.join([part[0] for part in res[0] if part and part[0]]).strip()
            if zh_trans:
                return zh_trans
    except Exception:
        pass
    return text


def search_url(source, query):
    source_name(source)
    query = str(query or '').strip()
    if not query or len(query) > 200:
        raise ValueError('Введите запрос до 200 символов.')
    effective = query
    if source == '1688':
        if re.search('[а-яА-ЯёЁ]', query):
            effective = translate_ru_to_zh(query)
            if not effective:
                effective = query
        try:
            encoded = urllib.parse.quote(effective.encode('gbk'))
        except UnicodeEncodeError:
            encoded = urllib.parse.quote(effective)
        return 'https://s.1688.com/selloffer/offer_search.htm?keywords=' + encoded + '&n=y', effective
    return 'https://ozon.kz/search/?' + urllib.parse.urlencode({'text': effective}), effective


def category_url(source, value):
    source_name(source)
    try:
        u = urllib.parse.urlsplit(str(value).strip())
        if u.scheme != 'https' or u.username or u.password or u.port or u.fragment:
            raise ValueError()
        if source == '1688':
            query = urllib.parse.parse_qs(u.query)
            if len(query.get('keywords', [''])[0]) > 120 or not query.get('keywords', [''])[0]:
                raise ValueError()
            if u.hostname == 'air.1688.com' and u.path == '/kapp/1688-global/sales/search':
                return 'https://air.1688.com/kapp/1688-global/sales/search?' + urllib.parse.urlencode({'keywords':query['keywords'][0]})
            if u.hostname == 's.1688.com' and u.path == '/selloffer/offer_search.htm' and query.get('charset') == ['utf8']:
                return 'https://s.1688.com/selloffer/offer_search.htm?' + urllib.parse.urlencode({'charset':'utf8','keywords':query['keywords'][0]})
            raise ValueError()
        if u.hostname not in ('ozon.kz', 'www.ozon.kz') or not re.fullmatch(r'/category/[a-z0-9-]+-\d+/',u.path):
            raise ValueError()
        return 'https://ozon.kz' + u.path
    except (TypeError, ValueError):
        raise ValueError('Выберите категорию в списке площадки.') from None


def catalog(source):
    source_name(source)
    path = os.path.join(ROOT, 'data', 'supplier-search-' + source + '.json')
    with _CATALOG_LOCK:
        try:
            with open(path, encoding='utf-8') as f:
                result = json.load(f)
            if not isinstance(result, dict) or not isinstance(result.get('items'), list):
                raise ValueError()
        except (OSError, ValueError):
            result = {'items': [], 'query': ''}
    return dict(result, success=True, source=source, city=_city_settings()[0])


def _city_settings():
    from core import secrets
    cfg=secrets.read_config(os.path.join(ROOT,'config.json'))
    return str(cfg.get('wb_city_name') or cfg.get('kaspi_city_name') or '').strip(),cfg.get('preorder_buffer_days',3)


def _save_catalog(source, result):
    source_name(source)
    path = os.path.join(ROOT, 'data', 'supplier-search-' + source + '.json')
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with _CATALOG_LOCK:
        with open(path + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False)
        os.replace(path + '.tmp', path)


def _browser_read(source, mode, url, photo_path=None, category_target=None):
    """One page at a time. Keep a challenged tab open for the user to resolve."""
    global _LAST_READ
    if not _LOCK.acquire(blocking=False):
        raise SupplierError('Уже идёт загрузка товара. Дождитесь её завершения.')
    ws = None
    try:
        error = wb_browser._ensure_browser()
        if error:
            raise SupplierError('Не удалось открыть браузер. Установите Edge или Chrome и повторите.')
        pause = 3 - (time.monotonic() - _LAST_READ)
        if pause > 0:
            time.sleep(pause)
        port = wb_browser.PORT
        tabs = wb_browser._http_json(f'http://127.0.0.1:{port}/json/list')
        tab = next((t for t in tabs if t.get('id') == _TABS.get(source)), None)
        if tab is None:
            # Reuse the marketplace tab in this app's browser after app restart.
            hosts = {'www.1688.com','s.1688.com','detail.1688.com','air.1688.com'} if source == '1688' else {'ozon.kz','www.ozon.kz'}
            tab = next((t for t in tabs if t.get('type') == 'page' and urllib.parse.urlsplit(t.get('url','')).hostname in hosts), None)
        if tab is None:
            tab = wb_browser._http_json(f'http://127.0.0.1:{port}/json/new?' + urllib.parse.quote(url, safe=''), method='PUT')
        _TABS[source] = tab['id']
        ws = _SupplierWS(tab['webSocketDebuggerUrl'], timeout=8)
        ws.call('Page.enable')
        if tab.get('url') != url:
            ws.call('Page.navigate', {'url': url})
        if photo_path:
            ws.call('DOM.enable')
            for _ in range(15):
                time.sleep(1)
                try:
                    doc = ws.call('DOM.getDocument', {'depth': 0})
                    node = ws.call('DOM.querySelector', {'nodeId': doc['root']['nodeId'], 'selector': 'input.image-file-reader-wrapper'})
                    if node.get('nodeId'):
                        ws.call('DOM.setFileInputFiles', {'nodeId': node['nodeId'], 'files': [photo_path]})
                        ws.eval("""(() => {
                            const inp = document.querySelector('input.image-file-reader-wrapper, #img-search-upload');
                            if (inp) {
                                inp.dispatchEvent(new Event('change', { bubbles: true }));
                                inp.dispatchEvent(new Event('input', { bubbles: true }));
                            }
                        })()""")
                        break
                except RuntimeError:
                    # Redirects replace the document between DOM calls.
                    continue
            else:
                raise SupplierError('1688 не показал загрузку фото. Откройте фотопоиск на сайте, пройдите вход или проверку и повторите.')
            for _ in range(15):
                time.sleep(1)
                clicked = ws.eval("""(() => {
                    const ok = document.getElementById('croper-ok-btn') || document.querySelector('[class*="croperBtn"][class*="ok"]');
                    if (ok && ok.offsetParent !== null) {
                        ok.click();
                        return true;
                    }
                    const e = document.querySelector('[data-tracker="pasteImagePreview"]') || [...document.querySelectorAll('button,div,span,a')].find(e => ['Поиск изображений','图片搜索','搜索图片','Search for images','Search images','确定'].includes((e.textContent||'').trim()) && e.children.length < 2);
                    if (e && e.offsetParent !== null) {
                        e.click();
                        return true;
                    }
                    return false;
                })()""")
                if clicked:
                    time.sleep(1)
                    break
        with open(os.path.join(ROOT, 'core', 'supplier_page.js'), encoding='utf-8') as script_file:
            script = script_file.read()
        expr = script + '\nreadSupplierPage(' + json.dumps(source) + ',' + json.dumps(mode) + ')'
        deadline = time.monotonic() + 45
        started = time.monotonic()
        blocked_hits = 0
        while time.monotonic() < deadline:
            time.sleep(2)
            try:
                if photo_path and not ws.eval("location.hostname==='air.1688.com' && location.pathname.includes('pc-image-search') && (location.search.includes('imageSearch') || location.search.includes('imageId') || location.search.includes('imageAddress'))"):
                    continue
                if source == '1688' and mode == 'categories':
                    count = ws.eval("document.querySelectorAll('[class*=\"modal_category_link--\"]').length") or 0
                    if not count:
                        point = ws.eval("""(() => {const e=document.querySelector('[class*="lv1ItemLink--"]');if(!e)return null;const r=e.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()""")
                        if point:
                            ws.call('Input.dispatchMouseEvent', {'type':'mouseMoved','x':point['x'],'y':point['y']})
                            time.sleep(0.6)
                            continue
                    if category_target and count:
                        index = ws.eval("""(target => {const key=new URL(target).searchParams.get('keywords');return [...document.querySelectorAll('[class*="modal_category_link--"]')].findIndex(a => new URL(a.href).searchParams.get('keywords')===key);})(%s)""" % json.dumps(category_target))
                        if isinstance(index, int) and index >= 0:
                            point = ws.eval("""(index => {const e=document.querySelectorAll('[class*="modal_category_link--"]')[index];e.scrollIntoView({block:'nearest'});const r=e.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})(%d)""" % index)
                            ws.call('Input.dispatchMouseEvent', {'type':'mouseMoved','x':1,'y':1})
                            time.sleep(0.1)
                            ws.call('Input.dispatchMouseEvent', {'type':'mouseMoved','x':point['x'],'y':point['y']})
                            for _ in range(8):
                                time.sleep(0.5)
                                items = ws.eval("""(index => [...(document.querySelectorAll('[class*="modal_subcategory_section--"]')[index]?.querySelectorAll('a[class*="modal_subcategory_link--"]')||[])].map(a=>({name:(a.textContent||'').trim().slice(0,120),url:a.href||''})).filter(x=>x.name&&x.url))(%d)""" % index)
                                if items:
                                    _LAST_READ = time.monotonic()
                                    return {'items': items}
                result = ws.eval(expr, timeout=16)
            except (OSError, RuntimeError):
                continue
            if result and result.get('blocked'):
                blocked_hits += 1
                if blocked_hits >= 3:
                    raise SupplierError('1688 просит вход или проверку. Пройдите её в открытом окне и повторите.')
                continue
            if result and (result.get('items') if mode in ('search','categories') else result.get('variants')):
                if source=='ozon' and mode=='product' and not result.get('delivery_raw',{}).get('text') and time.monotonic()-started<20:
                    continue
                if photo_path:
                    result['photo_url'] = ws.eval('location.href')
                _LAST_READ = time.monotonic()
                return result
            if mode == 'categories' and time.monotonic()-started > 8 and result is not None:
                return {'items': []}
        if photo_path and ws.eval("location.hostname==='air.1688.com' && /空空|здесь пусто/.test(document.body.innerText)"):
            return {'items': [], 'photo_url': ws.eval('location.href')}
        raise SupplierError('Сайт пока не отдал товары. Посмотрите открытое окно браузера: если сайт просит вход или проверку, пройдите её сами и повторите загрузку. Разрешения браузера выбираете вы.')
    finally:
        _LAST_READ = time.monotonic()
        if ws:
            ws.close()
        _LOCK.release()


def alibaba_login_status():
    """Whether the seller is logged into 1688 in the app browser. Opens the browser if needed."""
    error = wb_browser._ensure_browser()
    if error:
        return {'success': True, 'logged_in': False, 'browser_ready': False, 'message': error}
    port = wb_browser.PORT
    try:
        tabs = wb_browser._http_json(f'http://127.0.0.1:{port}/json/list')
    except Exception:
        return {'success': True, 'logged_in': False, 'browser_ready': False, 'message': 'Браузер не отвечает. Закройте окна Edge/Chrome и повторите.'}
    host = {'s.1688.com', 'air.1688.com', 'www.1688.com', 'detail.1688.com', 'login.1688.com', 'login.taobao.com', 'work.1688.com'}
    tab = next((t for t in tabs if t.get('type') == 'page' and urllib.parse.urlsplit(t.get('url', '')).hostname in host), None)
    if tab is None:
        return {'success': True, 'logged_in': False, 'browser_ready': True, 'message': 'Вы ещё не входили в 1688 в этом браузере.'}
    try:
        ws = _SupplierWS(tab['webSocketDebuggerUrl'], timeout=8)
        try:
            page_state = ws.eval("""(() => {
                const text=(document.body&&document.body.innerText)||'';
                const links=[...document.querySelectorAll('a')];
                const logout=links.some(a=>/退出登录|安全退出|logout/i.test((a.textContent||'')+' '+(a.href||'')));
                const loginPrompt=/会员登录|请登录后|立即登录|登录名|手机号登录|扫码登录/.test(text);
                return {logout,loginPrompt,host:location.hostname};
            })()""") or {}
            cookie_reply = ws.call('Network.getCookies', {'urls': [
                'https://www.1688.com/', 'https://air.1688.com/',
                'https://s.1688.com/', 'https://detail.1688.com/'
            ]})
            cookie_names = {str(c.get('name') or '') for c in cookie_reply.get('cookies', [])}
            # These cookies carry an Alibaba member identity. Generic anti-bot cookies
            # (cna/isg/tfstk) deliberately do not count as a signed-in session.
            identity_cookies = {'unb', 'tracknick', 'lgc', '_nk_', 'cookie17', 'login', '_l_g_'}
            logged = bool(page_state.get('logout') or cookie_names.intersection(identity_cookies))
            if page_state.get('loginPrompt'):
                logged = False
        finally:
            ws.close()
        return {'success': True, 'logged_in': bool(logged), 'browser_ready': True,
                'message': 'Вход в 1688 выполнен.' if logged else 'Вход в 1688 не выполнен.'}
    except Exception:
        return {'success': True, 'logged_in': False, 'browser_ready': True, 'message': 'Не удалось проверить вход. Откройте окно 1688 и войдите.'}


def open_alibaba_login():
    """Opens the 1688 login page in the app browser for the seller to sign in (QR / phone)."""
    error = wb_browser._ensure_browser()
    if error:
        raise SupplierError(error)
    port = wb_browser.PORT
    url = 'https://login.1688.com/member/signin.htm'
    try:
        tabs = wb_browser._http_json(f'http://127.0.0.1:{port}/json/list')
        host = {'login.1688.com', 'login.taobao.com', 'work.1688.com'}
        tab = next((t for t in tabs if t.get('type') == 'page' and urllib.parse.urlsplit(t.get('url', '')).hostname in host), None)
        if tab is None:
            tab = wb_browser._http_json(f'http://127.0.0.1:{port}/json/new?' + urllib.parse.quote(url, safe=''), method='PUT')
        else:
            ws = _SupplierWS(tab['webSocketDebuggerUrl'], timeout=8)
            try:
                ws.call('Page.enable')
                ws.call('Page.navigate', {'url': url})
            finally:
                ws.close()
    except Exception:
        raise SupplierError('Не удалось открыть окно входа 1688. Закройте окна Edge/Chrome и повторите.') from None
    return {'success': True, 'message': 'Окно входа 1688 открыто. Войдите по QR-коду через приложение 1688 или по телефону, затем нажмите «Проверить вход».'}


def search(source, query):
    url, effective = search_url(source, query)
    result = _browser_read(source, 'search', url)
    # Validate links again on the server before returning scraped content.
    result['items'] = [dict(item, url=product_url(source, item['url'])) for item in result.get('items', [])[:20]]
    result.update(success=True, query=effective, search_url=url)
    _save_catalog(source, result)
    try:
        from core import found
        result['found'] = dict(zip(('added', 'updated', 'total'),
                                   found.add_many(source, result['items'], effective)))
    except Exception:
        pass                      # копилка не должна ломать сам поиск
    return result


def categories(source, parent_url=None):
    source_name(source)
    parent=category_url(source,parent_url) if parent_url else None
    url=('https://www.1688.com/' if source=='1688' else (parent or 'https://ozon.kz/'))
    result=_browser_read(source,'categories',url,category_target=parent if source=='1688' else None)
    def clean(item):
        raw_name = str(item.get('name') or '').strip()[:120]
        name = translate_zh_to_ru(raw_name) if source == '1688' else raw_name
        return {'name': name, 'url': category_url(source, item.get('url'))}
    items=[]
    for raw in result.get('items',[])[:100]:
        try:
            item=clean(raw)
            if source=='1688':
                item['children']=[]
                for child in raw.get('children',[])[:200]:
                    if not child.get('url'):continue
                    group=clean(child)
                    group['children']=[clean(leaf) for leaf in child.get('children',[])[:200] if leaf.get('url')]
                    item['children'].append(group)
            items.append(item)
        except (ValueError,TypeError,AttributeError):
            continue
    return {'success':True,'source':source,'items':items,'parent_url':parent_url or ''}


def search_category(source, value):
    url=category_url(source,value)
    result=_browser_read(source,'search',url)
    result['items']=[dict(item,url=product_url(source,item['url'])) for item in result.get('items',[])[:20]]
    result.update(success=True,query='категория',search_url=url)
    _save_catalog(source,result)
    try:
        from core import found
        result['found']=dict(zip(('added','updated','total'),
                                 found.add_many(source,result['items'],'категория')))
    except Exception:
        pass                      # копилка не должна ломать сам поиск
    return result


def read_product(source, url):
    url = product_url(source, url)
    result = _browser_read(source, 'product', url)
    result['url'] = product_url(source, result.get('url', ''))
    result['checked_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if source=='ozon':
        from core.supplier_delivery import delivery_info
        city,buffer=_city_settings()
        result['delivery']=delivery_info(result.pop('delivery_raw',{}),city,buffer)
        for variant in result.get('variants',[]):
            if str(variant.get('id'))==str(result.get('id')):
                variant['delivery']=dict(result['delivery'])
    if len(_PRODUCTS) >= 30:
        _PRODUCTS.pop(next(iter(_PRODUCTS)))
    _PRODUCTS[(source, result['url'])] = result
    return {'success': True, 'product': result}


def photo_search(data=None, uploaded=None):
    """Upload only a selected product image, never arbitrary local files or URLs."""
    if uploaded:
        content = uploaded.read(8_000_001)
    else:
        try:
            wb_id = int((data or {}).get('wb_id'))
        except (TypeError, ValueError):
            raise ValueError('Выберите фото товара WB или загрузите изображение.') from None
        with open(os.path.join(ROOT, 'data', 'catalog.json'), encoding='utf-8') as f:
            catalog = json.load(f)
        item = next((it for it in catalog if int(it.get('id') or 0) == wb_id), None)
        if not item:
            raise ValueError('Товар WB не найден в списке.')
        image_url = item.get('img_main') or item.get('img_url') or ''
        u = urllib.parse.urlsplit(image_url)
        allowed_host=re.fullmatch(r'(?:basket-\d+\.wbbasket\.ru|[a-z]{2,4}-basket-cdn-\d+\.geobasket\.net)',u.hostname or '')
        if u.scheme != 'https' or not allowed_host or u.username or u.password or u.port not in (None, 443):
            raise ValueError('Не удалось скачать исходное фото WB. Сохраните фото и загрузите его через раздел 1688.')
        import requests
        with requests.get(image_url, timeout=20, stream=True, allow_redirects=False) as r:
            if r.status_code != 200:
                raise ValueError('WB не отдал фото. Сохраните и загрузите его вручную.')
            content = r.raw.read(8_000_001)
    if not content or len(content) > 8_000_000:
        raise ValueError('Выберите изображение размером до 8 МБ.')
    from PIL import Image, ImageFile
    ImageFile.LOAD_TRUNCATED_IMAGES = True
    try:
        im = Image.open(io.BytesIO(content))
        if im.width * im.height > 40_000_000:
            raise ValueError()
        im.load()
        if im.mode in ('RGBA', 'LA', 'P'):
            im = im.convert('RGBA')
            backdrop = Image.new('RGB', im.size, (255, 255, 255))
            backdrop.paste(im, mask=im.split()[-1])
            im = backdrop
        elif im.mode != 'RGB':
            im = im.convert('RGB')
    except Exception:
        raise ValueError('Не удалось прочитать фото. Выберите JPG, PNG или WebP до 40 мегапикселей.') from None
    folder = os.path.join(ROOT, 'data', 'supplier-search')
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, uuid.uuid4().hex + '.jpg')
    try:
        im.thumbnail((2400, 2400))
        im.save(path, 'JPEG', quality=92)
        url = 'https://air.1688.com/kapp/1688-search/pc-image-search/'
        result = _browser_read('1688', 'search', url, photo_path=path)
        photo_url = result.get('photo_url') or ''
        if not photo_url.startswith('https://air.1688.com/kapp/1688-search/pc-image-search/'):
            photo_url = 'https://s.1688.com/'
        result.update(success=True, query='по фотографии', search_url=photo_url, needs_login=True)
        return result
    finally:
        if os.path.exists(path):
            os.remove(path)


def estimate(data):
    """Manual estimate per unit; do not guess tariffs or missing package sizes."""
    source = source_name(data.get('source'))
    def n(key, positive=False):
        try:
            raw = data.get(key)
            if raw is None or raw == '' or isinstance(raw, bool):
                raise ValueError()
            value = float(raw)
            if not math.isfinite(value) or value < 0 or (positive and value <= 0):
                raise ValueError()
            return value
        except (TypeError, ValueError):
            raise ValueError('Заполните корректно все поля расчёта; неизвестные значения нельзя считать нулём.') from None
    purchase = n('price', True) * (n('cny_rate', True) if source == '1688' else 1)
    volume = None
    if source == '1688':
        volume = n('length_cm', True) * n('width_cm', True) * n('height_cm', True) / 1_000_000
        freight = max(n('weight_kg', True) * n('per_kg', True), volume * n('per_m3', True))
    else:
        freight = n('freight')
    total = purchase + freight + n('other_costs')
    fees = n('fees_pct') / 100
    if fees >= 1:
        raise ValueError('Сумма комиссии и налогов должна быть меньше 100%.')
    sale = n('sale_price', True)
    profit = sale * (1 - fees) - total
    return {'success': True, 'purchase_kzt': round(purchase, 2), 'freight_kzt': round(freight, 2),
            'volume_m3': volume, 'cost_kzt': round(total, 2), 'profit_kzt': round(profit, 2),
            'break_even_kzt': math.ceil(total / (1 - fees))}


def register(app):
    from flask import jsonify, request
    def catalog_api(source):
        try:
            return jsonify(catalog(source))
        except ValueError as error:
            return jsonify(success=False, error=str(error)), 400
    app.add_url_rule('/api/suppliers/catalog/<source>', 'suppliers_catalog', catalog_api, methods=['GET'])
    def categories_api(source):
        try:return jsonify(categories(source,request.args.get('parent_url') or None))
        except ValueError as error:return jsonify(success=False,error=str(error)),400
        except SupplierError as error:return jsonify(success=False,error=str(error)),503
        except Exception:return jsonify(success=False,error='Не удалось загрузить категории площадки. Повторите позже.'),503
    app.add_url_rule('/api/suppliers/categories/<source>','suppliers_categories',categories_api,methods=['GET'])
    def api(action):
        if action == 'photo' and request.content_length and request.content_length > 8_100_000:
            return jsonify(success=False, error='Фото должно быть не больше 8 МБ.'), 413
        uploaded = request.files.get('image') if action == 'photo' else None
        data = {} if uploaded else request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(success=False, error='Ожидается запрос с данными.'), 400
        try:
            if action == 'photo':
                result = photo_search(data, uploaded)
            elif action == 'search':
                result = search_category(data.get('source'),data['category_url']) if data.get('category_url') else search(data.get('source'), data.get('query'))
            elif action == 'product':
                result = read_product(data.get('source'), data.get('url'))
            elif action == 'drafts':
                source = source_name(data.get('source'))
                url = product_url(source, data.get('url'))
                product = _PRODUCTS.get((source, url))
                if product is None:
                    raise ValueError('Загрузите товар перед созданием черновиков.')
                from core.supplier_drafts import make
                if source=='ozon' and product.get('delivery',{}).get('expected_city')!=_city_settings()[0]:
                    raise ValueError('Город изменён. Повторно загрузите товар Ozon для нового города.')
                result = make(product, data.get('preorder_days'), data.get('variant_ids'))
            else:
                result = estimate(data)
            return jsonify(result)
        except ValueError as error:
            return jsonify(success=False, error=str(error)), 400
        except SupplierError as error:
            return jsonify(success=False, error=str(error)), 503
        except Exception:
            # No raw exceptions: third-party URLs or browser state may contain private data.
            return jsonify(success=False, error='Не удалось загрузить данные. Проверьте окно браузера, пройдите проверку сайта или вход и повторите. Если другая загрузка ещё идёт, дождитесь её завершения.'), 503
    app.add_url_rule('/api/suppliers/1688_login_status', 'suppliers_1688_login_status',
                     lambda: jsonify(alibaba_login_status()), methods=['GET'])
    def _open_1688():
        try:
            return jsonify(open_alibaba_login())
        except SupplierError as error:
            return jsonify(success=False, error=str(error)), 503
    app.add_url_rule('/api/suppliers/1688_open_login', 'suppliers_1688_open_login', _open_1688, methods=['POST'])
    for action in ('search', 'product', 'estimate', 'drafts', 'photo'):
        app.add_url_rule('/api/suppliers/' + action, 'suppliers_' + action,
                         lambda action=action: api(action), methods=['POST'])
