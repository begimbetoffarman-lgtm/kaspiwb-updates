"""Отчёт владельцу программы об активации и ежедневном использовании: имя из ключа, номер ПК, версия, дата.
Адрес отчётов задаёт владелец (core/endpoints.py REPORT_URL, например веб-приложение Google Apps Script → таблица).
Никаких данных магазина, заказов, покупателей, паролей и токенов не отправляется. Об этом сказано в инструкции и оферте."""
import json
import os
import threading
import time
import urllib.request

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _url():
    try:
        c = json.load(open(os.path.join(BASE, "config.json"), encoding="utf-8"))
    except Exception:
        c = {}
    try:
        from core import endpoints
        d = endpoints.REPORT_URL
    except Exception:
        d = ""
    return (c.get("report_url") or d or "").strip()


def report(event):
    """Отправка в фоне; любая ошибка молча игнорируется (программа от неё не зависит)."""
    url = _url()
    if not url:
        return

    def go():
        try:
            from core import license as lic, updater
            st = lic.init_or_load_license()
            name = ""
            try:
                import base64
                d = json.load(open(os.path.join(BASE, "data", ".license.json"), encoding="utf-8"))
                k = d.get("license_key") or ""
                if k.startswith("KWB1."):
                    name = json.loads(lic._unb64(k.split(".")[1]).decode("utf-8")).get("n", "")
            except Exception:
                pass
            body = json.dumps({"event": event, "name": name, "machine": st.get("machine_id"), "status": st.get("status"),
                               "version": updater.current_version(), "failed": ((__import__("core.selfcheck", fromlist=["x"]).last() or {}).get("failed") or []), "ts": time.strftime("%Y-%m-%d %H:%M:%S")}).encode()
            urllib.request.urlopen(urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}),
                                   timeout=15).read()
        except Exception:
            pass
    threading.Thread(target=go, daemon=True).start()
