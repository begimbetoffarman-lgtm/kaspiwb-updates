(() => {
  'use strict';
  const esc=value=>escHtml(value),attr=value=>escAttr(value);
  const photo=value=>{try{const u=new URL(value);return /^https?:$/.test(u.protocol)?u.href:'';}catch{return '';}};
  let cnyRate=0;fetch('/api/margin/cny').then(r=>r.json()).then(j=>{const v=Number(j&&j.rate);if(v>0)cnyRate=v;}).catch(()=>{});
  const money=(value,currency)=>value==null?'не получена':Number(value).toLocaleString('ru-RU',{maximumFractionDigits:2})+(currency==='CNY'?' ¥'+(cnyRate>0&&Number(value)>0?' (≈ '+Math.round(Number(value)*cnyRate).toLocaleString('ru-RU')+' ₸)':''):' ₸');
  let networkOwner=null;
  async function api(action,data) {
    const form=data instanceof FormData;
    const response=await fetch('/api/suppliers/'+action,{method:'POST',headers:form?undefined:{'Content-Type':'application/json'},body:form?data:JSON.stringify(data)});
    const result=await response.json();
    if(!response.ok||!result.success)throw new Error(result.error||'Сайт пока не отдал данные.');
    return result;
  }
  const controllers={};
  function cropPicker(src){
    const wrap=document.createElement('div');wrap.style.cssText='position:relative;display:inline-block;touch-action:none;cursor:crosshair;user-select:none;line-height:0';
    const img=new Image();img.referrerPolicy='no-referrer';img.draggable=false;img.src=src;img.style.cssText='display:block;max-width:300px;max-height:300px;border-radius:8px';
    const box=document.createElement('div');box.style.cssText='position:absolute;border:2px solid #ff4d00;background:rgba(255,77,0,.18);display:none;pointer-events:none';
    wrap.append(img,box);let crop=null,start=null;
    const pt=e=>{const r=wrap.getBoundingClientRect();return {x:Math.min(1,Math.max(0,(e.clientX-r.left)/r.width)),y:Math.min(1,Math.max(0,(e.clientY-r.top)/r.height))};};
    const draw=()=>{if(!crop){box.style.display='none';return;}box.style.display='block';box.style.left=crop.x*100+'%';box.style.top=crop.y*100+'%';box.style.width=crop.w*100+'%';box.style.height=crop.h*100+'%';};
    wrap.addEventListener('pointerdown',e=>{start=pt(e);crop=null;draw();wrap.setPointerCapture(e.pointerId);});
    wrap.addEventListener('pointermove',e=>{if(!start)return;const p=pt(e);crop={x:Math.min(start.x,p.x),y:Math.min(start.y,p.y),w:Math.abs(p.x-start.x),h:Math.abs(p.y-start.y)};draw();});
    wrap.addEventListener('pointerup',()=>{start=null;if(crop&&(crop.w<0.08||crop.h<0.08)){crop=null;draw();}});
    return {el:wrap,get:()=>crop,clear:()=>{crop=null;draw();}};
  }
  class MarketSearch {
    constructor(root) {
      this.root=root;this.source=root.dataset.market;this.prefix=root.dataset.prefix;
      this.items=[];this.selected=new Set();this.page=1;this.pageSize=10;this.product=null;this.busy=false;this.cancelled=false;this.bg={token:0,page:1,pages:0,target:1,query:'',sort:'',active:false};
      this.on();this.render();this.restore();
    }
    get(key){return document.getElementById(this.prefix+key);}
    status(text){this.get('Status').textContent=text;}
    lock() {
      if(networkOwner){this.status('Дождитесь завершения текущей загрузки поставщика.');return false;}
      networkOwner=this;this.busy=true;this.root.querySelectorAll('button').forEach(b=>b.disabled=true);this.get('Status').setAttribute('aria-busy','true');return true;
    }
    unlock(){networkOwner=null;this.busy=false;this.root.querySelectorAll('button').forEach(b=>b.disabled=false);this.get('Status').setAttribute('aria-busy','false');this.selection();}
    clearProduct(){this.product=null;this.get('Product').hidden=true;this.get('EstimateResult').textContent='';}
    async restore(){
      try{const r=await fetch('/api/suppliers/catalog/'+this.source),j=await r.json();if(!r.ok||!j.success)return;this.items=j.items||[];this.city=j.city||'';if(j.query&&this.items.length)this.status('Сохранено товаров: '+this.items.length+'. Последний запрос на сайте: '+j.query+'.');this.render();if(this.source==='ozon')this.get('City').textContent=this.city||'выберите город в «Первом запуске»';}catch{this.status('Не удалось восстановить поиск. Повторите запрос.');}
    }
    filtered(){
      const q=this.get('Filter').value.toLocaleLowerCase(),min=this.get('Min').value,max=this.get('Max').value;
      let items=this.items.filter(it=>(it.name+' '+it.id).toLocaleLowerCase().includes(q)&&(min===''||(it.price!=null&&it.price>=Number(min)))&&(max===''||(it.price!=null&&it.price<=Number(max))));
      items=this.richFilter(items);
      const sort=this.get('Sort').value;
      if(sort==='name')items.sort((a,b)=>a.name.localeCompare(b.name));
      if(sort==='salesDesc'||sort==='repeatDesc'){const k=sort==='salesDesc'?'sales':'repeat';items.sort((a,b)=>a[k]==null?(b[k]==null?0:1):b[k]==null?-1:b[k]-a[k]);}
      if(sort==='priceAsc'||sort==='priceDesc')items.sort((a,b)=>a.price==null?1:b.price==null?-1:(sort==='priceAsc'?a.price-b.price:b.price-a.price));
      return items;
    }
    render(){
      const list=this.filtered(),pages=Math.max(1,Math.ceil(list.length/this.pageSize));this.page=Math.min(this.page,pages);
      const slice=list.slice((this.page-1)*this.pageSize,this.page*this.pageSize);
      this.get('Count').textContent=list.length+' товаров';
      this.get('Table').innerHTML=slice.length?slice.map(it=>{
        const index=this.items.indexOf(it),q=encodeURIComponent(it.name),img=photo(it.image);
        return `<tr><td><input type="checkbox" data-select="${index}" ${this.selected.has(it.url)?'checked':''}></td><td>${img?`<img class="thumb-img" src="${attr(img)}" alt="" loading="lazy" referrerpolicy="no-referrer">`:''}</td><td><div class="rd-name">${esc(it.name)}</div><div class="rd-meta"><a href="${attr(it.url)}" target="_blank" rel="noopener noreferrer">${this.source==='1688'?'1688':'Ozon'} ↗</a> · цена предварительная</div>${this.rich(it)}<div class="rd-links"><a class="kaspi-verify-link" href="https://kaspi.kz/shop/search/?text=${q}" target="_blank" rel="noopener noreferrer">${IC.search} Поиск Kaspi</a>${img&&this.source==='1688'?`<a class="kaspi-verify-link" href="https://lens.google.com/uploadbyurl?url=${encodeURIComponent(img)}" target="_blank" rel="noopener noreferrer">${IC.camera} По фото в интернете</a>`:''}</div></td><td>${this.source==='ozon'?(it.feedbacks==null?'—':Number(it.feedbacks).toLocaleString('ru-RU')):(it.variant_count??'загрузить')}</td><td><strong>${esc(money(it.price,it.currency))}</strong></td><td>${esc(it.id)}</td><td><div class="market-actions"><button type="button" class="btn btn-sm btn-secondary" data-open="${index}">Варианты и расчёт</button><button type="button" class="btn btn-sm btn-accent" data-make="${index}">Создать карточки</button></div></td></tr>`;
      }).join(''):'<tr><td colspan="7" class="market-empty">Пока нет товаров. Выберите нишу или введите запрос и нажмите «Найти товары».</td></tr>';
      this.get('Pager').innerHTML=`<span class="pager-info">${list.length?'Показаны '+((this.page-1)*this.pageSize+1)+'–'+Math.min(list.length,this.page*this.pageSize)+' из '+list.length:'0 товаров'}</span><div class="pager-nav"><button class="pager-btn" type="button" data-page="-1" ${this.page===1?'disabled':''}>‹ Назад</button><span class="pager-info">${this.page} / ${pages}</span><button class="pager-btn" type="button" data-page="1" ${this.page===pages?'disabled':''}>Вперёд ›</button></div>`;
      this.get('SelectAll').checked=!!slice.length&&slice.every(it=>this.selected.has(it.url));this.selection();
    }
    selection(){this.get('SelectedCount').textContent=this.selected.size;this.get('MakeSelected').disabled=this.busy||!this.selected.size;}
    async search(query,categoryUrl){
      if(!this.lock())return;this.clearProduct();this.status('Ищем товары '+(this.source==='1688'?'1688':'Ozon')+'. Если сайт попросит вход или проверку, выполните её в открытом браузере.');
      try{this.bg.token++;const j=await api('search',{source:this.source,query:query||this.get('Query').value,category_url:categoryUrl||undefined,page:1,sort:this.get('Order')?this.get('Order').value:'',fresh:!!this.freshNext});this.items=j.items;this.selected.clear();this.page=1;this.render();if(!categoryUrl)this.histAdd(query||this.get('Query').value);this.status('Найдено '+this.items.length+' товаров. '+(categoryUrl?'Выбранная категория.':'Запрос на сайте: '+j.query+'.')+' Выберите товары или откройте варианты.');if(this.source==='1688'&&!categoryUrl)setTimeout(()=>this.startBg(j),0);}catch(e){this.status(e.message);}finally{this.unlock();}
    }
    histKey(){return 'ms_hist_'+this.source;}
    histLoad(){try{const h=JSON.parse(localStorage.getItem(this.histKey())||'[]');return Array.isArray(h)?h:[];}catch{return [];}}
    histAdd(q){q=String(q||'').trim();if(!q)return;const h=[q,...this.histLoad().filter(x=>x!==q)].slice(0,10);try{localStorage.setItem(this.histKey(),JSON.stringify(h));}catch{}this.histRender();}
    histRender(){const el=this.get('History');if(!el)return;const h=this.histLoad();el.innerHTML=h.length?'<span class="pill-label">Недавние поиски:</span>'+h.map(q=>`<button type="button" class="pill-btn" data-hist="${attr(q)}">${esc(q)}</button>`).join('')+'<button type="button" class="pill-btn" data-hist-clear="1" title="Очистить историю">✕</button>':'';}
    supplierBox(p){
      const el=this.get('Supplier');if(!el)return;const s=p&&p.supplier;if(s&&!s.name){const it=(this.items||[]).find(x=>x.id===p.id||x.url===p.url);if(it&&it.supplier)s.name=it.supplier;}
      if(this.source!=='1688'||!s||!(s.name||s.stars||s.quality||s.fulfil||s.repeat||s.rating)){if(el)el.hidden=true;return;}
      const row=[];
      if(s.stars)row.push('<span class="cn-stars" title="Уровень поставщика на 1688">'+'★'.repeat(s.stars)+'☆'.repeat(5-s.stars)+'</span>');
      if(s.years!=null)row.push('на 1688 '+s.years+' '+(s.years%10===1&&s.years!==11?'год':(s.years%10>=2&&s.years%10<=4&&(s.years<10||s.years>20)?'года':'лет')));
      const m=[];
      if(s.quality!=null)m.push(['Качество',s.quality+'%','Доля заказов без претензий к качеству']);
      if(s.fulfil!=null)m.push(['Выполнение заказов',s.fulfil+'%','Заказы, отправленные и доставленные в срок']);
      if(s.repeat!=null)m.push(['Повторные покупки',s.repeat+'%','Доля клиентов, которые заказывают снова']);
      if(s.rating!=null)m.push(['Оценка товара',s.rating+' / 5'+(s.reviews?' ('+s.reviews+' отзывов)':''),'Отзывы покупателей на странице товара']);
      if(s.item_repeat!=null)m.push(['Повторные покупки товара',s.item_repeat+'%','Доля повторных заказов именно этого товара']);
      if(s.good_rate!=null)m.push(['Хорошие отзывы',s.good_rate+'%','Доля положительных отзывов о товаре']);
      if(s.collect_24h!=null||s.collect_48h!=null)m.push(['Забор заказа 24 / 48 ч',(s.collect_24h!=null?s.collect_24h+'%':'—')+' / '+(s.collect_48h!=null?s.collect_48h+'%':'—'),'Доля заказов, переданных в доставку за 24 и 48 часов']);
      if(s.ship_from)m.push(['Склад поставщика',s.ship_from,'Откуда отправляется товар по Китаю']);
      if(s.ship_promise_h!=null||s.ship_latest_days!=null)m.push(['Срок отгрузки',s.ship_promise_h!=null?'до '+s.ship_promise_h+' ч':('до '+s.ship_latest_days+' дн'),'Обещание поставщика по отправке заказа']);
      if(s.ship_fee_from!=null)m.push(['Доставка по Китаю',s.ship_fee_from>0?'от '+s.ship_fee_from+' ¥':'бесплатно','Стоимость доставки до склада в Китае (минимум)']);
      if(s.downstream)m.push(['Продают у себя',String(s.downstream).replace(/(\d+)以内/,'до $1').replace(/(\d+)以上/,'более $1'),'Сколько перепродавцов уже торгуют этим товаром (чем меньше, тем свободнее ниша)']);
      const tiers=(p&&p.price_tiers)||[];
      if(tiers.length>1&&new Set(tiers.map(x=>x.min_qty)).size>1)m.push(['Оптовые цены',tiers.map(x=>'от '+x.min_qty+' шт: '+x.price+' ¥').join(' · '),'Цена за штуку при заказе от указанного количества']);
      const tr={'实力商家':'сильный продавец','超级工厂':'суперфабрика','源头工厂':'прямой завод','深度验厂':'проверенная фабрика','诚信通':'«Чэнсинь»','金牌供应商':'золотой поставщик','先采后付':'оплата после получения','退货包运费':'возврат бесплатный','7天无理由':'возврат 7 дней','一件代发':'дропшиппинг'};
      el.innerHTML='<div class="cn-sup-head"><b>'+esc(s.name||'Поставщик')+'</b> '+row.join(' · ')+'</div>'+(s.main?'<div class="cn-sup-main">Основное: '+esc(s.main)+'</div>':'')+
        (m.length?'<div class="cn-sup-grid">'+m.map(x=>'<div title="'+attr(x[2])+'"><span>'+esc(x[0])+'</span><b>'+esc(x[1])+'</b></div>').join('')+'</div>':'')+
        ((s.tags&&s.tags.length)?'<div class="cn-sup-tags">'+s.tags.map(t=>'<i>'+esc(tr[t]||t)+'</i>').join('')+'</div>':'');
      el.hidden=false;
    }
    richFilter(items){
      const g=id=>this.get(id),ms=g('MinSales'),mr=g('MinRepeat'),fr=g('FreeReturn'),ds=g('Dropship');
      return items.filter(it=>(!ms||ms.value===''||(it.sales!=null&&it.sales>=Number(ms.value)))&&(!mr||mr.value===''||(it.repeat!=null&&it.repeat>=Number(mr.value)))&&(!fr||!fr.checked||it.free_return)&&(!ds||!ds.checked||it.dropship));
    }
    rich(it){
      if(this.source!=='1688'||(it.sales==null&&it.repeat==null&&!it.supplier&&!it.eta))return '';
      const p=[];
      if(it.sales!=null)p.push('<b title="Продажи товара на 1688">'+Number(it.sales).toLocaleString('ru-RU')+'+ продаж</b>');
      if(it.repeat!=null)p.push('<span title="Доля повторных покупок у поставщика: чем выше, тем надёжнее">повторные '+it.repeat+'%</span>');
      if(it.supplier)p.push(esc(it.supplier));
      const t=[];if(it.free_return)t.push('возврат бесплатный');if(it.dropship)t.push('дропшиппинг');if(it.pay_later)t.push('оплата после получения');if(it.eta){const e={'当天达':'доставка по Китаю сегодня','明天达':'доставка по Китаю завтра','后天达':'доставка по Китаю послезавтра','次日达':'доставка по Китаю завтра'}[it.eta];t.push(e||('доставка '+it.eta));}
      if(t.length)p.push(t.join(', '));
      return '<div class="rd-meta cn-rich">'+p.join(' · ')+'</div>';
    }
    bgUi(active){const b=this.bg,s=this.get('BgStop'),m=this.get('More');if(s)s.hidden=!active;if(m)m.hidden=active||!(b.pages&&b.page<b.pages);}
    startBg(first){
      const b=this.bg;b.token++;b.page=1;b.fast=!!first.cached;b.fresh=!!this.freshNext;this.freshNext=false;b.oldest=first.cached_at||0;b.pages=Number(first.pages)||0;b.query=first.query;b.sort=this.get('Order')?this.get('Order').value:'';
      const want=Number(this.get('Pages')?this.get('Pages').value:1)||1;b.target=b.pages?Math.min(want,b.pages):want;
      this.runBg(b.token);
    }
    moreBg(){
      const b=this.bg;if(b.active||networkOwner)return;b.token++;
      const want=Number(this.get('Pages')?this.get('Pages').value:3)||3;b.target=Math.min(b.pages||b.page+want,b.page+want);this.runBg(b.token);
    }
    // страницы выдачи 1688 подгружаются по очереди в фоне: пока идёт следующая, можно листать, фильтровать и открывать товары
    async runBg(tok){
      const b=this.bg,wait=ms=>new Promise(r=>setTimeout(r,ms));let note='',fails=0;b.active=true;this.bgUi(true);
      while(b.page<b.target&&tok===b.token){
        if(!b.fast)await wait(6000+Math.random()*4000);else await wait(60);   // 6–10 с между страницами: частые загрузки 1688 принимает за робота и просит проверку
        if(tok!==b.token)break;
        if(networkOwner){await wait(2000);continue;}
        networkOwner=this;
        this.status('Найдено '+this.items.length+' товаров. Подгружаю страницу '+(b.page+1)+' из '+b.target+'… Можно листать и фильтровать.');
        try{
          const j=await api('search',{source:this.source,query:b.query,page:b.page+1,sort:b.sort,fresh:!!b.fresh});if(j.cached_at&&(!b.oldest||j.cached_at<b.oldest))b.oldest=j.cached_at;
          if(tok!==b.token)break;
          const have=new Set(this.items.map(x=>x.url)),add=(j.items||[]).filter(x=>!have.has(x.url));
          this.items=this.items.concat(add);b.page++;fails=0;b.fast=!!j.cached;if(j.pages)b.pages=j.pages;this.render();
          if(!add.length){note=' Новых товаров на следующих страницах нет.';break;}
        }catch(e){
          fails++;
          if(/Уже идёт загрузка/.test(e.message)&&fails<4)continue;
          note=' Подгрузка остановлена: '+e.message;break;
        }finally{networkOwner=null;}
      }
      b.active=false;this.bgUi(false);
      const ag=b.oldest?Math.floor((Date.now()/1000-b.oldest)/3600):-1,agt=ag<0?'':(ag<1?' Часть данных из памяти (меньше часа назад).':' Часть данных из памяти: '+(ag<48?ag+' ч':Math.floor(ag/24)+' дн')+' назад.');const rf=this.get('Refresh');if(rf)rf.hidden=!b.oldest;
      if(tok===b.token)this.status('Загружено '+this.items.length+' товаров (страниц выдачи: '+b.page+(b.pages?' из '+b.pages:'')+').'+agt+note+(b.pages&&b.page<b.pages?' Нажмите «Загрузить ещё страницы», чтобы продолжить.':''));
    }
    options(select,items,placeholder){select.replaceChildren(new Option(placeholder,''));for(const item of items||[])if(item.url&&item.name)select.add(new Option(item.name,item.url));}
    async categoryItems(parentUrl){
      const url='/api/suppliers/categories/'+this.source+(parentUrl?'?parent_url='+encodeURIComponent(parentUrl):'');
      const response=await fetch(url),data=await response.json();
      if(!response.ok||!data.success)throw new Error(data.error||'Не удалось получить категории площадки.');
      return data.items||[];
    }
    async loadCategories(parentUrl,level){
      const status=this.get('CategoryStatus');
      if(networkOwner){status.textContent='Дождитесь завершения текущей загрузки.';return;}
      networkOwner=this;status.textContent='Загружаем категории с '+(this.source==='ozon'?'Ozon':'1688')+'…';
      try{
        let items=await this.categoryItems(parentUrl);if(level===2)items=items.filter(x=>!this.categoryRoots?.some(root=>root.url===x.url));
        const select=this.get(level===0?'CategoryRoot':level===1?'CategoryChild':'CategoryLeaf');
        this.options(select,items,level===0?'Выберите категорию':level===1?'Вся категория':'Вся подкатегория');
        if(level===0)this.categoryRoots=items;
        status.textContent=items.length?'Показано разделов: '+items.length+'. Выберите нужный.':'В этой категории больше нет подкатегорий. Можно искать товары.';
      }catch(e){status.textContent=e.message;}finally{networkOwner=null;}
    }
    async open(url){
      if(!this.lock())return;this.clearProduct();this.status('Загружаем фото, варианты и условия доставки выбранного товара…');
      try{const r=await api('product',{source:this.source,url});this.product=r.product;this.showProduct();this.get('Product').scrollIntoView({behavior:'smooth',block:'start'});this.status('Товар загружен. Проверьте комплектации, наличие и цену за единицу.');}catch(e){this.status(e.message);}finally{this.unlock();}
    }
    showProduct(){
      const p=this.product;this.get('Product').hidden=false;this.get('Name').textContent=p.name;this.get('Checked').textContent='Проверено: '+new Date(p.checked_at).toLocaleString('ru-RU');this.supplierBox(p);
      this.get('Photos').innerHTML=p.images.slice(0,12).map(u=>`<img src="${attr(photo(u))}" alt="" loading="lazy" referrerpolicy="no-referrer">`).join('');
      this.get('Variant').innerHTML=p.variants.map((v,i)=>`<option value="${i}">${esc(v.name)} — ${esc(money(v.price,p.currency))}</option>`).join('');
      const selected=p.variants.findIndex(v=>v.id===p.id);this.get('Variant').value=Math.max(0,selected);
      this.get('ChinaCosts').hidden=this.source!=='1688';this.get('OzonCosts').hidden=this.source!=='ozon';this.get('Currency').textContent=p.currency==='CNY'?'¥':'₸';this.get('DraftCount').textContent=p.variants.length;
      this.get('Preorder').readOnly=this.source==='ozon';if(this.source==='1688')this.get('Preorder').value=this.get('PreorderDefault').value;this.variant();
    }
    variant(){
      const v=this.product.variants[Number(this.get('Variant').value)],p=this.product;
      this.get('Price').value=v.price??'';this.get('VariantLink').href=v.url;
      const availability={inStock:'Есть в наличии',outOfStock:'Нет в наличии',noSuchCombination:'Проверьте доступность этого сочетания',unknown:'Наличие не подтверждено'};
      let info=this.source==='1688'?'Остаток: '+(v.stock??'не получен')+'. Минимальный заказ: '+(v.min_quantity??'уточните')+'. Цена за количество: '+(v.price_quantity??'уточните')+'.':(availability[v.availability]||'Наличие нужно проверить');
      info+=' · Вес: '+(v.weight_kg==null?'не получен':v.weight_kg+' кг')+'.';
      if(v.labels?.length)info+=' · Комплектация: '+v.labels.join('; ')+'.';
      if(this.source==='ozon'){const d=v.delivery||{};this.get('Preorder').value=d.preorder_days??'';info+=' · '+(d.verified?'Доставка: '+d.text+'; город '+d.city+'. Предзаказ '+d.preorder_days+' дн. (запас '+d.buffer_days+' дн.)':d.error||'Срок будет получен при проверке выбранного варианта.');}
      this.get('VariantInfo').textContent=info;
      for(const [key,field]of Object.entries({weight_kg:'Weight',length_cm:'Length',width_cm:'Width',height_cm:'Height'}))this.get(field).value=v[key]??'';
      this.get('EstimateResult').textContent='';
    }
    async createItems(items){
      if(!items.length||!this.lock())return;
      let created=0,existing=0,failures=[];this.cancelled=false;this.get('Stop').hidden=false;this.get('Stop').disabled=false;
      try{
        for(let i=0;i<items.length&&!this.cancelled;i++){
          const item=items[i];this.status('Готовим товар '+(i+1)+' из '+items.length+': '+item.name+'. В Kaspi ничего не отправляется.');
          try{
            const p=(await api('product',{source:this.source,url:item.url})).product;
            if(this.source==='1688'){
              const days=Number(this.get('PreorderDefault').value),r=await api('drafts',{source:this.source,url:p.url,preorder_days:days});created+=r.created;existing+=r.existing;
            }else{
              for(let n=0;n<p.variants.length&&!this.cancelled;n++){
                const v=p.variants[n];this.status('Ozon: проверяем срок доставки варианта '+(n+1)+' из '+p.variants.length+' для '+(this.city||'города пользователя')+'…');
                try {
                  const current=v.id===p.id?p:(await api('product',{source:'ozon',url:v.url})).product;
                  const r=await api('drafts',{source:'ozon',url:current.url,variant_ids:[v.id]});created+=r.created;existing+=r.existing;
                } catch(e) { failures.push('Вариант '+v.id+': '+e.message); }
              }
            }
            this.selected.delete(item.url);
          }catch(e){failures.push(e.message);}
        }
        this.status((this.cancelled?'Остановлено. ':'')+'Создано черновиков: '+created+'. Уже были: '+existing+'.'+(failures.length?' Не удалось: '+failures.length+'. '+failures[0]:' Откройте «Карточки Kaspi» и проверьте поля перед отправкой.'));
        this.get('OpenCards').hidden=!created&&!existing;
      }finally{this.get('Stop').hidden=true;this.unlock();this.render();}
    }
    async calculate(){
      if(!this.product)return;const mapping={price:'Price',cny_rate:'Rate',weight_kg:'Weight',length_cm:'Length',width_cm:'Width',height_cm:'Height',per_kg:'PerKg',per_m3:'PerM3',freight:'Freight',other_costs:'Other',sale_price:'Sale',fees_pct:'Fees'},data={source:this.source};for(const[k,v]of Object.entries(mapping))data[k]=this.get(v).value;
      if(!this.product.currency){this.get('EstimateResult').textContent='Сначала проверьте валюту товара на сайте.';return;}
      try{const r=await api('estimate',data);this.get('EstimateResult').textContent='Закупка '+money(r.purchase_kzt,'KZT')+' · доставка '+money(r.freight_kzt,'KZT')+' · себестоимость '+money(r.cost_kzt,'KZT')+' · без убытка от '+money(r.break_even_kzt,'KZT')+' · прибыль '+money(r.profit_kzt,'KZT');}catch(e){this.get('EstimateResult').textContent=e.message;}
    }
    on(){
      this.get('Categories').addEventListener('toggle',()=>{if(this.get('Categories').open&&!this.categoryRoots)this.loadCategories(null,0);});
      const onCatChange = (selectEl) => {
        const text = selectEl.options[selectEl.selectedIndex]?.text;
        const url = selectEl.value;
        if (url && text && !text.startsWith('Все') && !text.startsWith('Вся') && !text.startsWith('Выберите')) {
          this.get('Query').value = text;
          this.categoryUrl = url; this.categoryLabel = text;
          this.status('Категория выбрана: «' + text + '». Нажмите «Найти товары». Если дописать слова в строку поиска, категория не учитывается и ищется по тексту.');
        }
      };
      this.get('CategoryRoot').addEventListener('change',()=>{
        const value=this.get('CategoryRoot').value;
        this.options(this.get('CategoryChild'),[],'Вся категория');
        this.options(this.get('CategoryLeaf'),[],'Вся подкатегория');
        if(value){
          this.loadCategories(value,1);
          onCatChange(this.get('CategoryRoot'));
        }
      });
      this.get('CategoryChild').addEventListener('change',()=>{
        const value=this.get('CategoryChild').value;
        this.options(this.get('CategoryLeaf'),[],'Вся подкатегория');
        if(!value)return;
        if(this.source==='ozon')this.loadCategories(value,2);
        else this.options(this.get('CategoryLeaf'),this.categoryRoots.find(x=>x.url===this.get('CategoryRoot').value)?.children.find(x=>x.url===value)?.children||[],'Вся подкатегория');
        onCatChange(this.get('CategoryChild'));
      });
      this.get('CategoryLeaf').addEventListener('change',()=>{
        onCatChange(this.get('CategoryLeaf'));
      });
      const catGo = this.get('CategoryGo');
      if (catGo) {
        catGo.addEventListener('click',()=>{
          const url=this.get('CategoryLeaf').value||this.get('CategoryChild').value||this.get('CategoryRoot').value;
          if(!url){this.get('CategoryStatus').textContent='Сначала выберите категорию.';return;}
          this.categoryUrl=url;this.categoryLabel=this.get('Query').value;this.search(null,url);
        });
      }
      if(this.get('Refresh'))this.get('Refresh').addEventListener('click',()=>{if(this.busy||networkOwner)return;this.freshNext=true;this.categoryUrl=null;this.search();});
      this.histRender();if(this.get('History'))this.get('History').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.histClear){try{localStorage.removeItem(this.histKey());}catch{}this.histRender();return;}if(b.dataset.hist!=null&&!this.busy){this.categoryUrl=null;this.get('Query').value=b.dataset.hist;this.search();}});
      this.get('SearchForm').addEventListener('submit',e=>{e.preventDefault();if(this.categoryUrl&&this.get('Query').value===this.categoryLabel)this.search(null,this.categoryUrl);else{this.categoryUrl=null;this.search();}});
      this.root.querySelectorAll('[data-niche]').forEach(b=>b.addEventListener('click',()=>{this.categoryUrl=null;this.root.querySelectorAll('[data-niche]').forEach(n=>n.classList.remove('active'));b.classList.add('active');this.get('Query').value=b.dataset.label;this.search(b.dataset.niche);}));
      for(const field of ['Filter','Min','Max','Sort','MinSales','MinRepeat','FreeReturn','Dropship']){const el=this.get(field);if(el)el.addEventListener('input',()=>{this.page=1;this.render();});}
      if(this.get('BgStop'))this.get('BgStop').addEventListener('click',()=>{this.bg.token++;this.status('Подгрузка остановлена. Загружено '+this.items.length+' товаров.');this.bgUi(false);});
      if(this.get('More'))this.get('More').addEventListener('click',()=>this.moreBg());
      this.get('Table').addEventListener('change',e=>{if(e.target.dataset.select!==undefined){const it=this.items[Number(e.target.dataset.select)];if(e.target.checked)this.selected.add(it.url);else this.selected.delete(it.url);this.selection();}});
      this.get('SelectAll').addEventListener('change',e=>{const list=this.filtered().slice((this.page-1)*this.pageSize,this.page*this.pageSize);list.forEach(it=>{if(e.target.checked)this.selected.add(it.url);else this.selected.delete(it.url);});this.render();});
      this.get('Table').addEventListener('click',e=>{const open=e.target.closest('[data-open]'),make=e.target.closest('[data-make]');if(open)this.open(this.items[Number(open.dataset.open)].url);if(make)this.createItems([this.items[Number(make.dataset.make)]]);});
      this.get('Pager').addEventListener('click',e=>{const b=e.target.closest('[data-page]');if(b&&!b.disabled){this.page+=Number(b.dataset.page);this.render();}});
      this.get('MakeSelected').addEventListener('click',()=>this.createItems(this.items.filter(it=>this.selected.has(it.url))));
      this.get('Stop').addEventListener('click',()=>{this.cancelled=true;this.status('Останавливаем после текущей загрузки…');});
      this.get('OpenCards').addEventListener('click',()=>document.querySelector('[data-tab="tab-cards"]').click());
      this.get('ProductForm').addEventListener('submit',e=>{e.preventDefault();this.open(this.get('Url').value);});
      this.get('Variant').addEventListener('change',()=>this.variant());
      this.get('ReloadVariant').addEventListener('click',()=>{if(this.product)this.open(this.product.variants[Number(this.get('Variant').value)].url);});
      this.get('MakeDrafts').addEventListener('click',()=>{if(this.product){if(this.source==='1688')this.get('PreorderDefault').value=this.get('Preorder').value;this.createItems([{url:this.product.url,name:this.product.name}]);}});
      this.get('EstimateForm').addEventListener('submit',e=>{e.preventDefault();this.calculate();});
      this.get('EstimateForm').addEventListener('input',()=>this.get('EstimateResult').textContent='');
      if(this.source==='1688'){
        this.get('PhotoForm').addEventListener('submit',e=>{e.preventDefault();const file=this.get('Photo').files[0];if(file)this.photoFile(file,this.cropper?this.cropper.get():null);});
        this.get('Photo').addEventListener('change',()=>{
          const slot=this.get('CropSlot'),file=this.get('Photo').files[0];slot.replaceChildren();this.cropper=null;if(!file)return;
          const url=URL.createObjectURL(file);this.cropper=cropPicker(url);
          const hint=document.createElement('p');hint.className='help-text';hint.textContent='Обведите мышкой сам товар на фото (без лишних предметов рядом), чтобы 1688 искал именно его. Без выделения ищется по всему фото.';
          const clear=document.createElement('button');clear.type='button';clear.className='btn btn-sm btn-secondary';clear.textContent='Всё фото';clear.onclick=()=>this.cropper.clear();
          slot.append(this.cropper.el,hint,clear);
        });
        this.get('Login').addEventListener('click',async()=>{
          this.status('Открываем безопасное окно входа 1688…');
          try{const r=await fetch('/api/suppliers/1688_open_login',{method:'POST'}),j=await r.json();this.status(r.ok&&j.success?j.message:(j.error||'Не удалось открыть вход 1688.'));}catch(e){this.status('Не удалось открыть вход 1688: '+e.message);}
        });
      }
    }
    async photoFile(file,crop){
      if(!this.lock())return;this.status('Ищем поставщиков 1688 по выбранной фотографии…');
      try{const data=new FormData();data.append('image',file);if(crop)data.append('crop',JSON.stringify(crop));const r=await api('photo',data);this.items=r.items;this.selected.clear();this.page=1;this.render();this.status(r.items.length?'Найдено по фото: '+r.items.length+'.':(r.needs_login?'1688 пустит фотопоиск только после входа. Откройте окно браузера, войдите в 1688 один раз — дальше поиск по фото будет работать.':(r.blocked?'1688 просит вход или проверку. Пройдите её в открытом окне и повторите.':'1688 не показал совпадений. Попробуйте другое фото.')));}catch(e){this.status(e.message);}finally{this.unlock();}
    }
  }
  window.findSupplierByPhoto=async function(wbId,button){
    const row=button?.closest('tr')||document.querySelector('.radar-sel[data-id="'+Number(wbId)+'"]')?.closest('tr');if(!row)return;
    let panel=document.getElementById('supplier-photo-'+Number(wbId));
    if(panel){panel.hidden=!panel.hidden;return;}
    panel=document.createElement('tr');panel.id='supplier-photo-'+Number(wbId);panel.className='wb-supplier-photo';
    const sourceImg=row.querySelector('.thumb-img')?.src||'',sourceName=row.querySelector('.rd-name')?.textContent||'Товар WB';
    const defaultDays=Number(controllers['1688']&&controllers['1688'].get('PreorderDefault')?.value)||30;
    panel.innerHTML=`<td colspan="8"><div class="cab-box supplier-inline"><div class="supplier-inline-head"><h3>Поставщики 1688 по фото: ${esc(sourceName)}</h3><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;"><button type="button" class="btn btn-sm btn-primary" data-search-name title="Найти этот товар на 1688 по названию (с переводом на китайский)">Искать по названию (1688)</button> <button type="button" class="btn btn-sm btn-secondary" data-login>Войти в 1688</button> <button type="button" class="btn btn-sm btn-secondary" data-retry>Повторить поиск</button> <button type="button" class="btn btn-sm btn-secondary" data-close>Закрыть</button></div></div><div style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-start;margin:8px 0"><div data-crop-slot></div><div class="help-text" style="max-width:380px"><b>Нашлось не то?</b> Обведите мышкой на фото сам товар (без лишних предметов рядом) и нажмите «Искать по выделенному».<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap"><button type="button" class="btn btn-sm btn-primary" data-crop-search>Искать по выделенному</button><button type="button" class="btn btn-sm btn-secondary" data-crop-clear>Всё фото</button></div></div></div><p data-photo-status role="status">Ищем по исходному фото WB. Если 1688 попросит вход или проверку, выполните её в открытом окне браузера.</p><p><label>Предзаказ для черновиков 1688, дней <input data-photo-days type="number" min="1" max="30" value="${defaultDays}"></label></p><div data-photo-results></div><p><a href="https://lens.google.com/uploadbyurl?url=${encodeURIComponent(sourceImg)}" target="_blank" rel="noopener noreferrer">Поиск этого фото в интернете</a> · <a href="https://s.1688.com/" data-photo-site target="_blank" rel="noopener noreferrer">Открыть поиск 1688</a></p></div></td>`;
    row.after(panel);panel.querySelector('[data-close]').onclick=()=>panel.hidden=true;
    panel.querySelector('[data-retry]').onclick=()=>{if(!networkOwner){panel.remove();window.findSupplierByPhoto(wbId,button);}};
    panel.querySelector('[data-search-name]').onclick=()=>{const tabBtn=document.querySelector('[data-tab="tab-1688"]');if(tabBtn)tabBtn.click();const qInp=document.getElementById('cnQuery');if(qInp)qInp.value=sourceName;if(controllers['1688'])controllers['1688'].search(sourceName);};
    const status=panel.querySelector('[data-photo-status]'),results=panel.querySelector('[data-photo-results]');
    panel.querySelector('[data-login]').onclick=async()=>{status.textContent='Открываем окно входа 1688…';try{const r=await fetch('/api/suppliers/1688_open_login',{method:'POST'}),j=await r.json();status.textContent=r.ok&&j.success?j.message:(j.error||'Не удалось открыть вход 1688.');}catch(e){status.textContent='Не удалось открыть вход 1688: '+e.message;}};
    const picker=cropPicker(sourceImg);panel.querySelector('[data-crop-slot]').appendChild(picker.el);
    panel.querySelector('[data-crop-clear]').onclick=()=>picker.clear();
    const run=async crop=>{
      if(networkOwner){status.textContent='Сейчас загружается другой товар. Повторите поиск после завершения.';return;}
      networkOwner=panel;if(button)button.disabled=true;
      try{
        const r=await api('photo',{wb_id:wbId,crop:crop||undefined});
        if(r.search_url)panel.querySelector('[data-photo-site]').href=r.search_url;
        status.textContent=r.items.length?'Найдено поставщиков: '+r.items.length+'. Откройте товар и проверьте, совпадают ли фото, модель и комплектация. Не тот товар? Обведите нужный предмет на фото и повторите.':(r.needs_login?'1688 пустит фотопоиск только после входа. Откройте окно браузера, войдите в 1688 один раз — дальше поиск по фото будет работать.':(r.blocked?'1688 просит вход или проверку. Пройдите её в открытом окне и повторите.':'1688 не показал совпадений по этому фото. Обведите товар на фото и повторите, либо воспользуйтесь поиском фото в интернете.'));
        results.innerHTML=r.items.slice(0,10).map(it=>`<div class="supplier-inline-result">${photo(it.image)?`<img src="${attr(photo(it.image))}" alt="" loading="lazy">`:''}<div><b>${esc(it.name)}</b><p>${esc(money(it.price,it.currency))}</p><a href="${attr(it.url)}" target="_blank" rel="noopener noreferrer">Открыть поставщика ↗</a><button type="button" class="btn btn-sm btn-accent" data-photo-make="${attr(it.url)}">Создать черновики вариантов</button></div></div>`).join('');
      }catch(e){status.textContent=e.message+' Вы остаётесь в списке WB; можно воспользоваться поиском фото в интернете.';}
      finally{networkOwner=null;if(button)button.disabled=false;}
    };
    panel.querySelector('[data-crop-search]').onclick=()=>{const c=picker.get();if(!c){status.textContent='Сначала обведите товар на фото мышкой.';return;}run(c);};
    run(null);
    {
      results.addEventListener('click',async e=>{const b=e.target.closest('[data-photo-make]');if(!b||networkOwner)return;networkOwner=panel;b.disabled=true;try{const p=(await api('product',{source:'1688',url:b.dataset.photoMake})).product,days=Number(panel.querySelector('[data-photo-days]').value),created=await api('drafts',{source:'1688',url:p.url,preorder_days:days});status.textContent='Создано черновиков: '+created.created+'. Уже были: '+created.existing+'. Предзаказ '+days+' дней. Проверьте поля в «Карточки Kaspi».';}catch(e){status.textContent=e.message;}finally{networkOwner=null;b.disabled=false;}});
    }
  };
  document.addEventListener('DOMContentLoaded',()=>document.querySelectorAll('.market-search[data-market]').forEach(root=>{const controller=new MarketSearch(root);controllers[controller.source]=controller;}));
})();
