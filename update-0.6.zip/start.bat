@echo off
chcp 65001 > nul
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1
title Kaspi Arbitrage Pro

:: 1. Проверка: запущен ли батник внутри нераспакованного архива ZIP
if not exist "%~dp0run.py" (
    cls
    echo ========================================================
    echo   [ОШИБКА] ВЫ ЗАПУСТИЛИ ПРОГРАММУ ПРЯМО ИЗ АРХИВА!
    echo ========================================================
    echo.
    echo   Так запускать нельзя, файлы программы заблокированы ZIP.
    echo.
    echo   КАК ПРАВИЛЬНО ЗАПУСТИТЬ:
    echo   1. Закройте это черное окно.
    echo   2. Нажмите правой кнопкой мыши по файлу архива ZIP.
    echo   3. Выберите "Извлечь все..." (Extract All).
    echo   4. Зайдите в созданную папку и запустите start.bat!
    echo.
    echo ========================================================
    pause
    exit /b
)

cd /d "%~dp0"

:: 2. Выбор Python (Встроенный Portable Runtime или системный Python)
set PY_CMD=

if exist "%~dp0runtime\python.exe" (
    set PY_CMD="%~dp0runtime\python.exe"
) else (
    where python >nul 2>nul
    if %errorlevel% equ 0 (
        set PY_CMD=python
    ) else (
        where py >nul 2>nul
        if %errorlevel% equ 0 (
            set PY_CMD=py
        )
    )
)

if "%PY_CMD%"=="" (
    cls
    echo ========================================================
    echo   [ВНИМАНИЕ] На вашем компьютере не найден Python!
    echo ========================================================
    echo.
    echo   Для первого запуска требуется бесплатный Python 3.10+.
    echo   Сейчас в браузере откроется официальный установщик...
    echo.
    echo   ОЧЕНЬ ВАЖНО ПРИ УСТАНОВКЕ:
    echo   В самом первом окне установщика ОБЯЗАТЕЛЬНО поставьте
    echo   галочку внизу: [X] "Add python.exe to PATH"
    echo.
    echo   После установки просто заново запустите start.bat!
    echo ========================================================
    start "" "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
    pause
    exit /b
)

:: 3. Запуск программы и автоматическое открытие в браузере по умолчанию
cls
echo ========================================================
echo   KASPI ARBITRAGE PRO ^& AI STUDIO (NanoBanana)
echo   Запуск локального сервера...
echo   Программа сейчас откроется в вашем браузере по умолчанию!
echo ========================================================

:: Запуск сервера
%PY_CMD% "%~dp0run.py"
pause
