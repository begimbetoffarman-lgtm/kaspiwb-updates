import os
from PIL import Image, ImageDraw, ImageFont

# 15 Category-specific USPs
USP_DATABASE = {
    "Кухня": [
        ("БЕЗ СВЕРЛЕНИЯ СТЕН", "Монтаж на усиленный влагостойкий клей за 1 минуту", "●"),
        ("НЕРЖАВЕЮЩАЯ СТАЛЬ", "100% защита от влаги, коррозии и моющих средств", "✦"),
        ("ПРОДУМАННЫЙ СЛИВ ВОДЫ", "Гигиенично, сухо и без неприятных запахов", "🛡")
    ],
    "Ванная": [
        ("БЕЗ СВЕРЛЕНИЯ И ПЫЛИ", "Надежный монтаж без повреждения плитки", "●"),
        ("АНТИКОРРОЗИЙНАЯ СТАЛЬ", "Устойчив к пару, воде и перепадам температур", "✦"),
        ("НАГРУЗКА ДО 15 КГ", "Усиленный каркас и высокие защитные бортики", "🛡")
    ],
    "Авто": [
        ("УСИЛЕННЫЙ ЗАЖИМ", "Надежно держит на любых неровностях и кочках", "●"),
        ("ПРЕМИУМ МАТЕРИАЛЫ", "Матовый корпус, устойчив к царапинам и нагреву", "✦"),
        ("БЫСТРАЯ УСТАНОВКА", "Монтируется за секунды в любой салон авто", "🛡")
    ],
    "Гаджеты": [
        ("МАГНИТ MAGSAFE", "Мощная фиксация и поддержка быстрой зарядки", "●"),
        ("АЛЮМИНИЕВЫЙ СПЛАВ", "Эффективное охлаждение и долговечность", "✦"),
        ("УНИВЕРСАЛЬНОСТЬ", "Совместим с iOS, Android и любыми устройствами", "🛡")
    ],
    "Зоотовары": [
        ("БЕЗОПАСНЫЙ ЭКО-ПЛАСТИК", "Пищевой материал, 100% без запаха и BPA", "●"),
        ("ЛЕГКАЯ ОЧИСТКА", "Разбирается и моется за считанные секунды", "✦"),
        ("АНТИСКОЛЬЗЯЩАЯ ОСНОВА", "Не гремит, не переворачивается и не царапает пол", "🛡")
    ],
    "Детские": [
        ("100% ПИЩЕВОЙ СИЛИКОН", "Безопасен для первых зубок, BPA Free", "●"),
        ("ТЕРМОСТОЙКИЙ МАТЕРИАЛ", "Выдерживает стерилизацию, СВЧ и заморозку", "✦"),
        ("АНАТОМИЧЕСКАЯ ФОРМА", "Разработано с заботой о комфорте малыша", "🛡")
    ],
    "Уборка": [
        ("МОЩНЫЙ ТУРБО-МОТОР", "Удаляет даже въевшуюся грязь без усилий", "●"),
        ("ВЛАГОЗАЩИТА IPX7", "Безопасное использование в воде и пене", "✦"),
        ("СМЕННЫЕ НАСАДКИ", "Комплект для любых поверхностей дома и авто", "🛡")
    ],
    "Освещение": [
        ("СЕНСОР ДВИЖЕНИЯ", "Автоматическое включение в темноте", "●"),
        ("МЯГКИЙ ТЁПЛЫЙ СВЕТ", "Комфортно для глаз, без мерцания", "✦"),
        ("МАГНИТНЫЙ МОНТАЖ", "Крепится без проводов и сверления стен", "🛡")
    ],
    "Инструменты": [
        ("ИНСТРУМЕНТАЛЬНАЯ СТАЛЬ CR-V", "Высокая твёрдость и защита от слизывания шлицев", "●"),
        ("МАГНИТНЫЕ БИТЫ", "Надёжно удерживают мелкие винты и крепеж", "✦"),
        ("КОМПАКТНЫЙ КЕЙС", "Всё под рукой в удобном алюминиевом пенале", "🛡")
    ],
    "Дом": [
        ("ИДЕАЛЬНЫЙ ПОРЯДОК", "Экономит до 70% свободного пространства", "●"),
        ("УДАРОПРОЧНЫЙ ПЛАСТИК", "Экологичный, безопасный и долговечный материал", "✦"),
        ("СКАНДИНАВСКИЙ ДИЗАЙН", "Эстетично впишется в современный интерьер", "🛡")
    ]
}

def detect_usp_category(name: str, category: str = "") -> list:
    text = f"{name} {category}".lower()
    if any(k in text for k in ["кухн", "раковин", "мойк", "нож", "посуд", "губк", "специ", "кофе"]):
        return USP_DATABASE["Кухня"]
    elif any(k in text for k in ["ванн", "душ", "фен", "мыл", "дозатор"]):
        return USP_DATABASE["Ванная"]
    elif any(k in text for k in ["авто", "машин", "рул", "держатель в авто"]):
        return USP_DATABASE["Авто"]
    elif any(k in text for k in ["магсейф", "телефон", "magsafe", "кабел", "провод", "зарядк", "хаб"]):
        return USP_DATABASE["Гаджеты"]
    elif any(k in text for k in ["кот", "собак", "животн", "зоо", "корм", "поилк", "лоток"]):
        return USP_DATABASE["Зоотовары"]
    elif any(k in text for k in ["детск", "малыш", "ребен", "прикорм", "бутылочк"]):
        return USP_DATABASE["Детские"]
    elif any(k in text for k in ["уборк", "щетк", "пылесос", "чистк", "стеклоочистител"]):
        return USP_DATABASE["Уборка"]
    elif any(k in text for k in ["ночник", "светильник", "led", "свет", "ламп"]):
        return USP_DATABASE["Освещение"]
    elif any(k in text for k in ["инструмент", "отвертк", "биты", "ключ", "набор"]):
        return USP_DATABASE["Инструменты"]
    return USP_DATABASE["Дом"]

def apply_apple_infographics(image_path: str, output_path: str, title_text: str = "", category: str = "") -> str:
    im = Image.open(image_path).convert("RGBA")
    W, H = im.size
    
    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    
    font_bold_path = r"C:\Windows\Fonts\arialbd.ttf"
    font_reg_path = r"C:\Windows\Fonts\arial.ttf"
    
    font_title = ImageFont.truetype(font_bold_path, size=max(14, int(W * 0.034)))
    font_sub = ImageFont.truetype(font_reg_path, size=max(11, int(W * 0.024)))
    
    usps = detect_usp_category(title_text, category)
    
    def draw_pill(x, y, title, subtitle, icon="✦"):
        pad_x = int(W * 0.032)
        pad_y = int(H * 0.014)
        
        b1 = draw.textbbox((0, 0), f"{icon}  {title}", font=font_title)
        w1, h1 = b1[2] - b1[0], b1[3] - b1[1]
        
        b2 = draw.textbbox((0, 0), subtitle, font=font_sub)
        w2, h2 = b2[2] - b2[0], b2[3] - b2[1]
        
        bw = max(w1, w2) + pad_x * 2
        bh = h1 + h2 + pad_y * 2 + 5
        rad = int(bh * 0.26)
        
        draw.rounded_rectangle(
            [(x, y), (x + bw, y + bh)],
            radius=rad,
            fill=(255, 255, 255, 238),
            outline=(226, 232, 240, 255),
            width=2
        )
        
        draw.text((x + pad_x, y + pad_y), f"{icon}  {title}", fill=(15, 23, 42, 255), font=font_title)
        draw.text((x + pad_x + int(W * 0.035), y + pad_y + h1 + 5), subtitle, fill=(100, 116, 139, 255), font=font_sub)

    draw_pill(int(W * 0.05), int(H * 0.06), usps[0][0], usps[0][1], usps[0][2])
    draw_pill(int(W * 0.05), int(H * 0.18), usps[1][0], usps[1][1], usps[1][2])
    draw_pill(int(W * 0.05), int(H * 0.80), usps[2][0], usps[2][1], usps[2][2])
    
    final_img = Image.alpha_composite(im, overlay).convert("RGB")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    final_img.save(output_path, "JPEG", quality=95)
    return output_path
