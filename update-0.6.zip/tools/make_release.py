"""Чистая сборка для другого продавца: без data/, config.json, паролей, токенов, ваших накладных и резервных копий.
Запуск (из папки проекта):  runtime\\python.exe tools\\make_release.py [версия]
Результат: D:\\kaspi-arbitrage-release\\KaspiWB-<версия>.zip. В конце — проверка, что в архиве нет ваших секретов."""
import json
import os
import re
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = r"D:\kaspi-arbitrage-release"
VERSION = sys.argv[1] if len(sys.argv) > 1 else open(os.path.join(ROOT, "version.txt")).read().strip()
SKIP_DIRS = {"data", "_wb_test", "_render", "_upload", "backups", "__pycache__", ".git", "tools_private"}
SKIP_FILES = {"config.json", "extract_live_kaspi_products.py", "inspect_kaspi_html.py", "check_xml_preorder.py", "ДЛЯ-ANTIGRAVITY.md", "ПЛАН-РАЗВИТИЯ.md"}
SKIP_EXT = {".pyc", ".pkl", ".log"}


def secrets():
    """Значения из вашего config.json, которых не должно быть в сборке (токен, пароли, логин, номер магазина)."""
    try:
        c = json.load(open(os.path.join(ROOT, "config.json"), encoding="utf-8"))
    except Exception:
        return []
    keys = ("kaspi_api_token", "kaspi_cab_password", "kaspi_cab_login", "gmail_app_password", "gmail_address",
            "royaltech_api_key", "kaspi_merchant_id", "feed_token")
    return [str(c[k]) for k in keys if c.get(k) and len(str(c[k])) >= 5]


def main():
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, f"KaspiWB-{VERSION}.zip")
    files = []
    for base, dirs, names in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for n in names:
            if n in SKIP_FILES or os.path.splitext(n)[1] in SKIP_EXT:
                continue
            files.append(os.path.join(base, n))
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f, os.path.join("KaspiWB", os.path.relpath(f, ROOT)))
    # проверка на утечки: ищем значения ваших секретов во всех текстовых файлах архива
    bad = []
    sec = secrets()
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            if os.path.splitext(info.filename)[1].lower() in (".py", ".js", ".html", ".json", ".md", ".bat", ".txt", ".css"):
                data = z.read(info).decode("utf-8", "ignore")
                for s in sec:
                    if s in data:
                        bad.append((info.filename, s[:2] + "…"))
    print("файлов:", len(files), "размер МБ:", round(os.path.getsize(path) / 1e6, 1))
    print("УТЕЧКИ:", bad if bad else "нет")
    print(path)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
