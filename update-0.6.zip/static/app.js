let currentItems = [];
const radarSelected = new Set();
let appConfig = {};
let storeData = { products: [] };
let activeStoreFilter = 'all';
let currentLicense = {};
let storeCurrentPage = 1;
let storePageSize = 50;

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  loadConfig();
  checkLicenseStatus();
  loadCatalog();
  setupEventListeners();
  setupStoreEvents();
  setupModalEvents();
  checkApiStatus();
});

// ==========================================================
// License & Trial Logic
// ==========================================================
async function checkLicenseStatus() {
  try {
    const res = await fetch('/api/license');
    const data = await res.json();
    currentLicense = data;
    
    const licDot = document.getElementById('licDot');
    const licLabel = document.getElementById('licLabel');
    const pill = document.getElementById('appLicensePill');
    const modalStatus = document.getElementById('modalLicStatus');
    const modalMachine = document.getElementById('modalMachineId');
    const btnAct = document.getElementById('btnSidebarActivate');

    if (modalMachine) modalMachine.innerText = data.machine_id || 'UNKNOWN-ID';

    if (data.status === 'PRO') {
      if (licDot) licDot.className = 'status-dot online';
      if (licLabel) licLabel.innerText = 'PRO Лицензия';
      if (pill) pill.innerText = 'PRO · Бессрочно';
      if (modalStatus) modalStatus.innerText = 'PRO Лицензия (Бессрочная)';
      if (btnAct) {
        btnAct.innerText = '✓ PRO Активирован';
        btnAct.style.textDecoration = 'none';
        btnAct.style.color = 'var(--green)';
      }
    } else if (data.status === 'TRIAL') {
      if (licDot) licDot.className = 'status-dot online';
      if (licLabel) licLabel.innerText = `Тест-драйв: ${data.days_left} дн.`;
      if (pill) pill.innerText = `Trial · ${data.days_left}д`;
      if (modalStatus) modalStatus.innerText = `Тест-драйв: ${data.days_left} дн. осталось`;
      if (btnAct) btnAct.innerText = 'Активировать PRO';
    } else {
      if (licDot) licDot.className = 'status-dot';
      if (licLabel) licLabel.innerText = 'Тест-драйв истёк';
      if (pill) pill.innerText = 'Лицензия истекла';
      if (modalStatus) modalStatus.innerText = 'Срок пробного периода истёк';
      if (btnAct) {
        btnAct.innerText = '⚠️ Требуется ключ PRO';
        btnAct.style.color = '#DC2626';
      }
    }
  } catch (err) {
    console.error('License check error:', err);
  }
}

function escHtml(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
}
function escAttr(v) { return escHtml(v); }
function photoPlaceholder(title) {
  const ch = escHtml((String(title || '?').trim()[0] || '?').toUpperCase());
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" rx="12" fill="#E8EEF7"/><text x="40" y="53" font-family="Arial,sans-serif" font-size="34" font-weight="700" text-anchor="middle" fill="#8EA2C0">${ch}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

// Tab Switching
function initTabs() {
  const tabs = document.querySelectorAll('.nav-item');
  const panes = document.querySelectorAll('.tab-pane');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      panes.forEach(p => p.classList.remove('active'));
      
      tab.classList.add('active');
      const target = tab.dataset.tab;
      const targetPane = document.getElementById(target);
      if (targetPane) targetPane.classList.add('active');
      if (target === 'tab-cards' && window.loadCards) window.loadCards();
      if (target === 'tab-setup' && window.loadSetupTab) window.loadSetupTab();
      if (target === 'tab-orders' && window.loadOrdersTab) window.loadOrdersTab();
      if (target === 'tab-preorder' && window.loadPreorderTab) window.loadPreorderTab();
      
      const titles = {
        'tab-radar': ['Радар вакуума Kaspi', 'Поиск хитов с Wildberries под предзаказ Kaspi (чистый х2)'],
        'tab-my-store': ['Мой магазин Kaspi', 'Регулировка цен, наличие и предзаказ, контроль Топ-3 корзины (BuyBox)'],
        'tab-cards': ['Карточки Kaspi из WB', 'Создание карточек через официальный API Kaspi: категория, характеристики, фото, модерация'],
        'tab-studio': ['AI Студия & УТП', 'Студийный ре-рендер предметных фото + инфографика в стиле Apple'],
        'tab-export': ['Экспорт в Kaspi Pay', 'Готовый Excel-шаблон прайс-листа для массовой загрузки'],
        'tab-settings': ['Настройки & API', 'Управление ключами Kaspi, RoyalTech и параметрами наценки'],
        'tab-orders': ['Заказы и накладные', 'Что собрать, когда передать, печать накладных'],
        'tab-preorder': ['Предзаказ карточек', 'Срок по реальной доставке WB'],
        'tab-setup': ['Первый запуск', 'Подключение магазина Kaspi'],
        'tab-guide': ['Инструкция от А до Я', 'Пошаговый план запуска продаж без склада и оптовых рисков']
      };
      if (titles[target]) {
        document.getElementById('pageTitle').innerText = titles[target][0];
        document.getElementById('pageSubtitle').innerText = titles[target][1];
      }

      const ta = document.getElementById('topbarActions');
      if (ta) ta.style.display = (target === 'tab-radar') ? '' : 'none';   // кнопки и счётчики радара WB нужны только на его вкладке

      if (target === 'tab-studio') {
        renderStudioGrid();
      } else if (target === 'tab-my-store') {
        loadKaspiStore();
      }
    });
  });
}

// Load Config
async function loadConfig() {
  try {
    const res = await fetch('/api/config');
    appConfig = await res.json();
    document.getElementById('cfgRoyaltechKey').value = appConfig.royaltech_api_key || '';
    document.getElementById('cfgKaspiId').value = appConfig.kaspi_merchant_id || '';
    document.getElementById('cfgKaspiToken').value = appConfig.kaspi_api_token || '';
    const delivSelect = document.getElementById('cfgKaspiDeliveryMode');
    if (delivSelect) {
      delivSelect.value = appConfig.kaspi_delivery_mode || 'official_kz';
      const cWrap = document.getElementById('cfgCustomDeliveryWrap');
      if (cWrap) cWrap.style.display = (delivSelect.value === 'custom') ? 'block' : 'none';
    }
    const delivCostInp = document.getElementById('cfgKaspiDeliveryCost');
    if (delivCostInp) delivCostInp.value = appConfig.kaspi_delivery_cost_kzt || 1507;
    document.getElementById('cfgMarginMultiplier').value = appConfig.margin_multiplier || 2.4;
    document.getElementById('cfgPackagingCost').value = appConfig.packaging_cost_kzt || 150;
  } catch (err) {
    console.error('Config load error:', err);
  }
}

// Check Royaltech API Status
async function checkApiStatus() {
  try {
    const res = await fetch('/api/account');
    const data = await res.json();
    const dot = document.querySelector('#apiStatusBadge .status-dot');
    const txt = document.getElementById('apiStatusText');
    const nbLimit = document.getElementById('nbDailyLimit');
    
    if (data.success && data.account) {
      dot.className = 'status-dot online';
      const daily = data.account.daily?.[0];
      const remaining = daily ? daily.remaining_today : 500;
      txt.innerText = `NanoBanana: ${remaining}/500`;
      if (nbLimit && daily) {
        nbLimit.innerText = `${daily.remaining_today} / ${daily.limit}`;
      }
    } else {
      dot.className = 'status-dot';
      txt.innerText = 'NanoBanana: Нужен ключ';
    }
  } catch (err) {
    console.error('API check failed:', err);
  }
}

// Load Catalog (WB Arbitrage)
async function loadCatalog() {
  try {
    const res = await fetch('/api/items');
    const data = await res.json();
    if (data.success) {
      currentItems = data.items || [];
      renderTable(currentItems);
      updateKpis(currentItems);
    }
  } catch (err) {
    console.error('Catalog load error:', err);
  }
}

function updateKpis(items) {
  document.getElementById('statCount').innerText = items.length;
  document.getElementById('tableFilterCount').innerText = `${items.length} карточек`;
}

// Render WB Catalog Table
function renderTable(items) {
  const tbody = document.getElementById('itemsTableBody');
  tbody.innerHTML = '';
  
  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="12" style="text-align: center; padding: 40px; color: var(--text-muted);">Товары не найдены. Выберите категорию или введите запрос.</td></tr>`;
    return;
  }
  
  items.forEach((it, idx) => {
    const tr = document.createElement('tr');
    const displayImg = it.infographic_image || it.ai_image || it.img_main || it.img_url || '';
    const kaspiName = it.kaspi_name || it.name;
    const cleanSearchQ = it.kaspi_search_query || (it.name ? it.name.replace(/[^\wа-яА-ЯёЁ\s]/g, ' ').split(/\s+/).filter(w => w.length > 3).slice(0, 3).join(' ') : kaspiName);
    const cost = it.cost_total || (it.price_kzt + 150);
    const kaspiPrice = it.kaspi_price || Math.round(cost * 2.4);
    const profit = it.profit || (kaspiPrice - cost - Math.round(kaspiPrice * 0.165));
    const roi = it.roi || Math.round((profit / cost) * 100);
    
    let photoStatus = '<span class="badge">Оригинал WB</span>';
    if (it.infographic_image) {
      photoStatus = '<span class="badge" style="background:#EFF6FF; color:#2563EB;">🏷️ УТП Готово</span>';
    } else if (it.ai_image) {
      photoStatus = '<span class="badge" style="background:#DCFCE7; color:#16A34A;">✨ AI Студия</span>';
    }

    tr.innerHTML = `
      <td style="color: var(--text-muted); text-align: center;"><label style="display:flex;flex-direction:column;align-items:center;gap:2px;cursor:pointer;"><input type="checkbox" class="radar-sel" data-id="${it.id}" ${radarSelected.has(it.id) ? 'checked' : ''}><span style="font-size:10px;">${idx + 1}</span></label></td>
      <td>
        <div class="thumb-wrap" style="cursor: pointer;" onclick="window.openImagePreview('${escAttr(displayImg)}', '${escAttr(kaspiName)}')" title="Кликните, чтобы открыть фото для сканирования камерой Kaspi">
          <img class="thumb-img" src="${displayImg}" alt="${it.brand}" loading="lazy" onerror="this.src='https://placehold.co/80x80?text=No+Photo'">
          <span class="thumb-sticker ${it.feedbacks > 10000 ? 'sticker-fire' : 'sticker-vacuum'}">
            ${it.feedbacks > 10000 ? '🔥 ТОП' : '💎 ХИТ'}
          </span>
        </div>
      </td>
      <td>
        <div style="font-weight: 600; line-height: 1.35; font-size: 13.5px;">${kaspiName}</div>
        <div style="margin-top: 4px; display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
          <a href="${it.wb_url}" target="_blank" style="color: var(--accent); text-decoration: none; font-size: 11px;">Арт. WB: ${it.id} ↗</a>
          <span class="apple-sticker sticker-vacuum" style="font-size: 9.5px; padding: 2px 6px;">💎 Вакуум 0 на Kaspi</span>
          <a href="https://kaspi.kz/shop/search/?text=${encodeURIComponent(cleanSearchQ)}" target="_blank" rel="noopener noreferrer" class="kaspi-verify-link" title="Точный поиск в Kaspi.kz по запросу: «${cleanSearchQ}». Если показывает заменители (аптечки, чехлы) — товара на Kaspi нет!">
            🔎 Поиск Kaspi ↗
          </a>
          <a href="https://lens.google.com/uploadbyurl?url=${encodeURIComponent(it.img_main || it.img_url || '')}" target="_blank" rel="noopener noreferrer" class="kaspi-verify-link" style="color:#7C3AED; background:rgba(124,58,237,0.08);" title="Найти по фото через нейросеть Google Lens (находит все совпадения на Kaspi и других маркетплейсах)">
            📷 По фото (Lens) ↗
          </a>
          <button type="button" class="kaspi-verify-link" style="border:none; cursor:pointer; color:#0284C7; background:rgba(2,132,199,0.09); font-weight:600;" onclick="window.testKaspiVacuum(${it.id}, this)" title="Проверить наличие дубликатов на Kaspi за 1 секунду">
            ⚡ Тест вакуума
          </button>
          ${it.in_stock === false ? '<span style="color:#DC2626; margin-left:4px; font-size: 11px;">● Нет на складе WB</span>' : ''}
        </div>
        <div id="vacuum-res-${it.id}" style="margin-top: 5px; font-size: 11px; display: none;"></div>
      </td>
      <td><span class="badge" style="font-weight:600;">${it.brand || 'ProHome'}</span></td>
      <td style="text-align: center;"><strong>${(it.feedbacks || 0).toLocaleString()}</strong></td>
      <td style="text-align: center;"><span class="rating-pill">★ ${it.rating || 4.9}</span></td>
      <td>${cost.toLocaleString()} ₸<div style="font-size:10px;color:${it.price_source && it.price_source.startsWith('WB ') ? '#15803D' : '#B45309'};">${it.price_source && it.price_source.startsWith('WB Актобе') ? 'WB Актобе ₸' : 'устарела — «Синхронизировать цены WB»'}</div></td>
      <td><strong>${kaspiPrice.toLocaleString()} ₸</strong></td>
      <td><span class="profit-pill">+${profit.toLocaleString()} ₸</span></td>
      <td><span class="roi-badge">+${roi}%</span></td>
      <td>${photoStatus}</td>
      <td>
        <button class="btn btn-sm btn-accent" style="width: 100%; white-space: nowrap; font-size: 11px; padding: 6px 4px; box-shadow: 0 2px 8px rgba(0,113,227,0.25);" onclick="window.addRadarItemToStore(${it.id})">
          ➕ В магазин (7д)
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// 1-Click transfer WB item to seller's Kaspi store under preorder
window.addRadarItemToStore = async function(itemId) {
  const it = currentItems.find(x => x.id === itemId);
  if (!it) {
    showToast('Товар не найден в списке');
    return;
  }
  showToast(`Добавление «${(it.kaspi_name || it.name || '').slice(0, 30)}...» в ваш магазин...`);
  try {
    const res = await fetch('/api/kaspi/add_from_wb', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_id: itemId, preorder_days: 7, item: it })
    });
    const data = await res.json();
    if (data.success) {
      showToast('✓ Товар добавлен в ваш магазин Kaspi со статусом "Под заказ: 7 дней"!');
      // background refresh
      loadKaspiStore();
    } else {
      showToast(`Ошибка: ${data.error || 'Не удалось добавить товар'}`);
    }
  } catch (err) {
    showToast(`Ошибка связи: ${err.message}`);
  }
};

// Render Studio Grid
function renderStudioGrid() {
  const grid = document.getElementById('studioGrid');
  grid.innerHTML = '';
  
  const displayItems = currentItems.slice(0, 30);
  displayItems.forEach(it => {
    const card = document.createElement('div');
    card.className = 'studio-card';
    const wbImg = it.img_main || it.img_url || '';
    const aiImg = it.infographic_image || it.ai_image || '';
    
    card.innerHTML = `
      <div class="studio-images-duo">
        <div class="img-box">
          <img src="${wbImg}" alt="WB" loading="lazy">
          <span class="img-tag">WB Оригинал</span>
        </div>
        <div class="img-box" id="aiBox_${it.id}">
          ${aiImg ? `<img src="${aiImg}" alt="AI" loading="lazy"><span class="img-tag ai">${it.infographic_image ? 'УТП Apple' : 'NanoBanana'}</span>` 
                  : `<div style="text-align: center; color: var(--text-muted); font-size: 11px; padding: 12px;">Кадр ещё не создан</div>`}
        </div>
      </div>
      <div class="studio-card-title">${it.kaspi_name || it.name}</div>
      <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto;">
        <span style="font-size: 12px; font-weight: 700; color: var(--green);">Маржа: х2 (+${it.roi || 102}%)</span>
        <button class="btn btn-sm btn-accent" id="btnGen_${it.id}" onclick="generateAiForProduct(${it.id})">
          ${aiImg ? 'Пересоздать' : '✨ Создать кадр'}
        </button>
      </div>
    `;
    grid.appendChild(card);
  });
}

// Generate AI Photo
window.generateAiForProduct = async function(itemId) {
  const btn = document.getElementById(`btnGen_${itemId}`);
  if (btn) {
    btn.disabled = true;
    btn.innerText = 'Генерация...';
  }
  
  const selectedMode = document.querySelector('input[name="studioGlobalMode"]:checked')?.value || 'infographic';
  showToast(selectedMode === 'infographic' ? 'Создание AI студии + инфографики УТП (≈20 сек)...' : 'Создание чистого AI рендера NanoBanana (≈20 сек)...');
  
  try {
    const res = await fetch('/api/generate_ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_id: itemId, mode: selectedMode })
    });
    const data = await res.json();
    if (data.success) {
      showToast('✓ Уникальное студийное фото готово!');
      const item = currentItems.find(x => x.id === itemId);
      if (item) {
        if (selectedMode === 'infographic') {
          item.infographic_image = data.ai_image;
        } else {
          item.ai_image = data.ai_image;
        }
      }
      renderTable(currentItems);
      const aiBox = document.getElementById(`aiBox_${itemId}`);
      if (aiBox) {
        aiBox.innerHTML = `<img src="${data.ai_image}" alt="AI"><span class="img-tag ai">${selectedMode === 'infographic' ? 'УТП Apple' : 'NanoBanana'}</span>`;
      }
      checkApiStatus();
    } else {
      showToast(`Ошибка: ${data.error || 'Сбой генерации'}`);
    }
  } catch (err) {
    showToast(`Ошибка связи: ${err.message}`);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerText = '✓ Готово';
    }
  }
};

// ==========================================================
// My Kaspi Store & BuyBox Logic (In-Stock & Preorder)
// ==========================================================
async function loadRepricerConfig() {
  try {
    const res = await fetch('/api/kaspi/repricer');
    const data = await res.json();
    if (data.success && data.config) {
      const cfg = data.config;
      const stratSel = document.getElementById('repricerStrategy');
      const minMargInp = document.getElementById('repricerMinMargin');
      const underInp = document.getElementById('repricerUndercut');
      if (stratSel && cfg.strategy) stratSel.value = cfg.strategy;
      if (minMargInp && cfg.min_margin_pct) minMargInp.value = cfg.min_margin_pct;
      if (underInp && cfg.undercut_kzt) underInp.value = cfg.undercut_kzt;
    }
  } catch (err) {
    console.error('Error loading repricer config:', err);
  }
}

async function saveRepricerConfig(runNow = false) {
  const strat = document.getElementById('repricerStrategy')?.value || 'top3';
  const minMarg = parseFloat(document.getElementById('repricerMinMargin')?.value) || 15;
  const under = parseInt(document.getElementById('repricerUndercut')?.value) || 10;
  
  const btn = document.getElementById('btnRunRepricer');
  if (btn && runNow) {
    btn.disabled = true;
    btn.innerText = '⚡️ Оптимизация...';
  }

  try {
    const res = await fetch('/api/kaspi/repricer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        strategy: strat,
        min_margin_pct: minMarg,
        undercut_kzt: under,
        run_now: runNow
      })
    });
    const data = await res.json();
    if (data.success && runNow) {
      const c = data.cycle || {};
      showToast(`Репрайсер: изменено ${c.repriced_count || 0}, на пороге маржи ${c.shielded_count || 0}, пропущено без себестоимости ${(c.skipped || {}).no_cost || 0}`); loadAutopilot();
      await loadKaspiStore();
      openRepricerLogsModal(c);
    } else if (data.success && !runNow) {
      showToast('✓ Настройки репрайсера сохранены');
    }
  } catch (err) {
    showToast('Ошибка сохранения настроек репрайсера');
  } finally {
    if (btn && runNow) {
      btn.disabled = false;
      btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg> <span>Применить ко всем</span>`;
    }
  }
}

// Display Repricer Audit Modal
function openRepricerLogsModal(cycle) {
  const modal = document.getElementById('repricerLogsModal');
  if (!modal) return;
  const sub = document.getElementById('repricerLogsSubtitle');
  if (sub) {
    sub.innerText = `Оптимизировано цен: ${cycle.repriced_count || 0} · Защищено полом маржи: ${cycle.shielded_count || 0} (всего проверено ${cycle.total_checked || 0})`;
  }
  const tbody = document.getElementById('repricerLogsTableBody');
  if (tbody) {
    tbody.innerHTML = '';
    const logs = cycle.logs || [];
    if (!logs.length) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 24px; color: var(--text-muted);">Все цены соответствуют выбранной стратегии и находятся в Топ-3 корзины.</td></tr>`;
    } else {
      logs.forEach(log => {
        const tr = document.createElement('tr');
        const diff = (log.new_price || 0) - (log.old_price || 0);
        let diffBadge = '';
        if (diff < 0) {
          diffBadge = `<span style="font-size: 11px; color: #DC2626; margin-left: 4px;">(${diff.toLocaleString()} ₸)</span>`;
        } else if (diff > 0) {
          diffBadge = `<span style="font-size: 11px; color: #16A34A; margin-left: 4px;">(+${diff.toLocaleString()} ₸)</span>`;
        }
        let statusBadge = '';
        if (log.is_shielded) {
          statusBadge = `<span class="badge" style="background:#FEE2E2; color:#DC2626; font-weight:700;">🛡 Защита маржи</span>`;
        } else if (diff !== 0) {
          statusBadge = `<span class="badge" style="background:#DCFCE7; color:#16A34A; font-weight:700;">⚡ В корзину (Top)</span>`;
        } else {
          statusBadge = `<span class="badge" style="background:#F3F4F6; color:#6B7280;">Без изменений</span>`;
        }
        tr.innerHTML = `
          <td><code style="font-size: 11px;">${escHtml(log.sku)}</code></td>
          <td><div style="max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${escAttr(log.title)}">${escHtml(log.title)}</div></td>
          <td style="color: var(--text-muted);">${(log.old_price || 0).toLocaleString()} ₸</td>
          <td><strong>${(log.new_price || 0).toLocaleString()} ₸</strong>${diffBadge}</td>
          <td style="font-size: 11px; color: var(--text-muted);">≥ ${(log.floor_price || 0).toLocaleString()} ₸</td>
          <td>${statusBadge}</td>
        `;
        tbody.appendChild(tr);
      });
    }
  }
  modal.classList.add('open');
}

async function loadKaspiStore() {
  const tbody = document.getElementById('storeTableBody');
  if (tbody && (!storeData.products || storeData.products.length === 0)) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; padding: 60px 20px;">
          <div class="spinner-inline" style="width: 32px; height: 32px; border-width: 3px; margin: 0 auto 16px;"></div>
          <div style="font-size: 15px; font-weight: 600; color: #1E293B;">Загрузка товаров вашего магазина Kaspi...</div>
          <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Синхронизация цен, остатков и расчет маржи по каждой карточке</div>
        </td>
      </tr>
    `;
  }
  try {
    loadRepricerConfig();
    const res = await fetch('/api/kaspi/store');
    const resp = await res.json();
    if (resp.success) {
      storeData = resp.data;
      renderStoreDashboard();
    } else {
      showToast('Ошибка: ' + (resp.error || 'Не удалось получить данные магазина'));
      if (tbody) tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding: 40px; color: #DC2626;">Ошибка загрузки: ${escHtml(resp.error || 'Сервер вернул ошибку')}</td></tr>`;
    }
  } catch (err) {
    console.error('Store load error:', err);
    showToast('Ошибка загрузки данных магазина');
    if (tbody) tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding: 40px; color: #DC2626;">Ошибка загрузки: ${escHtml(err.message)}</td></tr>`;
  }
}

function renderStoreDashboard() {
  if (!storeData || !storeData.products) return;

  // Update Mode Pill
  const pill = document.getElementById('storeModePill');
  if (pill) {
    pill.innerText = storeData.mode_label;
    if (storeData.is_live_api) {
      pill.style.background = '#DCFCE7';
      pill.style.color = '#15803D';
      pill.style.borderColor = '#BBF7D0';
    } else {
      pill.style.background = '#EFF6FF';
      pill.style.color = '#2563EB';
      pill.style.borderColor = '#BFDBFE';
    }
  }

  const clr = document.getElementById('btnClearImport');
  if (clr) clr.style.display = storeData.imported_count ? 'inline-flex' : 'none';

  const syncBanner = document.getElementById('storeSyncBanner');
  if (syncBanner) {
    syncBanner.style.display = (storeData.imported_count || storeData.products_count > 20) ? 'none' : 'flex';
  }

  // Update 5 KPI Cards
  const hasCostData = Boolean(storeData.items_with_cost > 0 && storeData.total_profit !== null && storeData.total_profit !== undefined);
  if (hasCostData) {
    const profitSign = storeData.total_profit > 0 ? '+' : '';
    document.getElementById('storeTotalProfit').innerText = `${profitSign}${storeData.total_profit.toLocaleString('ru-RU')} ₸`;
    document.getElementById('storeAvgMargin').innerText = `${storeData.avg_margin_pct}%`;
    const profitSub = document.querySelector('#storeTotalProfit + .kpi-subtext');
    if (profitSub) profitSub.innerText = `Для ${storeData.items_with_cost.toLocaleString('ru-RU')} товаров с известной закупкой`;
  } else {
    document.getElementById('storeTotalProfit').innerText = '—';
    document.getElementById('storeAvgMargin').innerText = '—';
    const profitSub = document.querySelector('#storeTotalProfit + .kpi-subtext');
    if (profitSub) profitSub.innerText = 'Укажите себестоимость товаров';
  }
  document.getElementById('storeTotalRevenue').innerText = `${storeData.total_revenue.toLocaleString('ru-RU')} ₸`;
  const revSub = document.querySelector('#storeTotalRevenue + .kpi-subtext');
  if (revSub) revSub.innerText = 'Сумма розничных цен каталога Kaspi';

  const note = document.getElementById('storeEstimateNote');
  if (note) {
    if ((storeData.items_with_cost || 0) < storeData.products_count) {
      note.innerHTML = `💡 <b>Себестоимость не указана:</b> в выгрузке Kaspi Pay себестоимости закупки нет. Софт показывает точную сумму «К выплате от Kaspi» без вымышленных оценок. Введите реальную закупку в ячейку товара или загрузите через кнопку <b>«💰 Загрузить себестоимость»</b>.`;
      note.style.display = 'block';
    } else {
      note.style.display = 'none';
    }
  }

  if (storeData.comp_known === 0) {
    document.getElementById('storeBuyBoxPct').innerText = '—';
    document.getElementById('storeBuyBoxCount').innerText = storeData.alone_count
      ? `конкурентов нет на ${storeData.alone_count} карточках из ${storeData.products_count}`
      : 'нет данных о конкурентах (товары из прайс-листа)';
  } else {
    document.getElementById('storeBuyBoxPct').innerText = `${storeData.top3_pct}%`;
    document.getElementById('storeBuyBoxCount').innerText = `${storeData.top3_count} из ${storeData.comp_known} карточек с конкурентами в Топ-3` + (storeData.alone_count ? ` (ещё ${storeData.alone_count} без конкурентов)` : '');
  }
  document.getElementById('storeDangerCount').innerText = storeData.danger_items;

  // Filter count tabs
  const inStockCount = storeData.products.filter(p => p.delivery_type === 'in_stock').length;
  const preorderCount = storeData.products.filter(p => p.delivery_type === 'preorder').length;
  const archiveCount = storeData.products.filter(p => p.delivery_type === 'archive').length;
  const top3Count = storeData.products.filter(p => p.buybox && p.buybox.is_in_buybox).length;
  const outCount = storeData.products.filter(p => p.buybox && !p.buybox.is_in_buybox).length;
  const dangerCount = storeData.products.filter(p => p.economics && (p.economics.verdict_status === 'LOSS' || p.economics.margin_pct < 10)).length;

  if (document.getElementById('storeFilterAllCount')) document.getElementById('storeFilterAllCount').innerText = storeData.products.length;
  if (document.getElementById('storeFilterInStockCount')) document.getElementById('storeFilterInStockCount').innerText = inStockCount;
  if (document.getElementById('storeFilterPreorderCount')) document.getElementById('storeFilterPreorderCount').innerText = preorderCount;
  if (document.getElementById('storeFilterArchiveCount')) document.getElementById('storeFilterArchiveCount').innerText = archiveCount;
  document.getElementById('storeFilterTop3Count').innerText = top3Count;
  document.getElementById('storeFilterOutCount').innerText = outCount;
  document.getElementById('storeFilterDangerCount').innerText = dangerCount;

  filterAndRenderStoreTable();
}


// Render delivery options supporting all Kaspi pre-order day variants (3..45 days)
function buildDeliveryOptionsHtml(delVal, currentDays) {
  const commonDays = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 30, 45];
  const daysList = [...commonDays];
  const curNum = parseInt(currentDays, 10);
  if (curNum && curNum > 0 && !daysList.includes(curNum)) {
    daysList.push(curNum);
    daysList.sort((a, b) => a - b);
  }
  let html = `<option value="in_stock" ${delVal === 'in_stock' ? 'selected' : ''}>🟢 В наличии (0 дн)</option>`;
  daysList.forEach(d => {
    const val = `preorder_${d}`;
    html += `<option value="${val}" ${delVal === val ? 'selected' : ''}>⏳ Заказ: ${d} дн</option>`;
  });
  html += `<option value="archive" ${delVal === 'archive' ? 'selected' : ''} style="color:#DC2626;font-weight:600;">🚫 Снять с продажи (Архив)</option>`;
  return html;
}

// Официальная сетка тарифов сервиса «Kaspi Доставка» (с НДС 16%)
const KASPI_DELIVERY_RATES = {
  under_10k: [
    { max_price: 1000, city: 57, kz: 57, express: 57, tier: 'до 1 000 ₸' },
    { max_price: 3000, city: 173, kz: 173, express: 173, tier: '1 000 – 3 000 ₸' },
    { max_price: 5000, city: 231, kz: 231, express: 231, tier: '3 000 – 5 000 ₸' },
    { max_price: 10000, city: 811, kz: 927, express: 927, tier: '5 000 – 10 000 ₸' }
  ],
  over_10k_by_weight: {
    under_5kg: { city: 1275, kz: 1507, express: 1971, tier: 'от 10 000 ₸ (до 5 кг)' },
    '5_to_15kg': { city: 1565, kz: 1971, express: 2145, tier: 'от 10 000 ₸ (5–15 кг)' },
    '15_to_30kg': { city: 2667, kz: 4175, express: 3653, tier: 'от 10 000 ₸ (15–30 кг)' }
  }
};

function getKaspiDeliveryDetails(price, scope = 'kz', weightTier = 'under_5kg') {
  const p = Number(price) || 0;
  const key = (scope === 'city' ? 'city' : (scope === 'express' ? 'express' : 'kz'));
  if (p < 10000) {
    for (const r of KASPI_DELIVERY_RATES.under_10k) {
      if (p <= r.max_price) {
        return {
          fee: r[key],
          tier: r.tier,
          scopeName: key === 'kz' ? 'По Казахстану' : (key === 'express' ? 'Express' : 'По городу')
        };
      }
    }
    const r = KASPI_DELIVERY_RATES.under_10k[KASPI_DELIVERY_RATES.under_10k.length - 1];
    return {
      fee: r[key],
      tier: r.tier,
      scopeName: key === 'kz' ? 'По Казахстану' : 'По городу'
    };
  } else {
    const w = KASPI_DELIVERY_RATES.over_10k_by_weight[weightTier] || KASPI_DELIVERY_RATES.over_10k_by_weight.under_5kg;
    return {
      fee: w[key],
      tier: w.tier,
      scopeName: key === 'kz' ? 'По Казахстану' : (key === 'express' ? 'Express' : 'По городу')
    };
  }
}

function getKaspiDeliveryFee(price, scope = 'kz', weightTier = 'under_5kg') {
  return getKaspiDeliveryDetails(price, scope, weightTier).fee;
}

// In-memory unit economics recalculator for instant 60 FPS zero-lag updates
function recalculateProductInMemory(p) {
  const sell = parseFloat(p.sell_price) || 0;
  const cost = parseFloat(p.cost_price || p.default_cost) || 0;
  const has_cost = cost > 0;
  const comm_rate = parseFloat(p.commission_rate) || 12.5;
  const comm_kzt = Math.round(sell * (comm_rate / 100));
  const pay_kzt = Math.round(sell * 0.0095);
  const tax_kzt = Math.round(sell * 0.03);

  // Exact official Kaspi Delivery tariff from schedule
  const delivMode = (window.appConfig && window.appConfig.kaspi_delivery_mode) || 'official_kz';
  const scope = delivMode === 'official_city' ? 'city' : (delivMode === 'official_express' ? 'express' : 'kz');
  
  let delivery_kzt, delivery_tier;
  if (delivMode === 'custom') {
    delivery_kzt = parseInt(window.appConfig && window.appConfig.kaspi_delivery_cost_kzt) || 1507;
    delivery_tier = 'Фикс. доставка';
  } else {
    const dDetails = getKaspiDeliveryDetails(sell, scope);
    delivery_kzt = dDetails.fee;
    delivery_tier = dDetails.tier;
  }
  const pack_kzt = 150;

  const kaspi_deductions = comm_kzt + pay_kzt + tax_kzt + delivery_kzt + pack_kzt;
  const kaspi_payout = Math.round(sell - kaspi_deductions);

  let net_profit = null, margin_pct = null, roi_pct = null;
  let status = "NO_COST", badge = "⚪ НЕ УКАЗАНА", badge_class = "neutral";

  if (has_cost) {
    const total_deductions = cost + kaspi_deductions;
    net_profit = Math.round(sell - total_deductions);
    margin_pct = sell > 0 ? parseFloat(((net_profit / sell) * 100).toFixed(1)) : 0;
    roi_pct = cost > 0 ? parseFloat(((net_profit / cost) * 100).toFixed(1)) : 0;

    if (net_profit < 0) {
      status = "LOSS"; badge = "🔴 В УБЫТОК"; badge_class = "danger";
    } else if (margin_pct < 12.0) {
      status = "LOW_MARGIN"; badge = "⚠️ НИЗКАЯ МАРЖА"; badge_class = "warning";
    } else if (margin_pct >= 25.0) {
      status = "HIGH_PROFIT"; badge = "🟢 СУПЕР-МАРЖА"; badge_class = "success";
    } else {
      status = "NORMAL"; badge = "🟡 СТАБИЛЬНО"; badge_class = "info";
    }
  }

  p.economics = {
    has_cost: has_cost,
    sell_price: sell,
    cost_price: has_cost ? cost : 0,
    comm_rate: comm_rate,
    comm_kzt: comm_kzt,
    pay_kzt: pay_kzt,
    tax_kzt: tax_kzt,
    delivery_kzt: delivery_kzt,
    delivery_tier: delivery_tier,
    pack_kzt: pack_kzt,
    kaspi_deductions: kaspi_deductions,
    kaspi_payout: kaspi_payout,
    total_deductions: has_cost ? (cost + kaspi_deductions) : kaspi_deductions,
    net_profit: net_profit,
    margin_pct: margin_pct,
    roi_pct: roi_pct,
    verdict_status: status,
    verdict_badge: badge,
    badge_class: badge_class
  };



  p.floor_min_price = Math.round((cost + 1050) / 0.6855);

  if (p.competitor_prices && p.competitor_prices.length && !p.alone) {
    const others = p.competitor_prices.filter(x => x > 0);
    const sorted = [...others].sort((a,b) => a - b);
    const p1 = sorted[0];
    const p2 = sorted.length > 1 ? sorted[1] : p1;
    const p3 = sorted.length > 2 ? sorted[2] : p2;
    if (sell <= p1) {
      p.buybox = { rank: 1, label: "🏆 Топ-1 (Лидер корзины)", badge_class: "buybox-top1", is_in_buybox: true, top1_price: p1, top2_price: p2, target_top3: p3 };
    } else if (sell <= p2) {
      p.buybox = { rank: 2, label: "🥈 Топ-2 (В корзине)", badge_class: "buybox-top2", is_in_buybox: true, top1_price: p1, top2_price: p2, target_top3: p3 };
    } else if (sell <= p3) {
      p.buybox = { rank: 3, label: "🥉 Топ-3 (В корзине)", badge_class: "buybox-top3", is_in_buybox: true, top1_price: p1, top2_price: p2, target_top3: p3 };
    } else {
      p.buybox = { rank: 4, label: "⚠️ Вне корзины (#4+)", badge_class: "buybox-out", is_in_buybox: false, top1_price: p1, top2_price: p2, target_top3: p3 };
    }
  }
}

// In-memory summary totals updater
function refreshStoreTotalsInMemory() {
  if (!storeData || !storeData.products) return;
  let totalRevenue = 0;
  let totalProfit = 0;
  let inStockCount = 0;
  let preorderCount = 0;
  let dangerCount = 0;

  storeData.products.forEach(p => {
    const qty = (p.stock && p.stock > 0) ? p.stock : 1;
    totalRevenue += (p.sell_price || 0) * qty;
    totalProfit += (p.economics ? p.economics.net_profit : 0) * qty;
    if (p.delivery_type === 'in_stock') inStockCount++;
    else preorderCount++;
    if (p.economics && (p.economics.net_profit < 0 || p.economics.margin_pct < 10)) {
      dangerCount++;
    }
  });

  storeData.total_revenue = Math.round(totalRevenue);
  storeData.total_profit = Math.round(totalProfit);
  storeData.avg_margin_pct = totalRevenue > 0 ? parseFloat(((totalProfit / totalRevenue) * 100).toFixed(1)) : 0;
  storeData.danger_items = dangerCount;
}

function filterAndRenderStoreTable() {
  const tbody = document.getElementById('storeTableBody');
  tbody.innerHTML = '';

  const q = document.getElementById('storeSearchInput')?.value.toLowerCase().trim() || '';
  
  let filtered = storeData.products.filter(p => {
    // Search query
    const matchSearch = !q || p.title.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q);
    if (!matchSearch) return false;

    // Filter tab
    if (activeStoreFilter === 'in_stock') return p.delivery_type === 'in_stock';
    if (activeStoreFilter === 'preorder') return p.delivery_type === 'preorder';
    if (activeStoreFilter === 'archive') return p.delivery_type === 'archive';
    if (activeStoreFilter === 'top3') return p.buybox.is_in_buybox === true;
    if (activeStoreFilter === 'out') return p.buybox.is_in_buybox === false;
    if (activeStoreFilter === 'danger') return p.economics.verdict_status === 'LOSS' || p.economics.margin_pct < 10;
    return true;
  });

  const totalFiltered = filtered.length;
  const totalPages = Math.ceil(totalFiltered / storePageSize) || 1;
  if (storeCurrentPage > totalPages) storeCurrentPage = totalPages;
  if (storeCurrentPage < 1) storeCurrentPage = 1;

  if (!filtered.length) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 36px; color: var(--text-muted);">Товары не найдены для выбранного фильтра</td></tr>`;
    renderStorePagination(0, 1, 0, 0);
    return;
  }

  const startIdx = (storeCurrentPage - 1) * storePageSize;
  const endIdx = Math.min(startIdx + storePageSize, totalFiltered);
  const pageItems = filtered.slice(startIdx, endIdx);

  renderStorePagination(totalFiltered, totalPages, startIdx, endIdx);

  pageItems.forEach((p, idx) => {
    const tr = document.createElement('tr');
    const econ = p.economics;
    const bb = p.buybox;
    const hasCost = Boolean(econ && econ.has_cost && p.cost_price > 0);
    const isLoss = hasCost && econ.net_profit < 0;

    // Delivery selector value
    const pDays = parseInt(p.preorder_days, 10) || 0;
    const delVal = (p.delivery_type === 'in_stock' || pDays === 0) ? 'in_stock' : `preorder_${pDays}`;

    const fmt = n => Math.round(n || 0).toLocaleString('ru-RU');
    const others = (p.competitor_prices || []).filter(x => x > 0);
    const rowCls = p.alone ? 'row-alone' : (!hasCost ? 'row-ok' : (econ.net_profit < 0 ? 'row-loss' : (econ.margin_pct < 10 ? 'row-low' : 'row-ok')));
    tr.className = rowCls;

    // Рекомендация
    let act = { cls: 'act-hold', text: 'Цена в порядке', btn: '' };
    const minOther = others.length ? Math.min(...others) : null;
    if (p.alone) {
      act = { cls: 'act-alone', text: 'Конкурентов нет: держите цену', btn: '' };
    } else if (hasCost && econ.net_profit < 0) {
      act = { cls: 'act-loss', text: 'Продажа в минус: поднимите цену', btn: p.floor_min_price > p.sell_price ? `<button class="act-btn" onclick="window.applyTargetPrice('${escAttr(p.sku)}', ${p.floor_min_price})">До ${fmt(p.floor_min_price)} ₸</button>` : '' };
    } else if (bb.rank === 1 && bb.top2_price > p.sell_price + 15) {
      act = { cls: 'act-up', text: `Вы лидер: можно поднять до ${fmt(bb.top2_price - 10)} ₸`, btn: `<button class="act-btn" onclick="window.applyTargetPrice('${escAttr(p.sku)}', ${bb.top2_price - 10})">Поднять</button>` };
    } else if (!bb.is_in_buybox) {
      act = { cls: 'act-down', text: `Вне корзины: снизьте до ${fmt(bb.target_top3)} ₸`, btn: `<button class="act-btn" onclick="window.applyTargetPrice('${escAttr(p.sku)}', ${bb.target_top3})">Снизить</button>` };
    }

    // Лесенка цен: разброс цен продавцов и ваша точка
    let ladder = '';
    if (!p.alone && others.length) {
      const all = others.concat([p.sell_price]);
      const lo = Math.min(...all), hi = Math.max(...all), span = Math.max(hi - lo, 1);
      const pos = v => (4 + (v - lo) / span * 92).toFixed(1);
      ladder = `<div class="ladder" title="Цены продавцов на карточке. Синяя точка — ваша цена">` +
        others.slice(0, 40).map(v => `<i class="ld" style="left:${pos(v)}%"></i>`).join('') +
        `<i class="ld me" style="left:${pos(p.sell_price)}%"></i></div>`;
    }
    const diffPct = (minOther && minOther > 0) ? ((p.sell_price - minOther) / minOther * 100) : 0;
    const diffTxt = minOther ? (diffPct === 0 ? 'как у лучшего' : `${diffPct > 0 ? '+' : ''}${diffPct.toFixed(1)}% к лучшей`) : '';

    tr.innerHTML = `
      <td class="c-prod"><div class="prod-cell">
        <img class="thumb-img" src="${p.img ? escAttr(p.img) : photoPlaceholder(p.title)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.onerror=null;this.src=this.dataset.ph" data-ph="${photoPlaceholder(p.title)}">
        <div class="prod-info">
          <div class="prod-title" title="${escAttr(p.title)}">${escHtml(p.title)}</div>
          <div class="prod-meta"><span class="sku">${escHtml(p.sku)}</span><span>${escHtml(p.category)}</span>${p.stock_est ? '' : `<span>остаток ${p.stock} шт</span>`}</div>
          <div class="prod-meta">закупка: <span class="sup-links"><a href="${p.supplier_links.url_1688}" target="_blank" rel="noopener noreferrer" class="sup-mini" title="Поиск на 1688">1688</a><a href="${p.supplier_links.url_ozon}" target="_blank" rel="noopener noreferrer" class="sup-mini" title="Поиск на Ozon">Ozon</a><a href="${p.supplier_links.url_wb}" target="_blank" rel="noopener noreferrer" class="sup-mini" title="Поиск на Wildberries">WB</a></span></div>
        </div>
      </div></td>
      <td class="c-price">
        <div class="price-row-inline">
          <input type="number" class="price-input-inline" value="${p.sell_price}" data-sku="${escAttr(p.sku)}" title="Измените цену и нажмите Enter">
          <span class="cur">₸</span>
        </div>
        <select class="delivery-select-inline in-cell ${p.delivery_type}" data-sku="${escAttr(p.sku)}">
          ${buildDeliveryOptionsHtml(delVal, pDays)}
        </select>
        ${p.floor_min_price > 0 ? `<div class="floor-note" title="Защита минимальной маржи 15%">🛡 пол ${fmt(p.floor_min_price)} ₸</div>` : ''}
      </td>
      <td class="c-cost">
        <div class="cost-input-wrap">
          <input type="number" class="cost-input-inline${hasCost ? '' : ' cost-empty'}" value="${hasCost ? p.cost_price : ''}" placeholder="Не указана" data-sku="${escAttr(p.sku)}" title="Введите себестоимость закупки и нажмите Enter">
          <span class="cur">₸</span>
        </div>
        ${hasCost ? '' : '<div class="est-note" style="color:var(--text-muted);font-size:11px;">введите закупку</div>'}
      </td>
      <td class="c-profit">
        ${hasCost ? `
          <div class="profit-big ${econ.net_profit < 0 ? 'neg' : 'pos'}">${econ.net_profit > 0 ? '+' : ''}${fmt(econ.net_profit)} ₸</div>
          <div class="profit-sub"><span class="status-badge-profit ${econ.badge_class}">${econ.margin_pct}%</span><span title="Комиссия Kaspi, Kaspi Pay, налог и доставка">расходы ${fmt(econ.kaspi_deductions)} ₸</span></div>
        ` : `
          <div class="profit-big neutral" style="font-size:13.5px;font-weight:600;color:var(--text-main);" title="К выплате от Kaspi после вычета комиссий и официальной Kaspi Доставки (${fmt(econ.delivery_kzt)} ₸)">К выплате: ${fmt(econ ? econ.kaspi_payout : (p.sell_price - econ.kaspi_deductions))} ₸</div>
          <div class="profit-sub"><span class="status-badge-profit neutral" style="background:#f1f5f9;color:#64748b;border:1px solid #e2e8f0;padding:2px 6px;border-radius:4px;font-size:11px;">Не указана</span><span title="Комиссия Kaspi ${fmt(econ.comm_kzt)} ₸ (${econ.comm_rate}%), Kaspi Pay ${fmt(econ.pay_kzt)} ₸ (0.95%), налог ИП ${fmt(econ.tax_kzt)} ₸ (3%), доставка Kaspi ${fmt(econ.delivery_kzt)} ₸ (${econ.delivery_tier}), упаковка ${fmt(econ.pack_kzt)} ₸">вычеты ${fmt(econ ? econ.kaspi_deductions : 0)} ₸</span></div>
        `}
      </td>
      <td class="c-comp">
        <div class="buybox-badge ${bb.badge_class}" title="${escAttr(bb.advice || '')}">${bb.label}</div>
        ${p.alone ? '<div class="comp-line">Других продавцов нет</div>' : `${ladder}<div class="comp-line">${minOther ? `лучшая ${fmt(minOther)} ₸ · ${diffTxt}` : ''}<br>${p.competitors_count - 1} конкурент(ов)</div>`}
        ${!p.alone ? `<button class="btn btn-xs btn-outline-comp" onclick="window.openCompetitorsModal('${escAttr(p.card_code || '')}', '${escAttr(p.sku)}', '${escAttr(p.title)}')">🔍 Продавцы (${Math.max(1, p.competitors_count - 1)})</button>` : ''}
      </td>
      <td class="c-act">
        <div class="act-chip ${act.cls}" title="${escAttr(p.advice || '')}">${act.text}</div>
        ${act.btn}
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Attach inline edit handlers for Prices
  document.querySelectorAll('.price-input-inline').forEach(inp => {
    inp.addEventListener('change', async (e) => {
      const sku = e.target.dataset.sku;
      const newPrice = parseFloat(e.target.value) || 0;
      await updateSellPrice(sku, newPrice);
    });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') e.target.blur();
    });
  });

  // Attach inline edit handlers for Costs
  document.querySelectorAll('.cost-input-inline').forEach(inp => {
    inp.addEventListener('change', async (e) => {
      const sku = e.target.dataset.sku;
      const newCost = parseFloat(e.target.value) || 0;
      await updateCostPrice(sku, newCost);
    });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') e.target.blur();
    });
  });

  // Attach inline delivery selector
  document.querySelectorAll('.delivery-select-inline').forEach(sel => {
    sel.addEventListener('change', async (e) => {
      const sku = e.target.dataset.sku;
      const val = e.target.value;
      let delType = 'in_stock';
      let preDays = 0;
      if (val.startsWith('preorder_')) {
        delType = 'preorder';
        preDays = parseInt(val.replace('preorder_', '')) || 7;
      } else if (val === 'archive') {
        delType = 'archive';
        preDays = 0;
      }
      await updateDeliveryType(sku, delType, preDays);
    });
  });
}

// Render Apple-Style Pagination Controls (Smooth 8000+ item navigation)
function renderStorePagination(total, totalPages, startIdx, endIdx) {
  const rangeEl = document.getElementById('storePageRange');
  const countEl = document.getElementById('storeTotalCount');
  const navEl = document.getElementById('storePaginationNav');
  const barEl = document.getElementById('storePaginationBar');

  if (rangeEl) rangeEl.innerText = total === 0 ? '0–0' : `${(startIdx + 1).toLocaleString()}–${endIdx.toLocaleString()}`;
  if (countEl) countEl.innerText = total.toLocaleString();

  if (!barEl || !navEl) return;
  if (total <= storePageSize) {
    navEl.innerHTML = '';
    return;
  }

  let html = '';
  // Prev button
  html += `<button class="pagination-btn" ${storeCurrentPage === 1 ? 'disabled' : ''} onclick="changeStorePage(${storeCurrentPage - 1})" title="Предыдущая страница">‹ Назад</button>`;

  // Calculate visible page buttons (compact window)
  const pages = [];
  pages.push(1);
  if (storeCurrentPage > 3) pages.push('...');
  for (let p = Math.max(2, storeCurrentPage - 2); p <= Math.min(totalPages - 1, storeCurrentPage + 2); p++) {
    pages.push(p);
  }
  if (storeCurrentPage < totalPages - 2) pages.push('...');
  if (totalPages > 1) pages.push(totalPages);

  pages.forEach(p => {
    if (p === '...') {
      html += `<span class="pagination-dots">…</span>`;
    } else {
      const active = (p === storeCurrentPage) ? 'active' : '';
      html += `<button class="pagination-btn ${active}" onclick="changeStorePage(${p})">${p}</button>`;
    }
  });

  // Next button
  html += `<button class="pagination-btn" ${storeCurrentPage === totalPages ? 'disabled' : ''} onclick="changeStorePage(${storeCurrentPage + 1})" title="Следующая страница">Вперед ›</button>`;

  navEl.innerHTML = html;
}

window.changeStorePage = function(newPage) {
  storeCurrentPage = newPage;
  filterAndRenderStoreTable();
  const card = document.querySelector('.table-card');
  if (card) {
    card.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
};

// Window function for quick Top-1 / Top-2 / Top-3 button clicks
window.applyTargetPrice = async function(sku, targetPrice) {
  showToast(`Установка цены ${targetPrice.toLocaleString()} ₸ для входа в корзину...`);
  await updateSellPrice(sku, targetPrice);
};

// Modal: Inspect all competitor merchants on a specific Kaspi card
window.openCompetitorsModal = async function(cardCode, sku, title) {
  const modal = document.getElementById('competitorsModal');
  const titleEl = document.getElementById('compModalTitle');
  const subEl = document.getElementById('compModalSubtitle');
  const loading = document.getElementById('compModalLoading');
  const content = document.getElementById('compModalContent');
  const tbody = document.getElementById('compModalTableBody');

  if (titleEl) titleEl.innerText = `Конкуренты Kaspi · Арт: ${sku}`;
  if (subEl) subEl.innerText = title || '';
  if (loading) loading.style.display = 'block';
  if (content) content.style.display = 'none';
  if (tbody) tbody.innerHTML = '';
  modal.classList.add('open');

  try {
    const res = await fetch(`/api/kaspi/competitors_detail?card_code=${encodeURIComponent(cardCode)}&sku=${encodeURIComponent(sku)}`);
    const data = await res.json();
    if (data.success && data.offers && data.offers.length) {
      tbody.innerHTML = '';
      data.offers.forEach((o, i) => {
        const tr = document.createElement('tr');
        const isMin = (i === 0);
        const compPrice = o.price || 0;
        tr.innerHTML = `
          <td style="color: var(--text-muted); text-align: center;">${i + 1}</td>
          <td>
            <div style="font-weight: 600;">${escHtml(o.merchant || 'Продавец Kaspi')}</div>
            ${isMin ? '<span class="badge" style="background:#DCFCE7; color:#16A34A; font-size:10px; margin-top:2px;">★ Лидер BuyBox</span>' : ''}
          </td>
          <td style="text-align: center;"><span class="rating-pill">★ 4.8</span></td>
          <td><strong>${compPrice.toLocaleString()} ₸</strong></td>
          <td>
            <span class="badge" style="font-size: 11px;">
              ${o.kaspi_delivery ? '⚡ Kaspi Доставка' : '📦 Доставка продавца'}
            </span>
          </td>
          <td>
            <button class="btn btn-xs btn-accent" style="white-space: nowrap;" onclick="window.applyTargetPrice('${escAttr(sku)}', ${compPrice - 10}); document.getElementById('competitorsModal').classList.remove('open');">
              Ниже на 10 ₸
            </button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } else {
      // Fallback: show known prices from storeData
      const prod = storeData.products.find(x => x.sku === sku);
      const prices = (prod && prod.competitor_prices) ? prod.competitor_prices : [];
      if (prices.length > 0) {
        tbody.innerHTML = '';
        prices.forEach((pr, i) => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td style="color: var(--text-muted); text-align: center;">${i + 1}</td>
            <td><div style="font-weight: 600;">Конкурент #${i + 1}</div></td>
            <td style="text-align: center;"><span class="rating-pill">★ 4.8</span></td>
            <td><strong>${pr.toLocaleString()} ₸</strong></td>
            <td><span class="badge">Kaspi Доставка</span></td>
            <td>
              <button class="btn btn-xs btn-accent" style="white-space: nowrap;" onclick="window.applyTargetPrice('${escAttr(sku)}', ${pr - 10}); document.getElementById('competitorsModal').classList.remove('open');">
                Ниже на 10 ₸
              </button>
            </td>
          `;
          tbody.appendChild(tr);
        });
      } else {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 24px; color: var(--text-muted);">
          Нет активных конкурентов на карточке или товар продаётся эксклюзивно вами.
        </td></tr>`;
      }
    }
  } catch (err) {
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 24px; color: #DC2626;">Ошибка загрузки конкурентов: ${escHtml(err.message)}</td></tr>`;
    }
  } finally {
    if (loading) loading.style.display = 'none';
    if (content) content.style.display = 'block';
  }
};

// Lightbox modal for Kaspi mobile camera scanning and Google Lens visual search
window.openImagePreview = function(imgUrl, title) {
  const modal = document.getElementById('imagePreviewModal');
  const img = document.getElementById('imgModalPreview');
  const lensBtn = document.getElementById('imgModalLensBtn');
  const titleEl = document.getElementById('imgModalTitle');

  if (img) img.src = imgUrl;
  if (titleEl) titleEl.innerText = title ? title.slice(0, 40) + '...' : 'Скан товара';
  if (lensBtn) lensBtn.href = `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(imgUrl)}`;
  modal?.classList.add('open');
};

// 1-Click Live Vacuum Check on Kaspi via backend analyzer
window.testKaspiVacuum = async function(itemId, btn) {
  const it = currentItems.find(x => x.id === itemId);
  if (!it) return;
  const resDiv = document.getElementById(`vacuum-res-${itemId}`);
  if (!resDiv) return;

  const originalHtml = btn.innerHTML;
  btn.innerHTML = '⏳ Проверка...';
  btn.disabled = true;

  try {
    const res = await fetch('/api/check_vacuum', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: it.name || it.kaspi_name || '',
        query: it.kaspi_search_query || ''
      })
    });
    const data = await res.json();
    if (data.success && data.result) {
      const r = data.result;
      resDiv.style.display = 'block';
      if (r.vacuum_status === 'vacuum_full') {
        resDiv.innerHTML = `
          <div style="background: rgba(22, 163, 74, 0.08); border: 1px solid rgba(22, 163, 74, 0.25); border-radius: 6px; padding: 6px 10px; color: #15803D; margin-top: 4px;">
            <div style="font-weight: 700;">🟢 100% ВАКУУМ НА KASPI: точных предложений нет!</div>
            <div style="color: #4B5563; margin-top: 2px;">
              ${r.replacement_title ? `Kaspi выдает не этот товар, а заменитель: <i>«${r.replacement_title.slice(0, 40)}...» (${r.replacement_price ? r.replacement_price.toLocaleString() + ' ₸' : ''})</i>. Ниша свободна!` : 'На Kaspi 0 совпадений. Свободная ниша!'}
            </div>
          </div>
        `;
      } else if (r.vacuum_status === 'vacuum_low_competition') {
        resDiv.innerHTML = `
          <div style="background: rgba(234, 179, 8, 0.1); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 6px; padding: 6px 10px; color: #B45309; margin-top: 4px;">
            <div style="font-weight: 700;">🟡 СЛАБАЯ КОНКУРЕНЦИЯ: всего ${r.exact_matches} продавец на Kaspi!</div>
            <div style="color: #4B5563; margin-top: 2px;">
              Топ-предложение: <i>«${(r.competitor_title || '').slice(0, 40)}...»</i> (${r.competitor_price ? r.competitor_price.toLocaleString() + ' ₸' : ''}). Отличная маржа для предзаказа!
            </div>
          </div>
        `;
      } else if (r.vacuum_status === 'saturated') {
        resDiv.innerHTML = `
          <div style="background: rgba(220, 38, 38, 0.08); border: 1px solid rgba(220, 38, 38, 0.25); border-radius: 6px; padding: 6px 10px; color: #B91C1C; margin-top: 4px;">
            <div style="font-weight: 700;">🔴 НИША ЗАНЯТА: ${r.exact_matches}+ продавцов на Kaspi</div>
            <div style="color: #4B5563; margin-top: 2px;">
              Цена конкурента от ${r.competitor_price ? r.competitor_price.toLocaleString() + ' ₸' : ''}. Рекомендуется выбрать другой товар.
            </div>
          </div>
        `;
      } else {
        resDiv.innerHTML = `<div style="color: #6B7280; margin-top: 4px;">${r.explanation || 'Проверка завершена'}</div>`;
      }
    } else {
      showToast('Не удалось получить ответ от поисковика Kaspi');
    }
  } catch (err) {
    showToast('Ошибка проверки: ' + err.message);
  } finally {
    btn.innerHTML = originalHtml;
    btn.disabled = false;
  }
};

async function updateSellPrice(sku, newPrice) {
  newPrice = parseFloat(newPrice) || 0;
  if (newPrice <= 0) return;

  // 1. Optimistic in-memory update (0ms latency, zero lag!)
  let prevPrice = 0;
  if (storeData && storeData.products) {
    const prod = storeData.products.find(x => x.sku === sku);
    if (prod) {
      prevPrice = prod.sell_price;
      prod.sell_price = newPrice;
      recalculateProductInMemory(prod);
      refreshStoreTotalsInMemory();
      renderStoreDashboard();
      filterAndRenderStoreTable();
    }
  }

  showToast(`✓ Цена сохранена в программе: ${newPrice.toLocaleString('ru-RU')} ₸.`);

  // 2. Asynchronous background persistence to server
  try {
    const res = await fetch('/api/kaspi/update_price', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sku: sku, sell_price: newPrice })
    });
    const data = await res.json();
    if (data.success && window.pushOfferToKaspi) window.pushOfferToKaspi(sku, { price: newPrice });
    if (!data.success) {
      showToast('⚠️ Ошибка сохранения цены: ' + (data.error || ''));
      if (prevPrice > 0 && storeData && storeData.products) {
        const prod = storeData.products.find(x => x.sku === sku);
        if (prod) {
          prod.sell_price = prevPrice;
          recalculateProductInMemory(prod);
          refreshStoreTotalsInMemory();
          renderStoreDashboard();
          filterAndRenderStoreTable();
        }
      }
    }
  } catch (err) {
    showToast('⚠️ Ошибка сети при обновлении цены');
  }
}

async function updateCostPrice(sku, newCost) {
  newCost = parseFloat(newCost) || 0;

  // 1. Optimistic in-memory update (0ms latency, zero lag!)
  if (storeData && storeData.products) {
    const prod = storeData.products.find(x => x.sku === sku);
    if (prod) {
      prod.cost_price = newCost;
      prod.cost_est = false;
      recalculateProductInMemory(prod);
      refreshStoreTotalsInMemory();
      renderStoreDashboard();
      filterAndRenderStoreTable();
    }
  }

  showToast(`✓ Себестоимость сохранена: ${newCost.toLocaleString('ru-RU')} ₸. Маржа пересчитана!`);

  // 2. Asynchronous background persistence to server
  try {
    const res = await fetch('/api/kaspi/update_cost', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sku: sku, cost_price: newCost })
    });
    const data = await res.json();
    if (!data.success) {
      showToast('⚠️ Ошибка сохранения себестоимости: ' + (data.error || ''));
    }
  } catch (err) {
    showToast('⚠️ Ошибка сети при сохранении себестоимости');
  }
}

async function updateDeliveryType(sku, deliveryType, preorderDays) {
  preorderDays = parseInt(preorderDays, 10) || 0;

  // 1. Optimistic in-memory update (0ms latency, zero lag!)
  if (storeData && storeData.products) {
    const prod = storeData.products.find(x => x.sku === sku);
    if (prod) {
      prod.delivery_type = deliveryType;
      prod.preorder_days = preorderDays;
      if (deliveryType === 'archive') {
        prod.delivery_label = '🚫 Снят с продажи';
        prod.stock = 0;
      } else if (deliveryType === 'in_stock') {
        prod.delivery_label = 'В наличии';
      } else {
        prod.delivery_label = `Под заказ (${preorderDays}д)`;
      }
      refreshStoreTotalsInMemory();
      renderStoreDashboard();
      filterAndRenderStoreTable();
    }
  }

  if (deliveryType === 'archive') {
    showToast('🚫 Снят с продажи в программе.');
  } else {
    const statusTxt = deliveryType === 'in_stock' ? '🟢 В наличии' : `⏳ Предзаказ (${preorderDays} дн)`;
    showToast(`✓ Статус сохранён в программе: ${statusTxt}.`);
  }

  // 2. Asynchronous background persistence to server
  try {
    const res = await fetch('/api/kaspi/update_delivery', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sku: sku, delivery_type: deliveryType, preorder_days: preorderDays })
    });
    const data = await res.json();
    if (data.success && window.pushOfferToKaspi) window.pushOfferToKaspi(sku, { mode: deliveryType, preorder_days: preorderDays });
    if (!data.success) {
      showToast('⚠️ Ошибка сохранения срока поставки: ' + (data.error || ''));
    }
  } catch (err) {
    showToast('⚠️ Ошибка сети при сохранении типа поставки');
  }
}

// Setup Store Events
function setupStoreEvents() {
  document.getElementById('btnRefreshStore')?.addEventListener('click', () => {
    showToast('Обновление остатков и позиций BuyBox...');
    loadKaspiStore();
  });

  // Live competitors sync button
  document.getElementById('btnSyncCompetitors')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnSyncCompetitors');
    btn.disabled = true;
    const oldHtml = btn.innerHTML;
    btn.innerHTML = `<span class="spinner-inline"></span> <span>Сканирование Kaspi...</span>`;
    showToast('⚡ Запущено онлайн-сканирование живых цен Kaspi...');
    try {
      const res = await fetch('/api/kaspi/refresh_competitors', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        showToast('✓ Сканирование цен Kaspi запущено в фоне! Обновление...');
        setTimeout(async () => {
          await loadKaspiStore();
          showToast('✓ Витрина актуализирована живыми ценами Kaspi!');
        }, 3000);
      } else {
        showToast('Ошибка запуска сканирования цен');
      }
    } catch (err) {
      showToast('Ошибка связи с сервером');
    } finally {
      setTimeout(() => {
        btn.disabled = false;
        btn.innerHTML = oldHtml;
      }, 3500);
    }
  });

  document.getElementById('btnExportXml')?.addEventListener('click', () => {
    showToast('Генерация XML-прайса для Kaspi Pay...');
    window.location.href = '/api/kaspi/export_xml';
  });

  document.getElementById('btnExportPrices')?.addEventListener('click', () => {
    showToast('Формирование файла обновления цен и предзаказа для Kaspi Pay...');
    window.location.href = '/api/kaspi/export_prices';
  });

  document.querySelectorAll('.store-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.store-filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeStoreFilter = btn.dataset.filter;
      storeCurrentPage = 1;
      filterAndRenderStoreTable();
    });
  });

  document.getElementById('storeSearchInput')?.addEventListener('input', () => {
    storeCurrentPage = 1;
    filterAndRenderStoreTable();
  });

  document.getElementById('storePageSizeSelect')?.addEventListener('change', (e) => {
    storePageSize = parseInt(e.target.value) || 50;
    storeCurrentPage = 1;
    filterAndRenderStoreTable();
  });

  document.getElementById('btnRunRepricer')?.addEventListener('click', () => {
    showToast('⚡️ Запуск Авто-репрайсера по всей базе товаров...');
    saveRepricerConfig(true);
  });

  ['repricerStrategy', 'repricerMinMargin', 'repricerUndercut'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', () => {
      saveRepricerConfig(false);
    });
  });

  // Kaspi Excel price list upload
  document.getElementById('kaspiExcelFileInput')?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);
    showToast('Импорт прайс-листа Kaspi...');
    try {
      // XML / CSV (например ACTIVE.xml из кабинета) идут в общий разбор прайс-листов
      if (/\.(xml|csv)$/i.test(file.name)) {
        const r = await (await fetch('/api/kaspi/import_file', { method: 'POST', body: formData })).json();
        if (r.success) {
          showToast(`🎉 Загружено товаров: ${r.count}`);
          await loadKaspiStore();
        } else {
          alert(r.error || 'Не удалось прочитать файл');
        }
        return;
      }
      const res = await fetch('/api/kaspi/upload_excel', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (data.success) {
        showToast(`🎉 Успешно! Добавлено ${data.imported_count} товаров из вашего прайс-листа!`);
        await loadKaspiStore();
      } else {
        showToast(`Ошибка импорта: ${data.error || 'Неверный формат'}`);
      }
    } catch (err) {
      showToast('Ошибка при загрузке прайс-листа');
    } finally {
      e.target.value = '';
    }
  });
}

// Setup Modals
function setupModalEvents() {
  // License Modal
  const licModal = document.getElementById('licenseModal');
  const btnOpenLic = document.getElementById('btnSidebarActivate');
  const btnCloseLic = document.getElementById('btnCloseLicenseModal');
  const btnCancelLic = document.getElementById('btnCancelLicenseModal');
  const btnSubmitLic = document.getElementById('btnSubmitActivation');

  btnOpenLic?.addEventListener('click', () => {
    licModal.classList.add('open');
  });

  [btnCloseLic, btnCancelLic].forEach(btn => {
    btn?.addEventListener('click', () => licModal.classList.remove('open'));
  });

  btnSubmitLic?.addEventListener('click', async () => {
    const key = document.getElementById('modalLicenseInput').value.trim();
    if (!key) {
      showToast('Пожалуйста, введите ключ активации');
      return;
    }
    btnSubmitLic.disabled = true;
    btnSubmitLic.innerText = 'Проверка...';

    try {
      const res = await fetch('/api/license/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: key })
      });
      const data = await res.json();
      if (data.success) {
        showToast('🎉 PRO Лицензия успешно активирована! Все функции разблокированы');
        licModal.classList.remove('open');
        checkLicenseStatus();
      } else {
        showToast(`Ошибка: ${data.error || 'Неверный ключ активации'}`);
      }
    } catch (err) {
      showToast('Ошибка проверки ключа');
    } finally {
      btnSubmitLic.disabled = false;
      btnSubmitLic.innerText = 'Активировать PRO';
    }
  });

  // Kaspi Connect Modal
  const kaspiModal = document.getElementById('kaspiModal');
  const btnOpenKaspi = document.getElementById('btnOpenKaspiModal');
  const btnCloseKaspi = document.getElementById('btnCloseKaspiModal');
  const btnCancelKaspi = document.getElementById('btnCancelKaspiModal');
  const btnSaveKaspi = document.getElementById('btnSaveKaspiApi');

  btnOpenKaspi?.addEventListener('click', () => {
    document.getElementById('modalKaspiToken').value = appConfig.kaspi_api_token || '';
    document.getElementById('modalKaspiMerchantId').value = appConfig.kaspi_merchant_id || '';
    kaspiModal.classList.add('open');
  });

  [btnCloseKaspi, btnCancelKaspi].forEach(btn => {
    btn?.addEventListener('click', () => kaspiModal.classList.remove('open'));
  });

  btnSaveKaspi?.addEventListener('click', async () => {
    const token = document.getElementById('modalKaspiToken').value.trim();
    const merchantId = document.getElementById('modalKaspiMerchantId').value.trim();
    
    btnSaveKaspi.disabled = true;
    btnSaveKaspi.innerText = 'Подключение...';

    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kaspi_api_token: token,
          kaspi_merchant_id: merchantId
        })
      });
      const data = await res.json();
      if (data.success) {
        appConfig = data.config;
        showToast('✓ Ключ Kaspi сохранён! Загрузка данных магазина...');
        kaspiModal.classList.remove('open');
        loadKaspiStore();
      }
    } catch (err) {
      showToast('Ошибка сохранения настроек');
    } finally {
      btnSaveKaspi.disabled = false;
      btnSaveKaspi.innerText = 'Сохранить и загрузить товары';
    }
  });

  // Add Product by Kaspi Link Modal
  const addModal = document.getElementById('addKaspiModal');
  const btnOpenAdd = document.getElementById('btnOpenAddKaspiModal');
  const btnCloseAdd = document.getElementById('btnCloseAddKaspiModal');
  const btnCancelAdd = document.getElementById('btnCancelAddKaspiModal');
  const btnSubmitAdd = document.getElementById('btnSubmitAddKaspi');

  btnOpenAdd?.addEventListener('click', () => {
    document.getElementById('addKaspiInputUrl').value = '';
    document.getElementById('addKaspiCostPrice').value = '';
    document.getElementById('addKaspiSellPrice').value = '';
    addModal.classList.add('open');
  });

  [btnCloseAdd, btnCancelAdd].forEach(btn => {
    btn?.addEventListener('click', () => addModal.classList.remove('open'));
  });

  btnSubmitAdd?.addEventListener('click', async () => {
    const url = document.getElementById('addKaspiInputUrl').value.trim();
    if (!url) {
      showToast('Пожалуйста, введите ссылку или артикул Kaspi');
      return;
    }

    const delVal = document.getElementById('addKaspiDeliveryType').value;
    let delType = 'in_stock';
    let preDays = 0;
    if (delVal.startsWith('preorder')) {
      delType = 'preorder';
      preDays = parseInt(delVal.replace('preorder_', '')) || 7;
    }

    const cost = parseFloat(document.getElementById('addKaspiCostPrice').value) || null;
    const price = parseFloat(document.getElementById('addKaspiSellPrice').value) || null;

    btnSubmitAdd.disabled = true;
    btnSubmitAdd.innerText = 'Добавление...';

    try {
      const res = await fetch('/api/kaspi/add_by_url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: url,
          delivery_type: delType,
          preorder_days: preDays,
          cost_price: cost,
          sell_price: price
        })
      });
      const data = await res.json();
      if (data.success) {
        showToast('✓ Товар успешно добавлен в дашборд!');
        addModal.classList.remove('open');
        loadKaspiStore();
      } else {
        showToast(`Ошибка: ${data.error || 'Не удалось распознать товар'}`);
      }
    } catch (err) {
      showToast('Ошибка при добавлении товара');
    } finally {
      btnSubmitAdd.disabled = false;
      btnSubmitAdd.innerText = 'Добавить карточку';
    }
  });

  // Competitors Modal
  const compModal = document.getElementById('competitorsModal');
  const btnCloseComp = document.getElementById('btnCloseCompModal');
  const btnCloseCompBtn = document.getElementById('btnCloseCompModalBtn');
  [btnCloseComp, btnCloseCompBtn].forEach(btn => {
    btn?.addEventListener('click', () => compModal?.classList.remove('open'));
  });

  // Repricer Logs Modal
  const repricerModal = document.getElementById('repricerLogsModal');
  const btnCloseRepricer = document.getElementById('btnCloseRepricerLogs');
  const btnCloseRepricerBtn = document.getElementById('btnCloseRepricerLogsBtn');
  [btnCloseRepricer, btnCloseRepricerBtn].forEach(btn => {
    btn?.addEventListener('click', () => repricerModal?.classList.remove('open'));
  });

  // Image Preview & Kaspi Scan Modal
  const imgModal = document.getElementById('imagePreviewModal');
  const btnCloseImg = document.getElementById('btnCloseImgModal');
  btnCloseImg?.addEventListener('click', () => imgModal?.classList.remove('open'));

  // Global ESC key and backdrop click to close any open modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-backdrop.open').forEach(m => m.classList.remove('open'));
    }
  });

  document.querySelectorAll('.modal-backdrop').forEach(b => {
    b.addEventListener('click', (e) => {
      if (e.target === b) {
        b.classList.remove('open');
      }
    });
  });
}

// Setup Event Listeners (WB Radar & Settings)
function setupEventListeners() {
  // Category Quick Pills
  document.querySelectorAll('.pill-btn').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.pill-btn').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      document.getElementById('scanQuery').value = pill.dataset.query;
      document.getElementById('btnStartScan').click();
    });
  });

  // Table filter
  document.getElementById('tableFilterInput')?.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase().trim();
    if (!q) {
      renderTable(currentItems);
      return;
    }
    const filtered = currentItems.filter(it => 
      (it.kaspi_name || it.name || '').toLowerCase().includes(q) ||
      (it.brand || '').toLowerCase().includes(q)
    );
    renderTable(filtered);
    document.getElementById('tableFilterCount').innerText = `${filtered.length} найдено`;
  });

  // Start Scan
  document.getElementById('btnStartScan')?.addEventListener('click', async () => {
    const query = document.getElementById('scanQuery').value.trim();
    const limit = document.getElementById('scanLimit').value;
    const minFeedbacks = document.getElementById('scanMinFeedbacks').value;
    const btn = document.getElementById('btnStartScan');
    btn.disabled = true;
    btn.innerText = 'Сканирование...';
    showToast(`Поиск хитов по запросу «${query}» (${limit} карточек)...`);

    try {
      const res = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, limit, min_feedbacks: minFeedbacks })
      });
      const data = await res.json();
      if (data.success) {
        currentItems = data.items || [];
        renderTable(currentItems);
        updateKpis(currentItems);
        showToast(`База обновлена: всего ${currentItems.length} товаров! Новых: ${data.added ?? 0}`);
      } else {
        alert((data.error || 'Поиск не удался') + ' Показаны ранее сохранённые карточки.');
      }
    } catch (err) {
      showToast('Ошибка при сканировании');
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg><span>Найти вакуум</span>`;
    }
  });

  // Sync WB Prices (Price Guard)
  document.getElementById('btnSyncWbPrices')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnSyncWbPrices');
    btn.disabled = true;
    btn.innerHTML = `<span>Проверка цен WB...</span>`;
    showToast('Синхронизация актуальных цен и остатков с серверами Wildberries...');

    try {
      const res = await fetch('/api/sync_wb_prices', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        currentItems = data.items || currentItems;
        renderTable(currentItems);
        showToast(`✓ Готово! Обновлено цен: ${data.updated_prices}, закончилось на WB: ${data.out_of_stock}`);
      }
    } catch (err) {
      showToast('Ошибка синхронизации с WB');
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg><span>Контроль цен WB</span>`;
    }
  });

  // Download Excel with custom export options
  const downloadHandler = () => {
    const days = document.getElementById('exportPreorderDays')?.value || 7;
    const photoMode = document.getElementById('exportPhotoMode')?.value || 'infographic';
    const descMode = document.getElementById('exportDescMode')?.value || 'ai_copywriter';
    showToast(`Формирование Excel (предзаказ ${days} дн, фото: ${photoMode})...`);
    window.location.href = `/api/export?preorder_days=${days}&photo_mode=${photoMode}&desc_mode=${descMode}`;
  };

  document.getElementById('btnDownloadExcel')?.addEventListener('click', downloadHandler);
  document.getElementById('btnQuickExport')?.addEventListener('click', downloadHandler);

  // Settings Save
  document.getElementById('settingsForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const cfg = {
      royaltech_api_key: document.getElementById('cfgRoyaltechKey').value.trim(),
      kaspi_merchant_id: document.getElementById('cfgKaspiId').value.trim(),
      kaspi_api_token: document.getElementById('cfgKaspiToken').value.trim(),
      kaspi_delivery_mode: (document.getElementById('cfgKaspiDeliveryMode') ? document.getElementById('cfgKaspiDeliveryMode').value : 'official_kz'),
      kaspi_delivery_cost_kzt: (document.getElementById('cfgKaspiDeliveryCost') ? parseInt(document.getElementById('cfgKaspiDeliveryCost').value) : 1507) || 1507,
      margin_multiplier: parseFloat(document.getElementById('cfgMarginMultiplier').value) || 2.4,
      packaging_cost_kzt: parseInt(document.getElementById('cfgPackagingCost').value) || 150
    };
    
    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg)
      });
      const data = await res.json();
      if (data.success) {
        appConfig = data.config;
        showToast('✓ Настройки успешно сохранены!');
        checkApiStatus();
      }
    } catch (err) {
      showToast('Ошибка сохранения настроек');
    }
  });

  // Test API
  document.getElementById('btnTestApi')?.addEventListener('click', () => {
    checkApiStatus();
    showToast('Проверка связи с NanoBanana...');
  });
}

// Загрузка всего каталога из прайс-листа Kaspi (xlsx / csv / xml)
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('btnImportMyProducts');
  const inp = document.getElementById('importPriceFile');
  const clr = document.getElementById('btnClearImport');
  const costInp = document.getElementById('costFileInput');
  if (costInp) {
    costInp.addEventListener('change', async () => {
      if (!costInp.files.length) return;
      const fd = new FormData();
      fd.append('file', costInp.files[0]);
      try {
        const r = await (await fetch('/api/kaspi/import_costs', { method: 'POST', body: fd })).json();
        if (r.success) { showToast(`Себестоимость обновлена у товаров: ${r.count}`); loadKaspiStore(); }
        else alert(r.error || 'Не удалось прочитать файл');
      } catch (e) { alert('Ошибка загрузки файла: ' + e); }
      costInp.value = '';
    });
  }
  if (btn && inp) {
    btn.addEventListener('click', () => inp.click());
    inp.addEventListener('change', async () => {
      if (!inp.files.length) return;
      const fd = new FormData();
      fd.append('file', inp.files[0]);
      try {
        const res = await fetch('/api/kaspi/import_file', { method: 'POST', body: fd });
        const r = await res.json();
        if (r.success) {
          showToast(`Загружено товаров: ${r.count}`);
          loadKaspiStore();
        } else {
          alert(r.error || 'Не удалось прочитать файл');
        }
      } catch (e) {
        alert('Ошибка загрузки файла: ' + e);
      }
      inp.value = '';
    });
  }
  if (clr) {
    clr.addEventListener('click', async () => {
      await fetch('/api/kaspi/import_clear', { method: 'POST' });
      loadKaspiStore();
    });
  }
});

// Toast
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.innerText = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3500);
}


// ==========================================================
// Автопилот репрайсера: статус, включение, ссылка на прайс
// ==========================================================
let _autopilotTimer = null;

function _feedFullUrl(path) {
  const base = (localStorage.getItem('publicBaseUrl') || '').replace(/\/$/, '');
  return (base || window.location.origin) + path;
}

async function loadAutopilot() {
  try {
    const res = await fetch('/api/autopilot');
    const d = await res.json();
    if (!d.success) return;
    const st = d.status || {};
    const en = document.getElementById('autopilotEnabled');
    const iv = document.getElementById('autopilotInterval');
    const state = document.getElementById('autopilotState');
    const meta = document.getElementById('autopilotMeta');
    const feed = document.getElementById('autopilotFeedUrl');
    if (en) en.checked = d.enabled;
    if (iv && document.activeElement !== iv) iv.value = String(d.interval_min);
    if (state) {
      state.className = 'autopilot-state';
      if (st.running) { state.textContent = 'идёт проверка…'; state.classList.add('on'); }
      else if (st.last_ok === false) { state.textContent = 'ошибка в прошлом цикле'; state.classList.add('err'); }
      else if (d.enabled) { state.textContent = d.next_run ? `ВКЛ · следующий запуск ≈ ${d.next_run}` : 'ВКЛ · первый запуск в течение минуты'; state.classList.add('on'); }
      else { state.textContent = 'ВЫКЛ'; }
    }
    if (meta) {
      const sk = st.skipped || {};
      let html = `Робот ведёт <b>${d.ready_count}</b> товар(ов) с вашей себестоимостью, из них с конкурентами: <b>${d.ready_with_competitors}</b>.`;
      if (st.last_run) {
        html += ` Последний цикл: ${st.last_run} — изменено ${st.repriced || 0}, на пороге маржи ${st.shielded || 0}, без изменений ${st.unchanged || 0}.`;
        if (sk.no_cost) html += ` <span class="autopilot-warn">Пропущено без себестоимости: ${sk.no_cost}.</span>`;
      }
      if (d.ready_count === 0) html += ' <span class="autopilot-warn">Укажите себестоимость у товаров (или загрузите файл себестоимости) — без неё робот цены не трогает.</span>';
      if (st.errors && st.errors.length) html += ` <span class="autopilot-warn">Ошибки: ${st.errors.slice(0, 3).join('; ')}</span>`;
      meta.innerHTML = html;
    }
    if (feed) feed.textContent = _feedFullUrl(d.feed_path);
  } catch (e) {
    console.error('autopilot status error', e);
  }
}

async function saveAutopilot() {
  const en = document.getElementById('autopilotEnabled')?.checked || false;
  const iv = parseInt(document.getElementById('autopilotInterval')?.value) || 30;
  await fetch('/api/kaspi/repricer', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ enabled: en, interval_min: iv })
  });
  showToast(en ? `Автопилот включён: каждые ${iv} мин` : 'Автопилот выключен');
  loadAutopilot();
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('autopilotEnabled')?.addEventListener('change', saveAutopilot);
  document.getElementById('autopilotInterval')?.addEventListener('change', saveAutopilot);
  document.getElementById('btnCopyFeed')?.addEventListener('click', async () => {
    const t = document.getElementById('autopilotFeedUrl')?.textContent || '';
    try { await navigator.clipboard.writeText(t); showToast('Ссылка скопирована'); } catch (e) { showToast(t); }
  });
  loadAutopilot();
  _autopilotTimer = setInterval(loadAutopilot, 20000);
});

// ==========================================================
// Карточки Kaspi из WB (официальный API Kaspi: /shop/api/products/import)
// ==========================================================
(function () {
  const RU = {
    'color': 'Цвет', 'material': 'Материал', 'type': 'Тип', 'length': 'Длина, см', 'width': 'Ширина, см', 'height': 'Высота, см',
    'depth': 'Глубина, см', 'weight': 'Вес', 'country': 'Страна производства', 'code': 'Артикул', 'vendor code': 'Артикул',
    'manufacturers code': 'Код производителя', 'features': 'Особенности', 'name': 'Наименование', 'gender': 'Пол', 'size': 'Размер',
    'quantity': 'Количество', 'amount in a package': 'Кол-во в упаковке', 'appointment': 'Назначение', 'form': 'Форма',
    'kit contents': 'Комплектация', 'additional information': 'Доп. информация', 'additional': 'Доп. информация',
    'dimensions': 'Габариты', 'installation': 'Установка', 'for whom': 'Для кого', 'diameter': 'Диаметр', 'head': 'Головка',
    'coating': 'Покрытие', 'components': 'Состав комплекта', 'peculiarities': 'Особенности', 'care instructions': 'Уход',
    'volume': 'Объём', 'purpose': 'Назначение', 'model': 'Модель', 'equipment': 'Комплектация', 'shape': 'Форма',
    'pattern': 'Рисунок', 'composition': 'Состав', 'age': 'Возраст', 'power': 'Мощность', 'capacity': 'Ёмкость',
  };
  const attrLabel = code => { const leaf = code.split('*').pop(); return RU[leaf.toLowerCase()] || leaf; };
  const STATUS = {
    draft: ['Черновик', '#64748B', '#F1F5F9'], sent: ['Загружается в Kaspi', '#B45309', '#FEF3C7'],
    accepted: ['На модерации Kaspi', '#B45309', '#FEF3C7'], error: ['Ошибка / отказ', '#B91C1C', '#FEE2E2'],
    selling: ['Выставляется в продажу', '#1D4ED8', '#DBEAFE'], on_sale: ['✓ В продаже на Kaspi', '#15803D', '#DCFCE7'],
  };
  const attrCache = {};
  let drafts = [];
  const sendSel = new Set();
  const esc = v => escHtml(v == null ? '' : String(v));

  async function api(url, body) {
    const res = await fetch(url, body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    return res.json();
  }
  async function categoryAttrs(cat) {
    if (!cat) return [];
    if (!attrCache[cat]) {
      const d = await api('/api/cards/attributes?c=' + encodeURIComponent(cat));
      attrCache[cat] = d.success ? d.attributes : [];
    }
    return attrCache[cat];
  }

  // ---------- Радар: выбор товаров и массовое создание ----------
  function updateRadarSel() {
    const n = radarSelected.size;
    const c = document.getElementById('cardsSelCount'); if (c) c.innerText = n;
    const b = document.getElementById('btnMakeCards'); if (b) b.disabled = n === 0;
  }
  document.addEventListener('change', e => {
    if (e.target.classList && e.target.classList.contains('radar-sel')) {
      const id = Number(e.target.dataset.id);
      e.target.checked ? radarSelected.add(id) : radarSelected.delete(id);
      updateRadarSel();
    }
    if (e.target.id === 'radarSelAll') {
      document.querySelectorAll('.radar-sel').forEach(cb => {
        cb.checked = e.target.checked; const id = Number(cb.dataset.id);
        e.target.checked ? radarSelected.add(id) : radarSelected.delete(id);
      });
      updateRadarSel();
    }
  });
  document.addEventListener('click', async e => {
    if (!(e.target.closest && e.target.closest('#btnMakeCards'))) return;
    const ids = [...radarSelected];
    if (!ids.length) return;
    const btn = document.getElementById('btnMakeCards');
    btn.disabled = true; const old = btn.innerHTML;
    let made = 0, failed = [];
    for (let i = 0; i < ids.length; i += 5) {          // пачками, чтобы видеть прогресс
      btn.innerHTML = `⏳ Готовлю: ${Math.min(i + 5, ids.length)} / ${ids.length}`;
      try {
        const d = await api('/api/cards/draft', { wb_ids: ids.slice(i, i + 5) });
        made += (d.drafts || []).length; failed = failed.concat(d.failed || []);
      } catch (err) { failed.push({ wb_id: '?', error: err.message }); }
    }
    btn.innerHTML = old; radarSelected.clear();
    document.querySelectorAll('.radar-sel, #radarSelAll').forEach(cb => cb.checked = false);
    updateRadarSel();
    showToast(`✓ Черновиков: ${made}` + (failed.length ? ` · не удалось: ${failed.length} (${failed[0].error})` : '') + '. Откройте вкладку «Карточки Kaspi из WB».');
    const tab = document.querySelector('.nav-item[data-tab="tab-cards"]'); if (tab && made) tab.click();
  });

  // ---------- Вкладка карточек ----------
  window.loadCards = async function () {
    const d = await api('/api/cards');
    if (!d.success) { showToast('Ошибка: ' + d.error); return; }
    drafts = d.drafts || [];
    render();
  };

  function render() {
    const list = document.getElementById('cardsList');
    const cnt = { draft: 0, ready: 0, sent: 0, accepted: 0, error: 0 };
    drafts.forEach(d => { cnt[d.status] = (cnt[d.status] || 0) + 1; if (!['sent','accepted','selling','on_sale'].includes(d.status) && !(d.problems || []).length) cnt.ready++; });
    const todo = drafts.filter(d => !['sent','accepted','selling','on_sale'].includes(d.status) && (d.problems || []).length).length;
    document.getElementById('cardsStats').innerHTML =
      `<span>Всего: <b>${drafts.length}</b></span><span>Готовы к отправке: <b style="color:#15803D">${cnt.ready}</b></span>` +
      `<span>Нужно дозаполнить: <b style="color:#B45309">${todo}</b></span>` +
      `<span>На модерации: <b>${cnt.accepted || 0}</b></span><span>Выставляются: <b>${cnt.selling || 0}</b></span><span>В продаже: <b style="color:#15803D">${cnt.on_sale || 0}</b></span><span>Ошибки: <b style="color:#B91C1C">${cnt.error}</b></span>` +
      (cnt.ready ? ` <button class="btn btn-sm" id="btnSelReady">Отметить все готовые</button>` : '');
    [...sendSel].forEach(s => { const d = drafts.find(x => x.sku === s); if (!d || (d.problems || []).length || ['sent','accepted','selling','on_sale'].includes(d.status)) sendSel.delete(s); });
    updateSendBtn();
    if (!drafts.length) { list.innerHTML = '<div class="cards-empty">Пока нет черновиков. Откройте «Радар», отметьте товары и нажмите «Создать карточки Kaspi».</div>'; return; }
    list.innerHTML = drafts.map(cardHtml).join('');
    drafts.forEach(d => fillAttrs(d));
  }

  function cardHtml(d) {
    const st = STATUS[d.status] || STATUS.draft;
    const probs = d.problems || [];
    const locked = ['sent','accepted','selling','on_sale'].includes(d.status);
    const canSend = !locked && !probs.length;
    const dis = locked ? 'disabled' : '';
    const sugg = (d.category_suggestions || []).map(c => `<option value="${esc(c.code)}" ${c.code === d.category ? 'selected' : ''}>${esc(c.title)}</option>`).join('');
    const curOpt = d.category && !(d.category_suggestions || []).some(c => c.code === d.category) ? `<option value="${esc(d.category)}" selected>${esc(d.category_title)}</option>` : '';
    const imgs = (d.images || []).map((u, i) => `<div class="card-img"><img src="${esc(u)}" loading="lazy" onerror="this.style.opacity=.3">${locked ? '' : `<button class="card-img-x" data-sku="${esc(d.sku)}" data-i="${i}" title="Убрать фото">×</button>${i ? `<button class="card-img-main" data-sku="${esc(d.sku)}" data-i="${i}" title="Сделать главным">★</button>` : '<span class="card-img-badge">главное</span>'}`}</div>`).join('');
    const kres = d.kaspi_result || d.kaspi_status || d.kaspi_response || null;
    const fill = probs.length ? `<span class="kcard-badge" style="color:#B45309;background:#FEF3C7">Не хватает: ${probs.length}</span>` : '<span class="kcard-badge" style="color:#15803D;background:#DCFCE7">✓ Всё заполнено</span>';
    return `
    <div class="kcard" data-sku="${esc(d.sku)}">
      <div class="kcard-top">
        <input type="checkbox" class="card-send-sel" data-sku="${esc(d.sku)}" ${canSend ? '' : 'disabled'} ${sendSel.has(d.sku) ? 'checked' : ''} title="${canSend ? 'Отправить эту карточку' : 'Сначала заполните поля'}">
        <img class="kcard-thumb" src="${esc((d.images || [])[0] || '')}" onerror="this.style.opacity=.3">
        <div class="kcard-main">
          <div class="kcard-row">
            <span class="kcard-badge" style="color:${st[1]};background:${st[2]}">${st[0]}</span>
            ${locked ? '' : fill}
            <a href="${esc(d.wb_url)}" target="_blank" class="kcard-link">WB ${esc(d.wb_id)} ↗</a>
            <span class="kcard-muted">SKU: ${esc(d.sku)} · предмет WB: ${esc(d.wb_subject)}</span>
            ${d.sale_note ? `<span class="kcard-muted" style="color:#1D4ED8">· ${esc(d.sale_note)}</span>` : ''}
            ${d.shop_url ? `<a href="${esc(d.shop_url)}" target="_blank" class="kcard-link">открыть на kaspi.kz ↗</a>` : ''}
            ${locked ? '' : `<button class="kcard-del" data-sku="${esc(d.sku)}" title="Удалить черновик">🗑</button>`}
          </div>
          <div class="kcard-grid3">
            <label>Название на Kaspi<input class="kf" data-f="title" value="${esc(d.title)}" ${dis}></label>
            <label>Бренд<input class="kf" data-f="brand" value="${esc(d.brand)}" ${dis}></label>
            <label>Цена, ₸<input class="kf" data-f="price" type="number" value="${esc(d.price)}" ${dis}></label>
            <label>Себестоимость, ₸<input class="kf" data-f="cost" type="number" value="${esc(d.cost)}" ${dis}></label>
            <label>Предзаказ, дней<input class="kf" data-f="preorder_days" type="number" min="1" max="30" value="${esc(d.preorder_days)}" ${dis}></label>
          </div>
          <div class="kcard-cat">
            <label>Категория Kaspi <b style="color:#B91C1C">*</b> <span class="kcard-muted">— проверьте! Подбор автоматический и может ошибаться.</span>
              <select class="kcat-sel" ${dis}>${curOpt}${sugg}</select>
            </label>
            ${locked ? '' : `<input class="kcat-search" data-sku="${esc(d.sku)}" placeholder="🔎 Другая категория: начните вводить..."><div class="kcat-results" id="kres-${esc(d.sku)}"></div>`}
          </div>
          ${probs.length && !locked ? `<div class="kcard-probs">${probs.map(p => esc(p.replace(/характеристика: (.+)$/, (m, x) => 'характеристика: ' + attrLabel(x)))).join(' · ')}</div>` : ''}
          ${(d.risks || []).length && !locked ? `<div class="kcard-probs" style="background:#FEF2F2;border-color:#FECACA;color:#991B1B">⚠ Риск отказа модерации: ${(d.risks || []).map(esc).join(' · ')}</div>` : ''}
          <details ${probs.length && !locked ? 'open' : ''}><summary>Характеристики (${(d.attributes || []).length})</summary>
            <div class="kattrs" id="kattrs-${esc(d.sku)}">Загрузка...</div></details>
          <details><summary>Описание (${(d.description || '').length} симв.) — текст продавца WB, лучше переписать своими словами</summary>
            <textarea class="kf kdesc" data-f="description" rows="8" ${dis}>${esc(d.description)}</textarea></details>
          <details><summary>Фото (${(d.images || []).length})</summary><div class="card-imgs">${imgs}</div>
            ${locked ? '' : `<div style="display:flex;gap:8px;align-items:center;"><button class="btn btn-sm kimg-ai" data-sku="${esc(d.sku)}" title="Студийное фото без надписей по первому фото (RoyalTech)">✨ ИИ-фото главным</button><input class="kimg-add" data-sku="${esc(d.sku)}" placeholder="или добавить фото по ссылке https://... и Enter"></div>`}</details>
          ${kres ? `<details ${d.status === 'error' ? 'open' : ''}><summary>Ответ Kaspi ${d.checked_at ? '(' + esc(d.checked_at) + ')' : ''}</summary><pre class="kres">${esc(JSON.stringify(kres, null, 2))}</pre></details>` : ''}
        </div>
      </div>
    </div>`;
  }

  async function fillAttrs(d) {
    const box = document.getElementById('kattrs-' + d.sku);
    if (!box) return;
    const defs = await categoryAttrs(d.category);
    const byCode = Object.fromEntries(defs.map(a => [a.code, a]));
    const locked = ['sent','accepted','selling','on_sale'].includes(d.status);
    const dis = locked ? 'disabled' : '';
    const attrs = [...(d.attributes || [])].sort((a, b) => (b.mandatory - a.mandatory));
    box.innerHTML = attrs.map(a => {
      const def = byCode[a.code] || {};
      const empty = a.value === null || a.value === '' || (Array.isArray(a.value) && !a.value.length);
      const lab = `<span class="ka-lab ${a.mandatory && empty ? 'ka-miss' : ''}">${esc(attrLabel(a.code))}${a.mandatory ? ' <b style="color:#B91C1C">*</b>' : ''}</span>`;
      const src = a.source ? `<span class="ka-src">авто: ${esc(a.source)}</span>` : '';
      let ctl;
      if (a.type === 'enum') {
        const vals = (def.values || []).map(v => v.name);
        const cur = Array.isArray(a.value) ? a.value : (empty ? [] : [a.value]);
        const opts = vals.map(v => `<option ${cur.includes(v) ? 'selected' : ''}>${esc(v)}</option>`).join('');
        if (!vals.length) ctl = `<input class="ka" data-code="${esc(a.code)}" value="${esc(cur.join(', '))}" ${dis}>`;
        else if (a.multiValued) ctl = `<select multiple size="${Math.min(4, Math.max(2, vals.length))}" class="ka" data-code="${esc(a.code)}" data-multi="1" ${dis} title="Ctrl+клик — выбрать несколько">${opts}</select>`;
        else ctl = `<select class="ka" data-code="${esc(a.code)}" ${dis}><option value="">— выберите —</option>${opts}</select>`;
      } else if (a.type === 'boolean') {
        ctl = `<select class="ka" data-code="${esc(a.code)}" ${dis}><option value="">— выберите —</option><option value="true" ${a.value === true ? 'selected' : ''}>да</option><option value="false" ${a.value === false ? 'selected' : ''}>нет</option></select>`;
      } else {
        ctl = `<input class="ka" data-code="${esc(a.code)}" ${a.type === 'number' ? 'type="number" step="any"' : ''} value="${empty ? '' : esc(a.value)}" ${dis}>`;
      }
      return `<div class="ka-row">${lab}${ctl}${src}</div>`;
    }).join('') || '<span class="kcard-muted">Выберите категорию</span>';
  }

  function keepOpen(sku, fn) {
    const el = document.querySelector(`.kcard[data-sku="${CSS.escape(sku)}"]`);
    const openStates = el ? [...el.querySelectorAll('details')].map(x => x.open) : [];
    fn();
    const nel = document.querySelector(`.kcard[data-sku="${CSS.escape(sku)}"]`);
    if (nel) [...nel.querySelectorAll('details')].forEach((x, k) => { if (k < openStates.length) x.open = openStates[k]; });
  }

  async function update(sku, fields) {
    const d = await api('/api/cards/update', { sku, fields });
    if (!d.success) { showToast('Ошибка: ' + d.error); return; }
    const i = drafts.findIndex(x => x.sku === sku); drafts[i] = d.draft;
    keepOpen(sku, render);
  }

  function updateSendBtn() {
    const c = document.getElementById('cardsSendCount'); if (c) c.innerText = sendSel.size;
    const b = document.getElementById('btnCardsSend'); if (b) b.disabled = sendSel.size === 0;
  }

  async function setCategory(sku, code) {
    showToast('Загружаю характеристики категории...');
    const d = await api('/api/cards/category', { sku, category: code });
    if (!d.success) { showToast('Ошибка: ' + d.error); return; }
    const i = drafts.findIndex(x => x.sku === sku); drafts[i] = d.draft;
    keepOpen(sku, render);
  }

  document.addEventListener('change', e => {
    const t = e.target; if (!t.classList) return;
    if (t.classList.contains('card-send-sel')) { t.checked ? sendSel.add(t.dataset.sku) : sendSel.delete(t.dataset.sku); updateSendBtn(); return; }
    const card = t.closest('.kcard'); const sku = card && card.dataset.sku;
    if (!sku) return;
    if (t.classList.contains('kf')) {
      let v = t.value; if (t.type === 'number') v = Number(v) || 0;
      update(sku, { [t.dataset.f]: v });
    } else if (t.classList.contains('ka')) {
      const v = t.dataset.multi ? [...t.selectedOptions].map(o => o.value) : t.value;
      update(sku, { attributes: { [t.dataset.code]: v } });
    } else if (t.classList.contains('kcat-sel')) {
      setCategory(sku, t.value);
    }
  });

  let searchTimer;
  document.addEventListener('input', e => {
    const t = e.target;
    if (!t.classList || !t.classList.contains('kcat-search')) return;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(async () => {
      const box = document.getElementById('kres-' + t.dataset.sku);
      if (t.value.trim().length < 3) { box.innerHTML = ''; return; }
      const d = await api('/api/cards/categories?q=' + encodeURIComponent(t.value.trim()));
      box.innerHTML = (d.categories || []).map(c => `<button class="kcat-opt" data-sku="${esc(t.dataset.sku)}" data-code="${esc(c.code)}">${esc(c.title)}</button>`).join('') || '<span class="kcard-muted">Ничего не найдено</span>';
    }, 300);
  });

  document.addEventListener('keydown', e => {
    const t = e.target;
    if (e.key === 'Enter' && t.classList && t.classList.contains('kimg-add') && /^https?:\/\//.test(t.value.trim())) {
      const d = drafts.find(x => x.sku === t.dataset.sku);
      update(d.sku, { images: [...(d.images || []), t.value.trim()].slice(0, 10) });
    }
  });

  document.addEventListener('click', async e => {
    const t = e.target; if (!t.classList) return;
    if (t.classList.contains('kcat-opt')) { setCategory(t.dataset.sku, t.dataset.code); return; }
    if (t.classList.contains('card-img-main')) {
      const d = drafts.find(x => x.sku === t.dataset.sku); const imgs = [...d.images]; const [m] = imgs.splice(Number(t.dataset.i), 1);
      update(d.sku, { images: [m, ...imgs] }); return;
    }
    if (t.classList.contains('kimg-ai')) {
      t.disabled = true; t.innerText = '⏳ Генерирую (до 2 мин)...';
      const d = await api('/api/cards/ai_photo', { sku: t.dataset.sku });
      if (!d.success) { showToast('ИИ-фото: ' + d.error); t.disabled = false; t.innerText = '✨ ИИ-фото главным'; return; }
      const i = drafts.findIndex(x => x.sku === d.draft.sku); drafts[i] = d.draft; keepOpen(d.draft.sku, render); showToast('✓ ИИ-фото стало главным'); return;
    }
    if (t.classList.contains('card-img-x')) {
      const d = drafts.find(x => x.sku === t.dataset.sku);
      const imgs = [...d.images]; imgs.splice(Number(t.dataset.i), 1); update(d.sku, { images: imgs }); return;
    }
    if (t.classList.contains('kcard-del')) {
      if (!confirm('Удалить черновик ' + t.dataset.sku + '?')) return;
      await api('/api/cards/delete', { sku: t.dataset.sku }); sendSel.delete(t.dataset.sku); window.loadCards(); return;
    }
    if (t.id === 'btnSelReady') {
      drafts.forEach(d => { if (!['sent','accepted','selling','on_sale'].includes(d.status) && !(d.problems || []).length) sendSel.add(d.sku); });
      render(); return;
    }
    if (t.closest('#btnCardsStatus')) {
      showToast('Проверяю загрузку и модерацию в Kaspi...');
      const d0 = await api('/api/cards/status', {});
      if (!d0.success) { showToast('Ошибка: ' + d0.error); return; }
      const d = await api('/api/cards/autosale', {});
      drafts = (d.success ? d.drafts : d0.drafts); render();
      if (!d.success) { showToast('Ошибка: ' + d.error); return; }
      const r = d.report;
      showToast(`Проверено: ${r.checked}. Выставлено в продажу: ${r.put_on_sale.length}. В продаже: ${r.on_sale.length}. Ждут модерацию: ${r.waiting.length}` + (r.errors.length ? ` · ${r.errors[0]}` : ''));
      return;
    }
    if (t.closest('#btnCardsSend')) {
      const skus = [...sendSel];
      if (!skus.length) return;
      if (!confirm(`Отправить ${skus.length} карточек в Kaspi на модерацию?\n\nОни уйдут в ваш магазин Kaspi через официальный API и попадут в прайс с указанной ценой и предзаказом.`)) return;
      const b = document.getElementById('btnCardsSend'); b.disabled = true; b.innerHTML = '⏳ Отправка...';
      const d = await api('/api/cards/send', { skus });
      b.innerHTML = '🚀 Отправить в Kaspi (<span id="cardsSendCount">0</span>)';
      if (!d.success) { showToast('Kaspi не принял: ' + d.error); window.loadCards(); return; }
      sendSel.clear();
      showToast(`✓ Отправлено: ${d.sent.length}. Код загрузки Kaspi: ${d.import_code || '—'}. Статус — кнопка «Статус модерации».`);
      window.loadCards();
    }
  });
})();


// ==========================================================
// Кабинет Kaspi через сотрудника: подключение и применение цены/предзаказа/снятия с продажи
// ==========================================================
(function () {
  const $ = id => document.getElementById(id);
  let cabConnected = false;

  async function post(url, body) {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
    return r.json();
  }

  async function loadCabinet() {
    if (!$('cabinetBox')) return;
    try {
      const d = await (await fetch('/api/cabinet/status')).json();
      if (!d.success) { $('cabStatus').innerHTML = '⚠ ' + escHtml(d.error || 'ошибка'); return; }
      const s = d.status;
      cabConnected = !!s.connected;
      if (s.login && !$('cabLogin').value) $('cabLogin').value = s.login;
      $('cabCodeRow').style.display = s.pending_code ? '' : 'none';
      if (s.pending_code) $('cabCodeLabel').innerText = 'Код из письма на ' + (s.pending_email || 'почту сотрудника');
      $('cabStatus').innerHTML = s.connected
        ? `<span class="cab-ok">● Подключено</span> — сотрудник <b>${escHtml(s.login)}</b>, магазин ${escHtml(s.merchant_id)}, склад ${escHtml(s.store_id)}`
        : (s.configured ? '<span class="cab-bad">● Не подключено</span> — сессия истекла или нужен код. Нажмите «Подключить».' : '<span class="cab-bad">● Не подключено</span> — введите email и пароль сотрудника.');
      $('cabLog').innerHTML = (d.log || []).map(l => `<div>${escHtml(l.ts)} — ${escHtml(l.event)} ${escHtml(l.sku || '')} ${l.price ? escHtml(l.price + ' ₸') : ''} ${l.preorder ? 'предзаказ ' + escHtml(l.preorder) + ' дн' : ''} ${l.available === false ? 'снят с продажи' : ''} ${escHtml(l.error || '')}</div>`).join('') || '<div>пока пусто</div>';
      $('cabAutopush').checked = (appConfig.kaspi_cab_autopush !== false);
    } catch (e) { $('cabStatus').innerText = 'Ошибка связи с программой'; }
  }
  window.loadCabinet = loadCabinet;

  document.addEventListener('click', async e => {
    const t = e.target;
    if (t.id === 'btnCabLogin') {
      t.disabled = true; t.innerText = 'Вход...';
      const d = await post('/api/cabinet/login', { login: $('cabLogin').value.trim(), password: $('cabPassword').value });
      t.disabled = false; t.innerText = 'Подключить'; $('cabPassword').value = '';
      if (!d.success) showToast('Kaspi: ' + d.error);
      else if (d.need_code) { showToast('Kaspi отправил код на ' + d.email + '. Введите его ниже.'); $('cabCodeRow').style.display = ''; $('cabCodeLabel').innerText = 'Код из письма на ' + d.email; $('cabCode').focus(); return; }
      else showToast('✓ Подключено к кабинету Kaspi');
      loadCabinet();
    }
    if (t.id === 'btnCabCode') {
      t.disabled = true;
      const d = await post('/api/cabinet/code', { code: $('cabCode').value.trim() });
      t.disabled = false;
      showToast(d.success ? '✓ Подключено к кабинету Kaspi' : 'Kaspi: ' + d.error);
      loadCabinet();
    }
    if (t.id === 'btnCabLogout') {
      if (!confirm('Отключить программу от кабинета Kaspi? Пароль сотрудника будет удалён с этого ПК.')) return;
      await post('/api/cabinet/logout'); cabConnected = false; showToast('Отключено'); loadCabinet();
    }
  });
  document.addEventListener('change', async e => {
    if (e.target.id === 'cabAutopush') {
      appConfig.kaspi_cab_autopush = e.target.checked;
      await post('/api/config', { kaspi_cab_autopush: e.target.checked });
    }
  });

  // Применить состояние товара в Kaspi (используется после правок в «Мой магазин» и для новых карточек)
  window.pushOfferToKaspi = async function (sku, opts) {
    opts = opts || {};
    if (!opts.force) {
      if (appConfig.kaspi_cab_autopush === false) return;
      if (!cabConnected) { showToast('ℹ Изменение сохранено в программе. Чтобы оно ушло в Kaspi, подключите сотрудника: Настройки → Подключение к кабинету Kaspi.'); return; }
    }
    const p = (storeData && storeData.products || []).find(x => x.sku === sku) || {};
    const mode = opts.mode || p.delivery_type || 'in_stock';
    const body = { sku, mode, price: opts.price || p.sell_price, preorder_days: opts.preorder_days || p.preorder_days || 7, model: opts.model || p.title };
    showToast('⏳ Отправляю в Kaspi: ' + sku + '...');
    const d = await post('/api/cabinet/offer', body);
    if (!d.success) { showToast('⚠ Kaspi не принял ' + sku + ': ' + d.error); return d; }
    const what = mode === 'archive' ? 'снять с продажи' : `${Number(body.price).toLocaleString('ru-RU')} ₸` + (mode === 'preorder' ? `, предзаказ ${body.preorder_days} дн` : ', в наличии');
    showToast(`✓ Kaspi принял (${what}). Применит в течение часа — проверить можно кнопкой «Проверить в Kaspi».`);
    loadCabinet();
    return d;
  };

  window.verifyOfferInKaspi = async function (sku) {
    const d = await (await fetch('/api/cabinet/verify?sku=' + encodeURIComponent(sku))).json();
    if (!d.success) { showToast('⚠ ' + d.error); return; }
    const sh = d.shop, c = d.cabinet;
    if (d.in_queue) showToast(`⏳ ${sku}: изменение ещё в очереди Kaspi.`);
    else if (sh) showToast(`✓ На kaspi.kz: ${sh.price.toLocaleString('ru-RU')} ₸` + (sh.preorder ? `, предзаказ ${sh.preorder} дн` : ', без предзаказа'));
    else showToast(`${sku}: на витрине не продаётся (в кабинете: ${c.available ? 'в продаже' : 'снят с продажи'}).`);
    return d;
  };

  document.addEventListener('DOMContentLoaded', () => setTimeout(loadCabinet, 800));
})();

// ==========================================================
// Слежение за WB (цена и наличие для вашего города) — по товарам в продаже
// ==========================================================
(function () {
  const $ = id => document.getElementById(id);
  const fmt = n => (n == null ? '—' : Number(n).toLocaleString('ru-RU'));
  function render(d) {
    const s = d.settings || {}, st = d.state || {};
    $('wbtEnabled').checked = s.wb_tracking_enabled !== false;
    $('wbtHours').value = String(s.wb_tracking_hours || 6);
    $('wbtMargin').value = s.wb_min_margin_pct || 15;
    $('wbtLast').innerText = st.last_run ? 'последняя проверка: ' + st.last_run : 'ещё не проверялось';
    const items = Object.values(st.items || {});
    if (!items.length) { $('wbtTable').innerHTML = '<div class="kcard-muted">Пока нет товаров в продаже из WB, либо проверка ещё не запускалась.</div>'; return; }
    $('wbtTable').innerHTML = `<table class="wbt-table"><thead><tr><th>Товар</th><th>WB сейчас</th><th>Было</th><th>Остаток WB</th><th>Доставка</th><th>Цена Kaspi</th><th>Маржа</th><th>Что сделано</th></tr></thead><tbody>` +
      items.map(r => {
        const ch = (r.wb_prev && r.wb_price && r.wb_prev !== r.wb_price) ? (r.wb_price > r.wb_prev ? '<span style="color:#B91C1C">▲</span>' : '<span style="color:#15803D">▼</span>') : '';
        const m = r.margin_pct == null ? '—' : `<span style="color:${r.margin_pct < 15 ? '#B91C1C' : '#15803D'}">${r.margin_pct.toFixed(0)}%</span>`;
        return `<tr><td>${escHtml((r.title || r.sku).slice(0, 48))}<div class="kcard-muted">${escHtml(r.sku)}</div></td><td>${r.wb_price ? fmt(r.wb_price) + ' ₸ ' + ch : '<b style="color:#B91C1C">нет</b>'}</td><td>${r.wb_prev ? fmt(r.wb_prev) + ' ₸' : '—'}</td><td>${fmt(r.qty)}</td><td>${r.delivery_h ? escHtml(r.delivery_h.join('–')) + ' ч' : '—'}</td><td>${fmt(r.kaspi_price)} ₸</td><td>${m}</td><td>${escHtml(r.action || '')}</td></tr>`;
      }).join('') + '</tbody></table>';
  }
  async function load() { try { render(await (await fetch('/api/wbtrack')).json()); } catch (e) {} }
  async function save() {
    const r = await fetch('/api/wbtrack', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ wb_tracking_enabled: $('wbtEnabled').checked, wb_tracking_hours: Number($('wbtHours').value), wb_min_margin_pct: Number($('wbtMargin').value) || 15 }) });
    render(await r.json()); showToast('✓ Настройки слежения сохранены');
  }
  document.addEventListener('change', e => { if (['wbtEnabled', 'wbtHours', 'wbtMargin'].includes(e.target.id)) save(); });
  document.addEventListener('click', async e => {
    if (!(e.target.closest && e.target.closest('#btnWbtRun'))) return;
    const b = $('btnWbtRun'); b.disabled = true; b.innerText = '⏳ Проверяю WB (до 1–2 мин, откроется окно браузера WB)...';
    try {
      const d = await (await fetch('/api/wbtrack/run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json();
      if (!d.success) showToast('WB: ' + d.error);
      else {
        const r = d.report;
        showToast(`Проверено: ${r.checked}. Снято с продажи: ${r.removed.length}. Возвращено: ${r.restored.length}. Цена поднята: ${r.repriced.length}.` + (r.errors.length ? ' · ' + r.errors[0] : ''));
      }
      load(); if (window.loadCards) window.loadCards();
    } finally { b.disabled = false; b.innerText = 'Проверить WB сейчас'; }
  });
  const orig = window.loadCards;
  window.loadCards = async function () { if (orig) await orig(); load(); };
})();


// ---------- Печать накладных ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('waybillBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  async function load() {
    $('wbList').textContent = 'Загрузка…';
    const d = await (await fetch('/api/orders/active')).json();
    if (!d.success) { $('wbList').textContent = d.error; return; }
    const list = d.orders.filter(o => o.state === 'KASPI_DELIVERY');
    $('wbList').innerHTML = list.map(o => `<label style="display:block;border:1px solid #ddd;border-radius:8px;padding:6px 8px;margin-bottom:5px;cursor:pointer;${o.assembled ? '' : 'background:#fff8e6'}">
      <input type="checkbox" class="wbChk" value="${esc(o.code)}" ${o.assembled ? 'checked' : ''}>
      <b>${esc(o.code)}</b> — ${o.assembled ? '✅ собран' : '⚠️ НЕ собран'}${o.preorder ? ' · предзаказ' : ''}${o.city ? ' · ' + esc(o.city) : ''}<br>
      ${o.items.map(i => (i.img ? `<img src="${esc(i.img)}" style="width:56px;height:56px;object-fit:cover;border-radius:6px;vertical-align:middle;margin-right:8px">` : '') + esc(i.sku) + ' × ' + esc(i.qty) + ' — ' + esc(i.name)).join('<br>')}<br>
      <span class="help-text">Передать курьеру до: ${esc(o.handover || '—')} · сумма ${esc(o.total)} ₸</span></label>`).join('') || 'Заказов Kaspi Доставки нет';
  }
  $('wbLoad').onclick = load;
  $('wbMake').onclick = async () => {
    const codes = [...document.querySelectorAll('.wbChk:checked')].map(x => x.value);
    if (!codes.length) { alert('Отметьте заказы'); return; }
    $('wbMake').disabled = true;
    try {
      const r = await fetch('/api/waybills/make', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ codes, layout: $('wbLayout').value, scale: (+$('wbScale').value || 67) / 100 }) });
      const d = await r.json();
      if (d.success) window.open('/api/waybills/file/' + encodeURIComponent(d.file), '_blank'); else alert(d.error);
    } finally { $('wbMake').disabled = false; }
  };
})();


// ---------- Экран заказов ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('ordersBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  $('ordLoad').onclick = async () => {
    $('ordList').textContent = 'Загрузка…';
    const d = await (await fetch('/api/orders/active')).json();
    if (!d.success) { $('ordList').textContent = d.error; return; }
    $('ordList').innerHTML = d.orders.map(o => `<div style="border:1px solid #ddd;border-radius:8px;padding:8px;margin-bottom:6px;${o.assembled ? 'opacity:.7' : ''}">
      <b>${esc(o.code)}</b> · ${o.assembled ? '✅ собран' : '📦 собрать'} · ${esc(o.status)}${o.preorder ? ' · предзаказ' : ''}${o.city ? ' · ' + esc(o.city) : ''}<br>
      ${o.items.map(i => (i.img ? `<img src="${esc(i.img)}" style="width:56px;height:56px;object-fit:cover;border-radius:6px;vertical-align:middle;margin-right:8px">` : '') + esc(i.sku) + ' × ' + esc(i.qty) + ' — ' + esc(i.name)).join('<br>')}<br>
      <span class="help-text">Передать курьеру до: ${esc(o.handover || '—')} · сумма ${esc(o.total)} ₸</span>
      ${o.contact ? `<br><span class="help-text">Покупатель: ${esc(o.contact.name)}, ${esc(o.contact.phone)}</span>` : ''}</div>`).join('') || 'Активных заказов нет';
  };
})();


window.loadOrdersTab = function () { document.getElementById('ordLoad')?.click(); document.getElementById('wbLoad')?.click(); };

// ---------- Предзаказ карточек ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('preorderBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  async function load() {
    $('poList').textContent = 'Загрузка…';
    const d = await (await fetch('/api/preorder/cards')).json();
    if (!d.success) { $('poList').textContent = d.error; return; }
    $('poList').innerHTML = d.cards.map(c => `<label style="display:block;border:1px solid #ddd;border-radius:8px;padding:6px 8px;margin-bottom:5px;cursor:pointer">
      <input type="checkbox" class="poChk" value="${esc(c.sku)}" data-wb="${esc(c.wb_days || '')}">
      ${c.img ? `<img src="${esc(c.img)}" style="width:56px;height:56px;object-fit:cover;border-radius:6px;vertical-align:middle;margin:0 8px">` : ''}
      <b>${esc(c.sku)}</b> — ${esc(c.title)}<br>
      <span class="help-text">Сейчас: ${esc(c.days || '—')} дн · по WB: <b>${esc(c.wb_days || '—')} дн</b>${c.wb_delivery_h ? ' (доставка ' + esc(c.wb_delivery_h.join('–')) + ' ч + запас)' : ''} · цена ${esc(c.price)} ₸</span></label>`).join('') || 'Нет карточек в продаже';
  }
  window.loadPreorderTab = load;
  $('poLoad').onclick = load;
  $('poApply').onclick = async () => {
    const boxes = [...document.querySelectorAll('.poChk:checked')];
    if (!boxes.length) { alert('Отметьте карточки'); return; }
    const fixed = +$('poDays').value || 0;
    if (!confirm('Отправить срок предзаказа в живой Kaspi для ' + boxes.length + ' карточек' + (fixed ? ' (' + fixed + ' дн)' : ' (по доставке WB)') + '?')) return;
    let ok = 0; const bad = [];
    for (const b of boxes) {
      const days = fixed || +b.dataset.wb;
      if (!days) { bad.push(b.value + ': нет срока WB'); continue; }
      try {
        const r = await (await fetch('/api/cabinet/offer', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sku: b.value, mode: 'preorder', preorder_days: days }) })).json();
        if (r.success === false) bad.push(b.value + ': ' + r.error); else ok++;
      } catch (e) { bad.push(b.value + ': ' + e); }
    }
    alert('Отправлено: ' + ok + (bad.length ? '\nОшибки:\n' + bad.join('\n') : '') + '\nKaspi применит изменения в течение часа.');
    load();
  };
})();


// ---------- Выходные дни ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('daysBox')) return;
  async function load() {
    const d = await (await fetch('/api/days/list')).json();
    $('dayList').innerHTML = d.success ? ('Ближайшие выходные: ' + (d.days.filter(x => x.closed).map(x => x.date.split('-').reverse().join('.')).join(', ') || 'нет')) : d.error;
  }
  async function check(from, to) {
    const q = from ? '?from=' + from + '&to=' + (to || from) : '';
    const d = await (await fetch('/api/days/check' + q)).json();
    const el = $('dayStatus');
    if (!d.success) { el.style.color = '#c0392b'; el.textContent = '⚠️ Не удалось проверить: ' + d.error; return d; }
    const fmt = x => x.split('-').reverse().join('.');
    if (d.ok) { el.style.color = '#1e8449'; el.textContent = '✅ Выходные проставлены: ' + d.closed + ' из ' + d.total + ' дней (' + fmt(d.from) + ' – ' + fmt(d.to) + '). Можно нажимать «Прибыл».'; }
    else { el.style.color = '#c0392b'; el.textContent = '❌ НЕ все дни закрыты: ' + d.closed + ' из ' + d.total + '. Не закрыты: ' + d.missing.slice(0, 12).map(fmt).join(', ') + (d.missing.length > 12 ? '…' : '') + '. «Прибыл» не нажимайте.'; }
    return d;
  }
  async function go(action) {
    const from = $('dayFrom').value, to = $('dayTo').value || from;
    if (!from) { alert('Выберите дату'); return; }
    if (!confirm((action === 'open' ? 'Убрать выходные' : 'Поставить выходные') + ' с ' + from + ' по ' + to + ' в живом Kaspi?')) return;
    const r = await (await fetch('/api/days/set', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ from, to, action }) })).json();
    if (!r.success) { alert(r.error); return; }
    await load();
    if (action !== 'open') await check(from, to);
    else $('dayStatus').textContent = '';
  }
  $('dayCheck').onclick = () => { const f = $('dayFrom').value; check(f || '', $('dayTo').value || f); };
  $('dayClose').onclick = () => go('close');
  $('dayOpen').onclick = () => go('open');
  const prev = window.loadOrdersTab;
  window.loadOrdersTab = function () { if (prev) prev(); load(); };
})();


// ---------- Gmail: код входа Kaspi ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('mailBox')) return;
  fetch('/api/mail/status').then(r => r.json()).then(d => {
    if (d.address) $('mailAddr').value = d.address;
    if (d.server) $('mailServer').value = d.server;
    if (d.has_password) $('mailMsg').textContent = 'Пароль приложения сохранён.';
  }).catch(() => {});
  $('mailSave').onclick = async () => {
    await fetch('/api/mail/save', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ address: $('mailAddr').value.trim(), server: $('mailServer').value.trim(), password: $('mailPass').value }) });
    $('mailPass').value = ''; $('mailMsg').textContent = 'Сохранено. Нажмите «Проверить».';
  };
  $('mailTest').onclick = async () => {
    $('mailMsg').textContent = 'Проверяю…';
    const d = await (await fetch('/api/mail/test', { method: 'POST' })).json();
    $('mailMsg').textContent = d.success ? ('✅ Почта подключена. Писем от Kaspi за 7 дней: ' + d.kaspi_mails_7d + (d.code_found_in_latest ? ', код в последнем найден.' : ', кода в последнем не нашлось.')) : ('❌ ' + d.error);
  };
})();


// ---------- Первый запуск ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('setupBox')) return;
  const rows = [
    ['merchant', '1. Merchant ID магазина', 'Настройки → «Kaspi Merchant ID» (виден в кабинете Kaspi).'],
    ['token', '2. Токен Kaspi API', 'Кабинет Kaspi → Настройки → «Токен API». Вводится в Настройках.'],
    ['cabinet', '3. Вход сотрудника в кабинет', 'Настройки → «Подключение к кабинету Kaspi (сотрудник)». Создайте сотрудника с правом «Загрузка товаров».'],
    ['store', '4. Склад, город и регион WB', 'Нажмите кнопку ниже — определится автоматически из кабинета.'],
    ['mail', '5. Почта для кода входа (по желанию)', 'Настройки → «Код входа Kaspi из почты»: программа сама введёт код из письма.']
  ];
  async function load() {
    const d = await (await fetch('/api/setup/status')).json();
    if (!d.success) { $('setupSteps').textContent = d.error; return; }
    $('setupSteps').innerHTML = rows.map(([k, t, h]) => `<div style="border:1px solid #ddd;border-radius:8px;padding:8px 10px;margin-bottom:6px;${d.steps[k] ? 'background:#f0faf3' : ''}">
      ${d.steps[k] ? '✅' : '⬜'} <b>${t}</b><br><span class="help-text">${h}</span></div>`).join('') +
      (d.store_id ? `<div class="help-text">Склад: <b>${d.store_id}</b> · город: <b>${d.city || '—'}</b> · регион WB: <b>${d.wb_dest || '—'}</b></div>` : '') +
      (d.done ? '<div style="margin-top:8px;font-weight:600;color:#1e8449">✅ Магазин подключён. Можно работать.</div>' : '');
  }
  async function cities() {
    const d = await (await fetch('/api/setup/status')).json();
    if (!d.success) return;
    $('setupCity').innerHTML = '<option value="">— выберите город —</option>' + d.cities.map(c => `<option ${c === d.wb_city ? 'selected' : ''}>${c}</option>`).join('');
  }
  window.loadSetupTab = () => { load(); cities(); };
  $('setupCitySave').onclick = async () => {
    const city = $('setupCity').value; if (!city) { alert('Выберите город'); return; }
    $('setupMsg').textContent = 'Применяю…';
    const d = await (await fetch('/api/setup/city', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ city }) })).json();
    $('setupMsg').textContent = d.success ? ('✅ Город ' + d.city + ', регион WB ' + d.wb_dest) : ('❌ ' + d.error);
    load();
  };
  $('setupRefresh').onclick = load;
  $('setupDetect').onclick = async () => {
    $('setupMsg').textContent = 'Определяю…';
    const d = await (await fetch('/api/setup/detect', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json();
    $('setupMsg').textContent = d.success ? ('✅ Склад ' + d.store_id + ', город ' + d.city + ', регион WB ' + (d.wb_dest || 'не определён — укажите вручную в Настройках')) : ('❌ ' + d.error);
    load();
  };
})();


// ---------- Обновления ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('updateBox')) return;
  const post = u => fetch(u, { method: 'POST' }).then(r => r.json());
  async function check() {
    $('updMsg').textContent = 'Проверяю…'; $('updApply').style.display = 'none';
    const d = await post('/api/update/check');
    if (!d.success) { $('updMsg').textContent = '❌ ' + d.error; return; }
    $('updVersion').textContent = 'Версия: ' + d.current;
    if (d.error) $('updMsg').textContent = '⚠️ ' + d.error;
    else if (d.available) { $('updMsg').textContent = '🆕 Доступна версия ' + d.latest + (d.notes ? ': ' + d.notes : ''); $('updApply').style.display = ''; }
    else $('updMsg').textContent = '✅ Установлена последняя версия.';
  }
  $('updCheck').onclick = check;
  $('updApply').onclick = async () => {
    if (!confirm('Установить обновление? Ваши данные и настройки не изменятся. После установки перезапустите программу.')) return;
    $('updMsg').textContent = 'Устанавливаю…';
    const d = await post('/api/update/apply');
    $('updMsg').textContent = d.success && d.ok ? ('✅ ' + d.note) : ('❌ ' + (d.error || 'не удалось'));
    $('updApply').style.display = 'none';
  };
  fetch('/api/update/check', { method: 'POST' }).then(r => r.json()).then(d => { if (d.success) $('updVersion').textContent = 'Версия: ' + d.current; });
})();


// ---------- Самопроверка ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('selfcheckBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  function show(d) {
    if (!d) { $('scList').textContent = 'Ещё не проверялось.'; return; }
    $('scList').innerHTML = `<div class="help-text" style="margin-bottom:6px">Проверено: ${esc(d.at)} — ${d.ok ? '✅ всё работает' : '❌ есть проблемы: ' + d.failed.length}</div>` +
      d.results.map(r => `<div style="padding:4px 0;border-bottom:1px solid #eee">${r.ok ? '✅' : '❌'} <b>${esc(r.name)}</b> <span class="help-text">— ${esc(r.detail)}</span>${r.ok ? '' : `<br><span style="color:#c0392b">Что делать: ${esc(r.hint)}</span>`}</div>`).join('');
  }
  fetch('/api/selfcheck/last').then(r => r.json()).then(d => show(d.success ? d.last : null)).catch(() => {});
  $('scRun').onclick = async () => {
    $('scRun').disabled = true; $('scList').textContent = 'Проверяю… (до минуты)';
    try { const d = await (await fetch('/api/selfcheck/run', { method: 'POST' })).json(); show(d.success ? d : null); if (!d.success) $('scList').textContent = d.error; }
    finally { $('scRun').disabled = false; }
  };
})();
