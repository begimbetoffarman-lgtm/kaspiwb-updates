"""⚡ Радар вилок: межмаркетплейсный арбитраж WB / Ozon -> Kaspi.

Находит связку «закупка на WB/Ozon — продажа на Kaspi», считает чистую прибыль
(комиссия, Kaspi Pay, доставка, налог ИП) и отдаёт готовые карточки в интерфейс.

Источники:
  - WB: core.wb_parser.parse_wb_search_sync (живая выдача, цены в ₸ для города из Первого запуска);
  - Ozon: core.suppliers.search (Ozon в браузере программы, цены в KZT);
  - Kaspi: core.kaspi_store.check_kaspi_vacuum (форс-обновление цены и продавцов
    для цены-подсказки Kaspi и режима «Вакуум»).
Если сеть недоступна, отдаётся проверенный эталонный кэш data/forks_cache.json.
В Kaspi ничего не отправляется: модуль только читает и складывает в «Найденное».
"""
import datetime
import hashlib
import json
import os
import threading

from core import secrets as _secrets
from core import supplier_delivery
from core.kaspi_store import calculate_product_economics, check_kaspi_vacuum
from core.wb_parser import clean_kaspi_title, parse_wb_search_sync

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_FILE = os.path.join(ROOT, 'data', 'forks_cache.json')
COMMISSIONS_FILE = os.path.join(ROOT, 'core', 'kaspi_commissions.json')

DEFAULT_RATE = 5.2            # ₽ -> ₸
DEFAULT_COMMISSION = 12.5
DEFAULT_PACK = 150            # упаковка, ₸
DEFAULT_SCOPE = 'kz'
MODES = ('spread', 'speed', 'vacuum')
SOURCES = ('all', 'wb', 'ozon')
VACUUM_MIN_FEEDBACKS = 500
VACUUM_MAX_SELLERS = 3
TTL_OK = 30 * 60              # живая выдача свежа 30 минут
TTL_FAIL = 10 * 60            # неудачу не повторяем 10 минут (не долбим площадки)
TTL_VACUUM = 6 * 60 * 60      # проверка Kaspi — 6 часов
CACHE_LIMIT = 1500

_MEMO = {}                    # (source, query|category) -> {'at': ts, 'error': str, 'items': [...]}
_VACUUM_MEMO = {}             # (query, mode) -> (ts, result)
_LOCK = threading.Lock()
_COMMISSIONS = []
_CACHE = None
_WARN = []


class RadarBusy(RuntimeError):
    pass


# ---------------------------------------------------------------- настройки
def _config():
    try:
        cfg = _secrets.read_config() or {}
    except Exception:
        cfg = {}
    try:
        rate = float(cfg.get('rub_to_kzt_rate') or DEFAULT_RATE)
    except (TypeError, ValueError):
        rate = DEFAULT_RATE
    return rate if 1 <= rate <= 30 else DEFAULT_RATE


def _commission_rate(category=''):
    global _COMMISSIONS
    if _COMMISSIONS is None:
        try:
            with open(COMMISSIONS_FILE, encoding='utf-8') as f:
                _COMMISSIONS = [tuple(p) for p in json.load(f) if isinstance(p, list) and len(p) == 2]
        except (OSError, ValueError):
            _COMMISSIONS = []
    words = _stems(category)
    if words:
        for name, rate in _COMMISSIONS:
            if len(words & _stems(name)) >= min(2, len(words)):
                try:
                    return float(rate)
                except (TypeError, ValueError):
                    break
    return DEFAULT_COMMISSION


def _stems(text):
    return {w[:5] for w in _words(text) if len(w) > 3}


def _words(text):
    import re
    return [w for w in re.sub(r'[^\w\s]', ' ', str(text or '').lower()).split() if len(w) > 2]


def retail_price(purchase_kzt):
    """Цена продажи-ориентир: та же формула, что «Мой магазин» — двойная наценка с шагом 100 ₸."""
    from core.wb_parser import round_kaspi_price
    return round_kaspi_price(max(0, float(purchase_kzt or 0)) * 2.4)


# ---------------------------------------------------------------- экономика
def compute(buy_kzt, sell_kzt, rate=DEFAULT_RATE, commission=None, scope=DEFAULT_SCOPE):
    """Честный расчёт вилки. Все суммы в ₸."""
    rate = rate or DEFAULT_RATE
    buy = max(0, float(buy_kzt or 0))
    sell = max(0, float(sell_kzt or 0))
    buy_rub = round(buy / rate) if buy else None
    if sell <= 0:
        sell = retail_price(buy)
    comm = DEFAULT_COMMISSION if commission is None else commission
    econ = calculate_product_economics(sell, buy, comm_rate=comm, pack_kzt=DEFAULT_PACK, delivery_scope=scope)
    return {
        'buy_kzt': int(round(buy)),
        'buy_rub': buy_rub,
        'rate': rate,
        'sell_kzt': int(sell),
        'commission_rate': comm,
        'commission_kzt': econ['comm_kzt'],
        'kaspi_pay_kzt': econ['pay_kzt'],
        'tax_kzt': econ['tax_kzt'],
        'delivery_kzt': econ['delivery_kzt'],
        'delivery_tier': econ['delivery_tier'],
        'delivery_vat_kzt': econ['delivery_vat'],
        'pack_kzt': econ['pack_kzt'],
        'fees_kzt': econ['kaspi_deductions'],
        'payout_kzt': econ['kaspi_payout'],
        'profit_kzt': econ['net_profit'],
        'roi_pct': econ['roi_pct'],
        'margin_pct': econ['margin_pct'],
        'status': econ['verdict_status'],
        'sell_source': 'estimate',
    }


# ---------------------------------------------------------------- кэш диска
def _load_cache():
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    data = {}
    try:
        with open(CACHE_FILE, encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    data.setdefault('version', 1)
    data.setdefault('items', {})
    data.setdefault('vacuum', {})
    data.setdefault('seeds', [])
    if not isinstance(data.get('items'), dict):
        data['items'] = {}
    _CACHE = data
    return _CACHE


def _save_cache():
    data = _load_cache()
    os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
    tmp = CACHE_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, separators=(',', ':'))
    os.replace(tmp, CACHE_FILE)


def _int(value, default, low, high):
    try:
        return max(low, min(high, int(float(value))))
    except (TypeError, ValueError):
        return default


def _ts():
    return int(datetime.datetime.now().timestamp())


def _now():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _key(source, query):
    raw = '%s|%s' % (source, ' '.join(_words(query)) or str(query or '').strip().lower())
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:16]


def _cache_put(query, source, items, error=''):
    data = _load_cache()
    data['items'][_key(source, query)] = {'query': query, 'source': source, 'items': items,
                                          'at': _ts(), 'error': error}
    if len(data['items']) > CACHE_LIMIT:
        for k, _ in sorted(data['items'].items(), key=lambda kv: kv[1].get('at', 0))[:len(data['items']) - CACHE_LIMIT]:
            data['items'].pop(k, None)
    _save_cache()


def _cache_get(query, source, max_age=None):
    entry = _load_cache()['items'].get(_key(source, query))
    if not entry:
        return None
    if max_age is not None and _ts() - int(entry.get('at') or 0) > max_age:
        return None
    return entry


# ---------------------------------------------------------------- MB -> связка
def _from_wb(row, rate):
    price_kzt = row.get('price_kzt') or row.get('cost_total')
    if not price_kzt:
        return None
    econ = compute(price_kzt, row.get('kaspi_price') or 0, rate)
    return {
        'id': 'wb:%s' % row.get('id'),
        'source': 'wb',
        'source_label': 'Wildberries',
        'name': row.get('name') or '',
        'brand': row.get('brand') or '',
        'image': row.get('img_main') or ((row.get('images') or [''])[0]),
        'url': row.get('wb_url') or '',
        'rating': row.get('rating'),
        'feedbacks': int(row.get('feedbacks') or 0),
        'stock': row.get('wb_qty'),
        'category': row.get('kaspi_search_query') or '',
        'kaspi_query': row.get('kaspi_search_query') or '',
        'economy': econ,
        'sell_source': 'estimate',
    }


def _from_ozon(row, rate):
    # Ozon в отдельном окне программы показывает цены в тенге (ozon.kz).
    price_kzt = row.get('price')
    if not price_kzt or str(row.get('currency') or '').upper() == 'CNY':
        return None
    econ = compute(price_kzt, 0, rate)
    name = str(row.get('name') or '')
    return {
        'id': 'ozon:%s' % (row.get('id') or row.get('url')),
        'source': 'ozon',
        'source_label': 'Ozon',
        'name': name,
        'brand': '',
        'image': row.get('image') or '',
        'url': row.get('url') or '',
        'rating': None,
        'feedbacks': 0,
        'stock': None,
        'category': '',
        'kaspi_query': ' '.join([w for w in _words(name) if len(w) > 3][:3]),
        'economy': econ,
    }


def _fresh_cnx():
    if not _LOCK.acquire(blocking=False):
        raise RadarBusy('Радар уже ищет по другой категории. Подождите пару секунд и повторите.')
    return True


# ---------------------------------------------------------------- источник
def _wb_items(query, limit, rate):
    cnx = _fresh_cnx()
    try:
        try:
            rows = parse_wb_search_sync(query, limit=max(limit, 30))
            error = ''
            if not rows:
                from core import wb_parser
                error = wb_parser.LAST_ERROR or 'WB не вернул товары по этому запросу.'
        except Exception as e:
            rows, error = [], 'WB недоступен: %s' % e
        items = [x for x in (_from_wb(r, rate) for r in rows) if x]
        return items, error
    finally:
        if cnx:
            _LOCK.release()


def _ozon_items(query, limit, rate):
    cnx = _fresh_cnx()
    try:
        try:
            from core import suppliers
            result = suppliers.search('ozon', query)
            rows = result.get('items') or []
            error = '' if rows else 'Ozon не вернул товары (нужен вход в Ozon в окне программы или смена запроса).'
            if result.get('blocked'):
                error = 'Ozon требует проверку входа. Откройте Ozon в окне программы и повторите.'
        except Exception as e:
            rows, error = [], 'Ozon недоступен: %s' % e
        items = [x for x in (_from_ozon(r, rate) for r in rows[:limit]) if x]
        return items, error
    finally:
        if cnx:
            _LOCK.release()


def _search_source(source, query, limit, rate):
    """Живой поиск с памятью в процессе: удача держится 30 минут, ошибка — 10."""
    memo_key = (source, _key(source, query))
    hit = _MEMO.get(memo_key)
    if hit:
        age = _ts() - hit['at']
        if (not hit['error'] and age <= TTL_OK) or (hit['error'] and age <= TTL_FAIL):
            return hit['items'], hit['error']
    items, error = (_wb_items if source == 'wb' else _ozon_items)(query, limit, rate)
    if not items and not error:
        error = 'По запросу ничего не нашлось.'
    _MEMO[memo_key] = {'at': _ts(), 'error': error, 'items': items}
    if items or not hit:
        _cache_put(query, source, items, error)
    return items, error


# ---------------------------------------------------------------- Kaspi
def _kaspi_blank():
    return {'exact_matches': None, 'sellers': None, 'competitor_price': None,
            'competitor_title': '', 'kaspi_url': '', 'vacuum_status': 'unknown', 'checked': False, 'note': ''}


def _kaspi_title_url(title):
    import urllib.parse
    return 'https://kaspi.kz/shop/search/?text=' + urllib.parse.quote(title or '')


def _kaspi_probe(item):
    global _LOCK
    q = item.get('kaspi_query') or item.get('name') or ''
    memo_key = ('kaspi', q.lower())
    hit = _VACUUM_MEMO.get(memo_key)
    if hit and _ts() - hit[0] <= TTL_VACUUM:
        return dict(hit[1])
    if not _LOCK.acquire(blocking=False):           # Kaspi — только когда никого не ищем
        return _kaspi_blank()
    try:
        res = check_kaspi_vacuum(item.get('name') or '', q, [item.get('image')] if item.get('image') else [])
    except Exception as e:
        res = {'vacuum_status': 'unknown', 'explanation': 'Kaspi недоступен: %s' % e}
    finally:
        _LOCK.release()
    short = {
        'exact_matches': res.get('exact_matches'),
        'sellers': res.get('sellers'),
        'competitor_price': res.get('competitor_price'),
        'competitor_title': res.get('competitor_title') or '',
        'kaspi_url': _kaspi_title_url(item.get('kaspi_query') or item.get('name')),
        'vacuum_status': res.get('vacuum_status') or 'unknown',
        'checked': res.get('vacuum_status') in ('vacuum_full', 'vacuum_low_competition', 'saturated'),
        'note': _short_note(res),
    }
    _VACUUM_MEMO[memo_key] = (_ts(), short)
    if short['checked']:
        data = _load_cache()
        data['vacuum'][_key('kaspi', q)] = dict(short, title=item.get('name'), at=_ts())
        if len(data['vacuum']) > 800:
            for k, _ in sorted(data['vacuum'].items(), key=lambda kv: kv[1].get('at', 0))[:200]:
                data['vacuum'].pop(k, None)
        _save_cache()
    return short


def _short_note(res):
    ex = res.get('exact_matches')
    if ex is None:
        return res.get('explanation') or 'Kaspi не ответил, показана цена-подсказка.'
    sellers = res.get('sellers')
    if res.get('vacuum_status') == 'vacuum_full':
        return 'Точных карточек на Kaspi не найдено — ниша свободна.'
    if res.get('vacuum_status') == 'vacuum_low_competition':
        return 'Похожих карточек: %s, продавцов: %s. Слабая конкуренция.' % (ex, sellers if sellers is not None else '?')
    return 'На Kaspi уже %s карточек, продавцов: %s.' % (ex, sellers if sellers is not None else '?')


def _cached_kaspi(item):
    data = _load_cache()['vacuum'].get(_key('kaspi', item.get('kaspi_query') or item.get('name') or ''))
    if not data:
        return None
    short = {k: v for k, v in data.items() if k != 'at'}
    short.setdefault('kaspi_url', _kaspi_title_url(item.get('kaspi_query') or item.get('name')))
    return short


def _attach_kaspi(item, live):
    info = (_kaspi_probe(item) if live else None) or _cached_kaspi(item) or _kaspi_blank()
    item['kaspi'] = info
    econ = item['economy']
    if not info.get('checked') and info.get('vacuum_status') == 'unknown':
        econ['status'] = 'ESTIMATE'
    return item


def _with_kaspi_price(item, price, estimate=False):
    """Пересчитать вилку по реальной цене Kaspi; estimate — цена-подсказка, а не BuyBox."""
    econ = compute(item['economy']['buy_kzt'], price, item['economy']['rate'])
    if estimate:
        econ['status'] = 'ESTIMATE'
    item['economy'] = econ
    item['sell_source'] = 'estimate' if estimate else 'kaspi'
    return item


# ---------------------------------------------------------------- публичный поиск
def search_forks(query='', category='', source='all', mode='spread', min_margin=20, limit=40, live_kaspi=True):
    limit = _int(limit, 40, 1, 200)
    query = (query or category or '').strip()[:200]
    category = (category or '').strip()[:200]
    if not query:
        raise ValueError('Введите запрос или выберите категорию.')
    source = source if source in SOURCES else 'all'
    mode = mode if mode in MODES else 'spread'
    min_margin = _int(min_margin, 20, 0, 90)
    rate = _config()
    wanted = max(limit * 2, 40)

    sources = ('wb', 'ozon') if source == 'all' else (source,)
    items, notes, live = [], {}, False
    for src in sources:
        got, error = _search_source(src, query, wanted, rate)
        if got:
            live = True
            items.extend(got)
        elif error:
            notes[src] = error

    if not items:
        cached = []
        for src in sources:
            cached.extend((_cache_get(query, src) or {}).get('items') or [])
        if cached:
            items = cached
            notes['cache'] = 'Сеть площадок не ответила: показаны последние найденные по этому запросу связки из кэша.'
        else:
            seeds = _seed_items(sources, category or query, rate)
            if seeds:
                items = seeds
                notes['cache'] = 'Сеть площадок не ответила: показаны эталонные связки по нише. Цены проверьте кнопкой «Обновить данные».'
    if not items:
        raise ValueError('Ничего не нашлось. ' + ' '.join(notes.values()))

    # Kaspi: живая проверка по 8 связкам шорт-листа (спред — самые прибыльные,
    # оборот — самые дешёвые), не дольше ~25 сек, чтобы UI отдавал результат сразу.
    import time
    deadline = time.monotonic() + 25
    short_ids = {id(x) for x in _shortlist(items, mode)[:8]}
    for it in items:
        it['_shortlisted'] = bool(live_kaspi and live and id(it) in short_ids)
        if it['_shortlisted'] and time.monotonic() < deadline:
            _attach_kaspi(it, live=True)
        elif _cached_kaspi(it):
            _attach_kaspi(it, live=False)
        else:
            it['kaspi'] = _kaspi_blank()
            if not live_kaspi:
                notes['kaspi_off'] = 'Включите «Проверять Kaspi сейчас», чтобы подставить реальную цену и число продавцов Kaspi.'
    items = _rank(items, mode, rate, live_kaspi, min_margin)
    items = [it for it in items if (it['economy'].get('margin_pct') or 0) >= min_margin]
    for it in items:
        it.pop('_shortlisted', None)
        it['revenue_delta'] = int(it['economy']['sell_kzt'] - it['economy']['buy_kzt'])

    data = _load_cache()
    data['last_query'] = {'query': query, 'category': category, 'source': source, 'mode': mode,
                          'min_margin': min_margin, 'at': _now()}
    _save_cache()
    return {
        'success': True,
        'query': query,
        'category': category,
        'source': source,
        'mode': mode,
        'min_margin': min_margin,
        'live': live,
        'notes': notes,
        'total': len(items),
        'checked_at': _now(),
        'items': items[:limit],
    }


def _seed_items(sources, needle, rate):
    words = {w[:5] for w in _words(needle)}
    out = []
    for seed in _load_cache().get('seeds') or []:
        if seed.get('source') not in sources:
            continue
        tags = {t.lower() for t in seed.get('tags') or []}
        title_stems = {w[:5] for w in _words(seed.get('name'))}
        if words and not (words & tags or words & title_stems):
            continue
        it = _seed_to_item(seed, rate)
        if it:
            out.append(it)
    return out


def _seed_to_item(seed, rate):
    buy = seed.get('buy_kzt')
    if not buy:
        return None
    econ = compute(buy, seed.get('sell_kzt') or 0, rate)
    item = {
        'id': 'seed:%s' % seed.get('id'),
        'source': seed.get('source') or 'wb',
        'source_label': 'Wildberries' if seed.get('source') == 'wb' else 'Ozon',
        'name': seed.get('name') or '',
        'brand': seed.get('brand') or '',
        'image': seed.get('image') or '',
        'url': seed.get('url') or '',
        'rating': seed.get('rating'),
        'feedbacks': int(seed.get('feedbacks') or 0),
        'stock': None,
        'category': seed.get('category') or '',
        'sell_source': 'estimate',
        'kaspi_query': seed.get('kaspi_query') or ' '.join(_words(seed.get('name'))[:3]),
        'economy': econ,
        'seed': True,
    }
    it_ks = seed.get('kaspi') or {}
    item['kaspi'] = {
        'exact_matches': it_ks.get('exact_matches'),
        'sellers': it_ks.get('sellers'),
        'competitor_price': it_ks.get('competitor_price'),
        'competitor_title': '',
        'kaspi_url': _kaspi_title_url(item['kaspi_query']),
        'vacuum_status': it_ks.get('vacuum_status') or 'unknown',
        'checked': False,
        'note': 'Эталонная связка из кэша. Нажмите «Обновить данные» для живой проверки.',
    }
    return item


# ---------------------------------------------------------------- ранжирование
def _shortlist(items, mode):
    """Спред: самые прибыльные. Оборот: самый мелкий чек (там рейтинг 4.7+ и есть смысл сверять Kaspi)."""
    if mode == 'speed':
        return sorted(items, key=lambda x: x['economy'].get('buy_kzt') or 10 ** 9)[:40]
    return sorted(items, key=lambda x: -(x['economy'].get('profit_kzt') or 0))[:40]


def _rank(items, mode, rate, live_kaspi, min_margin=0):
    seen = set()
    uniq = []
    for it in items:
        if it['id'] in seen:
            continue
        seen.add(it['id'])
        uniq.append(it)

    def by_profit(x):
        return x['economy'].get('profit_kzt') or 0

    def by_buy(x):
        return x['economy'].get('buy_kzt') or 10 ** 9

    if mode in ('spread', 'speed') and live_kaspi:
        # если у связки есть реальная цена Kaspi — считаем прибыль от неё, а не от подсказки
        for it in uniq:
            price = (it.get('kaspi') or {}).get('competitor_price')
            if it['kaspi'].get('vacuum_status') == 'saturated' and price:
                _with_kaspi_price(it, price)
                it['sell_source'] = 'kaspi'
    if mode == 'spread':
        return sorted(uniq, key=lambda x: (-by_profit(x), -(x.get('rating') or 0)))
    if mode == 'speed':
        shortlisted = [x for x in uniq if x.get('_shortlisted')]
        if shortlisted:
            return sorted(shortlisted, key=lambda x: (0 if (x.get('rating') or 0) >= 4.7 else 1,
                                                      by_buy(x), -by_profit(x)))

        def speed_key(x):
            rating_ok = (x.get('rating') or 0) >= 4.7
            return (0 if rating_ok else 1, x['economy'].get('buy_kzt') or 10 ** 9,
                    -(x['economy'].get('profit_kzt') or 0))
        return sorted(uniq, key=speed_key)
    # vacuum: хиты, которых нет на Kaspi (0 конкурентов) или почти нет
    out = []
    for it in uniq:
        ks = it.get('kaspi') or {}
        if not ks.get('checked'):
            continue
        if ks.get('vacuum_status') == 'vacuum_full':
            it['vacuum_level'] = 'free'
        elif (ks.get('vacuum_status') == 'vacuum_low_competition' and (ks.get('sellers') or 99) <= VACUUM_MAX_SELLERS):
            it['vacuum_level'] = 'weak'
        else:
            continue
        hits = it.get('feedbacks') or 0
        if it.get('source') == 'wb' and hits < VACUUM_MIN_FEEDBACKS:
            continue
        # вакуум — про свободную нишу, но убыточную связку не показываем
        if it['kaspi'].get('competitor_price'):
            _with_kaspi_price(it, it['kaspi']['competitor_price'], estimate=bool(it.get('seed')))
        if (it['economy'].get('margin_pct') or 0) < min_margin:
            continue
        out.append(it)
    return sorted(out, key=lambda x: (x.get('vacuum_level') != 'free', -(x.get('feedbacks') or 0),
                                      -(x['economy'].get('profit_kzt') or 0)))


# ---------------------------------------------------------------- сохранение в «Найденное»
def save_to_found(payload):
    items = payload.get('items')
    if not isinstance(items, list) or not items:
        raise ValueError('Не выбраны связки для сохранения.')
    from core import found
    groups = {}
    for it in items[:50]:
        if not isinstance(it, dict) or it.get('seed'):
            continue
        econ = it.get('economy') or {}
        source = it.get('source') if it.get('source') in ('wb', 'ozon') else 'wb'
        groups.setdefault(source, []).append({
            'id': str(it.get('id') or '').split(':', 1)[-1][:60],
            'name': it.get('name') or '',
            'url': it.get('url') or '',
            'image': it.get('image') or '',
            'price': econ.get('buy_kzt'),
            'rating': it.get('rating'),
            'feedbacks': it.get('feedbacks'),
            'brand': it.get('brand') or '',
        })
    added = updated = 0
    for source, batch in groups.items():
        a, u, _ = found.add_many(source, batch, payload.get('query') or 'радар вилок')
        added += a
        updated += u
    return {'success': True, 'added': added, 'updated': updated,
            'message': 'В «Найденное» добавлено: %d, обновлено: %d.' % (added, updated)}


# ---------------------------------------------------------------- индекс категорий
def categories():
    file = os.path.join(ROOT, 'static', 'wb_categories.json')
    try:
        with open(file, encoding='utf-8') as f:
            tree = json.load(f)
    except (OSError, ValueError):
        tree = []
    leaves = []
    for root in tree if isinstance(tree, list) else []:
        rname = str(root.get('n') or '')
        for child in root.get('c') or []:
            cname = str(child.get('n') or '')
            subs = child.get('c') or []
            if subs:
                for leaf in subs:
                    leaves.append({'name': str(leaf.get('n') or ''), 'path': [rname, cname, str(leaf.get('n') or '')]})
            elif cname:
                leaves.append({'name': cname, 'path': [rname, cname]})
    return {'success': True, 'total': len(leaves), 'items': leaves}


# ---------------------------------------------------------------- Flask
def register(app):
    from flask import jsonify, request

    def api_forks():
        args = request.args
        try:
            data = search_forks(
                query=args.get('query') or '',
                category=args.get('category') or '',
                source=args.get('source') or 'all',
                mode=args.get('mode') or 'spread',
                min_margin=args.get('min_margin') or 20,
                limit=_int(args.get('limit'), 40, 1, 200),
                live_kaspi=(args.get('live_kaspi', '1') != '0'),
            )
        except ValueError as e:
            return jsonify(success=False, error=str(e)), 400
        except RadarBusy as e:
            return jsonify(success=False, error=str(e)), 429
        except Exception as e:
            _WARN.append(str(e))
            return jsonify(success=False, error='Радар временно недоступен: %s' % e), 503
        return jsonify(data)

    def api_save():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(success=False, error='Ожидается список связок.'), 400
        try:
            return jsonify(save_to_found(data))
        except ValueError as e:
            return jsonify(success=False, error=str(e)), 400

    def api_categories():
        return jsonify(categories())

    app.add_url_rule('/api/radar/forks', 'radar_forks', api_forks, methods=['GET'])
    app.add_url_rule('/api/radar/save_to_found', 'radar_save_to_found', api_save, methods=['POST'])
    app.add_url_rule('/api/radar/categories', 'radar_categories', api_categories, methods=['GET'])