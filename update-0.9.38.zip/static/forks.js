// ⚡ Радар вилок (WB / Ozon → Kaspi): режим вкладки «Радар».
// Данные — /api/radar/forks, сохранение — /api/radar/save_to_found.
(function () {
  const $ = id => document.getElementById(id);
  const fmt = n => (n === null || n === undefined || n === '' || isNaN(n)) ? '—' : Math.round(n).toLocaleString('ru-RU') + ' ₸';
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const st = { source: 'all', mode: 'spread', margin: 20, items: [], selected: new Set(), busy: false, cats: null, query: 'органайзер для кухни', pre: {} };
  const toast = msg => { if (typeof window.showToast === 'function') window.showToast(msg); };

  function setMode(mode) {
    const isForks = mode === 'forks';
    const vac = $('radarVacuumPanel'), fk = $('radarForksPanel');
    if (vac) vac.hidden = isForks;
    if (fk) fk.hidden = !isForks;
    document.querySelectorAll('.rms-btn').forEach(b => {
      const on = b.dataset.radarMode === mode;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    if (isForks) {
      document.querySelectorAll('#forksPills .pill-btn').forEach(p => p.classList.toggle('active', (p.dataset.query || '') === st.query));
      loadCategories();
      if (!st.items.length) runSearch();
    }
  }

  function status(msg, cls) {
    const el = $('forksStatus'); if (!el) return;
    el.innerHTML = msg || '';
    el.className = 'help-text' + (cls ? ' ' + cls : '');
  }

  function renderNotes(notes) {
    const el = $('forksNotes'); if (!el) return;
    const list = Object.values(notes || {}).filter(Boolean);
    el.innerHTML = list.length ? list.map(n => `<div class="forks-note">${esc(n)}</div>`).join('') : '';
  }

  async function runSearch() {
    if (st.busy) return;
    const q = ($('forksQuery').value || '').trim();
    if (!q) { status('Введите запрос или выберите нишу.'); return; }
    st.query = q;
    st.busy = true;
    const btn = $('forksGo'); const old = btn.textContent;
    btn.disabled = true; btn.textContent = '⏳ Сканирую…';
    status('Ищу связки на ' + (st.source === 'all' ? 'WB и Ozon' : st.source.toUpperCase()) + ' и сверяю с Kaspi…');
    const range = $('forksMargin');
    st.margin = Number(range.value);
    const url = '/api/radar/forks?query=' + encodeURIComponent(q) +
      '&source=' + encodeURIComponent(st.source) +
      '&mode=' + encodeURIComponent(st.mode) +
      '&min_margin=' + st.margin +
      '&live_kaspi=' + ($('forksLiveKaspi').checked ? '1' : '0');
    const r = await apiGet(url);
    st.busy = false; btn.disabled = false; btn.textContent = old;
    if (!r.ok) {
      st.items = []; renderList();
      status(esc(r.error || 'Не удалось получить вилки.'));
      return;
    }
    const d = r.data;
    st.items = d.items || [];
    st.selected.clear(); updateSel();
    renderNotes(d.notes);
    const modeName = { spread: 'Жирный спред', speed: 'Быстрый оборот', vacuum: 'Вакуум' }[d.mode] || '';
    status(`${d.total} связок · ${modeName} · маржа от ${d.min_margin}% · обновлено ${esc(d.checked_at)}${d.live ? '' : ' · эталонные данные'}`);
    renderList();
    document.querySelectorAll('#forksPills .pill-btn').forEach(p => p.classList.toggle('active', (p.dataset.query || '') === q));
  }

  // ---------------- карточки
  function sideSource(it) {
    const src = it.source === 'ozon' ? 'Ozon' : 'WB';
    const rating = it.rating ? `<span class="fk-star">★ ${it.rating.toFixed(1)}</span>` : '<span class="fk-muted">рейтинг —</span>';
    const fb = it.feedbacks ? `<span class="fk-muted">${Number(it.feedbacks).toLocaleString('ru-RU')} отзывов</span>` : '';
    const img = it.image
      ? `<img class="fk-img" src="${esc(it.image)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">`
      : `<div class="fk-img fk-img-ph">${esc((it.name || '?')[0]).toUpperCase()}</div>`;
    return `<div class="fk-side">
      ${img}
      <div class="fk-side-main">
        <div class="fk-src">${src}${it.seed ? ' · эталон' : ''}</div>
        <div class="fk-name" title="${esc(it.name)}">${esc(it.name)}</div>
        <div class="fk-meta">${rating} ${fb}</div>
        <div class="fk-buy">Закупка <b>${fmt(it.economy.buy_kzt)}</b>
          <span class="fk-rub">${it.economy.buy_rub ? '≈ ' + it.economy.buy_rub.toLocaleString('ru-RU') + ' ₽' : ''}</span></div>
        ${it.url ? `<a class="fk-link" href="${esc(it.url)}" target="_blank" rel="noopener">Открыть на ${src} ↗</a>` : ''}
      </div>
    </div>`;
  }

  function kaspiSide(it) {
    const ks = it.kaspi || {};
    const price = it.economy.sell_kzt;
    const priceTag = it.sell_source === 'kaspi' ? 'Вилка от реальной BuyBox Kaspi' : 'Расчёт по формуле ×2,4 от закупки';
    let sellers;
    if (ks.sellers !== null && ks.sellers !== undefined) sellers = `${ks.sellers} продавцов`;
    else if (ks.checked) sellers = 'продавцов 0';
    else sellers = 'продавцы не проверены';
    const cls = ks.checked ? (ks.vacuum_status === 'saturated' ? 'is-busy' : 'is-free') : 'is-unknown';
    const vac = it.vacuum_level === 'free' ? '<span class="fk-vac fk-vac-free">🕳️ Вакуум: конкурентов нет</span>'
      : it.vacuum_level === 'weak' ? '<span class="fk-vac fk-vac-weak">🕳️ Почти вакуум</span>' : '';
    return `<div class="fk-side fk-kaspi">
      <div class="fk-side-main">
        <div class="fk-src">Kaspi.kz</div>
        <div class="fk-sell">${fmt(price)}</div>
        <div class="fk-muted">${priceTag}</div>
        <div class="fk-sellers ${cls}">${sellers}</div>
        ${vac}
        <div class="fk-muted fk-note" title="${esc(ks.note || '')}">${esc((ks.note || '').slice(0, 90))}</div>
        ${ks.kaspi_url ? `<a class="fk-link" href="${esc(ks.kaspi_url)}" target="_blank" rel="noopener">Проверить на Kaspi ↗</a>` : ''}
      </div>
    </div>`;
  }

  function verdict(e) {
    if (e.status === 'LOSS') return 'fk-verdict-loss';
    if (e.margin_pct >= 25) return 'fk-verdict-super';
    if (e.margin_pct >= 12) return 'fk-verdict-ok';
    return 'fk-verdict-low';
  }

  function card(it) {
    const e = it.economy || {};
    const id = esc(it.id);
    const sel = st.selected.has(it.id);
    const profit = e.profit_kzt || 0;
    const badge = e.status === 'ESTIMATE'
      ? `<div class="fk-badge fk-badge-est">оценка: цена продажи расчётная</div>`
      : `<div class="fk-badge">${profit > 0 ? '+' : ''}${Math.round(profit).toLocaleString('ru-RU')} ₸ чистыми <span>(${e.margin_pct}% маржа · ROI ${e.roi_pct}%)</span></div>`;
    return `<article class="fk-card ${sel ? 'is-sel' : ''}" data-id="${id}">
      <header class="fk-head">
        <label class="fk-check"><input type="checkbox" class="fk-sel" data-id="${id}" ${sel ? 'checked' : ''}><span></span></label>
        <div class="fk-title">${esc(it.name)}${it.brand ? ` <span class="fk-muted">· ${esc(it.brand)}</span>` : ''}</div>
      </header>
      <div class="fk-body">
        ${sideSource(it)}
        <div class="fk-middle ${verdict(e)}">
          <div class="fk-flow">Закуп <b>${fmt(e.buy_kzt)}</b> <span class="fk-arrow">➔</span> Kaspi <b>${fmt(e.sell_kzt)}</b></div>
          ${badge}
          <button type="button" class="fk-details-btn" data-details="${id}">Детализация расходов</button>
        </div>
        ${kaspiSide(it)}
      </div>
      <div class="fk-details" id="fk-det-${id}" hidden></div>
      <footer class="fk-actions">
        <button type="button" class="btn btn-sm btn-primary" data-to-store="${id}">В магазин</button>
        <button type="button" class="btn btn-sm" data-to-preorder="${id}">На предзаказ</button>
      </footer>
    </article>`;
  }

  function detailsHtml(it) {
    const e = it.economy || {};
    const rows = [
      ['Цена продажи Kaspi', e.sell_kzt, ''],
      ['Закупка на ' + (it.source === 'ozon' ? 'Ozon' : 'WB'), -e.buy_kzt, e.buy_rub ? '≈ ' + e.buy_rub.toLocaleString('ru-RU') + ' ₽ по курсу ' + e.rate : ''],
      ['Комиссия Kaspi (' + e.commission_rate + '%)', -e.commission_kzt, ''],
      ['Эквайринг Kaspi Pay', -e.kaspi_pay_kzt, ''],
      ['Доставка Kaspi (' + esc(e.delivery_tier) + ')', -e.delivery_kzt, 'с НДС ' + fmt(e.delivery_vat_kzt)],
      ['Упаковка', -e.pack_kzt, ''],
      ['Налог ИП 3%', -e.tax_kzt, ''],
    ];
    return `<table class="fk-det-table">
      <tbody>${rows.map(([k, v, note]) => `<tr><td>${k}</td><td class="${v < 0 ? 'neg' : ''}">${v < 0 ? '−' : ''}${fmt(Math.abs(v))}</td><td class="fk-muted">${note}</td></tr>`).join('')}</tbody>
      <tfoot>
        <tr><td>На руки с продажи</td><td colspan="2"><b>${fmt(e.payout_kzt)}</b></td></tr>
        <tr class="fk-det-net"><td>Чистая прибыль</td><td>${(e.profit_kzt || 0) > 0 ? '+' : ''}${fmt(e.profit_kzt)}</td><td class="fk-muted">ROI ${e.roi_pct}% · маржа ${e.margin_pct}%</td></tr>
      </tfoot>
    </table>`;
  }

  function renderList() {
    const box = $('forksList'); if (!box) return;
    if (!st.items.length) {
      box.innerHTML = '<div class="forks-empty">Связок нет. Подвиньте «Мин. чистую маржу» влево (0% — показать все), смените источник или запрос.</div>';
      return;
    }
    box.innerHTML = st.items.map(card).join('');
  }

  function updateSel() {
    const n = st.selected.size;
    const c = $('forksSelCount'); if (c) c.textContent = n;
    const b = $('forksSaveSel'); if (b) b.disabled = !n;
  }

  // ---------------- «Найденное»: выгрузка
  async function saveToFound(list) {
    if (!list.length) return false;
    const r = await apiPost('/api/radar/save_to_found', { items: list, query: st.query });
    if (r.ok) { toast('✓ ' + (r.data.message || 'Сохранено в «Найденное».')); return true; }
    toast('Не удалось сохранить: ' + r.error);
    return false;
  }

  function openPreorder() {
    const tab = document.querySelector('.nav-item[data-tab="tab-preorder"]');
    if (tab) tab.click();
    toast('Товар в «Найденном». В разделе «Предзаказ карточек» вставьте ссылку на такую же карточку Kaspi, чтобы присоединиться к ней.');
  }

  // Эталонные связки не имеют живых id WB/Ozon: сначала повторяю поиск по запросу,
  // затем беру живую связку с тем же товаром, иначе предлагаю найти товар в Радаре.
  async function resolveLive(it) {
    if (!it.seed) return it;
    if (st.pre[it.id]) return st.pre[it.id];
    status('Ищу этот товар в живой выдаче площадки…');
    const r = await apiGet('/api/radar/forks?query=' + encodeURIComponent(it.kaspi_query || it.name) +
      '&source=' + encodeURIComponent(it.source) + '&mode=spread&min_margin=0&live_kaspi=0&limit=60');
    const words = (it.name || '').toLowerCase().split(/\s+/).filter(w => w.length > 4);
    const hit = r.ok ? (r.data.items || []).find(x => !x.seed && words.filter(w => x.name.toLowerCase().includes(w)).length >= Math.min(2, words.length)) : null;
    if (hit) { st.pre[it.id] = hit; return hit; }
    status('');
    toast('Эталоны в «Найденное» не сохраняются: живой товар сейчас не нашёлся. Введите этот запрос в поиск Радара или откройте «Хиты Wildberries» — там живые ссылки.');
    return null;
  }

  async function toStoreOrPreorder(it, preorder) {
    const live = await resolveLive(it);
    if (!live) return;
    if (await saveToFound([live])) {
      const tab = document.querySelector('.nav-item[data-tab="' + (preorder ? 'tab-preorder' : 'tab-found') + '"]');
      if (tab) tab.click();
      if (preorder) openPreorder();
    }
  }

  async function refreshData(it, btn, id) {
    if (btn.dataset.busy) return;
    btn.dataset.busy = '1'; btn.disabled = true; btn.textContent = '⏳ Проверяю Kaspi…';
    const r = await apiGet('/api/radar/forks?query=' + encodeURIComponent(it.kaspi && it.kaspi.kaspi_url ? (it.kaspi_query || it.name) : st.query) +
      '&source=' + encodeURIComponent(it.source) + '&mode=spread&min_margin=0&live_kaspi=1');
    delete btn.dataset.busy;
    if (r.ok && (r.data.items || []).length) {
      const match = r.data.items.find(x => x.id === it.id) || r.data.items[0];
      const i = st.items.findIndex(x => x.id === it.id);
      if (i >= 0 && match) {
        const wasSel = st.selected.has(it.id);
        st.items[i] = match;
        st.selected.delete(it.id); if (wasSel) st.selected.add(match.id);
        updateSel();
        renderList();
        showToast('Данные обновлены.');
        return;
      }
    }
    btn.disabled = false; btn.textContent = 'Обновить данные';
    showToast('Не удалось обновить: ' + (r.error || 'повторите позже'));
  }

  // ---------------- категории
  async function loadCategories() {
    if (st.cats) return;
    const r = await apiGet('/api/radar/categories');
    st.cats = (r.ok && r.data.items) || [];
    renderCats('');
  }

  function renderCats(needle) {
    const box = $('forksCatList'); if (!box) return;
    const n = needle.trim().toLowerCase();
    const list = n ? st.cats.filter(c => c.name.toLowerCase().includes(n) || c.path.join(' ').toLowerCase().includes(n)) : [];
    box.innerHTML = list.slice(0, 60).map(c =>
      `<button type="button" class="forks-cat" data-cat="${esc(c.name)}"><b>${esc(c.name)}</b><span>${esc(c.path.slice(0, -1).join(' · '))}</span></button>`
    ).join('') + (!n ? `<div class="help-text">Всего ${st.cats.length.toLocaleString('ru-RU')} категорий. Начните вводить название.</div>` : (list.length ? '' : '<div class="help-text">Не найдено.</div>'));
  }

  // ---------------- события
  function bind() {
    document.querySelectorAll('.rms-btn').forEach(b => b.addEventListener('click', () => setMode(b.dataset.radarMode)));

    const go = $('forksGo'); if (go) go.addEventListener('click', runSearch);
    const q = $('forksQuery'); if (q) q.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); runSearch(); } });

    document.querySelectorAll('#forksSource .seg-btn').forEach(b => b.addEventListener('click', () => {
      st.source = b.dataset.v;
      document.querySelectorAll('#forksSource .seg-btn').forEach(x => x.classList.toggle('active', x === b));
      runSearch();
    }));

    const mode = $('forksMode'); if (mode) mode.addEventListener('change', () => { st.mode = mode.value; runSearch(); });

    const range = $('forksMargin'); if (range) range.addEventListener('input', () => { $('forksMarginVal').textContent = range.value + '%'; });
    if (range) range.addEventListener('change', () => { st.margin = Number(range.value); runSearch(); });

    const live = $('forksLiveKaspi'); if (live) live.addEventListener('change', () => { if (live.checked) runSearch(); });

    document.querySelectorAll('#forksPills .pill-btn').forEach(p => p.addEventListener('click', () => {
      $('forksQuery').value = p.dataset.query || '';
      runSearch();
    }));

    const cf = $('forksCatFind'); if (cf) cf.addEventListener('input', () => renderCats(cf.value));
    const cl = $('forksCatList');
    if (cl) cl.addEventListener('click', e => {
      const b = e.target.closest('.forks-cat'); if (!b) return;
      $('forksQuery').value = b.dataset.cat;
      const path = $('forksCatPath'); if (path) path.textContent = 'Выбрано: ' + b.dataset.cat;
      runSearch();
    });

    const saveBtn = $('forksSaveSel'); if (saveBtn) saveBtn.addEventListener('click', async () => {
      const list = st.items.filter(x => st.selected.has(x.id) && !x.seed);
      if (!list.length) { toast('Эталонные связки не сохраняются: они без живой ссылки. Выберите сканированные товары или нажмите «Обновить данные».'); return; }
      if (await saveToFound(list)) { st.selected.clear(); updateSel(); renderList(); }
    });

    const list = $('forksList');
    if (list) list.addEventListener('click', e => {
      const t = e.target;
      if (t.classList && t.classList.contains('fk-sel')) {
        const id = st.items.find(x => x.id === t.dataset.id)?.id;
        if (t.checked) st.selected.add(id); else st.selected.delete(id);
        const art = t.closest('.fk-card'); if (art) art.classList.toggle('is-sel', t.checked);
        updateSel();
        return;
      }
      const det = t.closest('[data-details]');
      if (det) {
        const it = st.items.find(x => x.id === det.dataset.details); if (!it) return;
        const box = $('fk-det-' + it.id); if (!box) return;
        if (box.hidden) { box.innerHTML = detailsHtml(it) + '<button type="button" class="btn btn-sm" data-refresh="1">Обновить данные</button>'; box.hidden = false; }
        else box.hidden = true;
        return;
      }
      const ref = t.closest('[data-refresh]');
      if (ref) {
        const art = ref.closest('.fk-card'); if (!art) return;
        const it = st.items.find(x => x.id === art.dataset.id);
        if (it) refreshData(it, ref, it.id);
        return;
      }
      const store = t.closest('[data-to-store]');
      if (store) {
        const it = st.items.find(x => x.id === store.dataset.toStore); if (!it) return;
        toStoreOrPreorder(it, false);
        return;
      }
      const pre = t.closest('[data-to-preorder]');
      if (pre) {
        const it = st.items.find(x => x.id === pre.dataset.toPreorder); if (!it) return;
        toStoreOrPreorder(it, true);
      }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind);
  else bind();
})();