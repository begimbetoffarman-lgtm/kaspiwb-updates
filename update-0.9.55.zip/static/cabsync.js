// Сверка с кабинетом Kaspi: быстрое чтение списка товаров пачками (только чтение), фото и коды карточек, расхождения.
(function () {
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let card = null, poll = null, wasRunning = false;

  function ensureCard() {
    if (card && document.body.contains(card)) return card;
    const anchor = $('apCard');
    if (!anchor) return null;
    card = document.createElement('div');
    card.className = 'card cs-card';
    card.id = 'csCard';
    card.innerHTML = `<div class="ap-head"><b>Сверка с Kaspi</b><span class="help-text">Программа читает список товаров вашего кабинета пачками (только чтение): подтягивает фото и коды карточек и показывает, где данные в программе и на Kaspi разошлись.</span></div>
      <div class="ap-global"><button type="button" class="btn btn-secondary btn-sm" id="csGo">Сверить сейчас</button><span id="csMsg" class="help-text"></span></div>
      <div id="csDiff"></div>`;
    anchor.insertAdjacentElement('afterend', card);
    $('csGo').onclick = () => start(true);
    return card;
  }

  async function j(url, opt) {
    try { return await fetch(url, opt).then(x => x.json()); } catch (e) { return { success: false, error: e.message }; }
  }

  function ago(ts) {
    if (!ts) return 'ещё не сверялось';
    const m = Math.round((Date.now() / 1000 - ts) / 60);
    return m < 1 ? 'только что' : (m < 60 ? m + ' мин назад' : Math.round(m / 60) + ' ч назад');
  }

  async function showDiff() {
    const r = await j('/api/cabinet/sync/diff');
    if (!r.success || !$('csDiff')) return;
    const d = r.diff || [];
    $('csDiff').innerHTML = d.length
      ? `<div class="help-text" style="margin:8px 0">Расхождений: ${d.length}${d.length >= 200 ? '+' : ''}. Откройте товар и отправьте нужное значение в Kaspi.</div><table class="cs-tbl">${d.slice(0, 50).map(x => `<tr><td>${esc(x.title)}<div class="cs-sku">${esc(x.sku)}</div></td><td>${x.diffs.map(esc).join('<br>')}</td><td><button type="button" class="btn btn-secondary btn-sm kp-open" data-sku="${esc(x.sku)}">Открыть</button></td></tr>`).join('')}</table>`
      : '<div class="kp-ok" style="margin-top:8px">Расхождений нет: цены, предзаказы и наличие в программе совпадают с Kaspi.</div>';
  }

  async function refreshStatus() {
    const r = await j('/api/cabinet/sync/status');
    if (!r.success || !ensureCard()) return;
    const msg = $('csMsg');
    if (r.running) {
      wasRunning = true;
      msg.textContent = `Читаю кабинет: ${r.done} из ${r.total || '…'} товаров`;
      if (!poll) poll = setInterval(refreshStatus, 2500);
      return;
    }
    if (poll) { clearInterval(poll); poll = null; }
    msg.textContent = r.error ? ('Не удалось: ' + r.error) : `Сверено ${r.items} товаров, ${ago(r.at)}.` + (r.capped ? ' Kaspi отдаёт список не глубже ~10 000 товаров за проход: остальные подгружаются по одному при листании.' : '');
    if (wasRunning && !r.error) {
      wasRunning = false;
      if (typeof window.loadKaspiStore === 'function') window.loadKaspiStore();   // фото и коды карточек появятся в таблице
    }
    if (!r.error && r.items) showDiff();
  }

  async function start(force) {
    if (!ensureCard()) return;
    $('csMsg').textContent = 'Запускаю…';
    const r = await j('/api/cabinet/sync/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ force: !!force }) });
    if (!r.success) { $('csMsg').textContent = r.error || 'Не удалось запустить.'; return; }
    refreshStatus();
  }

  // при открытии раздела: тихо запускаем (сервер не чаще раза в 10 минут) и показываем итог
  setTimeout(() => { if (ensureCard()) start(false); }, 2500);
  const prev = window.loadKaspiStore;
  if (typeof prev === 'function') window.loadKaspiStore = async function () { const x = await prev.apply(this, arguments); ensureCard(); return x; };
})();
