// Автопредзаказ: общая карточка настроек и маленький блок в строке товара («Мой магазин Kaspi»).
(function () {
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // блок в строке товара: вызывается из app.js при отрисовке таблицы
  window.apBoxHtml = function (p) {
    if (p.delivery_type === 'preorder') return `<div class="ap-box"><span class="ap-st">предзаказ ${esc(p.preorder_days)} дн: срок не меняется</span></div>`;
    const a = p.auto_pre || { on: false };
    const on = !!a.on;
    let st = '';
    if (on && a.known === false) st = '<span class="ap-st warn">остаток неизвестен: укажите</span>';
    else if (on && a.pre) st = `<span class="ap-st pre">в предзаказе · ${a.days} дн · остаток ${a.qty}</span>`;
    else if (on && a.remaining != null) st = `<span class="ap-st ok">осталось ${a.remaining} из ${a.base}</span>`;
    const stockVal = a.base != null ? '' : '';
    return `<div class="ap-box" data-sku="${esc(p.sku)}">
      <label class="ap-line"><input type="checkbox" class="ap-on" ${on ? 'checked' : ''}> Автопредзаказ</label>
      <label class="ap-line">остаток <input type="number" min="0" class="ap-stock" value="${stockVal}" placeholder="${a.base != null ? a.base : (p.stock_est ? '?' : p.stock)}"></label>
      ${st}
    </div>`;
  };

  async function post(url, body) {
    try {
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      return await r.json();
    } catch (e) { return { success: false, error: e.message }; }
  }
  function reloadStore() { if (typeof window.loadKaspiStore === 'function') window.loadKaspiStore(); }

  // события в таблице (таблица перерисовывается, поэтому делегирование)
  document.addEventListener('change', async e => {
    const box = e.target.closest && e.target.closest('.ap-box');
    if (!box) return;
    const sku = box.dataset.sku;
    const on = box.querySelector('.ap-on').checked;
    const stockEl = box.querySelector('.ap-stock');
    const body = { sku: sku, on: on };
    if (e.target === stockEl && stockEl.value !== '') body.stock = stockEl.value;
    if (e.target === box.querySelector('.ap-on') && on && stockEl.value !== '') body.stock = stockEl.value;
    const r = await post('/api/autopreorder/item', body);
    if (!r.success) { if (window.showToast) showToast('Не удалось сохранить: ' + (r.error || '')); return; }
    reloadStore();
  });

  async function loadGlobal() {
    if (!$('apCard')) return;
    try {
      const r = await fetch('/api/autopreorder').then(x => x.json());
      if (!r.success) return;
      $('apAll').checked = !!r.enabled_all;
      $('apThr').value = r.threshold;
      $('apQty').value = r.virtual_qty;
      $('apDays').value = r.default_days;
    } catch (e) { /* без связи оставляем значения по умолчанию */ }
  }
  if ($('apSave')) {
    $('apSave').onclick = async () => {
      $('apMsg').textContent = 'Сохраняю…';
      const r = await post('/api/autopreorder/global', {
        enabled_all: $('apAll').checked, threshold: $('apThr').value, virtual_qty: $('apQty').value, default_days: $('apDays').value,
      });
      $('apMsg').textContent = r.success ? 'Сохранено. Прайс для Kaspi обновится при следующей выгрузке.' : (r.error || 'Не удалось сохранить.');
      if (r.success) reloadStore();
    };
  }
  loadGlobal();
  const prev = window.loadKaspiStore;
  if (typeof prev === 'function') window.loadKaspiStore = async function () { const x = await prev.apply(this, arguments); loadGlobal(); return x; };
})();
