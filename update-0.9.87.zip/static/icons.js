// Значки перед текстом: заголовки разделов, плитки показателей, главные кнопки. Только оформление.
(function () {
  'use strict';
  const P = {
    link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    chart: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
    table: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 4v16"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7M12 17h.01"/>',
    wallet: '<path d="M3 7a2 2 0 0 1 2-2h13v4"/><path d="M3 7v11a2 2 0 0 0 2 2h15V9H5a2 2 0 0 1-2-2z"/><circle cx="16.5" cy="14.5" r="1"/>',
    box: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
    percent: '<path d="M19 5 5 19"/><circle cx="7" cy="7" r="2.5"/><circle cx="17" cy="17" r="2.5"/>',
    trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>',
    alert: '<path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17h.01"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    save: '<path d="M5 3h11l4 4v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M8 3v5h7V3M8 21v-7h8v7"/>',
    bolt: '<path d="M13 2 3 14h8l-1 8 10-12h-8z"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M16 7l3 3"/>',
    store: '<path d="M3 9l1.5-5h15L21 9"/><path d="M4 9v11h16V9M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/>'
  };
  // [селектор, значок, вид: tile | inline, оттенок]
  const MAP = [
    ['#kfBox > h3', 'link', 'tile'],
    ['#apCard .ap-head > b', 'clock', 'tile'],
    ['.store-hero-card h2', 'chart', 'tile'],
    ['#tab-my-store .table-title h3', 'table', 'tile'],
    ['#radarVacuumPanel .table-title h3', 'search', 'tile'],
    ['#radarHowto > summary', 'help', 'tile'],
    ['#preorderBox > h3', 'clock', 'tile'],
    ['.store-kpi-card:nth-child(1) .kpi-title', 'wallet', 'tile', 'good'],
    ['.store-kpi-card:nth-child(2) .kpi-title', 'box', 'tile'],
    ['.store-kpi-card:nth-child(3) .kpi-title', 'percent', 'tile', 'good'],
    ['.store-kpi-card:nth-child(4) .kpi-title', 'trophy', 'tile', 'warn'],
    ['.store-kpi-card:nth-child(5) .kpi-title', 'alert', 'tile', 'bad'],
    ['#forksGo', 'search', 'inline'],
    ['#kfFind', 'eye', 'inline'],
    ['#kfGo', 'clock', 'inline'],
    ['#apSave', 'save', 'inline'],
    ['#btnSidebarActivate', 'key', 'inline']
  ];
  function mk(name, tile, tone) {
    const s = document.createElement('span');
    s.className = tile ? 'ico-tile' + (tone ? ' ' + tone : '') : 'ico';
    s.setAttribute('aria-hidden', 'true');
    s.innerHTML = '<svg viewBox="0 0 24 24">' + P[name] + '</svg>';
    return s;
  }
  function apply() {
    MAP.forEach(([sel, name, kind, tone]) => {
      document.querySelectorAll(sel).forEach(el => {
        if (el.querySelector(':scope > .ico, :scope > .ico-tile')) return;
        if (!P[name]) return;
        el.insertBefore(mk(name, kind === 'tile', tone), el.firstChild);
      });
    });
  }
  function init() { apply(); setTimeout(apply, 1200); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  document.addEventListener('click', e => { if (e.target.closest && e.target.closest('.nav-item')) setTimeout(apply, 250); });
})();
