// Предзаказ по ссылке Kaspi: данные карточки (отзывы, цены, продавцы) и кнопка «Поставить на предзаказ».
(function () {
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fmt = n => (n == null || n === '') ? '—' : Math.round(+n).toLocaleString('ru-RU') + ' ₸';
  const post = async (u, b) => { const r = await apiPost(u, b); return r.data || { success: false, error: r.error }; };
  let card = null, lastSku = '';

  // кнопка в «Предзаказ карточек» ведёт сюда
  document.addEventListener('click', e => {
    if (!(e.target.closest && e.target.closest('#kfOpen'))) return;
    setTimeout(() => { const b = document.querySelector('.rms-btn[data-radar-mode="link"]'); if (b) b.click(); }, 80);
  });
  if (!$('kfBox')) return;

  function show(c) {
    const range = c.price_min != null ? (c.price_max && c.price_max !== c.price_min ? fmt(c.price_min) + ' – ' + fmt(c.price_max) : fmt(c.price_min)) : '—';
    const sellers = c.sellers ? String(c.sellers) : (c.offers_ok ? '0' : '—');
    const pre = c.sellers ? (c.preorder_sellers ? c.preorder_sellers + ' на предзаказе' : 'все в наличии') : (c.offers_ok ? '' : esc(c.offers_error || 'не прочитались'));
    const rows = (c.top || []).map(o => `<tr><td>${esc(o.merchant || 'продавец')}</td><td>${o.preorder ? 'предзаказ ' + o.preorder + ' дн.' : 'в наличии'}</td><td><b>${fmt(o.price)}</b></td></tr>`).join('');
    const href = c.link ? (c.link.startsWith('http') ? c.link : 'https://kaspi.kz' + c.link) : '';
    $('kfInfo').innerHTML =
      '<div class="kf-head">' +
      (c.img ? `<img class="kf-img" src="${esc(c.img)}" referrerpolicy="no-referrer" alt="">` : '') +
      `<div><div class="kf-title">${esc(c.title || 'Карточка ' + c.code)}</div>` +
      `<div class="kf-sub">${esc(c.category || '')}${c.category ? ' · ' : ''}код ${esc(c.code)}${href ? ` · <a href="${esc(href)}" target="_blank" rel="noopener">открыть на Kaspi</a>` : ''}</div>` +
      (c.preview_error ? `<div class="kf-sub">Название и фото не прочитались: войдите в кабинет Kaspi (${esc(c.preview_error)})</div>` : '') +
      '</div></div>' +
      '<div class="kf-tiles">' +
      `<div class="kf-tile"><span>Цена на Kaspi</span><b>${range}</b></div>` +
      `<div class="kf-tile"><span>Продавцов${pre ? ' · ' + pre : ''}</span><b>${sellers}</b></div>` +
      `<div class="kf-tile"><span>Отзывов</span><b>${c.reviews != null ? c.reviews : '—'}</b></div>` +
      `<div class="kf-tile"><span>Рейтинг</span><b>${c.rating ? (+c.rating).toFixed(1) : '—'}</b></div></div>` +
      (rows ? `<table class="kf-sellers">${rows}</table>` : '');
  }

  $('kfFind').onclick = async () => {
    $('kfForm').style.display = 'none'; card = null;
    $('kfInfo').textContent = 'Читаю карточку…';
    $('kfFind').disabled = true;
    try {
      const d = await post('/api/link/info', { code: $('kfUrl').value });
      if (!d.success) { $('kfInfo').innerHTML = '<div class="wbt-banner bad"><b class="t">Не получилось</b><br>' + esc(d.error) + '</div>'; return; }
      card = d.info; show(card);
      if (card.title) { $('kfPrice').value = card.price_min || ''; $('kfForm').style.display = 'flex'; }
    } finally { $('kfFind').disabled = false; }
  };
  $('kfUrl').addEventListener('keydown', e => { if (e.key === 'Enter') $('kfFind').click(); });

  $('kfGo').onclick = async () => {
    if (!card) return;
    const price = +$('kfPrice').value || 0, days = parseInt($('kfDays').value, 10) || 0;
    if (!price || !days) { $('kfInfo').insertAdjacentHTML('beforeend', '<div class="wbt-banner bad">Укажите цену и срок предзаказа в днях.</div>'); return; }
    if (!confirm('Присоединить ваш магазин к карточке «' + card.title + '» в живом Kaspi: цена ' + price + ' ₸, предзаказ ' + days + ' дн.?')) return;
    $('kfGo').disabled = true;
    const keep = $('kfInfo').innerHTML;
    $('kfInfo').textContent = 'Отправляю в Kaspi…';
    try {
      const d = await post('/api/link/apply', { code: card.code, price, days, confirm: true });
      if (!d.success) { $('kfInfo').innerHTML = '<div class="wbt-banner bad"><b class="t">Не получилось поставить на предзаказ</b><br>' + esc(d.error) + '</div>' + keep; return; }
      $('kfForm').style.display = 'none';
      lastSku = d.sku || lastSku; $('kfInfo').innerHTML = '<div class="wbt-banner ok">Готово. Артикул ' + esc(d.sku) + (d.offer_set ? ': цена и предзаказ выставлены.' : '. Цену и срок поставьте в кабинете' + (d.offer_error ? ' (' + esc(d.offer_error) + ')' : '') + '.') + '</div>' + keep;
    } finally { $('kfGo').disabled = false; }
  };

  // ---- набор с WB: фото, описание, характеристики ----
  const copy = async (text, btn) => {
    try { await navigator.clipboard.writeText(text); } catch (e) { const t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); } catch (x) { } t.remove(); }
    const old = btn.textContent; btn.textContent = '✓ Скопировано'; setTimeout(() => { btn.textContent = old; }, 1400);
  };
  $('kfWbGo').onclick = async () => {
    const out = $('kfWbOut'); out.textContent = 'Читаю карточку WB…'; $('kfWbGo').disabled = true;
    try {
      const d = await post('/api/link/wb_pack', { url: $('kfWbUrl').value });
      if (!d.success) { out.innerHTML = '<div class="wbt-banner bad"><b class="t">Не получилось</b><br>' + esc(d.error) + '</div>'; return; }
      const p = d.pack, now = card && card.photos != null ? card.photos : null;
      const chars = p.characteristics.map(c => c.name + ': ' + c.value).join('\n');
      const more = p.photo_count_wb > p.photos.length ? ' (на WB их ' + p.photo_count_wb + ', берём первые ' + p.photos.length + ')' : '';
      out.innerHTML =
        '<div class="kf-cmp"><div class="kf-cmp-col"><span>Сейчас на Kaspi</span><b>' + (now != null ? now + ' фото' : '—') + '</b>' + ((card && card.photo_urls && card.photo_urls.length) ? '<div class="kf-now">' + card.photo_urls.slice(0, 6).map(u => '<img src="' + esc(u) + '" referrerpolicy="no-referrer" alt="">').join('') + '</div>' : '') + '</div>' +
        '<div class="kf-cmp-arrow">→</div><div class="kf-cmp-col new"><span>С WB</span><b>' + p.photos.length + ' фото' + '</b></div></div>' +
        '<div class="kf-wb-title">' + esc(p.title || '') + (p.subject ? ' <small>· ' + esc(p.subject) + '</small>' : '') + '</div>' +
        '<div class="kf-thumbs" id="kfThumbs">' + p.photos.map((u, i) => '<img data-i="' + i + '" src="' + esc(u) + '" referrerpolicy="no-referrer" alt="">').join('') + '</div>' +
        '<div class="kf-sub">Нажимайте на фото, чтобы выбрать, какие отправить в Kaspi (выбрано: <b id="kfSelN">0</b>).</div>' +
        '<div class="kf-wb-actions"><a class="btn btn-accent" href="/api/link/wb_photos?id=' + p.wb_id + '" download>Скачать фото (архив JPEG)' + '</a><span>' + more + '</span></div>' +
        '<div class="kf-wb-block"><div class="kf-wb-h"><b>Описание</b> <small>' + p.description.length + ' / 7000</small><button type="button" class="btn btn-secondary btn-sm" id="kfCopyDesc">Скопировать</button></div><div class="kf-wb-text">' + esc(p.description) + '</div></div>' +
        '<div class="kf-wb-block"><div class="kf-wb-h"><b>Характеристики</b> <small>' + p.characteristics.length + '</small><button type="button" class="btn btn-secondary btn-sm" id="kfCopyChars">Скопировать</button></div>' +
        '<table class="kf-sellers">' + p.characteristics.map(c => '<tr><td>' + esc(c.name) + '</td><td>' + esc(c.value) + '</td></tr>').join('') + '</table></div>' +
        (p.brand_removed ? '<div class="kf-sub">Бренд поставщика WB убран из текста (настройка «без бренда»).</div>' : '') +
        '<div class="kf-sub">Kaspi может отклонить фото с надписями и инфографикой: надёжнее фото на белом фоне (на WB это обычно последние кадры).</div>' +
        '<div class="kf-edit"><b>Отправить в Kaspi заявкой</b>' +
        '<div class="kf-sub">Kaspi принимает правку карточки как заявку: проверяет её сам, это занимает время. Менять можно фото и описание, характеристики Kaspi не даёт править, поэтому их можно добавить в текст описания.</div>' +
        '<label class="kf-ck"><input type="checkbox" id="kfEdDesc" checked> Заменить описание</label>' +
        '<label class="kf-ck"><input type="checkbox" id="kfEdChars" checked> Добавить характеристики в текст описания</label>' +
        '<label class="kf-ck"><input type="checkbox" id="kfEdKeep" checked> Оставить старые фото Kaspi (новые добавятся к ним)</label>' +
        '<label class="kf-sku">Артикул вашего товара на Kaspi <input type="text" id="kfEdSku" placeholder="как в кабинете, например WB365719802" value="' + esc(lastSku || (card && card.my_sku) || '') + '"></label>' +
        '<div class="kf-wb-actions"><button type="button" class="btn btn-primary" id="kfEdPrep">Подготовить заявку</button></div>' +
        '<div id="kfEdOut" class="help-text"></div></div>';
      const sel = new Set();
      const upd = () => { $('kfSelN').textContent = sel.size; };
      $('kfThumbs').onclick = e => { const im = e.target.closest('img'); if (!im) return; const i = +im.dataset.i; if (sel.has(i)) sel.delete(i); else sel.add(i); im.classList.toggle('sel', sel.has(i)); upd(); };
      $('kfEdPrep').onclick = async () => {
        const out = $('kfEdOut');
        if (!card || !card.code) { out.innerHTML = '<div class="wbt-banner bad">Сначала нажмите «Показать данные» по карточке Kaspi выше.</div>'; return; }
        if (!sel.size && !$('kfEdDesc').checked) { out.innerHTML = '<div class="wbt-banner bad">Выберите фото или отметьте «Заменить описание».</div>'; return; }
        $('kfEdPrep').disabled = true; out.textContent = 'Загружаю фото в Kaspi и прошу черновик… (до минуты)';
        try {
          const d = await post('/api/link/edit_prepare', { code: card.code, sku: $('kfEdSku').value, wb: p.wb_id, photos: [...sel].sort((a, b) => a - b), description: $('kfEdDesc').checked, chars: $('kfEdChars').checked, keep_existing: $('kfEdKeep').checked });
          if (!d.success) { out.innerHTML = '<div class="wbt-banner bad"><b class="t">Не получилось</b><br>' + esc(d.error) + '</div>'; return; }
          const r = d.prep;
          out.innerHTML = '<div class="wbt-banner ok"><b class="t">Черновик готов, в Kaspi пока ничего не отправлено</b><br>' +
            'Фото: было ' + r.photos_before + ', станет ' + r.photos_total + ' (добавляется ' + r.photos_added + ').<br>' +
            (r.description_changed ? 'Описание: заменится на новое (' + r.description_len + ' знаков).<br>' : 'Описание не меняется.<br>') + '</div>' +
            '<div class="kf-wb-actions"><button type="button" class="btn btn-accent" id="kfEdGo">Подать заявку в Kaspi</button><span>Kaspi проверит заявку сам; отозвать её можно в кабинете.</span></div>';
          $('kfEdGo').onclick = async () => {
            if (!confirm('Подать заявку на изменение карточки «' + (card.title || card.code) + '» в живой Kaspi?\nФото: ' + r.photos_before + ' → ' + r.photos_total + (r.description_changed ? '\nОписание будет заменено.' : '') + '\nКарточка изменится только после одобрения Kaspi.')) return;
            $('kfEdGo').disabled = true; out.insertAdjacentHTML('beforeend', '<div>Отправляю заявку…</div>');
            const s = await post('/api/link/edit_submit', { token: r.token, confirm: true });
            if (!s.success) { out.innerHTML = '<div class="wbt-banner bad"><b class="t">Заявка не принята</b><br>' + esc(s.error) + '</div>'; return; }
            out.innerHTML = '<div class="wbt-banner ok"><b class="t">Заявка подана</b><br>Kaspi проверит её и применит изменения после одобрения. Статус виден в кабинете: «Управление товарами» → карточка.</div>';
          };
        } finally { $('kfEdPrep').disabled = false; }
      };
      upd();
      // автоподсказка: фото на белом фоне выбираем сами, инфографику оставляем на ваш выбор
      post('/api/link/wb_flags', { wb: p.wb_id }).then(f => {
        if (!f.success || !f.flags) return;
        const th = [...document.querySelectorAll('#kfThumbs img')];
        f.flags.clean.forEach((c, i) => {
          if (!th[i]) return;
          if (c === false) th[i].classList.add('info'); else if (c === true) { th[i].classList.add('ok'); sel.add(i); th[i].classList.add('sel'); }
        });
        upd();
        const n = f.flags.clean.filter(x => x === false).length;
        if (n) $('kfSelN').parentElement.insertAdjacentHTML('beforeend', ' Программа выбрала фото на белом фоне; ' + n + ' фото с надписями (инфографика, помечены) Kaspi может отклонить.');
      });
      $('kfCopyDesc').onclick = e => copy(p.description, e.target);
      $('kfCopyChars').onclick = e => copy(chars, e.target);
    } finally { $('kfWbGo').disabled = false; }
  };
  $('kfWbUrl').addEventListener('keydown', e => { if (e.key === 'Enter') $('kfWbGo').click(); });
})();
