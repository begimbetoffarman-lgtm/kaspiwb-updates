"""Read-only supplier search in the installed browser; no Kaspi operations."""
import datetime
import json
import math
import os
import re
import threading
import time
import urllib.parse
import uuid
import io

from core import wb_browser

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_LOCK = threading.Lock()
_TABS = {}
_LAST_READ = 0.0
_PRODUCTS = {}
_CN = [('обув', '鞋子收纳盒'), ('органайзер', '收纳盒'), ('полка', '置物架'),
       ('кухн', '厨房'), ('держатель', '支架'), ('лампа', '台灯'), ('сумка', '包'), ('рюкзак', '双肩包')]


class SupplierError(RuntimeError):
    """Only deliberate, safe messages for the seller; no raw browser exceptions."""


def source_name(source):
    if source not in ('1688', 'ozon'):
        raise ValueError('Выберите 1688 или Ozon.')
    return source


def product_url(source, value):
    source_name(source)
    try:
        u = urllib.parse.urlsplit(str(value).strip())
        hosts = ('detail.1688.com',) if source == '1688' else ('ozon.kz', 'www.ozon.kz', 'ozon.ru', 'www.ozon.ru')
        pattern = r'/offer/\d{5,20}\.html' if source == '1688' else r'/product/(?:[^/]*-)?\d{5,20}/?'
        if u.scheme not in ('https', 'http') or u.hostname not in hosts or u.username or u.password or u.port not in (None, 80, 443) or not re.fullmatch(pattern, u.path):
            raise ValueError()
    except (TypeError, ValueError):
        raise ValueError('Вставьте полную ссылку на товар выбранного сайта.') from None
    return ('https://detail.1688.com' if source == '1688' else 'https://ozon.kz') + u.path


def search_url(source, query):
    source_name(source)
    query = str(query or '').strip()
    if not query or len(query) > 200:
        raise ValueError('Введите запрос до 200 символов.')
    effective = query
    if source == '1688':
        if re.search('[а-яА-ЯёЁ]', query):
            effective = next((cn for ru, cn in _CN if ru in query.lower()), '')
            if not effective:
                raise ValueError('Для 1688 введите запрос на китайском или откройте товар по ссылке. Пример: 收纳盒 — органайзер.')
        try:
            encoded = urllib.parse.quote(effective.encode('gbk'))
        except UnicodeEncodeError:
            raise ValueError('1688 не поддерживает эти символы в поиске. Введите название без эмодзи.') from None
        return 'https://s.1688.com/selloffer/offer_search.htm?keywords=' + encoded + '&n=y', effective
    return 'https://ozon.kz/search/?' + urllib.parse.urlencode({'text': effective}), effective


def _browser_read(source, mode, url, photo_path=None):
    """One page at a time. Keep a challenged tab open for the user to resolve."""
    global _LAST_READ
    if not _LOCK.acquire(blocking=False):
        raise SupplierError('Уже идёт загрузка товара. Дождитесь её завершения.')
    ws = None
    try:
        error = wb_browser._ensure_browser()
        if error:
            raise SupplierError('Не удалось открыть браузер. Установите Edge или Chrome и повторите.')
        pause = 3 - (time.monotonic() - _LAST_READ)
        if pause > 0:
            time.sleep(pause)
        port = wb_browser.PORT
        tabs = wb_browser._http_json(f'http://127.0.0.1:{port}/json/list')
        tab = next((t for t in tabs if t.get('id') == _TABS.get(source)), None)
        if tab is None:
            tab = wb_browser._http_json(f'http://127.0.0.1:{port}/json/new?' + urllib.parse.quote(url, safe=''), method='PUT')
            _TABS[source] = tab['id']
        ws = wb_browser._WS(tab['webSocketDebuggerUrl'])
        ws.call('Page.enable')
        if tab.get('url') != url:
            ws.call('Page.navigate', {'url': url})
        if photo_path:
            for _ in range(15):
                time.sleep(1)
                doc = ws.call('DOM.getDocument', {'depth': 0})
                node = ws.call('DOM.querySelector', {'nodeId': doc['root']['nodeId'], 'selector': 'input.image-file-reader-wrapper'})
                if node.get('nodeId'):
                    ws.call('DOM.setFileInputFiles', {'nodeId': node['nodeId'], 'files': [photo_path]})
                    break
            else:
                raise SupplierError('1688 не показал загрузку фото. Откройте фотопоиск на сайте, пройдите вход или проверку и повторите.')
            for _ in range(12):
                time.sleep(1)
                clicked = ws.eval("""(() => { const e=[...document.querySelectorAll('button,div,span,a')].find(e=>['Поиск изображений','图片搜索','搜索图片'].includes(e.textContent.trim()) && e.children.length<2); if(e){e.click();return true;} return false; })()""")
                if clicked:
                    break
        with open(os.path.join(ROOT, 'core', 'supplier_page.js'), encoding='utf-8') as script_file:
            script = script_file.read()
        expr = script + '\nreadSupplierPage(' + json.dumps(source) + ',' + json.dumps(mode) + ')'
        deadline = time.monotonic() + 45
        started = time.monotonic()
        while time.monotonic() < deadline:
            time.sleep(2)
            try:
                if photo_path and not ws.eval("location.hostname==='air.1688.com' && location.pathname.includes('pc-image-search')"):
                    continue
                if photo_path and time.monotonic() - started > 18 and ws.eval("/空空|здесь пусто/.test(document.body.innerText)"):
                    return {'items': []}
                result = ws.eval(expr, timeout=16)
            except (OSError, RuntimeError):
                continue
            if result and (result.get('items') if mode == 'search' else result.get('variants')):
                _LAST_READ = time.monotonic()
                return result
        raise SupplierError('Сайт пока не отдал товары. Посмотрите открытое окно браузера: если сайт просит вход или проверку, пройдите её сами и повторите загрузку. Разрешения браузера выбираете вы.')
    finally:
        _LAST_READ = time.monotonic()
        if ws:
            ws.close()
        _LOCK.release()


def search(source, query):
    url, effective = search_url(source, query)
    result = _browser_read(source, 'search', url)
    # Validate links again on the server before returning scraped content.
    result['items'] = [dict(item, url=product_url(source, item['url'])) for item in result.get('items', [])[:20]]
    result.update(success=True, query=effective, search_url=url)
    return result


def read_product(source, url):
    url = product_url(source, url)
    result = _browser_read(source, 'product', url)
    result['url'] = product_url(source, result.get('url', ''))
    result['checked_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if len(_PRODUCTS) >= 30:
        _PRODUCTS.pop(next(iter(_PRODUCTS)))
    _PRODUCTS[(source, result['url'])] = result
    return {'success': True, 'product': result}


def photo_search(data=None, uploaded=None):
    """Upload only a selected product image, never arbitrary local files or URLs."""
    if uploaded:
        content = uploaded.read(8_000_001)
    else:
        try:
            wb_id = int((data or {}).get('wb_id'))
        except (TypeError, ValueError):
            raise ValueError('Выберите фото товара WB или загрузите изображение.') from None
        with open(os.path.join(ROOT, 'data', 'catalog.json'), encoding='utf-8') as f:
            catalog = json.load(f)
        item = next((it for it in catalog if int(it.get('id') or 0) == wb_id), None)
        if not item:
            raise ValueError('Товар WB не найден в списке.')
        image_url = item.get('img_main') or item.get('img_url') or ''
        u = urllib.parse.urlsplit(image_url)
        if u.scheme != 'https' or not re.fullmatch(r'basket-\d+\.wbbasket\.ru', u.hostname or '') or u.port not in (None, 443):
            raise ValueError('Не удалось скачать исходное фото WB. Сохраните фото и загрузите его через раздел 1688.')
        import requests
        with requests.get(image_url, timeout=20, stream=True, allow_redirects=False) as r:
            if r.status_code != 200:
                raise ValueError('WB не отдал фото. Сохраните и загрузите его вручную.')
            content = r.raw.read(8_000_001)
    if not content or len(content) > 8_000_000:
        raise ValueError('Выберите изображение размером до 8 МБ.')
    from PIL import Image
    try:
        im = Image.open(io.BytesIO(content))
        if im.width * im.height > 40_000_000:
            raise ValueError()
        im.load()
        im = im.convert('RGB')
    except Exception:
        raise ValueError('Не удалось прочитать фото. Выберите JPG, PNG или WebP до 40 мегапикселей.') from None
    folder = os.path.join(ROOT, 'data', 'supplier-search')
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, uuid.uuid4().hex + '.jpg')
    try:
        im.thumbnail((2400, 2400))
        im.save(path, 'JPEG', quality=92)
        url, _ = search_url('1688', '收纳盒')
        result = _browser_read('1688', 'search', url, photo_path=path)
        result.update(success=True, query='по фотографии', search_url='https://s.1688.com/')
        return result
    finally:
        if os.path.exists(path):
            os.remove(path)


def estimate(data):
    """Manual estimate per unit; do not guess tariffs or missing package sizes."""
    source = source_name(data.get('source'))
    def n(key, positive=False):
        try:
            raw = data.get(key)
            if raw is None or raw == '' or isinstance(raw, bool):
                raise ValueError()
            value = float(raw)
            if not math.isfinite(value) or value < 0 or (positive and value <= 0):
                raise ValueError()
            return value
        except (TypeError, ValueError):
            raise ValueError('Заполните корректно все поля расчёта; неизвестные значения нельзя считать нулём.') from None
    purchase = n('price', True) * (n('cny_rate', True) if source == '1688' else 1)
    volume = None
    if source == '1688':
        volume = n('length_cm', True) * n('width_cm', True) * n('height_cm', True) / 1_000_000
        freight = max(n('weight_kg', True) * n('per_kg', True), volume * n('per_m3', True))
    else:
        freight = n('freight')
    total = purchase + freight + n('other_costs')
    fees = n('fees_pct') / 100
    if fees >= 1:
        raise ValueError('Сумма комиссии и налогов должна быть меньше 100%.')
    sale = n('sale_price', True)
    profit = sale * (1 - fees) - total
    return {'success': True, 'purchase_kzt': round(purchase, 2), 'freight_kzt': round(freight, 2),
            'volume_m3': volume, 'cost_kzt': round(total, 2), 'profit_kzt': round(profit, 2),
            'break_even_kzt': math.ceil(total / (1 - fees))}


def register(app):
    from flask import jsonify, request
    def api(action):
        if action == 'photo' and request.content_length and request.content_length > 8_100_000:
            return jsonify(success=False, error='Фото должно быть не больше 8 МБ.'), 413
        uploaded = request.files.get('image') if action == 'photo' else None
        data = {} if uploaded else request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(success=False, error='Ожидается запрос с данными.'), 400
        try:
            if action == 'photo':
                result = photo_search(data, uploaded)
            elif action == 'search':
                result = search(data.get('source'), data.get('query'))
            elif action == 'product':
                result = read_product(data.get('source'), data.get('url'))
            elif action == 'drafts':
                source = source_name(data.get('source'))
                url = product_url(source, data.get('url'))
                product = _PRODUCTS.get((source, url))
                if product is None:
                    raise ValueError('Загрузите товар перед созданием черновиков.')
                from core.supplier_drafts import make
                result = make(product, data.get('preorder_days'))
            else:
                result = estimate(data)
            return jsonify(result)
        except ValueError as error:
            return jsonify(success=False, error=str(error)), 400
        except SupplierError as error:
            return jsonify(success=False, error=str(error)), 503
        except Exception:
            # No raw exceptions: third-party URLs or browser state may contain private data.
            return jsonify(success=False, error='Не удалось загрузить данные. Проверьте окно браузера, пройдите проверку сайта или вход и повторите. Если другая загрузка ещё идёт, дождитесь её завершения.'), 503
    for action in ('search', 'product', 'estimate', 'drafts', 'photo'):
        app.add_url_rule('/api/suppliers/' + action, 'suppliers_' + action,
                         lambda action=action: api(action), methods=['POST'])
