// Reads only the current marketplace page. Never submits orders or changes offers.
async function readSupplierPage(source, mode) {
  const num = value => {
    if (value === null || value === undefined || value === '') return null;
    const n = Number(String(value).replace(/[\s\u2009\u202f₸¥￥]/g, '').replace(',', '.'));
    return Number.isFinite(n) && n >= 0 ? n : null;
  };
  const image = value => {
    const s = typeof value === 'string' ? value : value?.src || value?.imageUrl || '';
    try { const u = new URL(s, location.href); return /^https?:$/.test(u.protocol) && s ? u.href : ''; } catch { return ''; }
  };
  const canonical = value => {
    try {
      const u = new URL(value, location.href);
      if (source === '1688' && u.hostname === 'detail.1688.com' && /^\/offer\/\d+\.html$/.test(u.pathname)) return 'https://detail.1688.com'+u.pathname;
      if (source === 'ozon' && /^(www\.)?ozon\.(kz|ru)$/.test(u.hostname) && /^\/product\/[^/]+\/?$/.test(u.pathname)) return 'https://ozon.kz'+u.pathname;
    } catch {}
    return '';
  };
  if (mode === 'search') {
    const found = new Map();
    const selector = source === '1688' ? 'a[href*="detail.1688.com/offer/"]' : 'a[href*="/product/"]';
    for (const a of document.querySelectorAll(selector)) {
      const url = canonical(a.href);
      if (!url || found.has(url)) continue;
      let card = a;
      if (source === 'ozon') {
        for (let i=0;i<5 && card.parentElement;i++) {
          if (card.querySelector('img') && card.innerText.includes('₸')) break;
          card=card.parentElement;
        }
      }
      const text = card.innerText || a.innerText || '';
      const img=card.querySelector('img');
      const name = source === '1688'
        ? (text.split('\n')[0] || img?.alt)
        : (Array.from(card.querySelectorAll('a[href*="/product/"]')).filter(x=>!x.querySelector('img')).map(x=>x.innerText.trim()).sort((a,b)=>b.length-a.length)[0] || img?.alt || 'Товар Ozon');
      // A search price is only a preview. Exclude Ozon instalment amounts explicitly.
      const priceText = source === '1688' ? text.match(/[¥￥]\s*(\d+(?:\s*\.\s*\d+)?)/)?.[1]
        : text.split('\n').find(x=>x.includes('₸') && !/[×x]|мес/i.test(x))?.match(/[\d\s\u2009\u202f]+(?=₸)/)?.[0];
      found.set(url,{source,url,id:url.match(source==='1688'?/\/(\d+)\.html/:/-(\d+)\/?$/)?.[1]||'',
        name:String(name||'Товар 1688').slice(0,500),price:num(priceText),currency:source==='1688'?'CNY':'KZT',image:image(img?.currentSrc||img?.src)});
      if(found.size>=20) break;
    }
    return {items:[...found.values()]};
  }
  const url=canonical(location.href);
  if(!url) return null;
  if(source==='1688') {
    const d=window.context?.result?.data;
    if(!d?.Root?.fields?.dataJson) return null;
    const root=d.Root.fields.dataJson,model=root.skuModel||{};
    const photos=(d.gallery?.fields?.offerImgList||[]).map(image).filter(Boolean);
    const packs=d.productPackInfo?.fields?.pieceWeightScale?.pieceWeightScaleInfo||[];
    const values=(model.skuProps||[]).flatMap(p=>p.value||[]);
    const entries=Object.entries(model.skuInfoMap||{});
    if(entries.length>1000) throw new Error('Слишком много вариантов: требуется отдельная обработка.');
    const variants=entries.map(([key,v])=>{
      const pack=packs.find(p=>String(p.skuId)===String(v.skuId))||{};
      const photo=values.find(p=>String(v.specAttrs||key).split(';').includes(p.name));
      return {id:String(v.skuId||v.specId||key),name:v.specAttrs||key,price:num(v.price),stock:num(v.canBookCount),
        min_quantity:num(root.orderParamModel?.orderParam?.beginNum),price_quantity:num(v.priceAmount),
        image:image(photo?.imageUrl)||photos[0]||'',weight_kg:num(pack.weight)===null?null:num(pack.weight)/1000,
        length_cm:num(pack.length),width_cm:num(pack.width),height_cm:num(pack.height),url};
    });
    if(!variants.length) return null;
    return {source,url,id:url.match(/\/(\d+)\.html/)[1],name:d.productTitle?.fields?.title||d.gallery?.fields?.subject||'',
      currency:'CNY',images:photos,variants,attributes:Array.from(document.querySelectorAll('[class*="offer-attr"], [class*="attribute"]')).map(n=>n.innerText).filter(Boolean).slice(0,40)};
  }
  const controller=new AbortController(), timer=setTimeout(()=>controller.abort(),12000);
  let j;
  try {
    const response=await fetch('/api/composer-api.bx/page/json/v2?url='+encodeURIComponent(location.pathname),{credentials:'include',signal:controller.signal});
    if(!response.ok) return null;
    j=await response.json();
  } finally { clearTimeout(timer); }
  const widgets={};
  for(const [k,v] of Object.entries(j.widgetStates||{})) {
    if(!/^web(ProductHeading|Gallery|Aspects|Price|ShortCharacteristics)/.test(k)) continue;
    try { widgets[k.split('-')[0]]=typeof v==='string'?JSON.parse(v):v; } catch {}
  }
  const heading=widgets.webProductHeading,price=widgets.webPrice||{},gallery=widgets.webGallery||{};
  if(!heading?.title) return null;
  // A currency mismatch must never become a tenge estimate.
  const currency=/₸|KZT/.test(String(price.price||'')+' '+String(price.disclaimerPriceHeader||''))?'KZT':null;
  const photos=(gallery.images||[]).map(image).filter(Boolean),id=String(gallery.sku||url.match(/-(\d+)\/?$/)?.[1]||'');
  const variants=new Map([[id,{id,name:heading.title,price:currency?num(price.price):null,currency,stock:null,
    availability:price.isAvailable===false?'outOfStock':'unknown',image:photos[0]||'',url}]]);
  for(const aspect of widgets.webAspects?.aspects||[]) for(const v of aspect.variants||[]) {
    const variantUrl=canonical(v.link);
    if(!v.sku||!variantUrl) continue;
    const key=String(v.sku),existing=variants.get(key);
    const labels=existing?.labels||[];
    labels.push(aspect.aspectName+': '+(v.data?.searchableText||''));
    variants.set(key,{...(existing||{}),id:key,name:v.data?.title||existing?.name||key,
      price:existing?.price??(currency?num(v.data?.price??v.price):null),currency,stock:null,
      availability:v.availability||existing?.availability||'unknown',image:existing?.image||image(v.data?.coverImage),url:variantUrl,labels});
  }
  return {source,url,id,name:heading.title,currency,images:photos,variants:[...variants.values()],
    attributes:(widgets.webShortCharacteristics?.characteristics||[]).map(c=>({name:(c.title?.textRs||[]).map(t=>t.content||'').join(''),value:(c.values||[]).map(v=>v.text||'').join(', ')}))};
}
