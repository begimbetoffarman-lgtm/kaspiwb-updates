(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let product = null, items = [], busy = false;
  const money = (n, currency='KZT') => n == null ? 'Цена не получена' : Number(n).toLocaleString('ru-RU', {maximumFractionDigits:2}) + (currency==='CNY'?' ¥':' ₸');
  const safeImage = value => { try { const u=new URL(value); return /^https?:$/.test(u.protocol)?u.href:''; } catch {return '';} };
  async function call(action, data) {
    const r=await fetch('/api/suppliers/'+action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    const j=await r.json();
    if(!r.ok || !j.success) throw new Error(j.error||'Не удалось получить данные.');
    return j;
  }
  function status(text) { $('supplierStatus').textContent=text; }
  function setBusy(value) {
    busy=value;
    document.querySelectorAll('#tab-suppliers button, #supplierSource').forEach(el=>el.disabled=value);
    $('supplierStatus').setAttribute('aria-busy',String(value));
  }
  function clearProduct() { product=null; $('supplierProduct').hidden=true; $('supplierEstimateResult').textContent=''; }
  function renderResults(j) {
    items=j.items;
    $('supplierResults').innerHTML=items.map((it,i)=>`<article class="cab-box supplier-result">${safeImage(it.image)?`<img src="${escAttr(safeImage(it.image))}" alt="" loading="lazy" referrerpolicy="no-referrer">`:''}<div><h3>${escHtml(it.name)}</h3><p>${escHtml(money(it.price,it.currency))} · предварительно</p><button type="button" class="btn btn-secondary" data-supplier-item="${i}">Загрузить товар</button> <a href="${escAttr(it.url)}" target="_blank" rel="noopener noreferrer">Открыть на сайте</a></div></article>`).join('');
    status(items.length ? 'Найдено: '+items.length+'. Запрос на сайте: '+j.query+'. Для точной цены загрузите товар.' : '1688 не показал совпадений по этому фото. Попробуйте другое фото или войдите в свой аккаунт на сайте.');
  }
  async function searchPhoto(wbId, file) {
    if(busy)return;
    document.querySelector('[data-tab="tab-suppliers"]').click();
    $('supplierSource').value='1688';
    clearProduct();setBusy(true);$('supplierResults').innerHTML=SK(3);
    status('Передаём выбранное фото в фотопоиск 1688. Если сайт попросит вход или проверку, пройдите её в открытом окне.');
    try {
      let result;
      if(file){const body=new FormData();body.append('image',file);const r=await fetch('/api/suppliers/photo',{method:'POST',body});result=await r.json();if(!r.ok||!result.success)throw new Error(result.error||'Фотопоиск пока не отдал результаты.');}
      else result=await call('photo',{wb_id:wbId});
      renderResults(result);
    }catch(e){$('supplierResults').replaceChildren();status(e.message);}finally{setBusy(false);}
  }
  window.findSupplierByPhoto=wbId=>searchPhoto(wbId,null);
  async function loadProduct(url) {
    if(busy) return;
    clearProduct();setBusy(true);status('Загружаем один товар. Если откроется проверка сайта, пройдите её в окне браузера.');
    try {
      const j=await call('product',{source:$('supplierSource').value,url});
      product=j.product;
      $('supplierProduct').hidden=false;
      $('supplierName').textContent=product.name;
      $('supplierChecked').textContent='Проверено: '+new Date(product.checked_at).toLocaleString('ru-RU');
      $('supplierPhotos').replaceChildren();
      product.images.slice(0,12).forEach(src=>{const img=document.createElement('img');img.src=safeImage(src);img.alt=product.name;img.loading='lazy';img.referrerPolicy='no-referrer';$('supplierPhotos').append(img);});
      $('supplierVariant').replaceChildren();
      product.variants.forEach((v,i)=>{const option=document.createElement('option');option.value=i;option.textContent=v.name+' — '+money(v.price,product.currency);$('supplierVariant').append(option);});
      const selected=product.variants.findIndex(v=>v.url===product.url);
      $('supplierVariant').value=String(selected<0?0:selected);
      $('supplierChinaCosts').hidden=product.source!=='1688';
      $('supplierOzonCosts').hidden=product.source!=='ozon';
      $('supplierCurrency').textContent=product.currency==='CNY'?'¥':'₸';
      $('supplierDraftCount').textContent=String(product.variants.length);
      renderVariant();
      status(product.currency?'Данные загружены. Проверьте выбранный вариант, цену и условия доставки на сайте.':'Валюта Ozon не подтверждена. Откройте сайт, выберите цены в тенге и загрузите товар повторно.');
    } catch(e) {status(e.message);} finally {setBusy(false);}
  }
  function renderVariant() {
    if(!product) return;
    const v=product.variants[Number($('supplierVariant').value)];
    $('supplierPrice').value=v.price??'';
    const avail={inStock:'Есть в наличии',outOfStock:'Нет в наличии',noSuchCombination:'Нужна проверка этого сочетания',unknown:'Наличие не подтверждено'};
    $('supplierVariantInfo').textContent=product.source==='1688'
      ? 'Остаток: '+(v.stock??'не получен')+'. Минимальный заказ: '+(v.min_quantity??'уточните у продавца')+'. Цена за количество: '+(v.price_quantity??'уточните на сайте')+'.'
      : (avail[v.availability]||'Наличие нужно проверить')+'. Цена и наличие другого варианта требуют повторной загрузки.';
    for(const [key,id]of Object.entries({weight_kg:'supplierWeight',length_cm:'supplierLength',width_cm:'supplierWidth',height_cm:'supplierHeight'})) $(id).value=v[key]??'';
    $('supplierVariantLink').href=v.url;
    $('supplierEstimateResult').textContent='';
  }
  document.addEventListener('DOMContentLoaded',()=>{
    $('supplierSource').addEventListener('change',()=>{items=[];$('supplierResults').replaceChildren();$('supplierUrl').value='';clearProduct();status('Введите название или вставьте ссылку на товар.');$('supplierQueryHint').textContent=$('supplierSource').value==='1688'?'Для точного поиска — запрос на китайском. Простые русские запросы ищем по близкой китайской категории; покажем, какой запрос использован.':'Ozon Казахстан: цена зависит от выбранного города и условий покупки.';});
    $('supplierSearchForm').addEventListener('submit',async e=>{
      e.preventDefault();if(busy) return;
      clearProduct();items=[];$('supplierResults').innerHTML=SK(3);setBusy(true);status('Открываем поиск в браузере. Получаем до 20 товаров с одной страницы.');
      try {
        const j=await call('search',{source:$('supplierSource').value,query:$('supplierQuery').value});renderResults(j);
      } catch(err) {$('supplierResults').replaceChildren();status(err.message);} finally {setBusy(false);}
    });
    $('supplierResults').addEventListener('click',e=>{const b=e.target.closest('[data-supplier-item]');if(b) loadProduct(items[Number(b.dataset.supplierItem)].url);});
    $('supplierPhotoForm').addEventListener('submit',e=>{e.preventDefault();const f=$('supplierPhoto').files[0];if(f)searchPhoto(null,f);});
    $('supplierProductForm').addEventListener('submit',e=>{e.preventDefault();loadProduct($('supplierUrl').value);});
    $('supplierVariant').addEventListener('change',renderVariant);
    $('supplierReloadVariant').addEventListener('click',()=>{if(product) loadProduct(product.variants[Number($('supplierVariant').value)].url);});
    $('supplierMakeDrafts').addEventListener('click',async()=>{
      if(!product||busy) return;
      setBusy(true);
      try {
        const r=await call('drafts',{source:product.source,url:product.url,preorder_days:Number($('supplierPreorder').value)});
        status('Вариантов: '+r.total_variants+'. Черновиков создано: '+r.created+'. Уже были: '+r.existing+'. Проверьте перевод, категорию, характеристики, фотографии и цену каждого варианта.');
        document.querySelector('[data-tab="tab-cards"]').click();
      } catch(err){status(err.message);} finally {setBusy(false);}
    });
    $('supplierEstimateForm').addEventListener('input',()=>{$('supplierEstimateResult').textContent='';});
    $('supplierEstimateForm').addEventListener('submit',async e=>{
      e.preventDefault();if(!product||busy) return;
      if(!product.currency){$('supplierEstimateResult').textContent='Сначала подтвердите валюту товара повторной загрузкой.';return;}
      const mapping={price:'supplierPrice',cny_rate:'supplierRate',weight_kg:'supplierWeight',length_cm:'supplierLength',width_cm:'supplierWidth',height_cm:'supplierHeight',per_kg:'supplierPerKg',per_m3:'supplierPerM3',freight:'supplierFreight',other_costs:'supplierOther',sale_price:'supplierSale',fees_pct:'supplierFees'};
      const data={source:product.source};for(const [key,id]of Object.entries(mapping)) data[key]=$(id).value;
      try {const r=await call('estimate',data);$('supplierEstimateResult').textContent='Закупка: '+money(r.purchase_kzt)+'. Доставка: '+money(r.freight_kzt)+'. Себестоимость: '+money(r.cost_kzt)+'. Безубыточная цена: '+money(r.break_even_kzt)+'. Прибыль: '+money(r.profit_kzt)+'.';}
      catch(err){$('supplierEstimateResult').textContent=err.message;}
    });
  });
})();
