// единые иконки (линейные, 16 px)
window.IC = (function () {
  const s = d => `<svg class="ic" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  return {
    search: s('<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>'),
    camera: s('<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>'),
    bolt: s('<path d="M13 2 3 14h8l-1 8 10-12h-8z"/>'),
    plus: s('<path d="M12 5v14M5 12h14"/>')
  };
})();
window.SK = n => '<div class="skeleton-list">' + '<div class="skeleton"></div>'.repeat(n || 3) + '</div>';
let currentItems = [];
const radarSelected = new Set();
let appConfig = {};
let storeData = { products: [] };
let activeStoreFilter = 'all';
let currentLicense = {};
let storeCurrentPage = 1;
let storePageSize = 50;

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  loadConfig();
  checkLicenseStatus();
  loadCatalog();
  setupEventListeners();
  setupStoreEvents();
  setupModalEvents();
  checkApiStatus();
});

// ==========================================================
// License & Trial Logic
// ==========================================================
async function checkLicenseStatus() {
  try {
    const res = await fetch('/api/license');
    const data = await res.json();
    currentLicense = data;
    
    const licDot = document.getElementById('licDot');
    const licLabel = document.getElementById('licLabel');
    const pill = document.getElementById('appLicensePill');
    const modalStatus = document.getElementById('modalLicStatus');
    const modalMachine = document.getElementById('modalMachineId');
    const btnAct = document.getElementById('btnSidebarActivate');

    if (modalMachine) modalMachine.innerText = data.machine_id || 'UNKNOWN-ID';

    if (data.status === 'PRO') {
      if (licDot) licDot.className = 'status-dot online';
      if (licLabel) licLabel.innerText = 'PRO Лицензия';
      if (pill) pill.innerText = 'PRO · Бессрочно';
      if (modalStatus) modalStatus.innerText = 'PRO Лицензия (Бессрочная)';
      if (btnAct) {
        btnAct.innerText = '✓ PRO Активирован';
        btnAct.style.textDecoration = 'none';
        btnAct.style.color = 'var(--green)';
      }
    } else if (data.status === 'TRIAL') {
      if (licDot) licDot.className = 'status-dot online';
      if (licLabel) licLabel.innerText = `Тест-драйв: ${data.days_left} дн.`;
      if (pill) pill.innerText = `Trial · ${data.days_left}д`;
      if (modalStatus) modalStatus.innerText = `Тест-драйв: ${data.days_left} дн. осталось`;
      if (btnAct) btnAct.innerText = 'Активировать PRO';
    } else {
      if (licDot) licDot.className = 'status-dot';
      if (licLabel) licLabel.innerText = 'Тест-драйв истёк';
      if (pill) pill.innerText = 'Лицензия истекла';
      if (modalStatus) modalStatus.innerText = 'Срок пробного периода истёк';
      if (btnAct) {
        btnAct.innerText = '⚠️ Требуется ключ PRO';
        btnAct.style.color = '#DC2626';
      }
    }
  } catch (err) {
    console.error('License check error:', err);
  }
}

function escHtml(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
}
function escAttr(v) { return escHtml(v); }
function photoPlaceholder(title) {
  const ch = escHtml((String(title || '?').trim()[0] || '?').toUpperCase());
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" rx="12" fill="#E8EEF7"/><text x="40" y="53" font-family="Arial,sans-serif" font-size="34" font-weight="700" text-anchor="middle" fill="#8EA2C0">${ch}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

// Tab Switching
function initTabs() {
  const tabs = document.querySelectorAll('.nav-item');
  const panes = document.querySelectorAll('.tab-pane');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      panes.forEach(p => p.classList.remove('active'));
      
      tab.classList.add('active');
      const target = tab.dataset.tab;
      const targetPane = document.getElementById(target);
      if (targetPane) targetPane.classList.add('active');
      if (target === 'tab-cards' && window.loadCards) window.loadCards();
      if (target === 'tab-setup' && window.loadSetupTab) window.loadSetupTab();
      if (target === 'tab-orders' && window.loadOrdersTab) window.loadOrdersTab();
      if (target === 'tab-preorder' && window.loadPreorderTab) window.loadPreorderTab();
      
      const titles = {
        'tab-1688': ['Поиск товаров с 1688', 'Ниши, поиск поставщиков, все цвета и комплектации для Kaspi'],
        'tab-ozon': ['Поиск товаров с Ozon', 'Поиск в Ozon Казахстана и подготовка вариантов для Kaspi'],
        'tab-radar': ['Поиск товаров с WB', 'Хиты Wildberries, которых нет на Kaspi или мало продавцов'],
        'tab-my-store': ['Мой магазин Kaspi', 'Регулировка цен, наличие и предзаказ, контроль Топ-3 корзины (BuyBox)'],
        'tab-cards': ['Карточки Kaspi', 'Создание карточек через официальный API Kaspi: категория, характеристики, фото, модерация'],
        'tab-studio': ['AI Студия & УТП', 'Студийный ре-рендер предметных фото + инфографика в стиле Apple'],
        'tab-export': ['Экспорт в Kaspi Pay', 'Готовый Excel-шаблон прайс-листа для массовой загрузки'],
        'tab-settings': ['Настройки & API', 'Управление ключами Kaspi, RoyalTech и параметрами наценки'],
        'tab-margin': ['Калькулятор маржи', 'Стоит ли возить товар из Китая: маржа, демпинг, размер партии, прогноз прибыли'],
        'tab-orders': ['Заказы и накладные', 'Что собрать, когда передать, печать накладных'],
        'tab-preorder': ['Предзаказ карточек', 'Срок по реальной доставке WB'],
        'tab-setup': ['Первый запуск', 'Подключение магазина Kaspi'],
        'tab-guide': ['Инструкция от А до Я', 'Пошаговый план запуска продаж без склада и оптовых рисков']
      };
      if (titles[target]) {
        document.getElementById('pageTitle').innerText = titles[target][0];
        document.getElementById('pageSubtitle').innerText = titles[target][1];
      }

      const ta = document.getElementById('topbarActions');
      if (ta) ta.style.display = (target === 'tab-radar') ? '' : 'none';   // кнопки и счётчики радара WB нужны только на его вкладке

      if (target === 'tab-studio') {
        renderStudioGrid();
      } else if (target === 'tab-my-store') {
        loadKaspiStore();
      }
    });
  });
}

// Load Config
async function loadConfig() {
  try {
    const res = await fetch('/api/config');
    appConfig = await res.json();
    document.getElementById('cfgRoyaltechKey').value = appConfig.royaltech_api_key || '';
    document.getElementById('cfgKaspiId').value = appConfig.kaspi_merchant_id || '';
    document.getElementById('cfgKaspiToken').value = appConfig.kaspi_api_token || '';
    const delivSelect = document.getElementById('cfgKaspiDeliveryMode');
    if (delivSelect) {
      delivSelect.value = appConfig.kaspi_delivery_mode || 'official_kz';
      const cWrap = document.getElementById('cfgCustomDeliveryWrap');
      if (cWrap) cWrap.style.display = (delivSelect.value === 'custom') ? 'block' : 'none';
    }
    const delivCostInp = document.getElementById('cfgKaspiDeliveryCost');
    if (delivCostInp) delivCostInp.value = appConfig.kaspi_delivery_cost_kzt || 1507;
    document.getElementById('cfgMarginMultiplier').value = appConfig.margin_multiplier || 2.4;
    document.getElementById('cfgPackagingCost').value = appConfig.packaging_cost_kzt || 150;
  } catch (err) {
    console.error('Config load error:', err);
  }
}

// Check Royaltech API Status
async function checkApiStatus() {
  try {
    const res = await fetch('/api/account');
    const data = await res.json();
    const dot = document.querySelector('#apiStatusBadge .status-dot');
    const txt = document.getElementById('apiStatusText');
    const nbLimit = document.getElementById('nbDailyLimit');
    
    if (data.success && data.account) {
      dot.className = 'status-dot online';
      const daily = data.account.daily?.[0];
      const remaining = daily ? daily.remaining_today : 500;
      txt.innerText = `NanoBanana: ${remaining}/500`;
      if (nbLimit && daily) {
        nbLimit.innerText = `${daily.remaining_today} / ${daily.limit}`;
      }
    } else {
      dot.className = 'status-dot';
      txt.innerText = 'NanoBanana: Нужен ключ';
    }
  } catch (err) {
    console.error('API check failed:', err);
  }
}

// Load Catalog (WB Arbitrage)
async function loadCatalog() {
  try {
    const res = await fetch('/api/items');
    const data = await res.json();
    if (data.success) {
      currentItems = data.items || [];
      renderTable(currentItems);
      updateKpis(currentItems);
    }
  } catch (err) {
    console.error('Catalog load error:', err);
  }
}

function updateKpis(items) {
  document.getElementById('statCount').innerText = items.length;
  document.getElementById('tableFilterCount').innerText = `${items.length} карточек`;
}

// Render WB Catalog Table (постранично: 20 карточек на странице)
let radarPage = 1, radarPageSize = 20, radarSort = 'default', radarLastRef = null;
function radarMetrics(it) {
  const cost = it.cost_total || (it.price_kzt + 150);
  const kaspiPrice = it.kaspi_price || Math.round(cost * 2.4);
  const profit = it.profit || (kaspiPrice - cost - Math.round(kaspiPrice * 0.165));
  const roi = it.roi || Math.round((profit / cost) * 100);
  return { cost, kaspiPrice, profit, roi };
}
function renderRadarPager(total, pages) {
  const el = document.getElementById('radarPager'); if (!el) return;
  if (total <= 10) { el.innerHTML = total ? `<span class="pager-info">Всего: ${total}</span>` : ''; return; }
  const from = (radarPage - 1) * radarPageSize + 1, to = Math.min(total, radarPage * radarPageSize);
  const nums = []; const add = n => { if (!nums.includes(n) && n >= 1 && n <= pages) nums.push(n); };
  add(1); add(2); for (let n = radarPage - 1; n <= radarPage + 1; n++) add(n); add(pages - 1); add(pages);
  nums.sort((a, b) => a - b);
  let btns = '', prev = 0;
  nums.forEach(n => { if (n - prev > 1) btns += '<span class="pager-gap">…</span>'; btns += `<button type="button" class="pager-btn ${n === radarPage ? 'on' : ''}" data-page="${n}">${n}</button>`; prev = n; });
  el.innerHTML = `<span class="pager-info">Показаны ${from}–${to} из ${total}</span>
    <div class="pager-nav"><button type="button" class="pager-btn" data-page="${radarPage - 1}" ${radarPage <= 1 ? 'disabled' : ''}>‹ Назад</button>${btns}<button type="button" class="pager-btn" data-page="${radarPage + 1}" ${radarPage >= pages ? 'disabled' : ''}>Вперёд ›</button></div>
    <div class="pager-opts"><label>Сортировка <select id="radarSort"><option value="default">как найдено</option><option value="feedbacks">по отзывам</option><option value="profit">по прибыли</option><option value="roi">по ROI</option></select></label>
    <label>На странице <select id="radarPageSize"><option>10</option><option>20</option><option>50</option><option>100</option></select></label></div>`;
  const s = el.querySelector('#radarSort'); if (s) s.value = radarSort;
  const z = el.querySelector('#radarPageSize'); if (z) z.value = String(radarPageSize);
}
let radarItemsAll = [];
function renderTable(items, keepPage) {
  const tbody = document.getElementById('itemsTableBody');
  if (items !== radarLastRef && !keepPage) { radarPage = 1; }
  radarLastRef = items; radarItemsAll = items;
  tbody.innerHTML = '';
  if (!items.length) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 40px; color: var(--text-muted);">Ничего не найдено. Выберите нишу или введите запрос и нажмите «Найти товары».</td></tr>`;
    renderRadarPager(0, 0);
    return;
  }
  let list = items;
  if (radarSort !== 'default') {
    const key = it => radarSort === 'feedbacks' ? (it.feedbacks || 0) : radarMetrics(it)[radarSort];
    list = [...items].sort((a, b) => key(b) - key(a));
  }
  const pages = Math.max(1, Math.ceil(list.length / radarPageSize));
  if (radarPage > pages) radarPage = pages;
  const start = (radarPage - 1) * radarPageSize;
  const slice = list.slice(start, start + radarPageSize);
  const selAll = document.getElementById('radarSelAll'); if (selAll) selAll.checked = false;

  slice.forEach((it, i) => {
    const tr = document.createElement('tr');
    const displayImg = it.infographic_image || it.ai_image || it.img_main || it.img_url || '';
    const kaspiName = it.kaspi_name || it.name;
    const cleanSearchQ = it.kaspi_search_query || (it.name ? it.name.replace(/[^\wа-яА-ЯёЁ\s]/g, ' ').split(/\s+/).filter(w => w.length > 3).slice(0, 3).join(' ') : kaspiName);
    const m = radarMetrics(it);
    // Цена считается устаревшей, если её не обновляли больше суток (или не обновляли совсем). Город не важен.
    const stale = !(it.price_source && it.price_source.startsWith('WB ') && it.price_checked_at && (Date.now() / 1000 - it.price_checked_at) < 86400);
    tr.innerHTML = `
      <td style="text-align:center;"><label style="display:flex;flex-direction:column;align-items:center;gap:2px;cursor:pointer;"><input type="checkbox" class="radar-sel" data-id="${it.id}" ${radarSelected.has(it.id) ? 'checked' : ''}><span style="font-size:10px;color:var(--ink-400);">${start + i + 1}</span></label></td>
      <td><div class="thumb-wrap" style="cursor:pointer;" onclick="window.previewRadarItem(${Number(it.id)}, false)" title="Открыть фото, чтобы навести камеру Kaspi"><img class="thumb-img" src="${escAttr(displayImg)}" alt="" loading="lazy" onerror="this.src='https://placehold.co/80x80?text=No+Photo'"></div></td>
      <td>
        <div class="rd-name">${escHtml(kaspiName)}</div>
        <div class="rd-meta">${it.brand ? escHtml(it.brand) + ' · ' : ''}<a href="${it.wb_url}" target="_blank" rel="noopener">Арт. WB ${it.id} ↗</a>${it.in_stock === false ? ' · <span style="color:#DC2626">нет на складе WB</span>' : ''}</div>
        <div class="rd-links">
          <a href="https://kaspi.kz/shop/search/?text=${encodeURIComponent(cleanSearchQ)}" target="_blank" rel="noopener noreferrer" class="kaspi-verify-link" title="Поиск на Kaspi: «${escAttr(cleanSearchQ)}». Если показаны заменители, товара на Kaspi нет">${IC.search} Поиск Kaspi</a>
          <button type="button" class="kaspi-verify-link" onclick="window.findSupplierByPhoto(${Number(it.id)}, this)" title="Передать исходное фото товара WB в фотопоиск 1688">${IC.camera} 1688 по фото</button>
          <a href="https://lens.google.com/uploadbyurl?url=${encodeURIComponent(it.img_main || it.img_url || '')}" target="_blank" rel="noopener noreferrer" class="kaspi-verify-link" title="Найти по фото через Google Lens">${IC.camera} Фото в интернете</a>
          <button type="button" class="kaspi-verify-link" onclick="window.previewRadarItem(${Number(it.id)}, true)" title="Показать исходное фото для поиска камерой в мобильном Kaspi">${IC.camera} Фото для Kaspi</button>
          <button type="button" class="kaspi-verify-link" onclick="window.testKaspiVacuum(${it.id}, this)" title="Проверить наличие товара на Kaspi за секунду">${IC.bolt} Проверить</button>
        </div>
        <div id="vacuum-res-${it.id}" style="margin-top:5px;font-size:11px;display:none;"></div>
      </td>
      <td style="text-align:center;"><strong>${(it.feedbacks || 0).toLocaleString()}</strong><div class="rd-sub">★ ${it.rating || 4.9}</div></td>
      <td>${m.cost.toLocaleString()} ₸${stale ? '<div class="rd-warn" title="Цена WB устарела: нажмите «Контроль цен WB» вверху">устарела</div>' : ''}</td>
      <td><strong>${m.kaspiPrice.toLocaleString()} ₸</strong></td>
      <td><span class="profit-pill">+${m.profit.toLocaleString()} ₸</span><div class="rd-sub">ROI +${m.roi}%</div></td>
      <td><button class="btn btn-sm btn-accent" style="white-space:nowrap;" onclick="window.createCardFromRadar(${it.id}, this)" title="Создать черновик карточки Kaspi из этого товара. В Kaspi ничего не отправится, пока вы сами не нажмёте «Отправить в Kaspi»">${IC.plus} Создать карточку</button></td>`;
    tbody.appendChild(tr);
  });
  renderRadarPager(list.length, pages);
}
document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('#radarPager .pager-btn'); if (!b || b.disabled) return;
  radarPage = Number(b.dataset.page) || 1; renderTable(radarItemsAll, true);
  const top = document.querySelector('.table-card'); if (top) top.scrollIntoView({ behavior: 'smooth', block: 'start' });
});
document.addEventListener('change', e => {
  if (e.target.id === 'radarSort') { radarSort = e.target.value; radarPage = 1; renderTable(radarItemsAll, true); }
  if (e.target.id === 'radarPageSize') { radarPageSize = Number(e.target.value) || 20; radarPage = 1; renderTable(radarItemsAll, true); }
});

// 1-Click transfer WB item to seller's Kaspi store under preorder
window.addRadarItemToStore = async function(itemId) {
  const it = currentItems.find(x => x.id === itemId);
  if (!it) {
    showToast('Товар не найден в списке');
    return;
  }
  showToast(`Добавление «${(it.kaspi_name || it.name || '').slice(0, 30)}...» в ваш магазин...`);
  try {
    const res = await fetch('/api/kaspi/add_from_wb', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_id: itemId, preorder_days: 7, item: it })
    });
    const data = await res.json();
    if (data.success) {
      showToast('✓ Товар добавлен в ваш магазин Kaspi со статусом "Под заказ: 7 дней"!');
      // background refresh
      loadKaspiStore();
    } else {
      showToast(`Ошибка: ${data.error || 'Не удалось добавить товар'}`);
    }
  } catch (err) {
    showToast(`Ошибка связи: ${err.message}`);
  }
};

// Render Studio Grid
function renderStudioGrid() {
  const grid = document.getElementById('studioGrid');
  grid.innerHTML = '';
  
  const displayItems = currentItems.slice(0, 30);
  displayItems.forEach(it => {
    const card = document.createElement('div');
    card.className = 'studio-card';
    const wbImg = it.img_main || it.img_url || '';
    const aiImg = it.infographic_image || it.ai_image || '';
    
    card.innerHTML = `
      <div class="studio-images-duo">
        <div class="img-box">
          <img src="${wbImg}" alt="WB" loading="lazy">
          <span class="img-tag">WB Оригинал</span>
        </div>
        <div class="img-box" id="aiBox_${it.id}">
          ${aiImg ? `<img src="${aiImg}" alt="AI" loading="lazy"><span class="img-tag ai">${it.infographic_image ? 'УТП Apple' : 'NanoBanana'}</span>` 
                  : `<div style="text-align: center; color: var(--text-muted); font-size: 11px; padding: 12px;">Кадр ещё не создан</div>`}
        </div>
      </div>
      <div class="studio-card-title">${it.kaspi_name || it.name}</div>
      <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto;">
        <span style="font-size: 12px; font-weight: 700; color: var(--green);">Маржа: х2 (+${it.roi || 102}%)</span>
        <button class="btn btn-sm btn-accent" id="btnGen_${it.id}" onclick="generateAiForProduct(${it.id})">
          ${aiImg ? 'Пересоздать' : '✨ Создать кадр'}
        </button>
      </div>
    `;
    grid.appendChild(card);
  });
}

// Generate AI Photo
window.generateAiForProduct = async function(itemId) {
  const btn = document.getElementById(`btnGen_${itemId}`);
  if (btn) {
    btn.disabled = true;
    btn.innerText = 'Генерация...';
  }
  
  const selectedMode = document.querySelector('input[name="studioGlobalMode"]:checked')?.value || 'infographic';
  showToast(selectedMode === 'infographic' ? 'Создание AI студии + инфографики УТП (≈20 сек)...' : 'Создание чистого AI рендера NanoBanana (≈20 сек)...');
  
  try {
    const res = await fetch('/api/generate_ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_id: itemId, mode: selectedMode })
    });
    const data = await res.json();
    if (data.success) {
      showToast('✓ Уникальное студийное фото готово!');
      const item = currentItems.find(x => x.id === itemId);
      if (item) {
        if (selectedMode === 'infographic') {
          item.infographic_image = data.ai_image;
        } else {
          item.ai_image = data.ai_image;
        }
      }
      renderTable(currentItems);
      const aiBox = document.getElementById(`aiBox_${itemId}`);
      if (aiBox) {
        aiBox.innerHTML = `<img src="${data.ai_image}" alt="AI"><span class="img-tag ai">${selectedMode === 'infographic' ? 'УТП Apple' : 'NanoBanana'}</span>`;
      }
      checkApiStatus();
    } else {
      showToast(`Ошибка: ${data.error || 'Сбой генерации'}`);
    }
  } catch (err) {
    showToast(`Ошибка связи: ${err.message}`);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerText = '✓ Готово';
    }
  }
};

// ==========================================================
// My Kaspi Store & BuyBox Logic (In-Stock & Preorder)
// ==========================================================
async function loadRepricerConfig() {
  try {
    const res = await fetch('/api/kaspi/repricer');
    const data = await res.json();
    if (data.success && data.config) {
      const cfg = data.config;
      const stratSel = document.getElementById('repricerStrategy');
      const minMargInp = document.getElementById('repricerMinMargin');
      const underInp = document.getElementById('repricerUndercut');
      if (stratSel && cfg.strategy) stratSel.value = cfg.strategy;
      if (minMargInp && cfg.min_margin_pct) minMargInp.value = cfg.min_margin_pct;
      if (underInp && cfg.undercut_kzt) underInp.value = cfg.undercut_kzt;
    }
  } catch (err) {
    console.error('Error loading repricer config:', err);
  }
}

async function saveRepricerConfig(runNow = false) {
  const strat = document.getElementById('repricerStrategy')?.value || 'top3';
  const minMarg = parseFloat(document.getElementById('repricerMinMargin')?.value) || 15;
  const under = parseInt(document.getElementById('repricerUndercut')?.value) || 10;
  
  const btn = document.getElementById('btnRunRepricer');
  if (btn && runNow) {
    btn.disabled = true;
    btn.innerText = '⚡️ Оптимизация...';
  }

  try {
    const res = await fetch('/api/kaspi/repricer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        strategy: strat,
        min_margin_pct: minMarg,
        undercut_kzt: under,
        run_now: runNow
      })
    });
    const data = await res.json();
    if (data.success && runNow) {
      const c = data.cycle || {};
      showToast(`Репрайсер: изменено ${c.repriced_count || 0}, на пороге маржи ${c.shielded_count || 0}, пропущено без себестоимости ${(c.skipped || {}).no_cost || 0}`); loadAutopilot();
      await loadKaspiStore();
      openRepricerLogsModal(c);
    } else if (data.success && !runNow) {
      showToast('✓ Настройки репрайсера сохранены');
    }
  } catch (err) {
    showToast('Ошибка сохранения настроек репрайсера');
  } finally {
    if (btn && runNow) {
      btn.disabled = false;
      btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg> <span>Применить ко всем</span>`;
    }
  }
}

// Display Repricer Audit Modal
function openRepricerLogsModal(cycle) {
  const modal = document.getElementById('repricerLogsModal');
  if (!modal) return;
  const sub = document.getElementById('repricerLogsSubtitle');
  if (sub) {
    sub.innerText = `Оптимизировано цен: ${cycle.repriced_count || 0} · Защищено полом маржи: ${cycle.shielded_count || 0} (всего проверено ${cycle.total_checked || 0})`;
  }
  const tbody = document.getElementById('repricerLogsTableBody');
  if (tbody) {
    tbody.innerHTML = '';
    const logs = cycle.logs || [];
    if (!logs.length) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 24px; color: var(--text-muted);">Все цены соответствуют выбранной стратегии и находятся в Топ-3 корзины.</td></tr>`;
    } else {
      logs.forEach(log => {
        const tr = document.createElement('tr');
        const diff = (log.new_price || 0) - (log.old_price || 0);
        let diffBadge = '';
        if (diff < 0) {
          diffBadge = `<span style="font-size: 11px; color: #DC2626; margin-left: 4px;">(${diff.toLocaleString()} ₸)</span>`;
        } else if (diff > 0) {
          diffBadge = `<span style="font-size: 11px; color: #16A34A; margin-left: 4px;">(+${diff.toLocaleString()} ₸)</span>`;
        }
        let statusBadge = '';
        if (log.is_shielded) {
          statusBadge = `<span class="badge" style="background:#FEE2E2; color:#DC2626; font-weight:700;">🛡 Защита маржи</span>`;
        } else if (diff !== 0) {
          statusBadge = `<span class="badge" style="background:#DCFCE7; color:#16A34A; font-weight:700;">⚡ В корзину (Top)</span>`;
        } else {
          statusBadge = `<span class="badge" style="background:#F3F4F6; color:#6B7280;">Без изменений</span>`;
        }
        tr.innerHTML = `
          <td><code style="font-size: 11px;">${escHtml(log.sku)}</code></td>
          <td><div style="max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${escAttr(log.title)}">${escHtml(log.title)}</div></td>
          <td style="color: var(--text-muted);">${(log.old_price || 0).toLocaleString()} ₸</td>
          <td><strong>${(log.new_price || 0).toLocaleString()} ₸</strong>${diffBadge}</td>
          <td style="font-size: 11px; color: var(--text-muted);">≥ ${(log.floor_price || 0).toLocaleString()} ₸</td>
          <td>${statusBadge}</td>
        `;
        tbody.appendChild(tr);
      });
    }
  }
  modal.classList.add('open');
}

async function loadKaspiStore() {
  const tbody = document.getElementById('storeTableBody');
  if (tbody && (!storeData.products || storeData.products.length === 0)) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; padding: 60px 20px;">
          <div class="spinner-inline" style="width: 32px; height: 32px; border-width: 3px; margin: 0 auto 16px;"></div>
          <div style="font-size: 15px; font-weight: 600; color: #1E293B;">Загрузка товаров вашего магазина Kaspi...</div>
          <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Синхронизация цен, остатков и расчет маржи по каждой карточке</div>
        </td>
      </tr>
    `;
  }
  try {
    loadRepricerConfig();
    const res = await fetch('/api/kaspi/store');
    const resp = await res.json();
    if (resp.success) {
      storeData = resp.data;
      renderStoreDashboard();
    } else {
      showToast('Ошибка: ' + (resp.error || 'Не удалось получить данные магазина'));
      if (tbody) tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding: 40px; color: #DC2626;">Ошибка загрузки: ${escHtml(resp.error || 'Сервер вернул ошибку')}</td></tr>`;
    }
  } catch (err) {
    console.error('Store load error:', err);
    showToast('Ошибка загрузки данных магазина');
    if (tbody) tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding: 40px; color: #DC2626;">Ошибка загрузки: ${escHtml(err.message)}</td></tr>`;
  }
}

// Способ продажи конкурента: в наличии или предзаказ на N дней (null: кэш старый, обновится при следующей проверке)
function saleMethod(o) {
  if (o.preorder === null || o.preorder === undefined) return { cls: 'unk', text: '—', title: 'Способ продажи уточняется' };
  if (Number(o.preorder) > 0) return { cls: 'pre', text: 'предзаказ ' + o.preorder + ' дн.', title: 'Продаёт под заказ, срок ' + o.preorder + ' дн.' };
  return { cls: 'stock', text: 'в наличии', title: 'Товар есть в наличии у продавца' };
}
// Блок «Топ-5 продавцов» в начале карточки товара
function topOffersHtml(p) {
  const fmt = n => Math.round(n || 0).toLocaleString('ru-RU');
  if (!p.card_code) {
    return `<div class="t5"><div class="t5-head">Продавцы на карточке</div><button type="button" class="btn btn-xs btn-outline-comp" onclick="window.resolveCard('${escAttr(p.sku)}', this)" title="Программа найдёт карточку Kaspi по вашему артикулу (чтение из кабинета) и покажет продавцов">Найти продавцов</button></div>`;
  }
  const offs = p.top_offers || [];
  if (!offs.length) return `<div class="t5"><div class="t5-head">Продавцы на карточке</div><div class="t5-empty">${p.alone ? 'Других продавцов нет' : 'Данные загружаются, обновите через минуту'}</div></div>`;
  return `<div class="t5"><div class="t5-head">Топ-${offs.length} продавцов по цене</div>` + offs.map((o, i) => {
    const m = saleMethod(o);
    const rt = o.rating ? ` · ★${o.rating}` : '';
    return `<div class="t5-row"><span class="t5-n">${i + 1}</span><b class="t5-price">${fmt(o.price)} ₸</b><span class="t5-name" title="${escAttr(o.merchant)}${escAttr(rt)}">${escHtml(o.merchant)}</span><span class="t5-tag ${m.cls}" title="${escAttr(m.title)}">${m.text}</span>${o.kaspi_delivery ? '<span class="t5-kd" title="Kaspi Доставка">KD</span>' : ''}</div>`;
  }).join('') + '</div>';
}
window.resolveCard = async function (sku, btn) {
  if (btn) { btn.disabled = true; btn.textContent = 'Ищу…'; }
  try {
    const res = await fetch('/api/kaspi/resolve_card', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sku }) });
    const d = await res.json();
    if (d.success) { showToast('✓ Карточка найдена, продавцов: ' + d.offers); await loadKaspiStore(); }
    else { showToast(d.error || 'Не удалось найти карточку'); if (btn) { btn.disabled = false; btn.textContent = 'Найти продавцов'; } }
  } catch (e) { showToast('Ошибка связи: ' + e.message); if (btn) { btn.disabled = false; btn.textContent = 'Найти продавцов'; } }
};

function renderStoreDashboard() {
  if (!storeData || !storeData.products) return;

  // Update Mode Pill
  const pill = document.getElementById('storeModePill');
  if (pill) {
    pill.innerText = storeData.mode_label;
    if (storeData.is_live_api) {
      pill.style.background = '#DCFCE7';
      pill.style.color = '#15803D';
      pill.style.borderColor = '#BBF7D0';
    } else {
      pill.style.background = '#EFF6FF';
      pill.style.color = '#2563EB';
      pill.style.borderColor = '#BFDBFE';
    }
  }

  const clr = document.getElementById('btnClearImport');
  if (clr) clr.style.display = storeData.imported_count ? 'inline-flex' : 'none';

  const syncBanner = document.getElementById('storeSyncBanner');
  if (syncBanner) {
    syncBanner.style.display = (storeData.imported_count || storeData.products_count > 20) ? 'none' : 'flex';
  }

  // Update 5 KPI Cards
  const hasCostData = Boolean(storeData.items_with_cost > 0 && storeData.total_profit !== null && storeData.total_profit !== undefined);
  if (hasCostData) {
    const profitSign = storeData.total_profit > 0 ? '+' : '';
    document.getElementById('storeTotalProfit').innerText = `${profitSign}${storeData.total_profit.toLocaleString('ru-RU')} ₸`;
    document.getElementById('storeAvgMargin').innerText = `${storeData.avg_margin_pct}%`;
    const profitSub = document.querySelector('#storeTotalProfit + .kpi-subtext');
    if (profitSub) profitSub.innerText = `Для ${storeData.items_with_cost.toLocaleString('ru-RU')} товаров с известной закупкой`;
  } else {
    document.getElementById('storeTotalProfit').innerText = '—';
    document.getElementById('storeAvgMargin').innerText = '—';
    const profitSub = document.querySelector('#storeTotalProfit + .kpi-subtext');
    if (profitSub) profitSub.innerText = 'Укажите себестоимость товаров';
  }
  document.getElementById('storeTotalRevenue').innerText = `${storeData.total_revenue.toLocaleString('ru-RU')} ₸`;
  const revSub = document.querySelector('#storeTotalRevenue + .kpi-subtext');
  if (revSub) revSub.innerText = 'Сумма розничных цен каталога Kaspi';

  const note = document.getElementById('storeEstimateNote');
  if (note) {
    if ((storeData.items_with_cost || 0) < storeData.products_count) {
      note.innerHTML = `💡 <b>Себестоимость не указана:</b> в выгрузке Kaspi Pay себестоимости закупки нет. Софт показывает точную сумму «К выплате от Kaspi» без вымышленных оценок. Введите реальную закупку в ячейку товара или загрузите через кнопку <b>«💰 Загрузить себестоимость»</b>.`;
      note.style.display = 'block';
    } else {
      note.style.display = 'none';
    }
  }

  if (storeData.comp_known === 0) {
    document.getElementById('storeBuyBoxPct').innerText = '—';
    document.getElementById('storeBuyBoxCount').innerText = storeData.alone_count
      ? `конкурентов нет на ${storeData.alone_count} карточках из ${storeData.products_count}`
      : 'нет данных о конкурентах (товары из прайс-листа)';
  } else {
    document.getElementById('storeBuyBoxPct').innerText = `${storeData.top3_pct}%`;
    document.getElementById('storeBuyBoxCount').innerText = `${storeData.top3_count} из ${storeData.comp_known} карточек с конкурентами в Топ-3` + (storeData.alone_count ? ` (ещё ${storeData.alone_count} без конкурентов)` : '');
  }
  document.getElementById('storeDangerCount').innerText = storeData.danger_items;

  // Filter count tabs
  const inStockCount = storeData.products.filter(p => p.delivery_type === 'in_stock').length;
  const preorderCount = storeData.products.filter(p => p.delivery_type === 'preorder').length;
  const archiveCount = storeData.products.filter(p => p.delivery_type === 'archive').length;
  const top3Count = storeData.products.filter(p => p.buybox && p.buybox.is_in_buybox).length;
  const outCount = storeData.products.filter(p => p.buybox && !p.buybox.is_in_buybox).length;
  const dangerCount = storeData.products.filter(p => p.economics && (p.economics.verdict_status === 'LOSS' || p.economics.margin_pct < 10)).length;

  if (document.getElementById('storeFilterAllCount')) document.getElementById('storeFilterAllCount').innerText = storeData.products.length;
  if (document.getElementById('storeFilterInStockCount')) document.getElementById('storeFilterInStockCount').innerText = inStockCount;
  if (document.getElementById('storeFilterPreorderCount')) document.getElementById('storeFilterPreorderCount').innerText = preorderCount;
  if (document.getElementById('storeFilterArchiveCount')) document.getElementById('storeFilterArchiveCount').innerText = archiveCount;
  document.getElementById('storeFilterTop3Count').innerText = top3Count;
  document.getElementById('storeFilterOutCount').innerText = outCount;
  document.getElementById('storeFilterDangerCount').innerText = dangerCount;

  filterAndRenderStoreTable();
}


// Render delivery options supporting all Kaspi pre-order day variants (3..45 days)
function buildDeliveryOptionsHtml(delVal, currentDays) {
  const commonDays = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 30, 45];
  const daysList = [...commonDays];
  const curNum = parseInt(currentDays, 10);
  if (curNum && curNum > 0 && !daysList.includes(curNum)) {
    daysList.push(curNum);
    daysList.sort((a, b) => a - b);
  }
  let html = `<option value="in_stock" ${delVal === 'in_stock' ? 'selected' : ''}>🟢 В наличии (0 дн)</option>`;
  daysList.forEach(d => {
    const val = `preorder_${d}`;
    html += `<option value="${val}" ${delVal === val ? 'selected' : ''}>⏳ Заказ: ${d} дн</option>`;
  });
  html += `<option value="archive" ${delVal === 'archive' ? 'selected' : ''} style="color:#DC2626;font-weight:600;">🚫 Снять с продажи (Архив)</option>`;
  return html;
}

// Официальная сетка тарифов сервиса «Kaspi Доставка» (с НДС 16%)
const KASPI_DELIVERY_RATES = {
  under_10k: [
    { max_price: 1000, city: 57, kz: 57, express: 57, tier: 'до 1 000 ₸' },
    { max_price: 3000, city: 173, kz: 173, express: 173, tier: '1 000 – 3 000 ₸' },
    { max_price: 5000, city: 231, kz: 231, express: 231, tier: '3 000 – 5 000 ₸' },
    { max_price: 10000, city: 811, kz: 927, express: 927, tier: '5 000 – 10 000 ₸' }
  ],
  over_10k_by_weight: {
    under_5kg: { city: 1275, kz: 1507, express: 1971, tier: 'от 10 000 ₸ (до 5 кг)' },
    '5_to_15kg': { city: 1565, kz: 1971, express: 2145, tier: 'от 10 000 ₸ (5–15 кг)' },
    '15_to_30kg': { city: 2667, kz: 4175, express: 3653, tier: 'от 10 000 ₸ (15–30 кг)' }
  }
};

function getKaspiDeliveryDetails(price, scope = 'kz', weightTier = 'under_5kg') {
  const p = Number(price) || 0;
  const key = (scope === 'city' ? 'city' : (scope === 'express' ? 'express' : 'kz'));
  if (p < 10000) {
    for (const r of KASPI_DELIVERY_RATES.under_10k) {
      if (p <= r.max_price) {
        return {
          fee: r[key],
          tier: r.tier,
          scopeName: key === 'kz' ? 'По Казахстану' : (key === 'express' ? 'Express' : 'По городу')
        };
      }
    }
    const r = KASPI_DELIVERY_RATES.under_10k[KASPI_DELIVERY_RATES.under_10k.length - 1];
    return {
      fee: r[key],
      tier: r.tier,
      scopeName: key === 'kz' ? 'По Казахстану' : 'По городу'
    };
  } else {
    const w = KASPI_DELIVERY_RATES.over_10k_by_weight[weightTier] || KASPI_DELIVERY_RATES.over_10k_by_weight.under_5kg;
    return {
      fee: w[key],
      tier: w.tier,
      scopeName: key === 'kz' ? 'По Казахстану' : (key === 'express' ? 'Express' : 'По городу')
    };
  }
}

function getKaspiDeliveryFee(price, scope = 'kz', weightTier = 'under_5kg') {
  return getKaspiDeliveryDetails(price, scope, weightTier).fee;
}

// In-memory unit economics recalculator for instant 60 FPS zero-lag updates
function recalculateProductInMemory(p) {
  const sell = parseFloat(p.sell_price) || 0;
  const cost = parseFloat(p.cost_price || p.default_cost) || 0;
  const has_cost = cost > 0;
  const comm_rate = parseFloat(p.commission_rate) || 12.5;
  const comm_kzt = Math.round(sell * (comm_rate / 100));
  const pay_kzt = Math.round(sell * 0.0095);
  const tax_kzt = Math.round(sell * 0.03);

  // Exact official Kaspi Delivery tariff from schedule
  const delivMode = (window.appConfig && window.appConfig.kaspi_delivery_mode) || 'official_kz';
  const scope = delivMode === 'official_city' ? 'city' : (delivMode === 'official_express' ? 'express' : 'kz');
  
  let delivery_kzt, delivery_tier;
  if (delivMode === 'custom') {
    delivery_kzt = parseInt(window.appConfig && window.appConfig.kaspi_delivery_cost_kzt) || 1507;
    delivery_tier = 'Фикс. доставка';
  } else {
    const dDetails = getKaspiDeliveryDetails(sell, scope);
    delivery_kzt = dDetails.fee;
    delivery_tier = dDetails.tier;
  }
  const pack_kzt = 150;

  const kaspi_deductions = comm_kzt + pay_kzt + tax_kzt + delivery_kzt + pack_kzt;
  const kaspi_payout = Math.round(sell - kaspi_deductions);

  let net_profit = null, margin_pct = null, roi_pct = null;
  let status = "NO_COST", badge = "⚪ НЕ УКАЗАНА", badge_class = "neutral";

  if (has_cost) {
    const total_deductions = cost + kaspi_deductions;
    net_profit = Math.round(sell - total_deductions);
    margin_pct = sell > 0 ? parseFloat(((net_profit / sell) * 100).toFixed(1)) : 0;
    roi_pct = cost > 0 ? parseFloat(((net_profit / cost) * 100).toFixed(1)) : 0;

    if (net_profit < 0) {
      status = "LOSS"; badge = "🔴 В УБЫТОК"; badge_class = "danger";
    } else if (margin_pct < 12.0) {
      status = "LOW_MARGIN"; badge = "⚠️ НИЗКАЯ МАРЖА"; badge_class = "warning";
    } else if (margin_pct >= 25.0) {
      status = "HIGH_PROFIT"; badge = "🟢 СУПЕР-МАРЖА"; badge_class = "success";
    } else {
      status = "NORMAL"; badge = "🟡 СТАБИЛЬНО"; badge_class = "info";
    }
  }

  p.economics = {
    has_cost: has_cost,
    sell_price: sell,
    cost_price: has_cost ? cost : 0,
    comm_rate: comm_rate,
    comm_kzt: comm_kzt,
    pay_kzt: pay_kzt,
    tax_kzt: tax_kzt,
    delivery_kzt: delivery_kzt,
    delivery_tier: delivery_tier,
    pack_kzt: pack_kzt,
    kaspi_deductions: kaspi_deductions,
    kaspi_payout: kaspi_payout,
    total_deductions: has_cost ? (cost + kaspi_deductions) : kaspi_deductions,
    net_profit: net_profit,
    margin_pct: margin_pct,
    roi_pct: roi_pct,
    verdict_status: status,
    verdict_badge: badge,
    badge_class: badge_class
  };



  p.floor_min_price = Math.round((cost + 1050) / 0.6855);

  if (p.competitor_prices && p.competitor_prices.length && !p.alone) {
    const others = p.competitor_prices.filter(x => x > 0);
    const sorted = [...others].sort((a,b) => a - b);
    const p1 = sorted[0];
    const p2 = sorted.length > 1 ? sorted[1] : p1;
    const p3 = sorted.length > 2 ? sorted[2] : p2;
    if (sell <= p1) {
      p.buybox = { rank: 1, label: "🏆 Топ-1 (Лидер корзины)", badge_class: "buybox-top1", is_in_buybox: true, top1_price: p1, top2_price: p2, target_top3: p3 };
    } else if (sell <= p2) {
      p.buybox = { rank: 2, label: "🥈 Топ-2 (В корзине)", badge_class: "buybox-top2", is_in_buybox: true, top1_price: p1, top2_price: p2, target_top3: p3 };
    } else if (sell <= p3) {
      p.buybox = { rank: 3, label: "🥉 Топ-3 (В корзине)", badge_class: "buybox-top3", is_in_buybox: true, top1_price: p1, top2_price: p2, target_top3: p3 };
    } else {
      p.buybox = { rank: 4, label: "⚠️ Вне корзины (#4+)", badge_class: "buybox-out", is_in_buybox: false, top1_price: p1, top2_price: p2, target_top3: p3 };
    }
  }
}

// In-memory summary totals updater
function refreshStoreTotalsInMemory() {
  if (!storeData || !storeData.products) return;
  let totalRevenue = 0;
  let totalProfit = 0;
  let inStockCount = 0;
  let preorderCount = 0;
  let dangerCount = 0;

  storeData.products.forEach(p => {
    const qty = (p.stock && p.stock > 0) ? p.stock : 1;
    totalRevenue += (p.sell_price || 0) * qty;
    totalProfit += (p.economics ? p.economics.net_profit : 0) * qty;
    if (p.delivery_type === 'in_stock') inStockCount++;
    else preorderCount++;
    if (p.economics && (p.economics.net_profit < 0 || p.economics.margin_pct < 10)) {
      dangerCount++;
    }
  });

  storeData.total_revenue = Math.round(totalRevenue);
  storeData.total_profit = Math.round(totalProfit);
  storeData.avg_margin_pct = totalRevenue > 0 ? parseFloat(((totalProfit / totalRevenue) * 100).toFixed(1)) : 0;
  storeData.danger_items = dangerCount;
}

function filterAndRenderStoreTable() {
  const tbody = document.getElementById('storeTableBody');
  tbody.innerHTML = '';

  const q = document.getElementById('storeSearchInput')?.value.toLowerCase().trim() || '';
  
  let filtered = storeData.products.filter(p => {
    // Search query
    const matchSearch = !q || p.title.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q);
    if (!matchSearch) return false;

    // Filter tab
    if (activeStoreFilter === 'in_stock') return p.delivery_type === 'in_stock';
    if (activeStoreFilter === 'preorder') return p.delivery_type === 'preorder';
    if (activeStoreFilter === 'archive') return p.delivery_type === 'archive';
    if (activeStoreFilter === 'top3') return p.buybox.is_in_buybox === true;
    if (activeStoreFilter === 'out') return p.buybox.is_in_buybox === false;
    if (activeStoreFilter === 'danger') return p.economics.verdict_status === 'LOSS' || p.economics.margin_pct < 10;
    return true;
  });

  const totalFiltered = filtered.length;
  const totalPages = Math.ceil(totalFiltered / storePageSize) || 1;
  if (storeCurrentPage > totalPages) storeCurrentPage = totalPages;
  if (storeCurrentPage < 1) storeCurrentPage = 1;

  if (!filtered.length) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 36px; color: var(--text-muted);">Товары не найдены для выбранного фильтра</td></tr>`;
    renderStorePagination(0, 1, 0, 0);
    return;
  }

  const startIdx = (storeCurrentPage - 1) * storePageSize;
  const endIdx = Math.min(startIdx + storePageSize, totalFiltered);
  const pageItems = filtered.slice(startIdx, endIdx);

  renderStorePagination(totalFiltered, totalPages, startIdx, endIdx);

  pageItems.forEach((p, idx) => {
    const tr = document.createElement('tr');
    const econ = p.economics;
    const bb = p.buybox;
    const hasCost = Boolean(econ && econ.has_cost && p.cost_price > 0);
    const isLoss = hasCost && econ.net_profit < 0;

    // Delivery selector value
    const pDays = parseInt(p.preorder_days, 10) || 0;
    const delVal = (p.delivery_type === 'in_stock' || pDays === 0) ? 'in_stock' : `preorder_${pDays}`;

    const fmt = n => Math.round(n || 0).toLocaleString('ru-RU');
    const others = (p.competitor_prices || []).filter(x => x > 0);
    const rowCls = p.alone ? 'row-alone' : (!hasCost ? 'row-ok' : (econ.net_profit < 0 ? 'row-loss' : (econ.margin_pct < 10 ? 'row-low' : 'row-ok')));
    tr.className = rowCls;

    // Рекомендация
    let act = { cls: 'act-hold', text: 'Цена в порядке', btn: '' };
    const minOther = others.length ? Math.min(...others) : null;
    if (p.alone) {
      act = { cls: 'act-alone', text: 'Конкурентов нет: держите цену', btn: '' };
    } else if (hasCost && econ.net_profit < 0) {
      act = { cls: 'act-loss', text: 'Продажа в минус: поднимите цену', btn: p.floor_min_price > p.sell_price ? `<button class="act-btn" onclick="window.applyTargetPrice('${escAttr(p.sku)}', ${p.floor_min_price})">До ${fmt(p.floor_min_price)} ₸</button>` : '' };
    } else if (bb.rank === 1 && bb.top2_price > p.sell_price + 15) {
      act = { cls: 'act-up', text: `Вы лидер: можно поднять до ${fmt(bb.top2_price - 10)} ₸`, btn: `<button class="act-btn" onclick="window.applyTargetPrice('${escAttr(p.sku)}', ${bb.top2_price - 10})">Поднять</button>` };
    } else if (!bb.is_in_buybox) {
      act = { cls: 'act-down', text: `Вне корзины: снизьте до ${fmt(bb.target_top3)} ₸`, btn: `<button class="act-btn" onclick="window.applyTargetPrice('${escAttr(p.sku)}', ${bb.target_top3})">Снизить</button>` };
    }

    // Лесенка цен: разброс цен продавцов и ваша точка
    let ladder = '';
    if (!p.alone && others.length) {
      const all = others.concat([p.sell_price]);
      const lo = Math.min(...all), hi = Math.max(...all), span = Math.max(hi - lo, 1);
      const pos = v => (4 + (v - lo) / span * 92).toFixed(1);
      ladder = `<div class="ladder" title="Цены продавцов на карточке. Синяя точка — ваша цена">` +
        others.slice(0, 40).map(v => `<i class="ld" style="left:${pos(v)}%"></i>`).join('') +
        `<i class="ld me" style="left:${pos(p.sell_price)}%"></i></div>`;
    }
    const diffPct = (minOther && minOther > 0) ? ((p.sell_price - minOther) / minOther * 100) : 0;
    const diffTxt = minOther ? (diffPct === 0 ? 'как у лучшего' : `${diffPct > 0 ? '+' : ''}${diffPct.toFixed(1)}% к лучшей`) : '';

    tr.innerHTML = `
      <td class="c-prod"><div class="prod-cell">
        <img class="thumb-img" src="${p.img ? escAttr(p.img) : photoPlaceholder(p.title)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.onerror=null;this.src=this.dataset.ph" data-ph="${photoPlaceholder(p.title)}">
        <div class="prod-info">
          <div class="prod-title" title="${escAttr(p.title)}">${escHtml(p.title)}</div>
          <div class="prod-meta"><span class="sku">${escHtml(p.sku)}</span><span>${escHtml(p.category)}</span>${p.stock_est ? '' : `<span>остаток ${p.stock} шт</span>`}</div>
          <div class="prod-meta">закупка: <span class="sup-links"><a href="${p.supplier_links.url_1688}" target="_blank" rel="noopener noreferrer" class="sup-mini" title="Поиск на 1688">1688</a><a href="${p.supplier_links.url_ozon}" target="_blank" rel="noopener noreferrer" class="sup-mini" title="Поиск на Ozon">Ozon</a><a href="${p.supplier_links.url_wb}" target="_blank" rel="noopener noreferrer" class="sup-mini" title="Поиск на Wildberries">WB</a></span></div>
          ${topOffersHtml(p)}
        </div>
      </div></td>
      <td class="c-price">
        <div class="price-row-inline">
          <input type="number" class="price-input-inline" value="${p.sell_price}" data-sku="${escAttr(p.sku)}" title="Измените цену и нажмите Enter">
          <span class="cur">₸</span>
        </div>
        <select class="delivery-select-inline in-cell ${p.delivery_type}" data-sku="${escAttr(p.sku)}">
          ${buildDeliveryOptionsHtml(delVal, pDays)}
        </select>
        ${p.floor_min_price > 0 ? `<div class="floor-note" title="Защита минимальной маржи 15%">🛡 пол ${fmt(p.floor_min_price)} ₸</div>` : ''}
        <div class="lim-box" title="Робот-демпинг не опустит цену ниже минимальной и не поднимет выше максимальной. Работает только в программе: в Kaspi без вашей кнопки ничего не уходит.">
          <label>мин <input type="number" min="0" class="lim-input lim-min" data-sku="${escAttr(p.sku)}" value="${p.min_price || ''}" placeholder="—"></label>
          <label>макс <input type="number" min="0" class="lim-input lim-max" data-sku="${escAttr(p.sku)}" value="${p.max_price || ''}" placeholder="—"></label>
        </div>
      </td>
      <td class="c-cost">
        <div class="cost-input-wrap">
          <input type="number" class="cost-input-inline${hasCost ? '' : ' cost-empty'}" value="${hasCost ? p.cost_price : ''}" placeholder="Не указана" data-sku="${escAttr(p.sku)}" title="Введите себестоимость закупки и нажмите Enter">
          <span class="cur">₸</span>
        </div>
        ${hasCost ? '' : '<div class="est-note" style="color:var(--text-muted);font-size:11px;">введите закупку</div>'}
      </td>
      <td class="c-profit">
        ${hasCost ? `
          <div class="profit-big ${econ.net_profit < 0 ? 'neg' : 'pos'}">${econ.net_profit > 0 ? '+' : ''}${fmt(econ.net_profit)} ₸</div>
          <div class="profit-sub"><span class="status-badge-profit ${econ.badge_class}">${econ.margin_pct}%</span><span title="Комиссия Kaspi, Kaspi Pay, налог и доставка">расходы ${fmt(econ.kaspi_deductions)} ₸</span></div>
        ` : `
          <div class="profit-big neutral" style="font-size:13.5px;font-weight:600;color:var(--text-main);" title="К выплате от Kaspi после вычета комиссий и официальной Kaspi Доставки (${fmt(econ.delivery_kzt)} ₸)">К выплате: ${fmt(econ ? econ.kaspi_payout : (p.sell_price - econ.kaspi_deductions))} ₸</div>
          <div class="profit-sub"><span class="status-badge-profit neutral" style="background:#f1f5f9;color:#64748b;border:1px solid #e2e8f0;padding:2px 6px;border-radius:4px;font-size:11px;">Не указана</span><span title="Комиссия Kaspi ${fmt(econ.comm_kzt)} ₸ (${econ.comm_rate}%), Kaspi Pay ${fmt(econ.pay_kzt)} ₸ (0.95%), налог ИП ${fmt(econ.tax_kzt)} ₸ (3%), доставка Kaspi ${fmt(econ.delivery_kzt)} ₸ (${econ.delivery_tier}), упаковка ${fmt(econ.pack_kzt)} ₸">вычеты ${fmt(econ ? econ.kaspi_deductions : 0)} ₸</span></div>
        `}
      </td>
      <td class="c-comp">
        <div class="buybox-badge ${bb.badge_class}" title="${escAttr(bb.advice || '')}">${bb.label}</div>
        ${p.alone ? '<div class="comp-line">Других продавцов нет</div>' : `${ladder}<div class="comp-line">${minOther ? `лучшая ${fmt(minOther)} ₸ · ${diffTxt}` : ''}<br>${p.competitors_count - 1} конкурент(ов)</div>`}
        ${!p.alone ? `<button class="btn btn-xs btn-outline-comp" onclick="window.openCompetitorsModal('${escAttr(p.card_code || '')}', '${escAttr(p.sku)}', '${escAttr(p.title)}')">🔍 Продавцы (${Math.max(1, p.competitors_count - 1)})</button>` : ''}
      </td>
      <td class="c-act">
        <div class="act-chip ${act.cls}" title="${escAttr(p.advice || '')}">${act.text}</div>
        ${act.btn}
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Attach inline edit handlers for Prices
  document.querySelectorAll('.price-input-inline').forEach(inp => {
    inp.addEventListener('change', async (e) => {
      const sku = e.target.dataset.sku;
      const newPrice = parseFloat(e.target.value) || 0;
      await updateSellPrice(sku, newPrice);
    });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') e.target.blur();
    });
  });

  // Мин. и макс. цена для робота-демпинга
  document.querySelectorAll('.lim-input').forEach(inp => {
    inp.addEventListener('change', async (e) => {
      const sku = e.target.dataset.sku;
      const box = e.target.closest('.lim-box');
      const lo = parseInt(box.querySelector('.lim-min').value, 10) || 0;
      const hi = parseInt(box.querySelector('.lim-max').value, 10) || 0;
      try {
        const res = await fetch('/api/kaspi/update_limits', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sku, min_price: lo, max_price: hi }) });
        const d = await res.json();
        if (d.success) {
          const pr = (storeData.products || []).find(x => x.sku === sku); if (pr) { pr.min_price = d.min_price; pr.max_price = d.max_price; }
          box.classList.remove('bad'); showToast(lo || hi ? `✓ Границы цены: ${lo || '—'} … ${hi || '—'} ₸` : '✓ Границы цены сняты');
        } else { box.classList.add('bad'); showToast(d.error || 'Не удалось сохранить'); }
      } catch (err) { showToast('Ошибка связи: ' + err.message); }
    });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') e.target.blur(); });
  });

  // Attach inline edit handlers for Costs
  document.querySelectorAll('.cost-input-inline').forEach(inp => {
    inp.addEventListener('change', async (e) => {
      const sku = e.target.dataset.sku;
      const newCost = parseFloat(e.target.value) || 0;
      await updateCostPrice(sku, newCost);
    });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') e.target.blur();
    });
  });

  // Attach inline delivery selector
  document.querySelectorAll('.delivery-select-inline').forEach(sel => {
    sel.addEventListener('change', async (e) => {
      const sku = e.target.dataset.sku;
      const val = e.target.value;
      let delType = 'in_stock';
      let preDays = 0;
      if (val.startsWith('preorder_')) {
        delType = 'preorder';
        preDays = parseInt(val.replace('preorder_', '')) || 7;
      } else if (val === 'archive') {
        delType = 'archive';
        preDays = 0;
      }
      await updateDeliveryType(sku, delType, preDays);
    });
  });
}

// Render Apple-Style Pagination Controls (Smooth 8000+ item navigation)
function renderStorePagination(total, totalPages, startIdx, endIdx) {
  const rangeEl = document.getElementById('storePageRange');
  const countEl = document.getElementById('storeTotalCount');
  const navEl = document.getElementById('storePaginationNav');
  const barEl = document.getElementById('storePaginationBar');

  if (rangeEl) rangeEl.innerText = total === 0 ? '0–0' : `${(startIdx + 1).toLocaleString()}–${endIdx.toLocaleString()}`;
  if (countEl) countEl.innerText = total.toLocaleString();

  if (!barEl || !navEl) return;
  if (total <= storePageSize) {
    navEl.innerHTML = '';
    return;
  }

  let html = '';
  // Prev button
  html += `<button class="pagination-btn" ${storeCurrentPage === 1 ? 'disabled' : ''} onclick="changeStorePage(${storeCurrentPage - 1})" title="Предыдущая страница">‹ Назад</button>`;

  // Calculate visible page buttons (compact window)
  const pages = [];
  pages.push(1);
  if (storeCurrentPage > 3) pages.push('...');
  for (let p = Math.max(2, storeCurrentPage - 2); p <= Math.min(totalPages - 1, storeCurrentPage + 2); p++) {
    pages.push(p);
  }
  if (storeCurrentPage < totalPages - 2) pages.push('...');
  if (totalPages > 1) pages.push(totalPages);

  pages.forEach(p => {
    if (p === '...') {
      html += `<span class="pagination-dots">…</span>`;
    } else {
      const active = (p === storeCurrentPage) ? 'active' : '';
      html += `<button class="pagination-btn ${active}" onclick="changeStorePage(${p})">${p}</button>`;
    }
  });

  // Next button
  html += `<button class="pagination-btn" ${storeCurrentPage === totalPages ? 'disabled' : ''} onclick="changeStorePage(${storeCurrentPage + 1})" title="Следующая страница">Вперед ›</button>`;

  navEl.innerHTML = html;
}

window.changeStorePage = function(newPage) {
  storeCurrentPage = newPage;
  filterAndRenderStoreTable();
  const card = document.querySelector('.table-card');
  if (card) {
    card.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
};

// Window function for quick Top-1 / Top-2 / Top-3 button clicks
window.applyTargetPrice = async function(sku, targetPrice) {
  showToast(`Установка цены ${targetPrice.toLocaleString()} ₸ для входа в корзину...`);
  await updateSellPrice(sku, targetPrice);
};

// Modal: Inspect all competitor merchants on a specific Kaspi card
window.openCompetitorsModal = async function(cardCode, sku, title) {
  const modal = document.getElementById('competitorsModal');
  const titleEl = document.getElementById('compModalTitle');
  const subEl = document.getElementById('compModalSubtitle');
  const loading = document.getElementById('compModalLoading');
  const content = document.getElementById('compModalContent');
  const tbody = document.getElementById('compModalTableBody');

  if (titleEl) titleEl.innerText = `Конкуренты Kaspi · Арт: ${sku}`;
  if (subEl) subEl.innerText = title || '';
  if (loading) loading.style.display = 'block';
  if (content) content.style.display = 'none';
  if (tbody) tbody.innerHTML = '';
  modal.classList.add('open');

  try {
    const res = await fetch(`/api/kaspi/competitors_detail?card_code=${encodeURIComponent(cardCode)}&sku=${encodeURIComponent(sku)}`);
    const data = await res.json();
    if (data.success && data.offers && data.offers.length) {
      tbody.innerHTML = '';
      data.offers.forEach((o, i) => {
        const tr = document.createElement('tr');
        const isMin = (i === 0);
        const compPrice = o.price || 0;
        tr.innerHTML = `
          <td style="color: var(--text-muted); text-align: center;">${i + 1}</td>
          <td>
            <div style="font-weight: 600;">${escHtml(o.merchant || 'Продавец Kaspi')}</div>
            ${isMin ? '<span class="badge" style="background:#DCFCE7; color:#16A34A; font-size:10px; margin-top:2px;">★ Лидер BuyBox</span>' : ''}
          </td>
          <td style="text-align: center;"><span class="rating-pill">${o.rating ? '★ ' + o.rating : '—'}</span></td>
          <td><strong>${compPrice.toLocaleString()} ₸</strong></td>
          <td>
            <span class="t5-tag ${saleMethod(o).cls}" title="${escAttr(saleMethod(o).title)}">${saleMethod(o).text}</span>
            <span class="badge" style="font-size: 11px;">
              ${o.kaspi_delivery ? '⚡ Kaspi Доставка' : '📦 Доставка продавца'}
            </span>
          </td>
          <td>
            <button class="btn btn-xs btn-accent" style="white-space: nowrap;" onclick="window.applyTargetPrice('${escAttr(sku)}', ${compPrice - 10}); document.getElementById('competitorsModal').classList.remove('open');">
              Ниже на 10 ₸
            </button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } else {
      // Fallback: show known prices from storeData
      const prod = storeData.products.find(x => x.sku === sku);
      const prices = (prod && prod.competitor_prices) ? prod.competitor_prices : [];
      if (prices.length > 0) {
        tbody.innerHTML = '';
        prices.forEach((pr, i) => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td style="color: var(--text-muted); text-align: center;">${i + 1}</td>
            <td><div style="font-weight: 600;">Конкурент #${i + 1}</div></td>
            <td style="text-align: center;"><span class="rating-pill">—</span></td>
            <td><strong>${pr.toLocaleString()} ₸</strong></td>
            <td><span class="badge">—</span></td>
            <td>
              <button class="btn btn-xs btn-accent" style="white-space: nowrap;" onclick="window.applyTargetPrice('${escAttr(sku)}', ${pr - 10}); document.getElementById('competitorsModal').classList.remove('open');">
                Ниже на 10 ₸
              </button>
            </td>
          `;
          tbody.appendChild(tr);
        });
      } else {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 24px; color: var(--text-muted);">
          Нет активных конкурентов на карточке или товар продаётся эксклюзивно вами.
        </td></tr>`;
      }
    }
  } catch (err) {
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 24px; color: #DC2626;">Ошибка загрузки конкурентов: ${escHtml(err.message)}</td></tr>`;
    }
  } finally {
    if (loading) loading.style.display = 'none';
    if (content) content.style.display = 'block';
  }
};

// Lightbox modal for Kaspi mobile camera scanning and Google Lens visual search
window.previewRadarItem = function(itemId, original) {
  const it = currentItems.find(x => Number(x.id) === Number(itemId)) || radarItemsAll.find(x => Number(x.id) === Number(itemId));
  if (!it) return;
  const source = it.img_main || it.img_url || '';
  window.openImagePreview(original ? source : it.infographic_image || it.ai_image || source, it.kaspi_name || it.name || '');
};
window.openImagePreview = function(imgUrl, title) {
  const modal = document.getElementById('imagePreviewModal');
  const img = document.getElementById('imgModalPreview');
  const lensBtn = document.getElementById('imgModalLensBtn');
  const titleEl = document.getElementById('imgModalTitle');

  if (img) img.src = imgUrl;
  if (titleEl) titleEl.innerText = title ? title.slice(0, 40) + '...' : 'Скан товара';
  if (lensBtn) lensBtn.href = `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(imgUrl)}`;
  modal?.classList.add('open');
};

// 1-Click Live Vacuum Check on Kaspi via backend analyzer
window.testKaspiVacuum = async function(itemId, btn) {
  const it = currentItems.find(x => x.id === itemId);
  if (!it) return;
  const resDiv = document.getElementById(`vacuum-res-${itemId}`);
  if (!resDiv) return;

  const originalHtml = btn.innerHTML;
  btn.innerHTML = '⏳ Проверка...';
  btn.disabled = true;

  try {
    const res = await fetch('/api/check_vacuum', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: it.name || it.kaspi_name || '',
        query: it.kaspi_search_query || '',
        images: [it.img_main || it.img_url, ...(it.images || [])].filter((u, i, a) => u && a.indexOf(u) === i).slice(0, 3)
      })
    });
    const data = await res.json();
    if (data.success && data.result) {
      const r = data.result;
      resDiv.style.display = 'block';
      if (r.vacuum_status === 'vacuum_full') {
        resDiv.innerHTML = `
          <div style="background: rgba(22, 163, 74, 0.08); border: 1px solid rgba(22, 163, 74, 0.25); border-radius: 6px; padding: 6px 10px; color: #15803D; margin-top: 4px;">
            <div style="font-weight: 700;">${escHtml(r.badge || '🟢 Похожих карточек не найдено')}</div>
            <div style="color: #4B5563; margin-top: 2px;">${escHtml(r.explanation || '')}</div>
          </div>
        `;
      } else if (r.vacuum_status === 'vacuum_low_competition') {
        resDiv.innerHTML = `
          <div style="background: rgba(234, 179, 8, 0.1); border: 1px solid rgba(234, 179, 8, 0.3); border-radius: 6px; padding: 6px 10px; color: #B45309; margin-top: 4px;">
            <div style="font-weight: 700;">${escHtml(r.badge || '')}</div>
            <div style="color: #4B5563; margin-top: 2px;">${escHtml(r.explanation || '')}</div>
          </div>
        `;
      } else if (r.vacuum_status === 'saturated') {
        resDiv.innerHTML = `
          <div style="background: rgba(220, 38, 38, 0.08); border: 1px solid rgba(220, 38, 38, 0.25); border-radius: 6px; padding: 6px 10px; color: #B91C1C; margin-top: 4px;">
            <div style="font-weight: 700;">${escHtml(r.badge || '')}</div>
            <div style="color: #4B5563; margin-top: 2px;">${escHtml(r.explanation || '')}</div>
          </div>
        `;
      } else {
        resDiv.innerHTML = `<div style="color: #6B7280; margin-top: 4px;">${r.explanation || 'Проверка завершена'}</div>`;
      }
    } else {
      showToast('Не удалось получить ответ от поисковика Kaspi');
    }
  } catch (err) {
    showToast('Ошибка проверки: ' + err.message);
  } finally {
    btn.innerHTML = originalHtml;
    btn.disabled = false;
  }
};

async function updateSellPrice(sku, newPrice) {
  newPrice = parseFloat(newPrice) || 0;
  if (newPrice <= 0) return;

  // 1. Optimistic in-memory update (0ms latency, zero lag!)
  let prevPrice = 0;
  if (storeData && storeData.products) {
    const prod = storeData.products.find(x => x.sku === sku);
    if (prod) {
      prevPrice = prod.sell_price;
      prod.sell_price = newPrice;
      recalculateProductInMemory(prod);
      refreshStoreTotalsInMemory();
      renderStoreDashboard();
      filterAndRenderStoreTable();
    }
  }

  showToast(`✓ Цена сохранена в программе: ${newPrice.toLocaleString('ru-RU')} ₸.`);

  // 2. Asynchronous background persistence to server
  try {
    const res = await fetch('/api/kaspi/update_price', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sku: sku, sell_price: newPrice })
    });
    const data = await res.json();
    if (data.success && window.pushOfferToKaspi) window.pushOfferToKaspi(sku, { price: newPrice });
    if (!data.success) {
      showToast('⚠️ Ошибка сохранения цены: ' + (data.error || ''));
      if (prevPrice > 0 && storeData && storeData.products) {
        const prod = storeData.products.find(x => x.sku === sku);
        if (prod) {
          prod.sell_price = prevPrice;
          recalculateProductInMemory(prod);
          refreshStoreTotalsInMemory();
          renderStoreDashboard();
          filterAndRenderStoreTable();
        }
      }
    }
  } catch (err) {
    showToast('⚠️ Ошибка сети при обновлении цены');
  }
}

async function updateCostPrice(sku, newCost) {
  newCost = parseFloat(newCost) || 0;

  // 1. Optimistic in-memory update (0ms latency, zero lag!)
  if (storeData && storeData.products) {
    const prod = storeData.products.find(x => x.sku === sku);
    if (prod) {
      prod.cost_price = newCost;
      prod.cost_est = false;
      recalculateProductInMemory(prod);
      refreshStoreTotalsInMemory();
      renderStoreDashboard();
      filterAndRenderStoreTable();
    }
  }

  showToast(`✓ Себестоимость сохранена: ${newCost.toLocaleString('ru-RU')} ₸. Маржа пересчитана!`);

  // 2. Asynchronous background persistence to server
  try {
    const res = await fetch('/api/kaspi/update_cost', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sku: sku, cost_price: newCost })
    });
    const data = await res.json();
    if (!data.success) {
      showToast('⚠️ Ошибка сохранения себестоимости: ' + (data.error || ''));
    }
  } catch (err) {
    showToast('⚠️ Ошибка сети при сохранении себестоимости');
  }
}

async function updateDeliveryType(sku, deliveryType, preorderDays) {
  preorderDays = parseInt(preorderDays, 10) || 0;

  // 1. Optimistic in-memory update (0ms latency, zero lag!)
  if (storeData && storeData.products) {
    const prod = storeData.products.find(x => x.sku === sku);
    if (prod) {
      prod.delivery_type = deliveryType;
      prod.preorder_days = preorderDays;
      if (deliveryType === 'archive') {
        prod.delivery_label = '🚫 Снят с продажи';
        prod.stock = 0;
      } else if (deliveryType === 'in_stock') {
        prod.delivery_label = 'В наличии';
      } else {
        prod.delivery_label = `Под заказ (${preorderDays}д)`;
      }
      refreshStoreTotalsInMemory();
      renderStoreDashboard();
      filterAndRenderStoreTable();
    }
  }

  if (deliveryType === 'archive') {
    showToast('🚫 Снят с продажи в программе.');
  } else {
    const statusTxt = deliveryType === 'in_stock' ? '🟢 В наличии' : `⏳ Предзаказ (${preorderDays} дн)`;
    showToast(`✓ Статус сохранён в программе: ${statusTxt}.`);
  }

  // 2. Asynchronous background persistence to server
  try {
    const res = await fetch('/api/kaspi/update_delivery', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sku: sku, delivery_type: deliveryType, preorder_days: preorderDays })
    });
    const data = await res.json();
    if (data.success && window.pushOfferToKaspi) window.pushOfferToKaspi(sku, { mode: deliveryType, preorder_days: preorderDays });
    if (!data.success) {
      showToast('⚠️ Ошибка сохранения срока поставки: ' + (data.error || ''));
    }
  } catch (err) {
    showToast('⚠️ Ошибка сети при сохранении типа поставки');
  }
}

// Setup Store Events
function setupStoreEvents() {
  document.getElementById('btnRefreshStore')?.addEventListener('click', () => {
    showToast('Обновление остатков и позиций BuyBox...');
    loadKaspiStore();
  });

  // Live competitors sync button
  document.getElementById('btnSyncCompetitors')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnSyncCompetitors');
    btn.disabled = true;
    const oldHtml = btn.innerHTML;
    btn.innerHTML = `<span class="spinner-inline"></span> <span>Сканирование Kaspi...</span>`;
    showToast('⚡ Запущено онлайн-сканирование живых цен Kaspi...');
    try {
      const res = await fetch('/api/kaspi/refresh_competitors', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        showToast('✓ Сканирование цен Kaspi запущено в фоне! Обновление...');
        setTimeout(async () => {
          await loadKaspiStore();
          showToast('✓ Витрина актуализирована живыми ценами Kaspi!');
        }, 3000);
      } else {
        showToast('Ошибка запуска сканирования цен');
      }
    } catch (err) {
      showToast('Ошибка связи с сервером');
    } finally {
      setTimeout(() => {
        btn.disabled = false;
        btn.innerHTML = oldHtml;
      }, 3500);
    }
  });

  document.getElementById('btnExportXml')?.addEventListener('click', () => {
    showToast('Генерация XML-прайса для Kaspi Pay...');
    window.location.href = '/api/kaspi/export_xml';
  });

  document.getElementById('btnExportPrices')?.addEventListener('click', () => {
    showToast('Формирование файла обновления цен и предзаказа для Kaspi Pay...');
    window.location.href = '/api/kaspi/export_prices';
  });

  document.querySelectorAll('.store-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.store-filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeStoreFilter = btn.dataset.filter;
      storeCurrentPage = 1;
      filterAndRenderStoreTable();
    });
  });

  document.getElementById('storeSearchInput')?.addEventListener('input', () => {
    storeCurrentPage = 1;
    filterAndRenderStoreTable();
  });

  document.getElementById('storePageSizeSelect')?.addEventListener('change', (e) => {
    storePageSize = parseInt(e.target.value) || 50;
    storeCurrentPage = 1;
    filterAndRenderStoreTable();
  });

  document.getElementById('btnRunRepricer')?.addEventListener('click', () => {
    showToast('⚡️ Запуск Авто-репрайсера по всей базе товаров...');
    saveRepricerConfig(true);
  });

  ['repricerStrategy', 'repricerMinMargin', 'repricerUndercut'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', () => {
      saveRepricerConfig(false);
    });
  });

  // Kaspi Excel price list upload
  document.getElementById('kaspiExcelFileInput')?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);
    showToast('Импорт прайс-листа Kaspi...');
    try {
      // XML / CSV (например ACTIVE.xml из кабинета) идут в общий разбор прайс-листов
      if (/\.(xml|csv)$/i.test(file.name)) {
        const r = await (await fetch('/api/kaspi/import_file', { method: 'POST', body: formData })).json();
        if (r.success) {
          showToast(`🎉 Загружено товаров: ${r.count}`);
          await loadKaspiStore();
        } else {
          alert(r.error || 'Не удалось прочитать файл');
        }
        return;
      }
      let res = await fetch('/api/kaspi/upload_excel', {
        method: 'POST',
        body: formData
      });
      let data = await res.json();
      if (!data.success && data.need_confirm) {
        const ok = confirm(`${data.error}\n\nТоваров сейчас: ${data.old_count}, в новом прайсе: ${data.new_count}.\nЗаменить список? Всё, чего нет в файле, уйдёт в архив.`);
        if (!ok) { showToast('Загрузка отменена, текущий список не изменён.'); return; }
        formData.append('confirm', '1');
        formData.append('replace', '1');
        res = await fetch('/api/kaspi/upload_excel', { method: 'POST', body: formData });
        data = await res.json();
      }
      if (data.success) {
        const arch = Number(data.archived_count || 0);
        showToast(`🎉 Успешно! Добавлено ${data.imported_count} товаров из вашего прайс-листа!` + (arch ? ` В архив отправлено: ${arch}.` : ''));
        await loadKaspiStore();
      } else {
        showToast(`Ошибка импорта: ${data.error || 'Неверный формат'}`);
      }
    } catch (err) {
      showToast('Ошибка при загрузке прайс-листа');
    } finally {
      e.target.value = '';
    }
  });
}

// Setup Modals
function setupModalEvents() {
  // License Modal
  const licModal = document.getElementById('licenseModal');
  const btnOpenLic = document.getElementById('btnSidebarActivate');
  const btnCloseLic = document.getElementById('btnCloseLicenseModal');
  const btnCancelLic = document.getElementById('btnCancelLicenseModal');
  const btnSubmitLic = document.getElementById('btnSubmitActivation');

  btnOpenLic?.addEventListener('click', () => {
    licModal.classList.add('open');
  });

  [btnCloseLic, btnCancelLic].forEach(btn => {
    btn?.addEventListener('click', () => licModal.classList.remove('open'));
  });

  btnSubmitLic?.addEventListener('click', async () => {
    const key = document.getElementById('modalLicenseInput').value.trim();
    if (!key) {
      showToast('Пожалуйста, введите ключ активации');
      return;
    }
    btnSubmitLic.disabled = true;
    btnSubmitLic.innerText = 'Проверка...';

    try {
      const res = await fetch('/api/license/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: key })
      });
      const data = await res.json();
      if (data.success) {
        showToast('🎉 PRO Лицензия успешно активирована! Все функции разблокированы');
        licModal.classList.remove('open');
        checkLicenseStatus();
      } else {
        showToast(`Ошибка: ${data.error || 'Неверный ключ активации'}`);
      }
    } catch (err) {
      showToast('Ошибка проверки ключа');
    } finally {
      btnSubmitLic.disabled = false;
      btnSubmitLic.innerText = 'Активировать PRO';
    }
  });

  // Kaspi Connect Modal
  const kaspiModal = document.getElementById('kaspiModal');
  const btnOpenKaspi = document.getElementById('btnOpenKaspiModal');
  const btnCloseKaspi = document.getElementById('btnCloseKaspiModal');
  const btnCancelKaspi = document.getElementById('btnCancelKaspiModal');
  const btnSaveKaspi = document.getElementById('btnSaveKaspiApi');

  btnOpenKaspi?.addEventListener('click', () => {
    document.getElementById('modalKaspiToken').value = appConfig.kaspi_api_token || '';
    document.getElementById('modalKaspiMerchantId').value = appConfig.kaspi_merchant_id || '';
    kaspiModal.classList.add('open');
  });

  [btnCloseKaspi, btnCancelKaspi].forEach(btn => {
    btn?.addEventListener('click', () => kaspiModal.classList.remove('open'));
  });

  btnSaveKaspi?.addEventListener('click', async () => {
    const token = document.getElementById('modalKaspiToken').value.trim();
    const merchantId = document.getElementById('modalKaspiMerchantId').value.trim();
    
    btnSaveKaspi.disabled = true;
    btnSaveKaspi.innerText = 'Подключение...';

    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kaspi_api_token: token,
          kaspi_merchant_id: merchantId
        })
      });
      const data = await res.json();
      if (data.success) {
        appConfig = data.config;
        showToast('✓ Ключ Kaspi сохранён! Загрузка данных магазина...');
        kaspiModal.classList.remove('open');
        loadKaspiStore();
      }
    } catch (err) {
      showToast('Ошибка сохранения настроек');
    } finally {
      btnSaveKaspi.disabled = false;
      btnSaveKaspi.innerText = 'Сохранить и загрузить товары';
    }
  });

  // Add Product by Kaspi Link Modal
  const addModal = document.getElementById('addKaspiModal');
  const btnOpenAdd = document.getElementById('btnOpenAddKaspiModal');
  const btnCloseAdd = document.getElementById('btnCloseAddKaspiModal');
  const btnCancelAdd = document.getElementById('btnCancelAddKaspiModal');
  const btnSubmitAdd = document.getElementById('btnSubmitAddKaspi');

  btnOpenAdd?.addEventListener('click', () => {
    document.getElementById('addKaspiInputUrl').value = '';
    document.getElementById('addKaspiCostPrice').value = '';
    document.getElementById('addKaspiSellPrice').value = '';
    addModal.classList.add('open');
  });

  [btnCloseAdd, btnCancelAdd].forEach(btn => {
    btn?.addEventListener('click', () => addModal.classList.remove('open'));
  });

  btnSubmitAdd?.addEventListener('click', async () => {
    const url = document.getElementById('addKaspiInputUrl').value.trim();
    if (!url) {
      showToast('Пожалуйста, введите ссылку или артикул Kaspi');
      return;
    }

    const delVal = document.getElementById('addKaspiDeliveryType').value;
    let delType = 'in_stock';
    let preDays = 0;
    if (delVal.startsWith('preorder')) {
      delType = 'preorder';
      preDays = parseInt(delVal.replace('preorder_', '')) || 7;
    }

    const cost = parseFloat(document.getElementById('addKaspiCostPrice').value) || null;
    const price = parseFloat(document.getElementById('addKaspiSellPrice').value) || null;

    btnSubmitAdd.disabled = true;
    btnSubmitAdd.innerText = 'Добавление...';

    try {
      const res = await fetch('/api/kaspi/add_by_url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: url,
          delivery_type: delType,
          preorder_days: preDays,
          cost_price: cost,
          sell_price: price
        })
      });
      const data = await res.json();
      if (data.success) {
        showToast('✓ Товар успешно добавлен в дашборд!');
        addModal.classList.remove('open');
        loadKaspiStore();
      } else {
        showToast(`Ошибка: ${data.error || 'Не удалось распознать товар'}`);
      }
    } catch (err) {
      showToast('Ошибка при добавлении товара');
    } finally {
      btnSubmitAdd.disabled = false;
      btnSubmitAdd.innerText = 'Добавить карточку';
    }
  });

  // Competitors Modal
  const compModal = document.getElementById('competitorsModal');
  const btnCloseComp = document.getElementById('btnCloseCompModal');
  const btnCloseCompBtn = document.getElementById('btnCloseCompModalBtn');
  [btnCloseComp, btnCloseCompBtn].forEach(btn => {
    btn?.addEventListener('click', () => compModal?.classList.remove('open'));
  });

  // Repricer Logs Modal
  const repricerModal = document.getElementById('repricerLogsModal');
  const btnCloseRepricer = document.getElementById('btnCloseRepricerLogs');
  const btnCloseRepricerBtn = document.getElementById('btnCloseRepricerLogsBtn');
  [btnCloseRepricer, btnCloseRepricerBtn].forEach(btn => {
    btn?.addEventListener('click', () => repricerModal?.classList.remove('open'));
  });

  // Image Preview & Kaspi Scan Modal
  const imgModal = document.getElementById('imagePreviewModal');
  const btnCloseImg = document.getElementById('btnCloseImgModal');
  btnCloseImg?.addEventListener('click', () => imgModal?.classList.remove('open'));

  // Global ESC key and backdrop click to close any open modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-backdrop.open').forEach(m => m.classList.remove('open'));
    }
  });

  document.querySelectorAll('.modal-backdrop').forEach(b => {
    b.addEventListener('click', (e) => {
      if (e.target === b) {
        b.classList.remove('open');
      }
    });
  });
}

// Setup Event Listeners (WB Radar & Settings)
function setupEventListeners() {
  // Category Quick Pills
  document.querySelectorAll('#tab-radar .pill-btn').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#tab-radar .pill-btn').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      document.getElementById('scanQuery').value = pill.dataset.query;
      document.getElementById('btnStartScan').click();
    });
  });

  // Table filter
  document.getElementById('tableFilterInput')?.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase().trim();
    if (!q) {
      renderTable(currentItems);
      return;
    }
    const filtered = currentItems.filter(it => 
      (it.kaspi_name || it.name || '').toLowerCase().includes(q) ||
      (it.brand || '').toLowerCase().includes(q)
    );
    renderTable(filtered);
    document.getElementById('tableFilterCount').innerText = `${filtered.length} найдено`;
  });

  // Start Scan
  document.getElementById('btnStartScan')?.addEventListener('click', async () => {
    const query = document.getElementById('scanQuery').value.trim();
    const limit = document.getElementById('scanLimit').value;
    const minFeedbacks = document.getElementById('scanMinFeedbacks').value;
    const btn = document.getElementById('btnStartScan');
    btn.disabled = true;
    btn.innerText = 'Сканирование...';
    showToast(`Поиск хитов по запросу «${query}» (${limit} карточек)...`);

    try {
      const res = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, limit, min_feedbacks: minFeedbacks })
      });
      const data = await res.json();
      if (data.success) {
        currentItems = data.items || [];
        renderTable(currentItems);
        updateKpis(currentItems);
        showToast(`База обновлена: всего ${currentItems.length} товаров! Новых: ${data.added ?? 0}`);
      } else {
        alert((data.error || 'Поиск не удался') + ' Показаны ранее сохранённые карточки.');
      }
    } catch (err) {
      showToast('Ошибка при сканировании');
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg><span>Найти товары</span>`;
    }
  });

  // Sync WB Prices (Price Guard)
  document.getElementById('btnSyncWbPrices')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnSyncWbPrices');
    btn.disabled = true;
    btn.innerHTML = `<span>Проверка цен WB...</span>`;
    showToast('Синхронизация актуальных цен и остатков с серверами Wildberries...');

    try {
      const res = await fetch('/api/sync_wb_prices', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        currentItems = data.items || currentItems;
        renderTable(currentItems);
        showToast(`✓ Готово! Обновлено цен: ${data.updated_prices}, закончилось на WB: ${data.out_of_stock}`);
      }
    } catch (err) {
      showToast('Ошибка синхронизации с WB');
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg><span>Контроль цен WB</span>`;
    }
  });

  // Download Excel with custom export options
  const downloadHandler = () => {
    const days = document.getElementById('exportPreorderDays')?.value || 7;
    const photoMode = document.getElementById('exportPhotoMode')?.value || 'infographic';
    const descMode = document.getElementById('exportDescMode')?.value || 'ai_copywriter';
    showToast(`Формирование Excel (предзаказ ${days} дн, фото: ${photoMode})...`);
    window.location.href = `/api/export?preorder_days=${days}&photo_mode=${photoMode}&desc_mode=${descMode}`;
  };

  document.getElementById('btnDownloadExcel')?.addEventListener('click', downloadHandler);
  document.getElementById('btnQuickExport')?.addEventListener('click', downloadHandler);

  // Settings Save
  document.getElementById('settingsForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const cfg = {
      royaltech_api_key: document.getElementById('cfgRoyaltechKey').value.trim(),
      kaspi_merchant_id: document.getElementById('cfgKaspiId').value.trim(),
      kaspi_api_token: document.getElementById('cfgKaspiToken').value.trim(),
      kaspi_delivery_mode: (document.getElementById('cfgKaspiDeliveryMode') ? document.getElementById('cfgKaspiDeliveryMode').value : 'official_kz'),
      kaspi_delivery_cost_kzt: (document.getElementById('cfgKaspiDeliveryCost') ? parseInt(document.getElementById('cfgKaspiDeliveryCost').value) : 1507) || 1507,
      margin_multiplier: parseFloat(document.getElementById('cfgMarginMultiplier').value) || 2.4,
      packaging_cost_kzt: parseInt(document.getElementById('cfgPackagingCost').value) || 150
    };
    
    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg)
      });
      const data = await res.json();
      if (data.success) {
        appConfig = data.config;
        showToast('✓ Настройки успешно сохранены!');
        checkApiStatus();
      }
    } catch (err) {
      showToast('Ошибка сохранения настроек');
    }
  });

  // Test API
  document.getElementById('btnTestApi')?.addEventListener('click', () => {
    checkApiStatus();
    showToast('Проверка связи с NanoBanana...');
  });
}

// Загрузка всего каталога из прайс-листа Kaspi (xlsx / csv / xml)
document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('btnImportMyProducts');
  const inp = document.getElementById('importPriceFile');
  const clr = document.getElementById('btnClearImport');
  const costInp = document.getElementById('costFileInput');
  if (costInp) {
    costInp.addEventListener('change', async () => {
      if (!costInp.files.length) return;
      const fd = new FormData();
      fd.append('file', costInp.files[0]);
      try {
        const r = await (await fetch('/api/kaspi/import_costs', { method: 'POST', body: fd })).json();
        if (r.success) { showToast(`Себестоимость обновлена у товаров: ${r.count}`); loadKaspiStore(); }
        else alert(r.error || 'Не удалось прочитать файл');
      } catch (e) { alert('Ошибка загрузки файла: ' + e); }
      costInp.value = '';
    });
  }
  if (btn && inp) {
    btn.addEventListener('click', () => inp.click());
    inp.addEventListener('change', async () => {
      if (!inp.files.length) return;
      const fd = new FormData();
      fd.append('file', inp.files[0]);
      try {
        const res = await fetch('/api/kaspi/import_file', { method: 'POST', body: fd });
        const r = await res.json();
        if (r.success) {
          showToast(`Загружено товаров: ${r.count}`);
          loadKaspiStore();
        } else {
          alert(r.error || 'Не удалось прочитать файл');
        }
      } catch (e) {
        alert('Ошибка загрузки файла: ' + e);
      }
      inp.value = '';
    });
  }
  if (clr) {
    clr.addEventListener('click', async () => {
      await fetch('/api/kaspi/import_clear', { method: 'POST' });
      loadKaspiStore();
    });
  }
});

// Toast
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.innerText = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3500);
}


// ==========================================================
// Автопилот репрайсера: статус, включение, ссылка на прайс
// ==========================================================
let _autopilotTimer = null;

function _feedFullUrl(path) {
  const base = (localStorage.getItem('publicBaseUrl') || '').replace(/\/$/, '');
  return (base || window.location.origin) + path;
}

async function loadAutopilot() {
  try {
    const res = await fetch('/api/autopilot');
    const d = await res.json();
    if (!d.success) return;
    const st = d.status || {};
    const en = document.getElementById('autopilotEnabled');
    const iv = document.getElementById('autopilotInterval');
    const state = document.getElementById('autopilotState');
    const meta = document.getElementById('autopilotMeta');
    const feed = document.getElementById('autopilotFeedUrl');
    if (en) en.checked = d.enabled;
    if (iv && document.activeElement !== iv) iv.value = String(d.interval_min);
    if (state) {
      state.className = 'autopilot-state';
      if (st.running) { state.textContent = 'идёт проверка…'; state.classList.add('on'); }
      else if (st.last_ok === false) { state.textContent = 'ошибка в прошлом цикле'; state.classList.add('err'); }
      else if (d.enabled) { state.textContent = d.next_run ? `ВКЛ · следующий запуск ≈ ${d.next_run}` : 'ВКЛ · первый запуск в течение минуты'; state.classList.add('on'); }
      else { state.textContent = 'ВЫКЛ'; }
    }
    if (meta) {
      const sk = st.skipped || {};
      let html = `Робот ведёт <b>${d.ready_count}</b> товар(ов) с вашей себестоимостью, из них с конкурентами: <b>${d.ready_with_competitors}</b>.`;
      if (st.last_run) {
        html += ` Последний цикл: ${st.last_run} — изменено ${st.repriced || 0}, на пороге маржи ${st.shielded || 0}, без изменений ${st.unchanged || 0}.`;
        if (sk.no_cost) html += ` <span class="autopilot-warn">Пропущено без себестоимости: ${sk.no_cost}.</span>`;
      }
      if (d.ready_count === 0) html += ' <span class="autopilot-warn">Укажите себестоимость у товаров (или загрузите файл себестоимости) — без неё робот цены не трогает.</span>';
      if (st.errors && st.errors.length) html += ` <span class="autopilot-warn">Ошибки: ${st.errors.slice(0, 3).join('; ')}</span>`;
      meta.innerHTML = html;
    }
    if (feed) feed.textContent = _feedFullUrl(d.feed_path);
  } catch (e) {
    console.error('autopilot status error', e);
  }
}

async function saveAutopilot() {
  const en = document.getElementById('autopilotEnabled')?.checked || false;
  const iv = parseInt(document.getElementById('autopilotInterval')?.value) || 30;
  await fetch('/api/kaspi/repricer', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ enabled: en, interval_min: iv })
  });
  showToast(en ? `Автопилот включён: каждые ${iv} мин` : 'Автопилот выключен');
  loadAutopilot();
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('autopilotEnabled')?.addEventListener('change', saveAutopilot);
  document.getElementById('autopilotInterval')?.addEventListener('change', saveAutopilot);
  document.getElementById('btnCopyFeed')?.addEventListener('click', async () => {
    const t = document.getElementById('autopilotFeedUrl')?.textContent || '';
    try { await navigator.clipboard.writeText(t); showToast('Ссылка скопирована'); } catch (e) { showToast(t); }
  });
  loadAutopilot();
  _autopilotTimer = setInterval(loadAutopilot, 20000);
});

// ==========================================================
// Карточки Kaspi (официальный API Kaspi: /shop/api/products/import)
// ==========================================================
(function () {
  const RU = {
    'color': 'Цвет', 'material': 'Материал', 'type': 'Тип', 'length': 'Длина, см', 'width': 'Ширина, см', 'height': 'Высота, см',
    'depth': 'Глубина, см', 'weight': 'Вес', 'country': 'Страна производства', 'code': 'Артикул', 'vendor code': 'Артикул',
    'manufacturers code': 'Код производителя', 'features': 'Особенности', 'name': 'Наименование', 'gender': 'Пол', 'size': 'Размер',
    'quantity': 'Количество', 'amount in a package': 'Кол-во в упаковке', 'appointment': 'Назначение', 'form': 'Форма',
    'kit contents': 'Комплектация', 'additional information': 'Доп. информация', 'additional': 'Доп. информация',
    'dimensions': 'Габариты', 'installation': 'Установка', 'for whom': 'Для кого', 'diameter': 'Диаметр', 'head': 'Головка',
    'coating': 'Покрытие', 'components': 'Состав комплекта', 'peculiarities': 'Особенности', 'care instructions': 'Уход',
    'volume': 'Объём', 'purpose': 'Назначение', 'model': 'Модель', 'equipment': 'Комплектация', 'shape': 'Форма',
    'pattern': 'Рисунок', 'composition': 'Состав', 'age': 'Возраст', 'power': 'Мощность', 'capacity': 'Ёмкость',
  };
  const attrLabel = code => { const leaf = code.split('*').pop(); return RU[leaf.toLowerCase()] || leaf; };
  const STATUS = {
    draft: ['Черновик', '#64748B', '#F1F5F9'], sent: ['Загружается в Kaspi', '#B45309', '#FEF3C7'],
    accepted: ['На модерации Kaspi', '#B45309', '#FEF3C7'], error: ['Ошибка / отказ', '#B91C1C', '#FEE2E2'],
    selling: ['Выставляется в продажу', '#1D4ED8', '#DBEAFE'], on_sale: ['✓ В продаже на Kaspi', '#15803D', '#DCFCE7'],
  };
  const attrCache = {};
  let drafts = [];
  const sendSel = new Set();
  const openSet = new Set();      // раскрытые карточки (по умолчанию всё свёрнуто)
  let cardFilter = 'all';
  const LOCKED = ['sent', 'accepted', 'selling', 'on_sale'];
  const kindOf = d => d.status === 'error' ? 'todo' : (d.status === 'on_sale' ? 'sale' : (LOCKED.includes(d.status) ? 'moder' : ((d.problems || []).length ? 'todo' : 'ready')));
  const KIND_ORDER = { todo: 0, ready: 1, moder: 2, sale: 3 };
  const fmtN = v => (v == null || v === '') ? '—' : Number(v).toLocaleString('ru-RU');
  const esc = v => escHtml(v == null ? '' : String(v));

  async function api(url, body) {
    const res = await fetch(url, body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    return res.json();
  }
  async function categoryAttrs(cat) {
    if (!cat) return [];
    if (!attrCache[cat]) {
      const d = await api('/api/cards/attributes?c=' + encodeURIComponent(cat));
      attrCache[cat] = d.success ? d.attributes : [];
    }
    return attrCache[cat];
  }

  // ---------- Радар: выбор товаров и массовое создание ----------
  function updateRadarSel() {
    const n = radarSelected.size;
    const c = document.getElementById('cardsSelCount'); if (c) c.innerText = n;
    const b = document.getElementById('btnMakeCards'); if (b) b.disabled = n === 0;
    const h = document.getElementById('radarSelHint');
    if (h) h.innerHTML = n === 0 ? '<b>Что дальше:</b> нажмите «Создать карточку» у нужного товара. Или отметьте несколько галочками слева и нажмите «Создать карточки Kaspi».'
      : '<b>Выбрано товаров: ' + n + '.</b> Нажмите «Создать карточки Kaspi (' + n + ')» справа вверху, дальше всё продолжится в разделе «Карточки Kaspi».';
  }
  document.addEventListener('change', e => {
    if (e.target.classList && e.target.classList.contains('radar-sel')) {
      const id = Number(e.target.dataset.id);
      e.target.checked ? radarSelected.add(id) : radarSelected.delete(id);
      updateRadarSel();
    }
    if (e.target.id === 'radarSelAll') {
      document.querySelectorAll('.radar-sel').forEach(cb => {
        cb.checked = e.target.checked; const id = Number(cb.dataset.id);
        e.target.checked ? radarSelected.add(id) : radarSelected.delete(id);
      });
      updateRadarSel();
    }
  });
  document.addEventListener('click', e => {
    if (!(e.target.closest && e.target.closest('#btnMakeCards'))) return;
    makeCardDrafts([...radarSelected], document.getElementById('btnMakeCards'));
  });
  // Кнопка «Создать карточку» в строке товара: отмечает товар и делает черновик так же, как «Создать карточки Kaspi».
  // В Kaspi ничего не уходит, пока вы сами не нажмёте «Отправить в Kaspi» в разделе «Карточки Kaspi».
  window.createCardFromRadar = function (itemId, btn) {
    radarSelected.add(itemId);
    document.querySelectorAll('.radar-sel').forEach(cb => { if (Number(cb.dataset.id) === itemId) cb.checked = true; });
    updateRadarSel();
    makeCardDrafts([itemId], btn);
  };
  async function makeCardDrafts(ids, btn) {
    if (!ids.length || !btn || btn.dataset.busy) return;
    btn.dataset.busy = '1';
    btn.disabled = true; const old = btn.innerHTML;
    let made = 0, failed = [];
    for (let i = 0; i < ids.length; i += 5) {          // пачками, чтобы видеть прогресс
      btn.innerHTML = `⏳ Готовлю: ${Math.min(i + 5, ids.length)} / ${ids.length}`;
      try {
        const d = await api('/api/cards/draft', { wb_ids: ids.slice(i, i + 5) });
        made += (d.drafts || []).length; failed = failed.concat(d.failed || []);
      } catch (err) { failed.push({ wb_id: '?', error: err.message }); }
    }
    btn.innerHTML = old; delete btn.dataset.busy; btn.disabled = false;
    ids.forEach(id => radarSelected.delete(id));
    document.querySelectorAll('.radar-sel').forEach(cb => { if (ids.includes(Number(cb.dataset.id))) cb.checked = false; });
    const all = document.getElementById('radarSelAll'); if (all) all.checked = false;
    updateRadarSel();
    showToast(`✓ Черновиков: ${made}` + (failed.length ? ` · не удалось: ${failed.length} (${failed[0].error})` : '') + (made ? '. Проверьте карточку в разделе «Карточки Kaspi»: в Kaspi она уйдёт только после кнопки «Отправить в Kaspi».' : '.'));
    const tab = document.querySelector('.nav-item[data-tab="tab-cards"]'); if (tab && made) tab.click();
  }

  // ---------- Вкладка карточек ----------
  window.loadCards = async function () {
    const d = await api('/api/cards');
    if (!d.success) { showToast('Ошибка: ' + d.error); return; }
    drafts = d.drafts || [];
    render();
  };

  function render() {
    const list = document.getElementById('cardsList');
    const cnt = { draft: 0, ready: 0, sent: 0, accepted: 0, error: 0 };
    drafts.forEach(d => { cnt[d.status] = (cnt[d.status] || 0) + 1; if (!['sent','accepted','selling','on_sale'].includes(d.status) && !(d.problems || []).length) cnt.ready++; });
    const todo = drafts.filter(d => !['sent','accepted','selling','on_sale'].includes(d.status) && (d.problems || []).length).length;
    const kc = { all: drafts.length, todo: 0, ready: 0, moder: 0, sale: 0 };
    drafts.forEach(d => { kc[kindOf(d)]++; });
    const CH = [['all', 'Все', ''], ['todo', 'Нужно дозаполнить или ошибка', '#B45309'], ['ready', 'Готовы к отправке', '#15803D'], ['moder', 'На модерации и выставляются', '#1D4ED8'], ['sale', 'В продаже', '#15803D']];
    document.getElementById('cardsStats').innerHTML = CH.map(([k, n, c]) => '<button type="button" class="cstat' + (cardFilter === k ? ' on' : '') + '" data-f="' + k + '">' + n + ' <b' + (c ? ' style="color:' + c + '"' : '') + '>' + kc[k] + '</b></button>').join('') +
      (kc.ready ? ' <button class="btn btn-sm" id="btnSelReady">Отметить все готовые к отправке</button>' : '');
    [...sendSel].forEach(s => { const d = drafts.find(x => x.sku === s); if (!d || (d.problems || []).length || ['sent','accepted','selling','on_sale'].includes(d.status)) sendSel.delete(s); });
    updateSendBtn();
    if (!drafts.length) { list.innerHTML = '<div class="cards-empty">Пока нет черновиков. Откройте «Поиск товаров с WB», отметьте товары и нажмите «Создать карточки Kaspi».</div>'; return; }
    const shown = drafts.filter(d => cardFilter === 'all' || kindOf(d) === cardFilter).sort((x, y) => KIND_ORDER[kindOf(x)] - KIND_ORDER[kindOf(y)]);
    list.innerHTML = shown.length ? shown.map(cardHtml).join('') : '<div class="cards-empty">В этой группе карточек нет. Выберите другую группу сверху.</div>';
    shown.filter(d => openSet.has(d.sku) || d.status === 'error').forEach(d => fillAttrs(d));
  }

  function cardHtml(d) {
    const st = STATUS[d.status] || STATUS.draft;
    const probs = d.problems || [];
    const locked = ['sent','accepted','selling','on_sale'].includes(d.status);
    const canSend = !locked && !probs.length;
    const dis = locked ? 'disabled' : '';
    const sugg = (d.category_suggestions || []).map(c => `<option value="${esc(c.code)}" ${c.code === d.category ? 'selected' : ''}>${esc(c.title)}</option>`).join('');
    const curOpt = d.category && !(d.category_suggestions || []).some(c => c.code === d.category) ? `<option value="${esc(d.category)}" selected>${esc(d.category_title)}</option>` : '';
    const imgs = (d.images || []).map((u, i) => `<div class="card-img"><img src="${esc(u)}" loading="lazy" onerror="this.style.opacity=.3">${locked ? '' : `<button class="card-img-x" data-sku="${esc(d.sku)}" data-i="${i}" title="Убрать фото">×</button>${i ? `<button class="card-img-main" data-sku="${esc(d.sku)}" data-i="${i}" title="Сделать главным">★</button>` : '<span class="card-img-badge">главное</span>'}`}</div>`).join('');
    const kres = d.kaspi_result || d.kaspi_status || d.kaspi_response || null;
    const fill = probs.length ? `<span class="kcard-badge" style="color:#B45309;background:#FEF3C7">Не хватает: ${probs.length}</span>` : '<span class="kcard-badge" style="color:#15803D;background:#DCFCE7">✓ Всё заполнено</span>';
    return `
    <div class="kcard" data-sku="${esc(d.sku)}">
      <div class="kcard-top">
        <input type="checkbox" class="card-send-sel" data-sku="${esc(d.sku)}" ${canSend ? '' : 'disabled'} ${sendSel.has(d.sku) ? 'checked' : ''} title="${canSend ? 'Отправить эту карточку' : 'Сначала заполните поля'}">
        <img class="kcard-thumb" src="${esc((d.images || [])[0] || '')}" onerror="this.style.opacity=.3">
        <div class="kcard-main">
          <div class="kcard-row">
            <span class="kcard-badge" style="color:${st[1]};background:${st[2]}">${st[0]}</span>
            ${locked ? '' : fill}
            <a href="${esc(d.source_url || d.wb_url)}" target="_blank" rel="noopener noreferrer" class="kcard-link">${esc(d.source === "1688" ? "1688" : d.source === "ozon" ? "Ozon" : "WB")} ${esc(d.source_variant_id || d.wb_id)} ↗</a>
            <span class="kcard-muted">SKU: ${esc(d.sku)} · ${d.source ? "вариант поставщика" : "предмет WB: " + esc(d.wb_subject)}</span>
            ${d.sale_note ? `<span class="kcard-muted" style="color:#1D4ED8">· ${esc(d.sale_note)}</span>` : ''}
            ${d.shop_url ? `<a href="${esc(d.shop_url)}" target="_blank" class="kcard-link">открыть на kaspi.kz ↗</a>` : ''}
            ${locked ? '' : `<button class="kcard-del" data-sku="${esc(d.sku)}" title="Удалить черновик">🗑</button>`}
          </div>
          <div class="kcard-sum"><b>${esc(d.title)}</b><span>Цена <b>${fmtN(d.price)} ₸</b></span><span>Себестоимость <b>${fmtN(d.cost)} ₸</b></span><span>Предзаказ <b>${esc(d.preorder_days)} дн</b></span><button type="button" class="btn btn-sm kcard-toggle" data-sku="${esc(d.sku)}">${(openSet.has(d.sku) || d.status === 'error') ? 'Свернуть ▴' : (locked ? 'Подробнее ▾' : (probs.length ? 'Дозаполнить ▾' : 'Изменить ▾'))}</button></div>
          <div class="kcard-body" style="display:${(openSet.has(d.sku) || d.status === 'error') ? 'block' : 'none'}">
          <div class="kcard-grid3">
            <label>Название на Kaspi<input class="kf" data-f="title" value="${esc(d.title)}" ${dis}></label>
            <label>Бренд<input class="kf" data-f="brand" value="${esc(d.brand)}" ${dis}></label>
            <label>Цена, ₸<input class="kf" data-f="price" type="number" value="${esc(d.price)}" ${dis}></label>
            <label>Себестоимость, ₸<input class="kf" data-f="cost" type="number" value="${esc(d.cost)}" ${dis}></label>
            <label>Предзаказ, дней${d.source === 'ozon' ? ' · автоматически по Ozon' : ''}<input class="kf" data-f="preorder_days" type="number" min="1" max="30" value="${esc(d.preorder_days)}" ${d.source === 'ozon' ? 'readonly' : ''} ${dis}></label>
          </div>
          <div class="kcard-cat">
            <label>Категория Kaspi <b style="color:#B91C1C">*</b> <span class="kcard-muted">— проверьте! Подбор автоматический и может ошибаться.</span>
              <select class="kcat-sel" ${dis}>${curOpt}${sugg}</select>
            </label>
            ${locked ? '' : `<input class="kcat-search" data-sku="${esc(d.sku)}" placeholder="🔎 Другая категория: начните вводить..."><div class="kcat-results" id="kres-${esc(d.sku)}"></div>`}
          </div>
          ${probs.length && !locked ? `<div class="kcard-probs">${probs.map(p => esc(p.replace(/характеристика: (.+)$/, (m, x) => 'характеристика: ' + attrLabel(x)))).join(' · ')}</div>` : ''}
          ${(d.risks || []).length && !locked ? `<div class="kcard-probs" style="background:#FEF2F2;border-color:#FECACA;color:#991B1B">⚠ Риск отказа модерации: ${(d.risks || []).map(esc).join(' · ')}</div>` : ''}
          <details ${probs.length && !locked ? 'open' : ''}><summary>Характеристики (${(d.attributes || []).length})</summary>
            <div class="kattrs" id="kattrs-${esc(d.sku)}">Загрузка...</div></details>
          <details><summary>Описание (${(d.description || '').length} симв.) — проверьте текст и перевод перед отправкой</summary>
            <textarea class="kf kdesc" data-f="description" rows="8" ${dis}>${esc(d.description)}</textarea></details>
          <details><summary>Фото (${(d.images || []).length})</summary><div class="card-imgs">${imgs}</div>
            ${locked ? '' : `<div style="display:flex;gap:8px;align-items:center;"><button class="btn btn-sm kimg-ai" data-sku="${esc(d.sku)}" title="Студийное фото без надписей по первому фото (RoyalTech)">✨ ИИ-фото главным</button><input class="kimg-add" data-sku="${esc(d.sku)}" placeholder="или добавить фото по ссылке https://... и Enter"></div>`}</details>
          ${kres ? `<details ${d.status === 'error' ? 'open' : ''}><summary>Ответ Kaspi ${d.checked_at ? '(' + esc(d.checked_at) + ')' : ''}</summary><pre class="kres">${esc(JSON.stringify(kres, null, 2))}</pre></details>` : ''}
          </div>
        </div>
      </div>
    </div>`;
  }

  async function fillAttrs(d) {
    const box = document.getElementById('kattrs-' + d.sku);
    if (!box) return;
    const defs = await categoryAttrs(d.category);
    const byCode = Object.fromEntries(defs.map(a => [a.code, a]));
    const locked = ['sent','accepted','selling','on_sale'].includes(d.status);
    const dis = locked ? 'disabled' : '';
    const attrs = [...(d.attributes || [])].sort((a, b) => (b.mandatory - a.mandatory));
    box.innerHTML = attrs.map(a => {
      const def = byCode[a.code] || {};
      const empty = a.value === null || a.value === '' || (Array.isArray(a.value) && !a.value.length);
      const lab = `<span class="ka-lab ${a.mandatory && empty ? 'ka-miss' : ''}">${esc(attrLabel(a.code))}${a.mandatory ? ' <b style="color:#B91C1C">*</b>' : ''}</span>`;
      const src = a.source ? `<span class="ka-src">авто: ${esc(a.source)}</span>` : '';
      let ctl;
      if (a.type === 'enum') {
        const vals = (def.values || []).map(v => v.name);
        const cur = Array.isArray(a.value) ? a.value : (empty ? [] : [a.value]);
        const opts = vals.map(v => `<option ${cur.includes(v) ? 'selected' : ''}>${esc(v)}</option>`).join('');
        if (!vals.length) ctl = `<input class="ka" data-code="${esc(a.code)}" value="${esc(cur.join(', '))}" ${dis}>`;
        else if (a.multiValued) ctl = `<select multiple size="${Math.min(4, Math.max(2, vals.length))}" class="ka" data-code="${esc(a.code)}" data-multi="1" ${dis} title="Ctrl+клик — выбрать несколько">${opts}</select>`;
        else ctl = `<select class="ka" data-code="${esc(a.code)}" ${dis}><option value="">— выберите —</option>${opts}</select>`;
      } else if (a.type === 'boolean') {
        ctl = `<select class="ka" data-code="${esc(a.code)}" ${dis}><option value="">— выберите —</option><option value="true" ${a.value === true ? 'selected' : ''}>да</option><option value="false" ${a.value === false ? 'selected' : ''}>нет</option></select>`;
      } else {
        ctl = `<input class="ka" data-code="${esc(a.code)}" ${a.type === 'number' ? 'type="number" step="any"' : ''} value="${empty ? '' : esc(a.value)}" ${dis}>`;
      }
      return `<div class="ka-row">${lab}${ctl}${src}</div>`;
    }).join('') || '<span class="kcard-muted">Выберите категорию</span>';
  }

  function keepOpen(sku, fn) {
    const el = document.querySelector(`.kcard[data-sku="${CSS.escape(sku)}"]`);
    const openStates = el ? [...el.querySelectorAll('details')].map(x => x.open) : [];
    fn();
    const nel = document.querySelector(`.kcard[data-sku="${CSS.escape(sku)}"]`);
    if (nel) [...nel.querySelectorAll('details')].forEach((x, k) => { if (k < openStates.length) x.open = openStates[k]; });
  }

  async function update(sku, fields) {
    const d = await api('/api/cards/update', { sku, fields });
    if (!d.success) { showToast('Ошибка: ' + d.error); return; }
    const i = drafts.findIndex(x => x.sku === sku); drafts[i] = d.draft;
    keepOpen(sku, render);
  }

  function updateSendBtn() {
    const c = document.getElementById('cardsSendCount'); if (c) c.innerText = sendSel.size;
    const b = document.getElementById('btnCardsSend'); if (b) b.disabled = sendSel.size === 0;
  }

  async function setCategory(sku, code) {
    showToast('Загружаю характеристики категории...');
    const d = await api('/api/cards/category', { sku, category: code });
    if (!d.success) { showToast('Ошибка: ' + d.error); return; }
    const i = drafts.findIndex(x => x.sku === sku); drafts[i] = d.draft;
    keepOpen(sku, render);
  }

  document.addEventListener('change', e => {
    const t = e.target; if (!t.classList) return;
    if (t.classList.contains('card-send-sel')) { t.checked ? sendSel.add(t.dataset.sku) : sendSel.delete(t.dataset.sku); updateSendBtn(); return; }
    const card = t.closest('.kcard'); const sku = card && card.dataset.sku;
    if (!sku) return;
    if (t.classList.contains('kf')) {
      let v = t.value; if (t.type === 'number') v = Number(v) || 0;
      update(sku, { [t.dataset.f]: v });
    } else if (t.classList.contains('ka')) {
      const v = t.dataset.multi ? [...t.selectedOptions].map(o => o.value) : t.value;
      update(sku, { attributes: { [t.dataset.code]: v } });
    } else if (t.classList.contains('kcat-sel')) {
      setCategory(sku, t.value);
    }
  });

  let searchTimer;
  document.addEventListener('input', e => {
    const t = e.target;
    if (!t.classList || !t.classList.contains('kcat-search')) return;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(async () => {
      const box = document.getElementById('kres-' + t.dataset.sku);
      if (t.value.trim().length < 3) { box.innerHTML = ''; return; }
      const d = await api('/api/cards/categories?q=' + encodeURIComponent(t.value.trim()));
      box.innerHTML = (d.categories || []).map(c => `<button class="kcat-opt" data-sku="${esc(t.dataset.sku)}" data-code="${esc(c.code)}">${esc(c.title)}</button>`).join('') || '<span class="kcard-muted">Ничего не найдено</span>';
    }, 300);
  });

  document.addEventListener('keydown', e => {
    const t = e.target;
    if (e.key === 'Enter' && t.classList && t.classList.contains('kimg-add') && /^https?:\/\//.test(t.value.trim())) {
      const d = drafts.find(x => x.sku === t.dataset.sku);
      update(d.sku, { images: [...(d.images || []), t.value.trim()].slice(0, 10) });
    }
  });

  document.addEventListener('click', async e => {
    const t = e.target; if (!t.classList) return;
    if (t.classList.contains('kcat-opt')) { setCategory(t.dataset.sku, t.dataset.code); return; }
    if (t.classList.contains('card-img-main')) {
      const d = drafts.find(x => x.sku === t.dataset.sku); const imgs = [...d.images]; const [m] = imgs.splice(Number(t.dataset.i), 1);
      update(d.sku, { images: [m, ...imgs] }); return;
    }
    if (t.classList.contains('kimg-ai')) {
      t.disabled = true; t.innerText = '⏳ Генерирую (до 2 мин)...';
      const d = await api('/api/cards/ai_photo', { sku: t.dataset.sku });
      if (!d.success) { showToast('ИИ-фото: ' + d.error); t.disabled = false; t.innerText = '✨ ИИ-фото главным'; return; }
      const i = drafts.findIndex(x => x.sku === d.draft.sku); drafts[i] = d.draft; keepOpen(d.draft.sku, render); showToast('✓ ИИ-фото стало главным'); return;
    }
    if (t.classList.contains('card-img-x')) {
      const d = drafts.find(x => x.sku === t.dataset.sku);
      const imgs = [...d.images]; imgs.splice(Number(t.dataset.i), 1); update(d.sku, { images: imgs }); return;
    }
    if (t.classList.contains('kcard-del')) {
      if (!confirm('Удалить черновик ' + t.dataset.sku + '?')) return;
      await api('/api/cards/delete', { sku: t.dataset.sku }); sendSel.delete(t.dataset.sku); window.loadCards(); return;
    }
    const tg = t.closest && t.closest('.kcard-toggle');
    if (tg) {
      const sku = tg.dataset.sku; const dd = drafts.find(x => x.sku === sku);
      if (openSet.has(sku)) openSet.delete(sku); else openSet.add(sku);
      const op = openSet.has(sku); const body = tg.closest('.kcard').querySelector('.kcard-body'); body.style.display = op ? 'block' : 'none';
      tg.textContent = op ? 'Свернуть ▴' : (dd && LOCKED.includes(dd.status) ? 'Подробнее ▾' : ((dd && (dd.problems || []).length) ? 'Дозаполнить ▾' : 'Изменить ▾'));
      if (op && dd) fillAttrs(dd);
      return;
    }
    const fl = t.closest && t.closest('.cstat');
    if (fl) { cardFilter = fl.dataset.f; render(); return; }
    if (t.id === 'btnSelReady') {
      drafts.forEach(d => { if (!['sent','accepted','selling','on_sale'].includes(d.status) && !(d.problems || []).length) sendSel.add(d.sku); });
      render(); return;
    }
    if (t.closest('#btnCardsStatus')) {
      showToast('Проверяю загрузку и модерацию в Kaspi...');
      const d0 = await api('/api/cards/status', {});
      if (!d0.success) { showToast('Ошибка: ' + d0.error); return; }
      const d = await api('/api/cards/autosale', {});
      drafts = (d.success ? d.drafts : d0.drafts); render();
      if (!d.success) { showToast('Ошибка: ' + d.error); return; }
      const r = d.report;
      showToast(`Проверено: ${r.checked}. Выставлено в продажу: ${r.put_on_sale.length}. В продаже: ${r.on_sale.length}. Ждут модерацию: ${r.waiting.length}` + (r.errors.length ? ` · ${r.errors[0]}` : ''));
      return;
    }
    if (t.closest('#btnCardsSend')) {
      const skus = [...sendSel];
      if (!skus.length) return;
      if (!confirm(`Отправить ${skus.length} карточек в Kaspi на модерацию?\n\nОни уйдут в ваш магазин Kaspi через официальный API и попадут в прайс с указанной ценой и предзаказом.`)) return;
      const b = document.getElementById('btnCardsSend'); b.disabled = true; b.innerHTML = '⏳ Отправка...';
      const d = await api('/api/cards/send', { skus });
      b.innerHTML = '🚀 Отправить в Kaspi (<span id="cardsSendCount">0</span>)';
      if (!d.success) { showToast('Kaspi не принял: ' + d.error); window.loadCards(); return; }
      sendSel.clear();
      showToast(`✓ Отправлено: ${d.sent.length}. Код загрузки Kaspi: ${d.import_code || '—'}. Статус — кнопка «Статус модерации».`);
      window.loadCards();
    }
  });
})();


// ==========================================================
// Кабинет Kaspi через сотрудника: подключение и применение цены/предзаказа/снятия с продажи
// ==========================================================
(function () {
  const $ = id => document.getElementById(id);
  let cabConnected = false;

  async function post(url, body) {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
    return r.json();
  }

  async function loadCabinet() {
    if (!$('cabinetBox')) return;
    try {
      const d = await (await fetch('/api/cabinet/status')).json();
      if (!d.success) { $('cabStatus').innerHTML = '⚠ ' + escHtml(d.error || 'ошибка'); return; }
      const s = d.status;
      cabConnected = !!s.connected;
      if (s.login && !$('cabLogin').value) $('cabLogin').value = s.login;
      $('cabCodeRow').style.display = s.pending_code ? '' : 'none';
      if (s.pending_code) $('cabCodeLabel').innerText = 'Код из письма на ' + (s.pending_email || 'почту сотрудника');
      $('cabStatus').innerHTML = s.connected
        ? `<span class="cab-ok">● Подключено</span> — сотрудник <b>${escHtml(s.login)}</b>, магазин ${escHtml(s.merchant_id)}, склад ${escHtml(s.store_id)}`
        : (s.configured ? '<span class="cab-bad">● Не подключено</span> — сессия истекла или нужен код. Нажмите «Подключить».' : '<span class="cab-bad">● Не подключено</span> — введите email и пароль сотрудника.');
      $('cabLog').innerHTML = (d.log || []).map(l => `<div>${escHtml(l.ts)} — ${escHtml(l.event)} ${escHtml(l.sku || '')} ${l.price ? escHtml(l.price + ' ₸') : ''} ${l.preorder ? 'предзаказ ' + escHtml(l.preorder) + ' дн' : ''} ${l.available === false ? 'снят с продажи' : ''} ${escHtml(l.error || '')}</div>`).join('') || '<div>пока пусто</div>';
      $('cabAutopush').checked = (appConfig.kaspi_cab_autopush !== false);
    } catch (e) { $('cabStatus').innerText = 'Ошибка связи с программой'; }
  }
  window.loadCabinet = loadCabinet;

  document.addEventListener('click', async e => {
    const t = e.target;
    if (t.id === 'btnCabLogin') {
      t.disabled = true; t.innerText = 'Вход... если почта подключена, код подставится сам (до 90 секунд)';
      const d = await post('/api/cabinet/login', { login: $('cabLogin').value.trim(), password: $('cabPassword').value });
      t.disabled = false; t.innerText = 'Подключить'; $('cabPassword').value = '';
      if (!d.success) showToast('Kaspi: ' + d.error);
      else if (d.need_code) { showToast('Kaspi отправил код на ' + d.email + '. Введите его ниже.'); $('cabCodeRow').style.display = ''; $('cabCodeLabel').innerText = 'Код из письма на ' + d.email; $('cabCode').focus(); return; }
      else showToast('✓ Подключено к кабинету Kaspi');
      loadCabinet();
    }
    if (t.id === 'btnCabCode') {
      t.disabled = true;
      const d = await post('/api/cabinet/code', { code: $('cabCode').value.trim() });
      t.disabled = false;
      showToast(d.success ? '✓ Подключено к кабинету Kaspi' : 'Kaspi: ' + d.error);
      loadCabinet();
    }
    if (t.id === 'btnCabLogout') {
      if (!confirm('Отключить программу от кабинета Kaspi? Пароль сотрудника будет удалён с этого ПК.')) return;
      await post('/api/cabinet/logout'); cabConnected = false; showToast('Отключено'); loadCabinet();
    }
  });
  document.addEventListener('change', async e => {
    if (e.target.id === 'cabAutopush') {
      appConfig.kaspi_cab_autopush = e.target.checked;
      await post('/api/config', { kaspi_cab_autopush: e.target.checked });
    }
  });

  // Применить состояние товара в Kaspi (используется после правок в «Мой магазин» и для новых карточек)
  window.pushOfferToKaspi = async function (sku, opts) {
    opts = opts || {};
    if (!opts.force) {
      if (appConfig.kaspi_cab_autopush === false) return;
      if (!cabConnected) { showToast('ℹ Изменение сохранено в программе. Чтобы оно ушло в Kaspi, подключите сотрудника: Настройки → Подключение к кабинету Kaspi.'); return; }
    }
    const p = (storeData && storeData.products || []).find(x => x.sku === sku) || {};
    const mode = opts.mode || p.delivery_type || 'in_stock';
    const body = { sku, mode, price: opts.price || p.sell_price, preorder_days: opts.preorder_days || p.preorder_days || 7, model: opts.model || p.title };
    showToast('⏳ Отправляю в Kaspi: ' + sku + '...');
    const d = await post('/api/cabinet/offer', body);
    if (!d.success) { showToast('⚠ Kaspi не принял ' + sku + ': ' + d.error); return d; }
    const what = mode === 'archive' ? 'снять с продажи' : `${Number(body.price).toLocaleString('ru-RU')} ₸` + (mode === 'preorder' ? `, предзаказ ${body.preorder_days} дн` : ', в наличии');
    showToast(`✓ Kaspi принял (${what}). Применит в течение часа — проверить можно кнопкой «Проверить в Kaspi».`);
    loadCabinet();
    return d;
  };

  window.verifyOfferInKaspi = async function (sku) {
    const d = await (await fetch('/api/cabinet/verify?sku=' + encodeURIComponent(sku))).json();
    if (!d.success) { showToast('⚠ ' + d.error); return; }
    const sh = d.shop, c = d.cabinet;
    if (d.in_queue) showToast(`⏳ ${sku}: изменение ещё в очереди Kaspi.`);
    else if (sh) showToast(`✓ На kaspi.kz: ${sh.price.toLocaleString('ru-RU')} ₸` + (sh.preorder ? `, предзаказ ${sh.preorder} дн` : ', без предзаказа'));
    else showToast(`${sku}: на витрине не продаётся (в кабинете: ${c.available ? 'в продаже' : 'снят с продажи'}).`);
    return d;
  };

  document.addEventListener('DOMContentLoaded', () => setTimeout(loadCabinet, 800));
})();

// ==========================================================
// Слежение за WB (цена и наличие для вашего города) — по товарам в продаже
// ==========================================================
(function () {
  const $ = id => document.getElementById(id);
  const fmt = n => (n == null ? '—' : Number(n).toLocaleString('ru-RU'));
  const hm = s => (s || '').slice(11, 16);
  const esc2 = s => String(s == null ? '' : s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  // Статус строки: иконка, короткий заголовок и понятное пояснение
  function status(r) {
    const a = r.action || '';
    if (!a) return { cls: 'info', ic: '·', t: 'Ещё не проверялся', d: '' };
    if (/^Ошибка/.test(a)) {
      const nf = /\(404\)/.test(a);
      return { cls: 'bad', ic: '!', t: 'Не удалось применить', d: nf ? 'Kaspi не нашёл этот товар (404): он ещё не прошёл модерацию или удалён. Проверьте его в кабинете Kaspi.' : a.replace(/^Ошибка:\s*/, '') };
    }
    if (/^Нет на WB/.test(a)) return { cls: 'bad', ic: '×', t: 'Нет на WB', d: a.replace(/^Нет на WB\s*→\s*/, '') };
    if (/^Снова есть/.test(a)) return { cls: 'ok', ic: '↺', t: 'Возвращён в продажу', d: a.replace(/^Снова есть на WB\s*→\s*/, '') };
    if (/^WB подорожал/.test(a)) return { cls: 'warn', ic: '↑', t: 'Цена в Kaspi поднята', d: a };
    if (/^OK/.test(a)) {
      const m = /от (\d+) ₸ при марже (\d+)%/.exec(a);
      const days = / предзаказ (\d+) → (\d+) дн/.exec(a);
      let d = m ? 'Можно снизить цену до ' + fmt(+m[1]) + ' ₸ (маржа ' + m[2] + '%)' : '';
      if (days) d += (d ? '. ' : '') + 'Срок предзаказа изменён: ' + days[1] + ' → ' + days[2] + ' дн';
      return { cls: 'ok', ic: '✓', t: 'Всё в порядке', d };
    }
    return { cls: 'info', ic: 'i', t: a, d: '' };
  }
  function banner(kind, html) {
    const b = $('wbtBanner'); b.style.display = ''; b.className = 'wbt-banner ' + kind; b.innerHTML = html;
  }
  function reportBanner(rep, when) {
    if (!rep) return;
    if (rep.busy) { banner('warn', '<b class="t">Проверка уже идёт</b><br>Подождите минуту и откройте раздел снова.'); return; }
    const parts = ['проверено товаров: <b>' + rep.checked + '</b>'];
    if ((rep.removed || []).length) parts.push('снято с продажи: <b>' + rep.removed.length + '</b>');
    if ((rep.restored || []).length) parts.push('возвращено в продажу: <b>' + rep.restored.length + '</b>');
    if ((rep.repriced || []).length) parts.push('цена поднята: <b>' + rep.repriced.length + '</b>');
    if ((rep.cheaper || []).length) parts.push('можно снизить цену: <b>' + rep.cheaper.length + '</b>');
    const errs = rep.errors || [];
    const changed = (rep.removed || []).length + (rep.restored || []).length + (rep.repriced || []).length;
    const title = errs.length ? 'Проверка завершена, есть замечания' : 'Проверка завершена успешно';
    const nothing = !changed && !errs.length ? '<br>Изменений в Kaspi не потребовалось.' : '';
    const ehtml = errs.length ? '<br><b>Что не получилось:</b><ul style="margin:4px 0 0 18px">' + errs.slice(0, 6).map(e => '<li>' + esc2(e) + '</li>').join('') + '</ul>' : '';
    banner(errs.length ? 'warn' : 'ok', '<b class="t">' + (errs.length ? '⚠ ' : '✅ ') + title + '</b> <span class="kcard-muted">' + (when ? 'в ' + hm(when) : '') + '</span><br>' + parts.join(' · ') + nothing + ehtml);
  }
  function render(d) {
    const s = d.settings || {}, st = d.state || {};
    $('wbtEnabled').checked = s.wb_tracking_enabled !== false;
    $('wbtHours').value = String(s.wb_tracking_hours || 6);
    $('wbtMargin').value = s.wb_min_margin_pct || 15;
    $('wbtLast').innerText = st.last_run ? 'Последняя проверка: ' + st.last_run.slice(0, 16) : 'Ещё не проверялось';
    if (!window.__wbtRunning && st.last_report && $('wbtBanner').style.display === 'none') reportBanner(st.last_report, st.last_run);
    const items = Object.values(st.items || {});
    if (!items.length) { $('wbtTable').innerHTML = '<div class="cards-empty">Пока нет товаров в продаже из WB, либо проверка ещё не запускалась. Когда в Kaspi появятся товары, созданные из WB, они появятся здесь.</div>'; return; }
    const minM = +$('wbtMargin').value || 15;
    $('wbtTable').innerHTML = '<table class="wbt-table"><thead><tr><th>Товар</th><th>Цена на WB</th><th>Остаток на WB</th><th>Доставка WB</th><th>Цена в Kaspi</th><th>Маржа</th><th>Статус</th></tr></thead><tbody>' +
      items.map(r => {
        const ch = (r.wb_prev && r.wb_price && r.wb_prev !== r.wb_price) ? (r.wb_price > r.wb_prev ? ' <span style="color:#B91C1C">▲ было ' + fmt(r.wb_prev) + '</span>' : ' <span style="color:#15803D">▼ было ' + fmt(r.wb_prev) + '</span>') : '';
        const m = r.margin_pct == null ? '—' : '<b style="color:' + (r.margin_pct < minM ? '#B91C1C' : '#15803D') + '">' + r.margin_pct.toFixed(0) + '%</b>';
        const s2 = status(r);
        return '<tr><td>' + esc2((r.title || r.sku).slice(0, 70)) + '<div class="wbt-sub">' + esc2(r.sku) + (r.checked_at ? ' · проверен ' + hm(r.checked_at) : '') + '</div></td>' +
          '<td class="num">' + (r.wb_price ? fmt(r.wb_price) + ' ₸' + ch : '<b style="color:#B91C1C">нет в наличии</b>') + '</td>' +
          '<td class="num">' + fmt(r.qty) + ' шт.</td><td class="num">' + (r.delivery_h ? esc2(r.delivery_h.join('–')) + ' ч' : '—') + '</td>' +
          '<td class="num"><b>' + fmt(r.kaspi_price) + ' ₸</b></td><td class="num">' + m + '</td>' +
          '<td><div class="wbt-st"><span class="ic ' + s2.cls + '">' + s2.ic + '</span><div><b>' + esc2(s2.t) + '</b>' + (s2.d ? '<small>' + esc2(s2.d) + '</small>' : '') + '</div></div></td></tr>';
      }).join('') + '</tbody></table>';
  }
  async function load() { try { render(await (await fetch('/api/wbtrack')).json()); } catch (e) { } }
  async function save() {
    const r = await fetch('/api/wbtrack', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ wb_tracking_enabled: $('wbtEnabled').checked, wb_tracking_hours: Number($('wbtHours').value), wb_min_margin_pct: Number($('wbtMargin').value) || 15 }) });
    render(await r.json()); showToast('✓ Настройки слежения сохранены');
  }
  document.addEventListener('change', e => { if (['wbtEnabled', 'wbtHours', 'wbtMargin'].includes(e.target.id)) save(); });
  document.addEventListener('click', async e => {
    if (!(e.target.closest && e.target.closest('#btnWbtRun'))) return;
    const b = $('btnWbtRun'); b.disabled = true; b.innerText = 'Проверяю…'; window.__wbtRunning = true;
    banner('run', '<span class="sp"></span><b class="t">Идёт проверка WB…</b><br>Займёт до 1–2 минут (может открыться окно браузера WB). Не закрывайте программу.');
    try {
      const d = await (await fetch('/api/wbtrack/run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json();
      if (!d.success) banner('bad', '<b class="t">❌ Проверка не удалась</b><br>' + esc2(d.error || 'Неизвестная ошибка') + '<br><span class="kcard-muted">Проверьте интернет и повторите. Если повторяется, пришлите скриншот автору.</span>');
      else reportBanner(d.report, (d.state || {}).last_run);
      if (d.state) render({ settings: { wb_tracking_enabled: $('wbtEnabled').checked, wb_tracking_hours: $('wbtHours').value, wb_min_margin_pct: $('wbtMargin').value }, state: d.state });
      if (window.loadCards) window.loadCards();
    } catch (err) {
      banner('bad', '<b class="t">❌ Нет связи с программой</b><br>Проверка не завершена. Попробуйте ещё раз.');
    } finally { window.__wbtRunning = false; b.disabled = false; b.innerText = 'Проверить WB сейчас'; }
  });
  const orig = window.loadCards;
  window.loadCards = async function () { if (orig) await orig(); load(); };
})();


// ---------- Печать накладных ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('waybillBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  // Статусы как в приложении Kaspi Pay: Предзаказ, Упаковка, Передача, Переданы на доставку.
  const GROUPS = [
    { id: 'pre', name: 'Предзаказ', hint: 'Ждут товара, ещё не упаковываются', test: o => o.state === 'KASPI_DELIVERY' && o.preorder && !o.assembled && !o.transmitted },
    { id: 'pack', name: 'Упаковка', hint: 'Нужно собрать и упаковать', test: o => o.state === 'KASPI_DELIVERY' && !o.preorder && !o.assembled && !o.transmitted },
    { id: 'hand', name: 'Передача', hint: 'Собраны, ждут передачи курьеру', test: o => o.state === 'KASPI_DELIVERY' && o.assembled && !o.transmitted },
    { id: 'sent', name: 'Переданы на доставку', hint: 'Уже у курьера', test: o => o.transmitted || o.state === 'DELIVERY' || o.state === 'PICKUP' },
  ];
  let allOrders = [];
  const chev = '<svg width="10" height="16" viewBox="0 0 10 16" fill="none" stroke="#8387b5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 2l6 6-6 6"/></svg>';
  // Внутри статуса: день передачи, затем товар (одинаковые подряд), затем номер. Порядок в PDF = порядок на экране.
  const dayOf = o => o.handover_ms ? new Date(o.handover_ms).setHours(0, 0, 0, 0) : 9e15;
  const prodOf = o => ((o.items[0] && (o.items[0].sku || o.items[0].name)) || '').toString();
  const sortOrders = l => l.sort((a, b) => (dayOf(a) - dayOf(b)) || prodOf(a).localeCompare(prodOf(b), 'ru') || String(a.code).localeCompare(String(b.code)));
  function showMenu() {
    $('wbTools').style.display = 'none';
    $('wbList').innerHTML = `<div style="background:var(--surface,#fff);border:1px solid #e6e7f4;border-radius:16px;padding:6px 18px;max-width:560px">` +
      GROUPS.map(g => { const n = allOrders.filter(g.test).length;
        return `<div class="wbGroup" data-g="${g.id}" style="display:flex;align-items:center;justify-content:space-between;padding:16px 0;border-bottom:1px solid #eef;cursor:pointer"><span style="font-size:16px;font-weight:600">${g.name}<div class="help-text" style="font-weight:400">${g.hint}</div></span><span style="display:flex;gap:14px;align-items:center"><b style="font-size:18px">${n}</b>${chev}</span></div>`; }).join('') + '</div>';
    document.querySelectorAll('.wbGroup').forEach(el => el.onclick = () => showGroup(el.dataset.g));
  }
  function showGroup(id) {
    const g = GROUPS.find(x => x.id === id);
    const list = sortOrders(allOrders.filter(g.test));
    $('wbTools').style.display = list.length ? 'flex' : 'none';
    let html = `<div style="display:flex;align-items:center;gap:10px;margin:4px 0 10px"><button type="button" class="btn btn-secondary btn-sm" id="wbBack">← Назад</button><b style="font-size:19px">${g.name}</b><span class="help-text">${list.length}</span></div>`;
    let last = null;
    for (const o of list) {
      const day = o.handover_ms ? 'передать до ' + new Date(o.handover_ms).toLocaleDateString('ru-RU', { weekday: 'short', day: '2-digit', month: '2-digit' }) : 'дата не указана';
      if (day !== last) { html += `<div style="font-weight:800;margin:12px 0 6px">${esc(day)}</div>`; last = day; }
      html += `<label style="display:block;border:1px solid #ddd;border-radius:8px;padding:6px 8px;margin-bottom:5px;cursor:pointer">
      <input type="checkbox" class="wbChk" value="${esc(o.code)}" ${id === 'hand' || id === 'pack' ? 'checked' : ''}>
      <b>${esc(o.code)}</b>${o.city ? ' · ' + esc(o.city) : ''}<br>
      ${o.items.map(i => (i.img ? `<img src="${esc(i.img)}" style="width:56px;height:56px;object-fit:cover;border-radius:6px;vertical-align:middle;margin-right:8px">` : '') + esc(i.sku) + ' × ' + esc(i.qty) + ' — ' + esc(i.name)).join('<br>')}<br>
      <span class="help-text">Передать курьеру до: ${esc(o.handover || '—')} · сумма ${esc(o.total)} ₸</span></label>`;
    }
    if (!list.length) html += '<div class="help-text">В этом статусе заказов нет.</div>';
    $('wbList').innerHTML = html;
    $('wbBack').onclick = showMenu;
    const cnt = () => { $('wbCount').textContent = 'отмечено: ' + document.querySelectorAll('.wbChk:checked').length + ' из ' + list.length; };
    $('wbAll').onclick = () => { document.querySelectorAll('.wbChk').forEach(x => x.checked = true); cnt(); };
    $('wbNone').onclick = () => { document.querySelectorAll('.wbChk').forEach(x => x.checked = false); cnt(); };
    $('wbList').onchange = cnt; cnt();
  }
  async function load() {
    $('wbList').innerHTML = SK(3);
    const d = await (await fetch('/api/orders/active')).json();
    if (!d.success) { $('wbList').textContent = d.error; return; }
    allOrders = d.orders;
    showMenu();
  }
  $('wbLoad').onclick = load;
  $('wbMake').onclick = async () => {
    const codes = [...document.querySelectorAll('.wbChk:checked')].map(x => x.value);
    if (!codes.length) { alert('Отметьте заказы'); return; }
    $('wbMake').disabled = true;
    try {
      const r = await fetch('/api/waybills/make', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ codes, layout: $('wbLayout').value, scale: 1 }) });
      const d = await r.json();
      if (d.success) window.open('/api/waybills/file/' + encodeURIComponent(d.file), '_blank'); else alert(d.error);
    } finally { $('wbMake').disabled = false; }
  };
})();


// ---------- Экран заказов ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('ordersBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  $('ordLoad').onclick = async () => {
    $('ordList').innerHTML = SK(4);
    const d = await (await fetch('/api/orders/active')).json();
    if (!d.success) { $('ordList').textContent = d.error; return; }
    $('ordList').innerHTML = d.orders.map(o => `<div style="border:1px solid #ddd;border-radius:8px;padding:8px;margin-bottom:6px;${o.assembled ? 'opacity:.7' : ''}">
      <b>${esc(o.code)}</b> · ${o.assembled ? '✅ собран' : '📦 собрать'} · ${esc(o.status)}${o.preorder ? ' · предзаказ' : ''}${o.city ? ' · ' + esc(o.city) : ''}<br>
      ${o.items.map(i => (i.img ? `<img src="${esc(i.img)}" style="width:56px;height:56px;object-fit:cover;border-radius:6px;vertical-align:middle;margin-right:8px">` : '') + esc(i.sku) + ' × ' + esc(i.qty) + ' — ' + esc(i.name)).join('<br>')}<br>
      <span class="help-text">Передать курьеру до: ${esc(o.handover || '—')} · сумма ${esc(o.total)} ₸</span>
      ${o.contact ? `<br><span class="help-text">Покупатель: ${esc(o.contact.name)}, ${esc(o.contact.phone)}</span>` : ''}</div>`).join('') || 'Активных заказов нет';
  };
})();


window.loadOrdersTab = function () { document.getElementById('ordLoad')?.click(); document.getElementById('wbLoad')?.click(); };

// ---------- Предзаказ карточек ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('preorderBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  async function load() {
    $('poList').innerHTML = SK(4);
    const d = await (await fetch('/api/preorder/cards')).json();
    if (!d.success) { $('poList').textContent = d.error; return; }
    $('poList').innerHTML = d.cards.map(c => {
      const diff = c.days && c.wb_days && Number(c.days) !== Number(c.wb_days);
      return `<label class="po-row ${diff ? 'diff' : ''}">
        <input type="checkbox" class="poChk" value="${esc(c.sku)}" data-wb="${esc(c.wb_days || '')}">
        ${c.img ? `<img class="po-img" src="${esc(c.img)}" alt="">` : '<div class="po-img"></div>'}
        <div class="po-main"><div class="po-title">${esc(c.title)}</div><div class="po-sku">${esc(c.sku)}${c.wb_delivery_h ? ' · доставка WB ' + esc(c.wb_delivery_h.join('–')) + ' ч' : ''}</div></div>
        <div class="po-stat"><span class="po-k">Сейчас</span><b>${esc(c.days || '—')} дн</b></div>
        <div class="po-stat ${diff ? 'warn' : ''}"><span class="po-k">По WB</span><b>${esc(c.wb_days || '—')} дн</b></div>
        <div class="po-stat"><span class="po-k">Цена</span><b>${esc(c.price)} ₸</b></div></label>`;
    }).join('') || '<div class="cards-empty">Пока нет карточек в продаже</div>';
    count();
  }
  function count() { const n = document.querySelectorAll('.poChk:checked').length, all = document.querySelectorAll('.poChk').length; $('poCount').textContent = all ? 'отмечено ' + n + ' из ' + all : ''; }
  document.addEventListener('change', e => { if (e.target.classList && e.target.classList.contains('poChk')) count(); });
  window.loadPreorderTab = load;
  $('poLoad').onclick = load;
  $('poSelAll').onclick = () => { const cs = [...document.querySelectorAll('.poChk')]; const all = cs.every(c => c.checked); cs.forEach(c => c.checked = !all); count(); };
  $('poSelDiff').onclick = () => { document.querySelectorAll('.po-row').forEach(r => { const c = r.querySelector('.poChk'); c.checked = r.classList.contains('diff'); }); count(); };
  $('poApply').onclick = async () => {
    const boxes = [...document.querySelectorAll('.poChk:checked')];
    if (!boxes.length) { alert('Отметьте карточки'); return; }
    const fixed = +$('poDays').value || 0;
    if (!confirm('Отправить срок предзаказа в живой Kaspi для ' + boxes.length + ' карточек' + (fixed ? ' (' + fixed + ' дн)' : ' (по доставке WB)') + '?')) return;
    let ok = 0; const bad = [];
    for (const b of boxes) {
      const days = fixed || +b.dataset.wb;
      if (!days) { bad.push(b.value + ': нет срока WB'); continue; }
      try {
        const r = await (await fetch('/api/cabinet/offer', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sku: b.value, mode: 'preorder', preorder_days: days }) })).json();
        if (r.success === false) bad.push(b.value + ': ' + r.error); else ok++;
      } catch (e) { bad.push(b.value + ': ' + e); }
    }
    const rb = $('poResult'); rb.style.display = ''; rb.className = 'wbt-banner ' + (bad.length ? 'warn' : 'ok');
    rb.innerHTML = '<b class="t">' + (bad.length ? '⚠ Срок отправлен не для всех карточек' : '✅ Срок предзаказа отправлен в Kaspi') + '</b><br>Успешно: <b>' + ok + '</b>' + (bad.length ? ', с ошибкой: <b>' + bad.length + '</b><ul style="margin:4px 0 0 18px">' + bad.slice(0, 8).map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' : '') + '<br><span class="kcard-muted">Kaspi применит изменения в течение часа. Нажмите «Обновить список» позже, чтобы увидеть новые сроки.</span>';
    load();
  };
})();


// ---------- Выходные дни ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('daysBox')) return;
  async function load() {
    const d = await (await fetch('/api/days/list')).json();
    $('dayList').innerHTML = d.success ? ('Ближайшие выходные: ' + (d.days.filter(x => x.closed).map(x => x.date.split('-').reverse().join('.')).join(', ') || 'нет')) : d.error;
  }
  async function check(from, to, mode) {
    const q = from ? '?from=' + from + '&to=' + (to || from) : '';
    const d = await (await fetch('/api/days/check' + q)).json();
    const el = $('dayStatus');
    if (!d.success) { el.style.color = '#c0392b'; el.textContent = '⚠️ Не удалось проверить: ' + d.error; return d; }
    const fmt = x => x.split('-').reverse().join('.');
    if (mode === 'open') {   // проверка, что выходные УБРАНЫ: закрытых дней в диапазоне быть не должно
      const miss = new Set(d.missing || []), still = [];
      for (let t = new Date(d.from + 'T00:00:00'); t <= new Date(d.to + 'T00:00:00'); t.setDate(t.getDate() + 1)) {
        const iso = t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
        if (!miss.has(iso)) still.push(iso);
      }
      if (!still.length) { el.style.color = '#1e8449'; el.textContent = '✅ Выходные убраны: на даты ' + fmt(d.from) + ' – ' + fmt(d.to) + ' нет закрытых дней.'; }
      else { el.style.color = '#c0392b'; el.textContent = '❌ Ещё закрыты: ' + still.slice(0, 12).map(fmt).join(', ') + (still.length > 12 ? '…' : '') + '. Нажмите «Убрать выходные» ещё раз.'; }
      return d;
    }
    if (d.ok) { el.style.color = '#1e8449'; el.textContent = '✅ Выходные проставлены: ' + d.closed + ' из ' + d.total + ' дней (' + fmt(d.from) + ' – ' + fmt(d.to) + '). Можно нажимать «Прибыл».'; }
    else { el.style.color = '#c0392b'; el.textContent = '❌ НЕ все дни закрыты: ' + d.closed + ' из ' + d.total + '. Не закрыты: ' + d.missing.slice(0, 12).map(fmt).join(', ') + (d.missing.length > 12 ? '…' : '') + '. «Прибыл» не нажимайте.'; }
    return d;
  }
  async function go(action) {
    const from = $('dayFrom').value, to = $('dayTo').value || from;
    if (!from) { alert('Выберите дату'); return; }
    if (!confirm((action === 'open' ? 'Убрать выходные' : 'Поставить выходные') + ' с ' + from + ' по ' + to + ' в живом Kaspi?')) return;
    const r = await (await fetch('/api/days/set', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ from, to, action }) })).json();
    if (!r.success) { alert(r.error); return; }
    await load();
    await check(from, to, action === 'open' ? 'open' : undefined);
  }
  $('dayCheck').onclick = () => { const f = $('dayFrom').value; check(f || '', $('dayTo').value || f); };
  $('dayCheckOpen').onclick = () => { const f = $('dayFrom').value; check(f || '', $('dayTo').value || f, 'open'); };
  $('dayClose').onclick = () => go('close');
  $('dayOpen').onclick = () => go('open');
  const prev = window.loadOrdersTab;
  window.loadOrdersTab = function () { if (prev) prev(); load(); };
})();


// ---------- Gmail: код входа Kaspi ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('mailBox')) return;
  fetch('/api/mail/status').then(r => r.json()).then(d => {
    if (d.address) $('mailAddr').value = d.address;
    if (d.server) $('mailServer').value = d.server;
    if (d.has_password) $('mailMsg').textContent = 'Пароль приложения сохранён.';
  }).catch(() => {});
  $('mailSave').onclick = async () => {
    let ok = false;
    try {
      const r = await fetch('/api/mail/save', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address: $('mailAddr').value.trim(), server: $('mailServer').value.trim(), password: $('mailPass').value }) });
      ok = r.ok && (await r.json()).success === true;
      // убеждаемся, что программа действительно запомнила пароль
      if (ok) { const s = await (await fetch('/api/mail/status')).json(); ok = !!(s.address && s.has_password); }
    } catch (e) { ok = false; }
    if (ok) { $('mailPass').value = ''; $('mailMsg').textContent = '✅ Сохранено. Нажмите «Проверить».'; }
    else { $('mailMsg').textContent = '❌ Не сохранилось: проверьте, что введены адрес и пароль приложения. Если так и остаётся, закройте программу и запустите заново (возможно, после обновления работает старая версия).'; }
  };
  $('mailTest').onclick = async () => {
    $('mailMsg').textContent = 'Проверяю…';
    const d = await (await fetch('/api/mail/test', { method: 'POST' })).json();
    $('mailMsg').textContent = d.success ? ('✅ Почта подключена. Писем от Kaspi за 7 дней: ' + d.kaspi_mails_7d + (d.code_found_in_latest ? ', код в последнем найден.' : ', кода в последнем не нашлось.')) : ('❌ ' + d.error);
  };
})();


// ---------- Первый запуск ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('setupBox')) return;
  const rows = [
    ['merchant', '1. Merchant ID магазина', 'Настройки → «Kaspi Merchant ID» (виден в кабинете Kaspi).'],
    ['token', '2. Токен Kaspi API', 'Кабинет Kaspi → Настройки → «Токен API». Вводится в Настройках.'],
    ['mail', '3. Почта для кода входа (сделайте ДО шага 4)', 'Создайте в кабинете Kaspi сотрудника (Пользователи → Добавить, право «Загрузка товаров»). На его почте включите «пароль приложения» и впишите в Настройки → «Код входа Kaspi из почты».'],
    ['cabinet', '4. Вход сотрудника в кабинет', 'Настройки → «Подключение к кабинету Kaspi»: логин и пароль сотрудника. Код из письма программа введёт сама (если настроена почта).'],
    ['store', '5. Склад, город и регион WB', 'Нажмите кнопку ниже, затем выберите свой город.'],
    ['price', '6. Прайс-лист магазина (рекомендуется)', 'Kaspi API отдаёт только товары с недавними заказами. В кабинете Kaspi: Товары → Экспорт прайс-листа, затем в программе: Дополнительно → Мой магазин Kaspi → «Загрузить прайс-лист Kaspi».'],
    ['alibaba', '7. Вход в 1688 (для поиска товаров и по фото)', '1688 показывает товары, категории и фотопоиск только вошедшим. Войдите один раз по QR-коду приложения 1688 — дальше браузер запомнит вход.']
  ];
  async function load() {
    if (!$('setupSteps').children.length) $('setupSteps').innerHTML = '<div class="wz-step"><div class="wz-num">…</div><div class="wz-body"><div class="wz-title">Проверяю подключение магазина</div><div class="wz-help">Это занимает несколько секунд.</div></div></div>';
    const d = await (await fetch('/api/setup/status')).json();
    if (!d.success) { $('setupSteps').textContent = d.error; return; }
    const doneN = rows.filter(r => d.steps[r[0]]).length;
    const goTab = { merchant: 'tab-settings', token: 'tab-settings', mail: 'tab-settings', cabinet: 'tab-settings', price: 'tab-my-store' };
    $('setupSteps').innerHTML = `<div class="wz-progress"><div class="wz-bar"><i style="width:${Math.round(doneN / rows.length * 100)}%"></i></div><span>Готово ${doneN} из ${rows.length}</span></div>` +
      rows.map(([k, t, h], i) => `<div class="wz-step ${d.steps[k] ? 'ok' : ''}">
        <div class="wz-num">${d.steps[k] ? '✓' : i + 1}</div>
        <div class="wz-body"><div class="wz-title">${t.replace(/^\d+\.\s*/, '')}</div><div class="wz-help">${h}</div>
          ${!d.steps[k] && goTab[k] ? `<button type="button" class="btn btn-secondary wz-go" data-go="${goTab[k]}">${k === 'price' ? 'Открыть «Мой магазин»' : 'Открыть Настройки'}</button>` : ''}</div>
        <div class="wz-chip">${d.steps[k] ? 'Готово' : 'Нужно сделать'}</div></div>`).join('') +
      (d.store_id ? `<div class="help-text">Склад: <b>${d.store_id}</b> · город: <b>${d.city || '—'}</b> · регион WB: <b>${d.wb_dest || '—'}</b></div>` : '') +
      (d.done ? '<div style="margin-top:8px;font-weight:600;color:#1e8449">✅ Магазин подключён. Можно работать.</div>' : '') +
      `<div style="margin-top:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <button type="button" class="btn btn-secondary" id="aliOpen">Открыть окно входа 1688</button>
        <button type="button" class="btn btn-secondary" id="aliCheck">Проверить вход в 1688</button>
        <span id="aliMsg" class="help-text"></span>
      </div>`;
    const aliOpen = document.getElementById('aliOpen'), aliCheck = document.getElementById('aliCheck'), aliMsg = document.getElementById('aliMsg');
    if (aliOpen) aliOpen.onclick = async () => {
      aliMsg.textContent = 'Открываю окно 1688…';
      const r = await (await fetch('/api/suppliers/1688_open_login', { method: 'POST' })).json();
      aliMsg.textContent = r.success ? (r.message || 'Войдите в открывшемся окне.') : ('❌ ' + (r.error || 'Не удалось открыть окно.'));
    };
    if (aliCheck) aliCheck.onclick = async () => {
      aliMsg.textContent = 'Проверяю…';
      const r = await (await fetch('/api/suppliers/1688_login_status')).json();
      aliMsg.textContent = r.logged_in ? '✅ Вход в 1688 выполнен.' : ('❌ ' + (r.message || 'Вход не выполнен.'));
      load();
    };
  }
  async function cities() {
    const d = await (await fetch('/api/setup/status')).json();
    if (!d.success) return;
    $('setupCity').innerHTML = '<option value="">— выберите город —</option>' + d.cities.map(c => `<option ${c === d.wb_city ? 'selected' : ''}>${c}</option>`).join('');
  }
  window.loadSetupTab = () => { load(); cities(); };
  $('setupCitySave').onclick = async () => {
    const city = $('setupCity').value; if (!city) { alert('Выберите город'); return; }
    $('setupMsg').textContent = 'Применяю…';
    const d = await (await fetch('/api/setup/city', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ city }) })).json();
    $('setupMsg').textContent = d.success ? ('✅ Город ' + d.city + ', регион WB ' + d.wb_dest) : ('❌ ' + d.error);
    load();
  };
  $('setupRefresh').onclick = load;
  $('setupDetect').onclick = async () => {
    $('setupMsg').textContent = 'Определяю…';
    const d = await (await fetch('/api/setup/detect', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json();
    $('setupMsg').textContent = d.success ? ('✅ Склад ' + d.store_id + ', город ' + d.city + ', регион WB ' + (d.wb_dest || 'не определён — укажите вручную в Настройках')) : ('❌ ' + d.error);
    load();
  };
})();


// ---------- Обновления ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('updateBox')) return;
  const post = u => fetch(u, { method: 'POST' }).then(r => r.json());
  async function check() {
    $('updMsg').textContent = 'Проверяю…'; $('updApply').style.display = 'none';
    const d = await post('/api/update/check');
    if (!d.success) { $('updMsg').textContent = '❌ ' + d.error; return; }
    $('updVersion').textContent = 'Версия: ' + d.current;
    if (d.error) $('updMsg').textContent = '⚠️ ' + d.error;
    else if (d.available) { $('updMsg').textContent = '🆕 Доступна версия ' + d.latest + (d.notes ? ': ' + d.notes : ''); $('updApply').style.display = ''; }
    else $('updMsg').textContent = '✅ Установлена последняя версия.';
  }
  $('updCheck').onclick = check;
  $('updApply').onclick = async () => {
    if (!confirm('Установить обновление? Ваши данные и настройки не изменятся. После установки перезапустите программу.')) return;
    $('updMsg').textContent = 'Устанавливаю…';
    const d = await post('/api/update/apply');
    $('updMsg').textContent = d.success && d.ok ? ('✅ ' + d.note) : ('❌ ' + (d.error || 'не удалось'));
    $('updApply').style.display = 'none';
  };
  fetch('/api/update/check', { method: 'POST' }).then(r => r.json()).then(d => { if (d.success) $('updVersion').textContent = 'Версия: ' + d.current; });
})();


// ---------- Самопроверка ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('selfcheckBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  function show(d) {
    if (!d) { $('scList').textContent = 'Ещё не проверялось.'; return; }
    $('scList').innerHTML = `<div class="help-text" style="margin-bottom:6px">Проверено: ${esc(d.at)} — ${d.ok ? '✅ всё работает' : '❌ есть проблемы: ' + d.failed.length}</div>` +
      d.results.map(r => `<div style="padding:4px 0;border-bottom:1px solid #eee">${r.ok ? '✅' : '❌'} <b>${esc(r.name)}</b> <span class="help-text">— ${esc(r.detail)}</span>${r.ok ? '' : `<br><span style="color:#c0392b">Что делать: ${esc(r.hint)}</span>`}</div>`).join('');
  }
  fetch('/api/selfcheck/last').then(r => r.json()).then(d => show(d.success ? d.last : null)).catch(() => {});
  $('scRun').onclick = async () => {
    $('scRun').disabled = true; $('scList').textContent = 'Проверяю… (до минуты)';
    try { const d = await (await fetch('/api/selfcheck/run', { method: 'POST' })).json(); show(d.success ? d : null); if (!d.success) $('scList').textContent = d.error; }
    finally { $('scRun').disabled = false; }
  };
})();

// ---------- Выставление на готовую карточку ----------
(function () {
  const $ = id => document.getElementById(id);
  if (!$('linkBox')) return;
  const esc = t => String(t == null ? '' : t).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  let card = null;
  const post = (u, b) => fetch(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(r => r.json());
  $('lnkFind').onclick = async () => {
    $('lnkForm').style.display = 'none'; card = null;
    $('lnkInfo').textContent = 'Ищу…';
    const d = await post('/api/link/preview', { code: $('lnkCode').value });
    if (!d.success) { $('lnkInfo').style.color = ''; $('lnkInfo').innerHTML = '<div class="wbt-banner bad"><b class="t">Карточка не найдена</b><br>' + esc(d.error) + '</div>'; return; }
    card = d.card; $('lnkInfo').style.color = '';
    $('lnkInfo').innerHTML = (card.img ? `<img src="${esc(card.img)}" style="width:64px;height:64px;object-fit:cover;border-radius:6px;vertical-align:middle;margin-right:8px">` : '') + `<b>${esc(card.title)}</b> · ${esc(card.category || '')} · код ${esc(card.code)}`;
    $('lnkForm').style.display = 'flex';
  };
  $('lnkGo').onclick = async () => {
    if (!card) return;
    const price = +$('lnkPrice').value || 0;
    if (!confirm('Присоединить ваш магазин к карточке «' + card.title + '» в живом Kaspi' + (price ? ' и выставить по цене ' + price + ' ₸' : '') + '?')) return;
    $('lnkInfo').textContent = 'Отправляю…';
    const d = await post('/api/link/apply', { code: card.code, price: price || null, days: $('lnkDays').value, confirm: true });
    if (!d.success) { $('lnkInfo').style.color = ''; $('lnkInfo').innerHTML = '<div class="wbt-banner bad"><b class="t">❌ Не получилось присоединить</b><br>' + esc(d.error) + '</div>'; return; }
    $('lnkInfo').style.color = '';
    $('lnkInfo').textContent = '✅ Присоединено. Артикул: ' + d.sku + (d.offer_set ? '. Цена и наличие выставлены.' : (d.offer_error ? '. Цену поставьте вручную: ' + d.offer_error : '. Цену и наличие укажите в кабинете.'));
    $('lnkForm').style.display = 'none';
    $('lnkInfo').innerHTML = '<div class="wbt-banner ok">' + $('lnkInfo').innerHTML + '</div>';
  };
  $('lnkCode').addEventListener('keydown', e => { if (e.key === 'Enter') $('lnkFind').click(); });
})();
// ---------- Всплывающие подсказки при наведении ----------
(function () {
  const tips = {
    supplierSource: '1688 - поставщики из Китая, цены в юанях. Ozon - каталог Казахстана, цены в тенге. Доставку и цену каждого варианта проверяйте отдельно.',
    supplierQuery: 'Введите название. Для 1688 точнее запрос на китайском; простые русские слова программа заменяет близкой категорией и показывает, какой запрос использован.',
    supplierSearchButton: 'Открывает сайт поставщика и читает до 20 товаров с одной страницы. Поиск ничего не меняет в Kaspi.',
    supplierUrl: 'Скопируйте полную ссылку из адресной строки карточки 1688 или Ozon. Ссылки на поиск и магазин сюда не подходят.',
    supplierLoadButton: 'Загружает фото и все варианты, которые сайт отдал в этой карточке. Если сайт просит вход или проверку, пройдите её сами в открытом браузере.',
    supplierPhoto: 'Фото товара для поиска поставщиков 1688. Подходят JPG, PNG и WebP до 8 МБ. Изображение будет передано на сайт 1688.',
    supplierPhotoButton: 'Передаёт выбранное фото в поиск 1688. Сайт может запросить вход или не показать совпадений; тогда попробуйте другое фото.',
    supplierVariant: 'Выберите цвет, размер или комплектацию. У каждого варианта могут отличаться цена, фото, вес и минимальная партия.',
    supplierReloadVariant: 'Повторно загружает страницу выбранного варианта. Это особенно важно для Ozon: варианты там имеют отдельные ссылки.',
    supplierPrice: 'Цена закупки ОДНОЙ продаваемой единицы. У поставщика цена может быть за упаковку или зависеть от размера партии - сначала уточните это.',
    supplierRate: 'Ваш реальный курс покупки юаня: сколько тенге вы отдаёте за 1 юань. Автоматический курс банка здесь не подставляется.',
    supplierWeight: 'Вес одной единицы с упаковкой в килограммах. Например, 370 граммов = 0,37 кг. Неизвестный вес заполните вручную.',
    supplierLength: 'Длина УПАКОВКИ одной единицы в сантиметрах. Размер самого товара может быть меньше упаковки.',
    supplierWidth: 'Ширина УПАКОВКИ одной единицы в сантиметрах.',
    supplierHeight: 'Высота УПАКОВКИ одной единицы в сантиметрах. Она влияет на стоимость объёмного карго.',
    supplierPerKg: 'Тариф вашей доставки в тенге за 1 кг. Калькулятор сравнит плату по весу с платой по объёму и возьмёт большую.',
    supplierPerM3: 'Тариф вашей доставки в тенге за 1 кубический метр. Для лёгких объёмных товаров этот расчёт часто дороже весового.',
    supplierFreight: 'Полная стоимость доставки одной единицы с Ozon в тенге. Если доставка действительно бесплатна, введите 0.',
    supplierOther: 'Доставка по Китаю до карго, упаковка, доставка Kaspi, доплаты и минимальный платёж карго в расчёте на одну единицу.',
    supplierSale: 'Ваша предполагаемая цена продажи на Kaspi в тенге. Эта сумма используется только в расчёте и никуда не отправляется.',
    supplierFees: 'Общий процент удержаний: комиссия, налоги и другие процентные платежи. Возьмите значения для своего товара и условий работы.',
    supplierPreorder: 'От 1 до 30 календарных дней. В срок должны входить закупка, доставка от поставщика и передача заказа покупателю.',
    supplierMakeDrafts: 'Создаёт отдельный местный черновик для каждого цвета, размера и комплектации. Повтор не стирает ваши правки. Для отправки сначала заполните перевод, категорию, характеристики и цены.',
    supplierEstimateButton: 'Считает предварительную себестоимость, прибыль и цену без убытка для одной единицы. Не учитывает скидки за объём и минимальную партию поставщика.',
    btnSidebarActivate: 'Ввод лицензионного ключа. Без ключа работает пробный период 7 дней.',
    btnMakeCards: 'Создать черновики карточек из отмеченных товаров. В Kaspi ничего не уходит, пока вы не нажмёте «Отправить в Kaspi» в разделе «Карточки Kaspi».',
    btnImportMyProducts: 'Загрузить ваш прайс-лист Kaspi, чтобы программа знала ваши товары.',
    setupCitySave: 'Запомнить город: цены и наличие WB считаются для него.',
    setupRefresh: 'Заново проверить, что из первого запуска уже настроено.',
    setupDetect: 'Программа сама возьмёт склад и город из вашего кабинета Kaspi и определит регион доставки WB.',
    ordLoad: 'Показать активные заказы за 13 дней с фото и сроком передачи курьеру.',
    wbLoad: 'Показать заказы Kaspi Доставки, для которых можно скачать накладную.',
    wbMake: 'Собрать PDF с накладными отмеченных заказов в выбранном формате.',
    dayClose: 'Закрыть магазин на выбранные даты (не дальше 60 дней вперёд). Уходит в живой Kaspi.',
    dayOpen: 'Убрать выходные на выбранные даты и вернуть обычное расписание.',
    dayCheckOpen: 'Перечитать расписание у Kaspi и показать, реально ли убрались выходные на выбранные даты (без дат проверит все ближайшие 60 дней).',
    dayCheck: 'Перечитать расписание у Kaspi и показать, все ли выходные реально проставились. Делайте это перед «Прибыл».',
    poLoad: 'Обновить список ваших карточек с текущим сроком предзаказа и сроком по доставке WB.',
    poApply: 'Отправить срок предзаказа в живой Kaspi для отмеченных карточек. Kaspi применяет до часа.',
    lnkFind: 'Найти карточку Kaspi по ссылке или коду и показать её, ничего не меняя.',
    lnkGo: 'Присоединить ваш магазин к найденной карточке и выставить товар. Уходит в живой Kaspi.',
    btnCardsStatus: 'Проверить, прошли ли карточки модерацию, и выставить прошедшие в продажу.',
    btnCardsSend: 'Отправить отмеченные карточки в ЖИВОЙ Kaspi на модерацию. После одобрения программа выставит их в продажу с указанными ценами и сроком предзаказа.',
    btnWbtRun: 'Прямо сейчас проверить цены и наличие на WB и обновить Kaspi.',
    btnTestApi: 'Проверить, что ключ ИИ-сервиса для фото принят.',
    scRun: 'Проверить токен, вход, склады, заказы, WB, почту и лицензию. Ничего не меняет.',
    updCheck: 'Проверить, вышла ли новая версия программы.',
    updApply: 'Скачать и установить обновление. Ваши данные и настройки сохранятся.',
    mailSave: 'Сохранить адрес почты и пароль приложения для автоматического ввода кода Kaspi.',
    mailTest: 'Проверить подключение к почте и поиск писем Kaspi.',
    btnCabLogin: 'Войти в кабинет Kaspi под сотрудником. Kaspi пришлёт код на его почту.',
    btnCabCode: 'Ввести код из письма Kaspi.',
    btnCabLogout: 'Отключить программу от кабинета Kaspi.',
    btnSubmitActivation: 'Активировать лицензию введённым ключом.',
    btnCopyFeed: 'Скопировать адрес прайс-листа.',
    cfgRoyaltechKey: 'Ключ сервиса ИИ-фото. Хранится только на этом компьютере.'
  };
  const apply = () => { for (const id in tips) { const ids = id.startsWith('supplier') ? ['cn' + id.slice(8), 'oz' + id.slice(8)] : [id]; for (const target of ids) { const e = document.getElementById(target); if (e && !e.title) e.title = tips[id]; } } };
  apply(); setTimeout(apply, 1500);
})();
// ---------- Меню: «Дополнительно» и стартовая вкладка ----------
(function () {
  const tg = document.getElementById('navExtraToggle'), box = document.getElementById('navExtra'), ar = document.getElementById('navExtraArrow');
  if (!tg || !box) return;
  const set = open => { box.style.display = open ? 'block' : 'none'; ar.textContent = open ? '▾' : '▸'; try { localStorage.setItem('navExtraOpen', open ? '1' : '0'); } catch (e) {} };
  set((function () { try { return localStorage.getItem('navExtraOpen') === '1'; } catch (e) { return false; } })());
  tg.onclick = () => set(box.style.display === 'none');
  // новичку сразу показываем «Первый запуск», пока магазин не подключён
  fetch('/api/setup/status').then(r => r.json()).then(d => {
    if (d && d.success && !d.done) { const b = document.querySelector('.nav-item[data-tab="tab-setup"]'); if (b) b.click(); }
  }).catch(() => {});
})();
// переход по кнопкам «Открыть Настройки» в мастере первого запуска
document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('.wz-go'); if (!b) return;
  const t = document.querySelector('.nav-item[data-tab="' + b.dataset.go + '"]'); if (t) t.click();
});
// ---------- переключатель живого фона: авто / живой / статичный / выключен ----------
(function () {
  const foot = document.querySelector('.sidebar-footer'); if (!foot) return;
  const KEY = 'bgMode';
  const weak = (navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 8) <= 4;
  const get = () => { try { return localStorage.getItem(KEY) || 'auto'; } catch (e) { return 'auto'; } };
  const names = { auto: 'авто', on: 'живой', still: 'статичный', off: 'выключен' };
  const apply = m => {
    const eff = m === 'auto' ? (weak ? 'still' : 'on') : m;
    document.body.classList.toggle('no-bg-motion', eff === 'still');
    document.body.classList.toggle('no-bg-scene', eff === 'off');
    b.textContent = 'Фон: ' + names[m] + (m === 'auto' ? (weak ? ' (статичный)' : ' (живой)') : '');
  };
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'bg-toggle'; b.title = 'Живой фон можно отключить, если компьютер слабый';
  b.onclick = () => { const n = ({ auto: 'on', on: 'still', still: 'off', off: 'auto' })[get()] || 'auto'; try { localStorage.setItem(KEY, n); } catch (e) {} apply(n); };
  foot.appendChild(b); apply(get());
})();

// ---------- постраничный вывод длинных списков (слежение, карточки, предзаказ) ----------
(function () {
  function autoPager(id, itemsOf, size) {
    const box = document.getElementById(id); if (!box) return;
    let page = 1, lastCount = -1, busy = false;
    const pager = document.createElement('div'); pager.className = 'pager pager-mini'; pager.id = id + 'Pager';
    box.insertAdjacentElement('afterend', pager);
    function render() {
      if (busy) return; busy = true;
      const items = itemsOf(box);
      if (items.length !== lastCount) { page = 1; lastCount = items.length; }
      const pages = Math.max(1, Math.ceil(items.length / size));
      if (page > pages) page = pages;
      items.forEach((el, i) => { el.style.display = (i >= (page - 1) * size && i < page * size) ? '' : 'none'; });
      if (items.length <= size) { pager.innerHTML = ''; pager.style.display = 'none'; busy = false; return; }
      pager.style.display = '';
      const from = (page - 1) * size + 1, to = Math.min(items.length, page * size);
      pager.innerHTML = `<span class="pager-info">Показаны ${from}–${to} из ${items.length}</span><div class="pager-nav"><button type="button" class="pager-btn" data-d="-1" ${page <= 1 ? 'disabled' : ''}>‹ Назад</button><span class="pager-info">${page} / ${pages}</span><button type="button" class="pager-btn" data-d="1" ${page >= pages ? 'disabled' : ''}>Вперёд ›</button></div>`;
      busy = false;
    }
    pager.addEventListener('click', e => { const b = e.target.closest('.pager-btn'); if (!b || b.disabled) return; page += Number(b.dataset.d); render(); box.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
    new MutationObserver(render).observe(box, { childList: true });
    render();
  }
  autoPager('wbtTable', c => [...c.querySelectorAll('tbody tr')], 10);
  autoPager('cardsList', c => [...c.children].filter(e => !e.classList.contains('cards-empty')), 8);
  autoPager('poList', c => [...c.querySelectorAll('.po-row')], 10);
})();
