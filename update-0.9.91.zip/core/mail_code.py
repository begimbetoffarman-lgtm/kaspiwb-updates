"""Автоматическое чтение кода входа Kaspi из Gmail (IMAP, пароль приложения).
Читаются ТОЛЬКО письма, где отправитель содержит «kaspi». Код и пароль нигде не логируются."""
import email
import email.utils
import imaplib
import json
import os
import re
import socket
import ssl
import time
from email.header import decode_header, make_header

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _cfg():
    from core import secrets as _sec
    c = _sec.read_config()
    return (c.get("gmail_address") or "").strip(), (c.get("gmail_app_password") or "").replace(" ", "")


SERVERS = {"gmail.com": "imap.gmail.com", "googlemail.com": "imap.gmail.com",
           "mail.ru": "imap.mail.ru", "bk.ru": "imap.mail.ru", "inbox.ru": "imap.mail.ru", "list.ru": "imap.mail.ru",
           "yandex.ru": "imap.yandex.ru", "yandex.kz": "imap.yandex.ru", "ya.ru": "imap.yandex.ru",
           "outlook.com": "outlook.office365.com", "hotmail.com": "outlook.office365.com",
           "live.com": "outlook.office365.com", "icloud.com": "imap.mail.me.com", "yahoo.com": "imap.mail.yahoo.com"}


def _server(addr):
    """Свой сервер из настроек или по домену почты; иначе imap.<домен>."""
    from core import secrets as _sec
    custom = (_sec.read_config().get("mail_server") or "").strip()
    return custom or SERVERS.get(addr.split("@")[-1].lower(), "imap." + addr.split("@")[-1].lower())


def configured():
    a, p = _cfg()
    return bool(a and p)


_STYLE_RE = re.compile(r"<(style|script|head)\b[^>]*>.*?</\1\s*>", re.I | re.S)
_COLOR_RE = re.compile(r"#(?:[0-9a-f]{3,8})\b", re.I)
_TAG_RE = re.compile(r"<[^>]+>")


def _text(msg):
    parts = []
    for part in (msg.walk() if msg.is_multipart() else [msg]):
        if part.get_content_type() in ("text/plain", "text/html"):
            try:
                parts.append(part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", "ignore"))
            except Exception:
                pass
    raw = " ".join(parts)
    # В CSS письма есть цветовые коды вида #0438xx — они попадают в «числа» и уводят поиск кода.
    raw = _STYLE_RE.sub(" ", raw)
    raw = _COLOR_RE.sub(" ", raw)
    return _TAG_RE.sub(" ", raw)


def _code_from(msg):
    subj = str(make_header(decode_header(msg.get("Subject", ""))))
    body = _text(msg)
    for src in (subj, body):          # сначала число рядом со словом «код»/code
        for m in re.finditer(r"(?:код|code)\D{0,25}(?<!\d)(\d{4,6})(?!\d)", src, re.I):
            c = m.group(1)
            if len(set(c)) > 1:        # 0000, 1111 — почти всегда не код, а заглушка/номер
                return c
    for src in (subj, body):
        for m in re.finditer(r"(?<!\d)(\d{4,6})(?!\d)", src):
            c = m.group(1)
            if len(set(c)) > 1:
                return c
    return None


class _TemporaryIMAPError(RuntimeError):
    """Сбой соединения, после которого можно снова прочитать то же письмо."""


def _connection_error(error, addr, srv):
    if isinstance(error, socket.gaierror):
        temporary = error.errno == socket.EAI_AGAIN
    else:
        temporary = isinstance(error, (OSError, imaplib.IMAP4.abort)) and not isinstance(
            error, ssl.SSLCertVerificationError
        )
    error_type = _TemporaryIMAPError if temporary else RuntimeError
    return error_type(_explain(error, addr, srv))


def _connect(timeout=30):
    addr, pwd = _cfg()
    if not (addr and pwd):
        raise RuntimeError("Почта не настроена (адрес и пароль приложения).")
    if "@" not in addr or "." not in addr.split("@")[-1]:
        raise RuntimeError("Адрес почты введён неверно: нужен полный адрес с @, например ivan@gmail.com.")
    if "@gmail.com" in addr and len(pwd) != 16:
        raise RuntimeError("Пароль приложения Gmail состоит из 16 символов. Похоже, вставлен обычный пароль от аккаунта: "
                           "создайте пароль приложения (Настройки → Безопасность → Пароли приложений) и вставьте его.")
    srv = _server(addr)
    try:
        box = imaplib.IMAP4_SSL(srv, 993, timeout=timeout)
    except Exception as e:
        raise _connection_error(e, addr, srv) from None
    try:
        box.login(addr, pwd)
        box.select("INBOX", readonly=True)
    except Exception as e:
        try:
            box.logout()
        except Exception:
            pass
        raise _connection_error(e, addr, srv) from None
    return box


def _explain(e, addr, srv):
    """Понятная причина, почему не удалось войти в почту (без пароля в тексте)."""
    raw = (e.args[0].decode("utf-8", "ignore") if e.args and isinstance(e.args[0], bytes) else str(e)).strip()
    low = raw.lower()
    dom = addr.split("@")[-1].lower() if "@" in addr else ""
    if isinstance(e, socket.gaierror):
        return "Не найден почтовый сервер «%s». Проверьте адрес почты или впишите сервер IMAP вручную (например imap.gmail.com)." % srv
    if isinstance(e, (socket.timeout, TimeoutError, ConnectionError, OSError)) and not isinstance(e, imaplib.IMAP4.error):
        return "Не удалось соединиться с почтовым сервером %s. Проверьте интернет; если он есть, возможно, сервер заблокирован или IMAP отключён у почты." % srv
    if dom in ("outlook.com", "hotmail.com", "live.com", "outlook.kz", "msn.com") or "office365" in srv:
        return ("Outlook не пускает программу по паролю: Microsoft отключил такой вход. "
                "Настройте в Outlook пересылку писем Kaspi на Gmail, Mail.ru или Яндекс и подключите ту почту (инструкция в Настройках).")
    if "application-specific" in low or "app password" in low or "web login" in low:
        return "Нужен пароль приложения, а не обычный пароль от почты. Создайте его по инструкции в Настройках и вставьте вместо обычного."
    if "imap" in low and ("disabled" in low or "not enabled" in low or "отключ" in low):
        return "В почте выключен доступ по IMAP. Включите его в настройках почты («Почтовые программы») и повторите."
    if dom in ("gmail.com", "googlemail.com"):
        if "invalid credentials" in low or "authenticationfailed" in low or "username and password not accepted" in low or "login failed" in low:
            return ("Gmail не принял адрес или пароль. Вставьте именно пароль приложения из 16 символов, а не обычный пароль от аккаунта. "
                    "Если пароль приложения ещё не создан: Настройки → Безопасность → включите двухэтапную аутентификацию, "
                    "затем «Пароли приложений». У рабочего или учебного аккаунта Google этот раздел обычно закрыт — "
                    "заведите отдельный Gmail для программы.")
    if ("invalid credentials" in low or "authenticationfailed" in low or "login failed" in low
            or "authentication failed" in low or "invalid login" in low or "bad credentials" in low):
        return ("Почта не приняла адрес или пароль. Проверьте адрес и вставьте именно пароль приложения (не обычный пароль). "
                "Для Mail.ru и Яндекса ещё должен быть включён доступ по IMAP.")
    return "Не удалось войти в почту: %s" % (raw[:120] or type(e).__name__)


def _from_kaspi(msg):
    """Отправитель — Kaspi: по адресу домена или по имени, без привязки к слову в From."""
    try:
        raw = str(make_header(decode_header(msg.get("From", "")))).lower()
    except Exception:
        raw = str(msg.get("From", "")).lower()
    return "kaspi" in raw


def _collect(box, since_ts):
    """Все письма Kaspi новее since_ts. Ищем и по отправителю, и по теме: Kaspi шлёт коды
    с разных адресов и рассылочных сервисов, поэтому одного запроса FROM мало."""
    day = time.strftime("%d-%b-%Y", time.gmtime(since_ts - 2 * 86400))
    seen, order = set(), []
    for query in (("SINCE", day, "FROM", "kaspi"), ("SINCE", day, "TEXT", "kaspi"), ("SINCE", day)):
        try:
            typ, ids = box.search(None, *query)
        except Exception:
            continue
        for i in (ids[0].split() if typ == "OK" and ids and ids[0] else [])[-40:]:
            if i in seen:
                continue
            seen.add(i)
            order.append(i)
    out = []
    for i in order:
        try:
            typ, data = box.fetch(i, "(RFC822)")
        except Exception:
            continue
        if typ != "OK" or not data or not data[0]:
            continue
        try:
            msg = email.message_from_bytes(data[0][1])
        except Exception:
            continue
        if not _from_kaspi(msg):
            continue
        try:
            ts = email.utils.mktime_tz(email.utils.parsedate_tz(msg.get("Date"))) if msg.get("Date") else 0
        except Exception:
            ts = 0
        if ts >= since_ts:
            out.append((ts, msg))
    return sorted(out, key=lambda x: x[0], reverse=True)


def _kaspi_mails(box, since_ts):
    """[(время, письмо)] от Kaspi новее since_ts, свежие первыми."""
    return _collect(box, since_ts)


def fetch_code(since_ts, wait=180, report=None):
    """Ждёт письмо Kaspi с кодом (не старше since_ts). Возвращает код или None.
    report — необязательный словарь: в него кладём, сколько писем Kaspi нашлось и был ли в них код."""
    end = time.monotonic() + wait
    found = 0
    while True:
        last_error = None
        try:
            box = _connect(timeout=min(30, max(1, end - time.monotonic())))
        except _TemporaryIMAPError as e:
            last_error = e
        else:
            try:
                mails = _kaspi_mails(box, since_ts)
                found = max(found, len(mails))
                for _, msg in mails:
                    code = _code_from(msg)
                    if code:
                        if report is not None:
                            report.update(mails=found, code_found=True)
                        return code
            finally:
                try:
                    box.logout()
                except Exception:
                    pass
        remaining = end - time.monotonic()
        if remaining <= 0:
            if last_error is not None:
                raise last_error
            if report is not None:
                report.update(mails=found, code_found=False)
            return None
        time.sleep(min(5, remaining))


def test():
    """Проверка подключения: сколько писем Kaspi за 7 дней и нашёлся ли код в последнем. Сам код не возвращается."""
    box = _connect()
    try:
        mails = _kaspi_mails(box, time.time() - 7 * 86400)
        return {"ok": True, "kaspi_mails_7d": len(mails), "code_found_in_latest": bool(mails and _code_from(mails[0][1]))}
    finally:
        try:
            box.logout()
        except Exception:
            pass
