"""Выставление на готовые карточки Kaspi (присоединение к существующей карточке).
Адреса взяты из кода кабинета (kaspi.kz/mc, страница «Добавить товар → присоединиться к карточке»):
  данные карточки:  GET  mc.shop.kaspi.kz/content/item/api/v1/item/<код карточки>
  новый суффикс:    GET  mc.shop.kaspi.kz/content/pending/mc/product/<merchant_id>/new-code
  присоединить:     POST mc.shop.kaspi.kz/content/pending/mc/product/link-to-master  {merchantCode, merchantProductCode, masterProductCode}
preview() только читает. link() пишет в живой Kaspi: вызывать только после подтверждения пользователя."""
import json
import re
import time

from core import kaspi_cabinet as kc

_HDR = {"Origin": "https://kaspi.kz", "Referer": "https://kaspi.kz/mc/"}


def parse_code(text):
    """Код карточки из числа или ссылки kaspi.kz/shop/p/...-123456789/ ."""
    s = str(text or "").strip()
    m = re.search(r"-(\d{5,})/?(?:[?#].*)?$", s) or re.fullmatch(r"(\d{5,})", s)
    if not m:
        raise ValueError("Не нашёл код карточки. Вставьте ссылку на товар Kaspi (оканчивается на -числа) или сам код.")
    return m.group(1)


def preview(text):
    """Что за карточка (название, категория, фото). Ничего не меняет."""
    code = parse_code(text)
    kc._ensure()
    for _ in range(8):                      # карточка может быть «переехавшей» на другой код
        r = kc._session().get(kc.MC + f"/content/item/api/v1/item/{code}", headers=_HDR, timeout=30)
        if r.status_code != 200:
            raise RuntimeError(f"Kaspi не отдал карточку {code} ({r.status_code}).")
        d = r.json()
        if d.get("status") == "ACTUAL":
            break
        nxt = (d.get("redirectCodes") or [None])[0]
        if not nxt:
            raise RuntimeError("Карточка недоступна (удалена или не опубликована).")
        code = str(nxt)
    card = d.get("card") or {}
    imgs = d.get("galleryImages") or []
    return {"code": str(card.get("id") or code), "title": card.get("title"), "category": d.get("masterCategoryName"), "photos": len(imgs), "photo_urls": [str(i.get("medium") or i.get("small") or "") for i in imgs[:8]],
            "img": (imgs[0].get("medium") if imgs else None), "link": (card.get("shopLink") or "").replace("/p/", "/shop/p/", 1) if str(card.get("shopLink") or "").startswith("/p/") else card.get("shopLink")}


def _public_card(code, title):
    """Отзывы, рейтинг и цена «от» из публичной выдачи Kaspi: ищем карточку по названию и берём ту, у которой тот же код."""
    import json
    import urllib.parse
    import urllib.request
    from core import kaspi_store as ks
    try:
        city = str(ks._config_value("kaspi_city", "750000000"))
        q = urllib.parse.quote(str(title or "")[:80])
        h = {"User-Agent": ks.USER_AGENT, "Accept": "application/json, text/plain, */*", "Referer": "https://kaspi.kz/shop/search/"}
        h.update(ks._city_headers(city))
        req = urllib.request.Request(f"https://kaspi.kz/yml/product-view/pl/results?page=0&q={q}&text={q}&c={city}", headers=h)
        with ks._urlopen(req, 10) as r:
            data = json.loads(r.read().decode("utf-8")).get("data") or []
    except Exception:
        return {}
    for c in data:
        if str(c.get("id")) == str(code):
            return {"reviews": c.get("reviewsQuantity"), "rating": c.get("rating"), "price_from": c.get("unitPrice")}
    return {}


def info(text):
    """Данные карточки Kaspi по ссылке: название, фото, отзывы, цены и число продавцов. Только чтение."""
    from core import kaspi_store as ks
    code = parse_code(text)
    out = {"code": code, "title": None, "img": None, "category": None, "link": None}
    try:
        p = preview(code)
        out.update({k: p.get(k) for k in ("code", "title", "img", "category", "link", "photos", "photo_urls")})
        out["my_sku"] = my_sku_for(out.get("code") or code)
    except Exception as e:                      # кабинет не открыт: покажем хотя бы продавцов
        out["preview_error"] = str(e)[:160]
    pub = _public_card(out["code"], out.get("title")) if out.get("title") else {}
    out.update({"reviews": pub.get("reviews"), "rating": pub.get("rating")})
    r = ks.fetch_competitor_prices(out["code"])
    offers = r.get("offers") or []
    prices = [o["price"] for o in offers if o.get("price")]
    out["offers_ok"] = bool(r.get("ok"))
    out["offers_error"] = r.get("error") or ""
    out["sellers"] = len(offers)
    out["price_min"] = min(prices) if prices else pub.get("price_from")
    out["price_max"] = max(prices) if prices else None
    out["preorder_sellers"] = sum(1 for o in offers if (o.get("preorder") or 0) > 0)
    out["top"] = [{"merchant": o.get("merchant"), "price": o.get("price"), "preorder": o.get("preorder") or 0,
                   "rating": o.get("rating"), "reviews": o.get("reviews")} for o in offers[:5]]
    return out


def parse_wb_id(text):
    """Артикул WB из ссылки wildberries.ru/catalog/<id>/detail.aspx или из самого числа."""
    s = str(text or "").strip()
    m = re.search(r"/catalog/(\d{5,})", s) or re.fullmatch(r"(\d{5,})", s) or re.search(r"[?&]card=(\d{5,})", s)
    if not m:
        raise ValueError("Не нашёл артикул WB. Вставьте ссылку вида wildberries.ru/catalog/123456789/detail.aspx или сам артикул.")
    return int(m.group(1))


def wb_pack(text, max_photos=15):
    """Набор с карточки WB для улучшения карточки Kaspi: фото (до 15), описание и характеристики. Только чтение."""
    from core import kaspi_content as kcn
    wb_id = parse_wb_id(text)
    card = kcn.wb_card(wb_id)
    first = (card.get("_images") or [""])[0]
    host = first.rsplit("/images/", 1)[0] if "/images/" in first else ""
    n = int((card.get("media") or {}).get("photo_count") or 1)
    photos = [f"{host}/images/big/{i}.webp" for i in range(1, min(n, max_photos) + 1)] if host else []
    brand = ((card.get("selling") or {}).get("brand_name") or "").strip()
    drop_brand = bool(kcn.load_prefs().get("no_brand")) and brand
    def scrub(t):
        t = str(t or "")
        if drop_brand:
            t = re.sub(re.escape(brand), "", t, flags=re.I)
        return re.sub(r"[ \t]{2,}", " ", t).strip()
    chars = []
    for o in (card.get("options") or [])[:40]:
        name, val = o.get("name"), o.get("value")
        if not name or not val or kcn._WB_JUNK.search(f"{name} {val}"):
            continue
        if drop_brand and str(name).strip().lower() == "бренд":
            continue
        chars.append({"name": str(name), "value": scrub(val)})
    desc = kcn._WB_JUNK.sub("", card.get("description") or "")
    desc = re.sub(r"[ \t]+", " ", scrub(desc)).strip()
    return {"wb_id": wb_id, "wb_url": f"https://www.wildberries.ru/catalog/{wb_id}/detail.aspx",
            "title": scrub(card.get("imt_name") or ""), "brand": "" if drop_brand else brand,
            "subject": card.get("subj_name") or "", "photos": photos, "photo_count_wb": n,
            "description": desc[:7000], "characteristics": chars,
            "contents": scrub(card.get("contents") or ""), "brand_removed": bool(drop_brand)}


def wb_photos_zip(wb_id, max_photos=15):
    """Фото WB одним архивом (JPEG для Kaspi). Возвращает bytes."""
    import io
    import urllib.request
    import zipfile
    pack = wb_pack(wb_id, max_photos)
    buf = io.BytesIO()
    saved = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED) as z:
        for i, u in enumerate(pack["photos"], 1):
            try:
                with urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}), timeout=20) as r:
                    raw = r.read()
            except Exception:
                continue
            name, data = f"{i:02d}.webp", raw
            try:
                from PIL import Image
                im = Image.open(io.BytesIO(raw)).convert("RGB")
                out = io.BytesIO()
                im.save(out, "JPEG", quality=92)
                name, data = f"{i:02d}.jpg", out.getvalue()
            except Exception:
                pass
            z.writestr(name, data)
            saved += 1
    if not saved:
        raise RuntimeError("Не удалось скачать фото WB.")
    return buf.getvalue()


# ------------------------------------------------------------------ заявка на правку карточки Kaspi
# Адреса и форматы взяты из самого кабинета (kaspi.kz/mc, форма «Редактировать карточку товара»), проверены в живом кабинете:
#   карточка:     GET  /content/editor/mc/product/preview/<код>?m=<магазин>&p=<артикул>
#   фото:         POST /image/processor/merchant/upl/cnt/ce/i/t  (multipart, поле file) -> {images:[{id}]}, ждать GET .../api/status/cnt/ce/i/t/<id> = OK
#   черновик:     POST /content/editor/mc/application/draft   (тело = карточка с новыми images/description)
#   отправка:     POST /content/editor/mc/application/create  (тело = ответ черновика + issuer=<магазин>)
# Kaspi принимает правку как заявку на модерацию; менять можно только поля из editableFields (обычно фото, описание, видео).
import threading as _th
_EDIT_DRAFTS = {}
_EDIT_LOCK = _th.Lock()
_EDIT_HDR = {"Origin": "https://kaspi.kz", "Referer": "https://kaspi.kz/mc/"}
_IMG_BUCKET = "temp-content-editor-images"
MAX_CARD_PHOTOS = 15


def _unwrap_master(j):
    """Ответ preview может быть самой карточкой или обёрнут: достаём объект, где есть code и editableFields."""
    if isinstance(j, dict) and ("editableFields" in j or "classifications" in j) and "code" in j:
        return j
    if isinstance(j, dict):
        for v in j.values():
            if isinstance(v, dict):
                r = _unwrap_master(v)
                if r:
                    return r
    return None


def edit_load(code, sku):
    """Текущая карточка в том виде, в каком её отдаёт форма редактирования. Только чтение."""
    code = parse_code(code)
    kc._ensure()
    mid = kc.merchant_id()
    params = {"m": mid}
    if sku:
        params["p"] = sku
    r = kc._session().get(kc.MC + f"/content/editor/mc/product/preview/{code}", params=params,
                          headers=_EDIT_HDR, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"Kaspi не отдал карточку для правки ({r.status_code}). Откройте «Мой магазин» и проверьте вход в кабинет.")
    m = _unwrap_master(r.json())
    if not m:
        raise RuntimeError("Не удалось прочитать карточку для правки (Kaspi изменил формат ответа).")
    return m, mid


def _upload_photo(jpeg_bytes, name):
    import io
    sess = kc._session()
    r = sess.post(kc.MC + "/image/processor/merchant/upl/cnt/ce/i/t", files={"file": (name, io.BytesIO(jpeg_bytes), "image/jpeg")},
                  headers=_EDIT_HDR, timeout=90)
    if r.status_code != 200:
        raise RuntimeError(f"Kaspi не принял фото {name} ({r.status_code}).")
    imgs = (r.json() or {}).get("images") or []
    if not imgs or imgs[0].get("status") not in ("OK", "PARTIAL_OK", None):
        raise RuntimeError(f"Kaspi отклонил фото {name}.")
    iid = imgs[0]["id"]
    for _ in range(20):                       # фото обрабатывается: ждём статус OK
        s = sess.get(kc.MC + f"/image/processor/merchant/api/status/cnt/ce/i/t/{iid}", headers=_EDIT_HDR, timeout=30)
        st = (s.json() or {}).get(iid, {}) if s.status_code == 200 else {}
        if st.get("status") == "OK":
            break
        if st.get("status") in ("ERROR", "FAILED", "REJECTED"):
            raise RuntimeError(f"Kaspi не обработал фото {name}.")
        time.sleep(0.8)
    base = kc.MC + f"/image/processor/merchant/img/cnt/ce/i/t/{iid}"
    return {"small": base + "?format=thumbnail", "medium": base + "?format=gallery_medium",
            "large": base + "?format=gallery_large", "location": iid, "bucket": _IMG_BUCKET}


def my_sku_for(code):
    """Артикул вашего товара на этой карточке Kaspi (из загруженных данных магазина), если он там есть."""
    from core import kaspi_store as ks
    code = str(code)
    found = []
    def walk(o):
        if isinstance(o, dict):
            if str(o.get("card_code") or "") == code and o.get("sku"):
                found.append(str(o["sku"]))
            for v in o.values():
                if isinstance(v, (dict, list)):
                    walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    for path in (getattr(ks, "LIVE_PRODUCTS_FILE", ""), getattr(ks, "IMPORTED_PRODUCTS_FILE", ""), getattr(ks, "CUSTOM_PRODUCTS_FILE", "")):
        try:
            import os
            if path and os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    walk(json.load(f))
        except Exception:
            continue
        if found:
            break
    return found[0] if found else ""


def photo_is_clean(raw):
    """Грубая оценка: фото товара на белом фоне (рамка по краям светлая и ровная). Инфографика с цветным фоном и надписями не проходит."""
    import io
    try:
        from PIL import Image
    except Exception:
        return None
    try:
        im = Image.open(io.BytesIO(raw)).convert("RGB")
        im.thumbnail((120, 160))
        w, h = im.size
        px = im.load()
        edge = [px[x, y] for x in range(w) for y in (0, 1, h - 2, h - 1)] + [px[x, y] for y in range(h) for x in (0, 1, w - 2, w - 1)]
        light = sum(1 for p in edge if min(p) >= 232)
        return light / max(1, len(edge)) >= 0.9
    except Exception:
        return None


def wb_photo_flags(text, max_photos=MAX_CARD_PHOTOS):
    """Для каждого фото WB: True = вероятно чистое фото на белом фоне, False = вероятно инфографика/цветной фон."""
    import urllib.request
    from concurrent.futures import ThreadPoolExecutor
    pack = wb_pack(text, max_photos)
    def one(u):
        small = u.replace("/images/big/", "/images/c246x328/")
        try:
            with urllib.request.urlopen(urllib.request.Request(small, headers={"User-Agent": "Mozilla/5.0"}), timeout=20) as r:
                return photo_is_clean(r.read())
        except Exception:
            return None
    with ThreadPoolExecutor(max_workers=6) as ex:
        flags = list(ex.map(one, pack["photos"]))
    return {"wb_id": pack["wb_id"], "clean": flags}


def wb_photo_jpegs(wb_id, indices=None, max_photos=MAX_CARD_PHOTOS):
    """JPEG-байты фото WB (по номерам из набора, считая с 0)."""
    import io
    import urllib.request
    pack = wb_pack(wb_id, max_photos)
    out = []
    for i, u in enumerate(pack["photos"]):
        if indices is not None and i not in indices:
            continue
        with urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}), timeout=25) as r:
            raw = r.read()
        try:
            from PIL import Image
            im = Image.open(io.BytesIO(raw)).convert("RGB")
            b = io.BytesIO()
            im.save(b, "JPEG", quality=92)
            raw = b.getvalue()
        except Exception:
            pass
        out.append((f"wb{pack['wb_id']}-{i + 1:02d}.jpg", raw))
    return out, pack


def build_draft_body(master, new_images, description=None, keep_existing=True):
    """Тело черновика: карточка Kaspi + новые фото и/или новое описание. Менять можно только поля из editableFields."""
    editable = set(master.get("editableFields") or [])
    body = json.loads(json.dumps(master))             # копия
    if new_images:
        if "images" not in editable:
            raise RuntimeError("Kaspi не разрешает менять фото у этой карточки.")
        old = list(master.get("images") or []) if keep_existing else []
        body["images"] = (old + list(new_images))[:MAX_CARD_PHOTOS]
    if description is not None:
        if not ({"description", "descriptionLp"} & editable):
            raise RuntimeError("Kaspi не разрешает менять описание у этой карточки.")
        text = str(description).replace("\r\n", "\n").strip()[:7000]
        body["description"] = text.replace("\n", "<br/>")
        lp = dict(body.get("descriptionLp") or {})
        lp["ru"] = text
        body["descriptionLp"] = lp
    body.setdefault("videoId", None)
    return body


def edit_prepare(code, sku, wb_text, photo_idx=None, with_description=True, with_chars=True, keep_existing=True):
    """Загружает выбранные фото WB в Kaspi и просит у Kaspi черновик заявки (что изменится). Заявку НЕ подаёт."""
    from core import license as _lic
    _lic.require()
    master, mid = edit_load(code, sku)
    jpegs, pack = wb_photo_jpegs(wb_text, None if photo_idx is None else set(int(i) for i in photo_idx))
    if not jpegs and with_description is False:
        raise RuntimeError("Нечего менять: выберите фото или описание.")
    new_imgs = [_upload_photo(b, n) for n, b in jpegs]
    desc = None
    if with_description:
        parts = [pack["description"]]
        if with_chars and pack["characteristics"]:
            parts.append("Характеристики:\n" + "\n".join(f"- {c['name']}: {c['value']}" for c in pack["characteristics"]))
        desc = "\n\n".join(p for p in parts if p)
    body = build_draft_body(master, new_imgs, desc, keep_existing)
    r = kc._session().post(kc.MC + "/content/editor/mc/application/draft", json=body, headers=dict(_EDIT_HDR, **{"Content-Type": "application/json"}), timeout=60)
    if r.status_code >= 400:
        low = r.text[:300]
        if "no.changes" in low:
            raise RuntimeError("Kaspi: изменений нет, такие фото и описание уже стоят.")
        raise RuntimeError(f"Kaspi не принял черновик заявки ({r.status_code}): {low[:200]}")
    draft = r.json()
    token = hashlib_token(code, sku)
    with _EDIT_LOCK:
        _EDIT_DRAFTS[token] = {"draft": draft, "mid": mid, "ts": time.time(), "code": parse_code(code), "sku": sku}
        for k in [k for k, v in _EDIT_DRAFTS.items() if time.time() - v["ts"] > 1800]:
            _EDIT_DRAFTS.pop(k, None)
    return {"token": token, "photos_added": len(new_imgs), "photos_total": len(body.get("images") or []),
            "photos_before": len(master.get("images") or []), "description_changed": desc is not None,
            "description_len": len(desc or ""), "status": draft.get("status"),
            "editable": master.get("editableFields") or []}


def hashlib_token(code, sku):
    import hashlib
    return hashlib.sha1(f"{code}|{sku}|{time.time()}".encode()).hexdigest()[:16]


def edit_submit(token):
    """Подаёт заявку на модерацию Kaspi по ранее подготовленному черновику. ПИШЕТ В ЖИВОЙ KASPI: только после подтверждения человека."""
    from core import license as _lic
    _lic.require()
    with _EDIT_LOCK:
        d = _EDIT_DRAFTS.pop(token, None)
    if not d:
        raise RuntimeError("Черновик заявки устарел. Подготовьте его заново.")
    kc._ensure()
    body = dict(d["draft"])
    body["issuer"] = d["mid"]
    r = kc._session().post(kc.MC + "/content/editor/mc/application/create", json=body, headers=dict(_EDIT_HDR, **{"Content-Type": "application/json"}), timeout=60)
    if r.status_code >= 400:
        if "application.exists" in r.text:
            raise RuntimeError("На эту карточку уже подана ваша заявка: дождитесь решения Kaspi или отмените её в кабинете.")
        raise RuntimeError(f"Kaspi не принял заявку ({r.status_code}): {r.text[:200]}")
    kc._log("card_edit_application", card=d["code"], sku=d["sku"])
    try:
        res = r.json()
    except Exception:
        res = {}
    return {"ok": True, "deadline": res.get("moderationDeadline") or res.get("deadline") if isinstance(res, dict) else None}


def link(text, price=None, preorder_days=None):
    from core import license as _lic
    _lic.require()
    """Присоединяет магазин к карточке; если указаны цена и срок — сразу выставляет. ПИШЕТ В ЖИВОЙ KASPI."""
    info = preview(text)
    mid = kc.merchant_id()
    r = kc._session().get(kc.MC + f"/content/pending/mc/product/{mid}/new-code", headers=_HDR, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"Kaspi не выдал код товара ({r.status_code}).")
    suffix = re.sub(r"[^0-9A-Za-z_-]", "", r.text.strip())
    if not suffix:
        raise RuntimeError("Kaspi вернул пустой код товара.")
    sku = f"{info['code']}_{suffix}"
    body = {"merchantCode": mid, "merchantProductCode": sku, "masterProductCode": info["code"]}
    resp = None
    for q in ({}, {"m": mid}, {"_m": mid}):
        resp = kc._session().post(kc.MC + "/content/pending/mc/product/link-to-master", params=q, json=body, timeout=60,
                                  headers=dict(_HDR, **{"Content-Type": "application/json"}))
        if resp.status_code not in (403, 404):
            break
    if resp.status_code >= 400:
        kc._log("link_error", card=info["code"], http=resp.status_code)
        raise RuntimeError(f"Kaspi не присоединил карточку ({resp.status_code}): {resp.text[:200]}")
    kc._save_session()
    kc._log("link_to_master", card=info["code"], sku=sku)
    out = {"ok": True, "sku": sku, "card": info, "offer_set": False}
    if price:
        try:
            kc.set_offer(sku, price=int(price), preorder_days=preorder_days, available=True, stock=10)
            out["offer_set"] = True
        except Exception as e:
            out["offer_error"] = str(e)[:200]
    return out
