"""Доля магазина в нише: ваша выручка за месяц / выручка категории Kaspi за месяц.

Журнал собственных продаж копится сам: когда считается отчёт прибыли (завершённые
заказы), позиции записываются в data/own_sales.db вместе с окном, которое реально
просмотрено. Месяц считается покрытым только если окно накрывает его целиком.
Модуль ничего не запрашивает у Kaspi и Redstat: только читает свои данные и
таблицу cat_month. Неизвестное возвращается как None, а не как ноль.
"""
import os
import re
import sqlite3
import time
from contextlib import contextmanager

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SEP = " → "
PLACEHOLDERS = {"каталог kaspi", "мои товары", ""}
_SCHEMA = """
CREATE TABLE IF NOT EXISTS lines (
    order_id TEXT NOT NULL, line_no INTEGER NOT NULL, sku TEXT NOT NULL, name TEXT,
    qty REAL NOT NULL, amount REAL NOT NULL, completed_ms INTEGER NOT NULL, month TEXT NOT NULL,
    category TEXT,
    PRIMARY KEY(order_id, line_no)
);
CREATE INDEX IF NOT EXISTS lines_month ON lines(month);
CREATE TABLE IF NOT EXISTS coverage (from_ms INTEGER NOT NULL, to_ms INTEGER NOT NULL, recorded_at INTEGER NOT NULL);
"""


def db_path():
    return os.environ.get("KWB_OWN_SALES_DB") or os.path.join(ROOT, "data", "own_sales.db")


@contextmanager
def connect():
    path = os.path.abspath(db_path())
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=20)
    conn.row_factory = sqlite3.Row
    try:
        conn.executescript(_SCHEMA)
        cols = {r[1] for r in conn.execute("PRAGMA table_info(lines)")}
        if "category" not in cols:   # старая база: строки без категории считаются неподтверждёнными
            conn.execute("ALTER TABLE lines ADD COLUMN category TEXT")
            conn.commit()
        yield conn
    finally:
        conn.close()


def item_ok(it):
    """Позиция пригодна для журнала: есть SKU, количество и цена больше нуля."""
    try:
        return (str(it.get("sku") or "") != "" and float(it["qty"]) > 0 and float(it["unit"]) > 0)
    except (AttributeError, KeyError, TypeError, ValueError):
        return False


def _month_of(ms):
    return time.strftime("%Y-%m", time.localtime(ms / 1000))


def _month_bounds(month):
    y, m = map(int, month.split("-"))
    start = time.mktime((y, m, 1, 0, 0, 0, 0, 0, -1))
    ny, nm = (y + 1, 1) if m == 12 else (y, m + 1)
    return int(start * 1000), int(time.mktime((ny, nm, 1, 0, 0, 0, 0, 0, -1)) * 1000)


def _clean_category(t):
    t = re.sub(r"\s+", " ", str(t or "")).strip()
    return None if _norm(t) in PLACEHOLDERS else t[:200]


def record(orders, window_from_ms, window_to_ms, conn=None, categories=None):
    """orders: [{id, completed_ms, items:[{sku,name,qty,unit}]}] — только завершённые.

    window_*: границы по дате завершения, которые просмотрены полностью.
    categories: {sku: название категории Kaspi на момент записи}; сохраняется в строке, поэтому позднее
    перенесённый в другую категорию или исчезнувший из каталога товар историческую долю не меняет.
    Возвращает число записанных позиций. Повторная запись идемпотентна.
    """
    no_window = window_from_ms is None and window_to_ms is None   # только строки, без отметки о полном просмотре
    if not no_window and (not (isinstance(window_from_ms, (int, float)) and isinstance(window_to_ms, (int, float))) or window_to_ms <= window_from_ms):
        raise ValueError("Некорректное окно просмотра.")

    def work(c):
        n = 0
        with c:
            for o in orders or []:
                oid, done = str(o.get("id") or ""), o.get("completed_ms")
                if not oid or not isinstance(done, (int, float)) or done <= 0:
                    continue
                for i, it in enumerate(o.get("items") or []):
                    try:
                        qty, unit = float(it["qty"]), float(it["unit"])
                    except (KeyError, TypeError, ValueError):
                        continue
                    if qty <= 0 or unit <= 0 or str(it.get("sku") or "") == "":
                        continue
                    cat = _clean_category((categories or {}).get(str(it["sku"])))
                    # для той же позиции историческую категорию не меняем (даже если она неизвестна: строка остаётся
                    # неподтверждённой); если на месте позиции теперь другой SKU, берём категорию нового
                    c.execute("INSERT INTO lines(order_id,line_no,sku,name,qty,amount,completed_ms,month,category) VALUES(?,?,?,?,?,?,?,?,?) "
                              "ON CONFLICT(order_id,line_no) DO UPDATE SET sku=excluded.sku, name=excluded.name, qty=excluded.qty, "
                              "amount=excluded.amount, completed_ms=excluded.completed_ms, month=excluded.month, "
                              "category=CASE WHEN lines.sku=excluded.sku THEN lines.category ELSE excluded.category END",
                              (oid, i, str(it["sku"]), str(it.get("name") or "")[:200], qty, qty * unit,
                               int(done), _month_of(done), cat))
                    n += 1
            if not no_window:
                c.execute("INSERT INTO coverage VALUES(?,?,?)", (int(window_from_ms), int(window_to_ms), int(time.time())))
        return n

    if conn is not None:
        return work(conn)
    with connect() as c:
        return work(c)


def _coverage_state(conn, month):
    """Текущий месяц, отсутствие подтверждённого просмотра, частичное или полное покрытие."""
    start, end = _month_bounds(month)
    if end > time.time() * 1000:
        return "month_open"
    pos = start
    seen = False
    windows = conn.execute(
        "SELECT from_ms, to_ms FROM coverage WHERE to_ms>? AND from_ms<? ORDER BY from_ms",
        (start, end),
    )
    for f, t in windows:
        seen = True
        if f > pos:
            return "partial_coverage"
        pos = max(pos, t)
        if pos >= end:
            return "covered"
    return "partial_coverage" if seen else "no_coverage"


def _covered(conn, month):
    return _coverage_state(conn, month) == "covered"


def _norm(s):
    return re.sub(r"\s+", " ", str(s or "").lower().replace("ё", "е")).strip()


def _leaf(path):
    return _norm(str(path).split(SEP)[-1])


def share_in_category(own_conn, market_conn, month, category_path, sku_category):
    """Доля в категории за месяц.

    sku_category: {sku: название категории Kaspi} (из каталога магазина).
    Строка привязывается к категории, только если название совпадает с последним
    сегментом пути и в этом месяце такое название встречается ровно в одном пути
    (иначе привязка неоднозначна и строка не учитывается).
    Возвращает {own_revenue, own_orders, own_units, market_revenue, share_pct, status}.
    unmapped_revenue: продажи месяца, у которых категория неизвестна (в долю не входят).
    status: ok | not_covered | no_market | zero_market | ambiguous
    reason при not_covered: month_open | no_coverage | partial_coverage
    """
    out = {"month": month, "path": category_path, "own_revenue": None, "own_orders": None,
           "own_units": None, "market_revenue": None, "share_pct": None, "status": "not_covered"}
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", str(month or "")):
        raise ValueError("Выберите месяц.")
    row = market_conn.execute("SELECT revenue FROM cat_month WHERE month=? AND path=?", (month, category_path)).fetchone()
    market = row["revenue"] if row else None
    out["market_revenue"] = market if market and market > 0 else None
    coverage = _coverage_state(own_conn, month)
    if coverage != "covered":
        out["reason"] = coverage
        return out
    if market is None:
        out["status"] = "no_market"
        return out
    leaf = _leaf(category_path)
    same = [r["path"] for r in market_conn.execute("SELECT path FROM cat_month WHERE month=?", (month,)) if _leaf(r["path"]) == leaf]
    if leaf in PLACEHOLDERS or len(same) != 1:
        out["status"] = "ambiguous"
        out["reason"] = "placeholder_category" if leaf in PLACEHOLDERS else "duplicate_category_name"
        return out
    cats = {str(s): _norm(t) for s, t in (sku_category or {}).items()}
    rev, units, orders, unmapped, unconf = 0.0, 0.0, set(), 0.0, 0.0
    for r in own_conn.execute("SELECT order_id, sku, qty, amount, category FROM lines WHERE month=?", (month,)):
        if r["category"]:                        # категория, сохранённая при записи заказа: подтверждена
            c, confirmed = _norm(r["category"]), True
        else:                                    # старая строка: берём текущую категорию из каталога, но помечаем неподтверждённой
            c, confirmed = cats.get(r["sku"]), False
        if c is None or c in PLACEHOLDERS:
            unmapped += r["amount"]
        elif c == leaf:
            rev += r["amount"]
            units += r["qty"]
            orders.add(r["order_id"])
            if not confirmed:
                unconf += r["amount"]
    out.update(own_revenue=round(rev, 2), own_orders=len(orders), own_units=units, unmapped_revenue=round(unmapped, 2),
               unconfirmed_revenue=round(unconf, 2))
    if market <= 0:
        out["status"] = "zero_market"
    else:
        out["share_pct"] = rev / market * 100
        out["status"] = "ok"
    return out


# ---------------------------------------------------------------- ежедневное наполнение
_ATTEMPTS = {}


def last_recorded_day(conn=None):
    """Локальная дата последней записи окна просмотра (YYYY-MM-DD) или None."""
    def work(c):
        r = c.execute("SELECT MAX(recorded_at) FROM coverage").fetchone()[0]
        return time.strftime("%Y-%m-%d", time.localtime(r)) if r else None
    if conn is not None:
        return work(conn)
    with connect() as c:
        return work(c)


def fill_if_due(report_fn, days=56, max_attempts=3, today=None):
    """Раз в сутки вызывает report_fn(days=days) — отчёт прибыли сам пишет журнал.

    Возвращает "done" | "skipped" (сегодня уже записано) | "limit" (лимит попыток
    за сутки) | "failed" (отчёт упал; будет повтор позже, не чаще max_attempts в сутки).
    Сам модуль к Kaspi не обращается: сеть использует только report_fn.
    """
    today = today or time.strftime("%Y-%m-%d")
    if last_recorded_day() == today:
        return "skipped"
    if _ATTEMPTS.get(today, 0) >= max_attempts:
        return "limit"
    _ATTEMPTS.clear() if today not in _ATTEMPTS else None
    _ATTEMPTS[today] = _ATTEMPTS.get(today, 0) + 1
    try:
        report_fn(days=days)
    except Exception:
        return "failed"
    return "done" if last_recorded_day() == today else "failed"

