import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from core.ai_copywriter import generate_kaspi_description
from core.kaspi_store import calculate_product_economics, category_commission

def export_to_excel(items: list[dict], output_path: str, options: dict = None):
    if options is None:
        options = {}
    preorder_days = options.get("preorder_days", 7)
    photo_mode = options.get("photo_mode", "ai_studio")  # "original", "ai_studio", "infographic"
    desc_mode = options.get("desc_mode", "ai_copywriter") # "wb", "ai_copywriter"

    cfg = options.get("config", {})
    mode = cfg.get("kaspi_delivery_mode", "official_kz")
    econ_options = {"pack_kzt": float(cfg.get("packaging_cost_kzt", 150)),
                    "delivery_scope": "city" if mode == "official_city" else "kz",
                    "include_vat": cfg.get("kaspi_delivery_vat", True)}
    if mode == "custom":
        econ_options["delivery_kzt"] = float(cfg.get("kaspi_delivery_cost_kzt", 1299))

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Прайс-лист Kaspi Pay (Импорт)"
    ws.views.sheetView[0].showGridLines = True
    calc = wb.create_sheet("Расчёт")
    calc.sheet_state = "hidden"
    calc.append(["Всего затрат", "Комиссия", "Эквайринг", "Налог", "Удержания", "Выплата", "Прибыль", "ROI", "Маржа"])
    
    headers = [
        "№",
        "Артикул (SKU)",
        "Название товара для Kaspi",
        "Бренд",
        "Категория",
        "Цена продажи на Kaspi (₸)",
        "Срок предзаказа (дней)",
        "Главное фото (Ссылка)",
        "Описание товара (УТП)",
        "Отзывов на WB",
        "Рейтинг WB",
        "Наличие на WB, шт",
        "Цена закупки WB (₸)",
        "Упаковка (₸)",
        "Всего затрат с закупкой (₸)",
        "Комиссия Kaspi по категории (₸)",
        "Kaspi Pay 0.95% (₸)",
        "Налог ИП 3% (₸)",
        "Удержания с доставкой и упаковкой (₸)",
        "Выплата на счёт (₸)",
        "Чистая прибыль (₸)",
        "ROI к себестоимости",
        "Маржа от выручки",
        "Ссылка на выкуп WB"
    ]
    
    ws.append(headers)
    
    navy_fill = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    data_font = Font(name="Calibri", size=10)
    bold_data_font = Font(name="Calibri", size=10, bold=True)
    green_font = Font(name="Calibri", size=10, bold=True, color="15803D")
    link_font = Font(name="Calibri", size=10, color="0284C7", underline="single")
    light_green_fill = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")
    zebra_fill = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
    white_fill = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")
    
    thin_side = Side(border_style="thin", color="E2E8F0")
    thin_border = Border(left=thin_side, right=thin_side, top=thin_side, bottom=thin_side)
    
    ws.row_dimensions[1].height = 28
    for c in range(1, len(headers) + 1):
        cell = ws.cell(1, c)
        cell.fill = navy_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
        
    for r_idx, it in enumerate(items, start=2):
        # Choose photo based on mode
        if photo_mode == "infographic" and it.get("infographic_url"):
            main_photo = it.get("infographic_url")
        elif photo_mode in ["ai_studio", "infographic"] and it.get("ai_cdn_url"):
            main_photo = it.get("ai_cdn_url")
        else:
            main_photo = it.get("img_main") or it.get("img_url") or ""
            
        # Choose description based on mode
        if desc_mode == "ai_copywriter":
            desc_text = generate_kaspi_description(it)
        else:
            desc_text = it.get("description") or generate_kaspi_description(it)
            
        kaspi_price = it.get("kaspi_price", 0)
        econ = calculate_product_economics(kaspi_price, it.get("price_kzt", 0),
                    comm_rate=category_commission(it.get("category"), it.get("commission_rate", 12.5)), **econ_options)
        calc.append([econ[k] for k in ("total_deductions", "comm_kzt", "pay_kzt", "tax_kzt",
                                      "kaspi_deductions", "kaspi_payout", "net_profit")] +
                    [econ[k] / 100 if econ[k] is not None else None for k in ("roi_pct", "margin_pct")])
        
        row_data = [
            r_idx - 1,                                          # 1: №
            it.get("id"),                                       # 2: SKU
            it.get("kaspi_name") or it.get("name"),             # 3: Название
            it.get("brand", "ProHome"),                         # 4: Бренд
            it.get("category", "Товары для дома"),              # 5: Категория
            kaspi_price,                                        # 6: Цена Kaspi
            f"Под заказ: {preorder_days} дней",                 # 7: Предзаказ
            main_photo,                                         # 8: Ссылка на фото
            desc_text,                                          # 9: Описание
            it.get("feedbacks", 0),                             # 10: Отзывов
            it.get("rating", 4.9),                              # 11: Рейтинг
            it.get("wb_qty", ""),                               # 12: наличие на WB
            it.get("price_kzt", 0),                             # 13: WB (₸)
            econ["pack_kzt"],                                    # 14: Упаковка
            f"='Расчёт'!A{r_idx}",
            f"='Расчёт'!B{r_idx}",
            f"='Расчёт'!C{r_idx}",
            f"='Расчёт'!D{r_idx}",
            f"='Расчёт'!E{r_idx}",
            f"='Расчёт'!F{r_idx}",
            f"='Расчёт'!G{r_idx}",
            f"='Расчёт'!H{r_idx}",
            f"='Расчёт'!I{r_idx}",
            "Выкупить на WB"                                    # 24: Ссылка WB
        ]
        ws.append(row_data)
        # External text must remain literal text; only O-W contain our formulas.
        for c, value in enumerate(row_data, 1):
            if not 15 <= c <= 23 and isinstance(value, str):
                ws.cell(r_idx, c).data_type = "s"
        ws.row_dimensions[r_idx].height = 22
        row_fill = zebra_fill if (r_idx % 2 == 0) else white_fill
        
        for c in range(1, len(headers) + 1):
            cell = ws.cell(r_idx, c)
            cell.border = thin_border
            cell.fill = row_fill
            cell.font = data_font
            
            if c in [1, 2, 10]:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.number_format = "#,##0"
            elif c == 11:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.number_format = "0.0"
            elif c == 7:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.fill = light_green_fill
                cell.font = bold_data_font
            elif c == 12:
                cell.alignment = Alignment(horizontal="right", vertical="center")
                cell.number_format = '#,##0 "₽"'
            elif c in [6, 13, 14, 15, 16, 17, 18, 19, 20, 21]:
                cell.alignment = Alignment(horizontal="right", vertical="center")
                cell.number_format = '#,##0 "₸"'
                if c in [6, 21]:
                    cell.font = bold_data_font
                    if c == 21:
                        cell.font = green_font
            elif c in [22, 23]:
                cell.alignment = Alignment(horizontal="right", vertical="center")
                cell.number_format = "0.0%"
                cell.font = green_font
                if c == 22:
                    cell.fill = light_green_fill
            elif c == 8:
                cell.hyperlink = main_photo
                cell.font = link_font
                cell.alignment = Alignment(horizontal="left", vertical="center")
            elif c == 24:
                cell.hyperlink = it.get("wb_url", "")
                cell.font = link_font
                cell.alignment = Alignment(horizontal="center", vertical="center")
            elif c == 9:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")
                
    widths = {
        1: 6, 2: 14, 3: 45, 4: 16, 5: 22, 6: 18, 7: 20, 8: 24, 9: 45, 10: 12,
        11: 12, 12: 14, 13: 14, 14: 14, 15: 18, 16: 16, 17: 14, 18: 14, 19: 16,
        20: 16, 21: 18, 22: 20, 23: 16, 24: 18
    }
    for col_idx, width in widths.items():
        ws.column_dimensions[get_column_letter(col_idx)].width = width
        
    ws.freeze_panes = "D2"
    ws.auto_filter.ref = f"A1:X{len(items) + 1}"
    
    wb.save(output_path)
    return output_path
