"""Daily public Kaspi observations; no cabinet/config access and no scheduler at import.

Deploy as core/price_watch.py. DB location follows core.market_cats; an environment
override is resolved on every call. All observations use CITY (Almaty), independently
of the live-card city, so the series never mixes different city markets.
Days use the supplied datetime's timezone, or the computer's local timezone.
One durable attempt per code/day, including failures: restarting never hammers a
failed item. An interrupted ('running') attempt also waits until the next day.
remove() disables tracking but preserves history and today's attempt; add() re-enables.
"""

import math
import os
import re
import sqlite3
import threading
import time
from collections.abc import Mapping
from contextlib import contextmanager
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CITY = "750000000"
_RUN_LOCK = threading.RLock()
SCHEMA = """
CREATE TABLE IF NOT EXISTS watch_items (
    code TEXT PRIMARY KEY, title TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS snapshots (
    code TEXT NOT NULL REFERENCES watch_items(code), day TEXT NOT NULL,
    price REAL, sellers INTEGER, reviews INTEGER, checked_at TEXT NOT NULL,
    PRIMARY KEY(code, day)
);
CREATE TABLE IF NOT EXISTS watch_attempts (
    code TEXT NOT NULL REFERENCES watch_items(code), day TEXT NOT NULL,
    checked_at TEXT NOT NULL, status TEXT NOT NULL, error TEXT,
    PRIMARY KEY(code, day)
);
"""


def db_path():
    return os.environ.get("KWB_PRICE_WATCH_DB") or os.path.join(ROOT, "data", "price_watch.db")


@contextmanager
def _connect():
    path = os.path.abspath(db_path())
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=20)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(SCHEMA)
        yield conn
    finally:
        conn.close()


def _code(value):
    value = str(value).strip() if value is not None else ""
    if not re.fullmatch(r"[0-9]{5,15}", value):
        raise ValueError("Код Kaspi должен содержать от 5 до 15 цифр.")
    return value


def _now():
    return datetime.now().astimezone()


def _clock(now):
    value = now() if callable(now) else now
    if value is None:
        return _now()
    if not isinstance(value, datetime):
        raise ValueError("now должен быть datetime или функцией, возвращающей datetime.")
    return value


def _limit(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(name + " должен быть целым неотрицательным числом.")
    return value


def add(code, title):
    code = _code(code)
    if not isinstance(title, str) or not title.strip() or len(title.strip()) > 500:
        raise ValueError("Название должно содержать от 1 до 500 символов.")
    title = title.strip()
    with _connect() as conn, conn:
        conn.execute("INSERT INTO watch_items(code,title) VALUES(?,?) "
                     "ON CONFLICT(code) DO UPDATE SET title=excluded.title, active=1", (code, title))
    return {"code": code, "title": title}


def remove(code):
    """Stop tracking, retaining observations and same-day deduplication."""
    with _connect() as conn, conn:
        return bool(conn.execute("UPDATE watch_items SET active=0 WHERE code=? AND active=1",
                                 (_code(code),)).rowcount)


def list_items():
    with _connect() as conn:
        return [dict(row) for row in conn.execute(
            "SELECT w.code,w.title,a.checked_at AS last_checked_at,a.status,a.error AS last_error "
            "FROM watch_items w LEFT JOIN watch_attempts a ON a.code=w.code AND "
            "a.day=(SELECT MAX(day) FROM watch_attempts WHERE code=w.code) "
            "WHERE w.active=1 ORDER BY w.code")]


def live_product(code, city):
    """Lazy adapter: importing this module neither imports the app nor accesses data."""
    from core.margin_calc import live_product as fetch
    return fetch(code, city)


def _metrics(data):
    if not isinstance(data, Mapping):
        raise ValueError("invalid public response")
    values = []
    for key in ("price", "sellers", "reviews"):
        value = data.get(key)
        if value is not None:
            if (isinstance(value, bool) or not isinstance(value, (int, float))
                    or not math.isfinite(value) or value < 0
                    or (key != "price" and int(value) != value)):
                raise ValueError("invalid public metric")
            value = float(value) if key == "price" else int(value)
        values.append(value)
    if all(value is None for value in values):
        raise ValueError("empty public response")
    return values


def snapshot_due(fetch=live_product, now=None, pause=2.5, max_items=50):
    """Return {attempted,saved,failed,errors}; fetch(code, CITY), at most max_items.

    now may be a datetime or a clock callable (useful for midnight tests). Claims
    commit before network work; SQLite's unique key prevents duplicate requests
    across processes. The process lock also serializes calls and their pauses.
    Errors persist as exception type only, avoiding arbitrary upstream secret text.
    """
    max_items = _limit(max_items, "max_items")
    if isinstance(pause, bool) or not isinstance(pause, (int, float)) or not math.isfinite(pause) or pause < 0:
        raise ValueError("pause должен быть конечным неотрицательным числом.")
    result = {"attempted": 0, "saved": 0, "failed": 0, "errors": []}
    if not max_items:
        return result
    with _RUN_LOCK, _connect() as conn:
        day = _clock(now).date().isoformat()
        # Oldest attempts first; goods beyond max_items cannot starve indefinitely.
        candidates = conn.execute(
            "SELECT w.code FROM watch_items w WHERE w.active=1 AND NOT EXISTS "
            "(SELECT 1 FROM watch_attempts a WHERE a.code=w.code AND a.day=?) "
            "ORDER BY COALESCE((SELECT MAX(day) FROM watch_attempts WHERE code=w.code),''), w.code "
            "LIMIT ?", (day, max_items)).fetchall()
        for item in candidates:
            if result["attempted"]:
                time.sleep(pause)
            stamp = _clock(now)
            day, checked_at, code = stamp.date().isoformat(), stamp.isoformat(), item["code"]
            with conn:
                claimed = conn.execute(
                    "INSERT OR IGNORE INTO watch_attempts(code,day,checked_at,status) "
                    "SELECT code,?,?, 'running' FROM watch_items WHERE code=? AND active=1",
                    (day, checked_at, code)).rowcount
            if not claimed:
                continue
            result["attempted"] += 1
            try:
                price, sellers, reviews = _metrics(fetch(code, CITY))
                with conn:
                    conn.execute("INSERT INTO snapshots VALUES(?,?,?,?,?,?)",
                                 (code, day, price, sellers, reviews, checked_at))
                    conn.execute("UPDATE watch_attempts SET status='ok',error=NULL WHERE code=? AND day=?",
                                 (code, day))
                result["saved"] += 1
            except Exception as exc:
                error = type(exc).__name__
                with conn:
                    conn.execute("UPDATE watch_attempts SET status='error',error=? WHERE code=? AND day=?",
                                 (error, code, day))
                result["failed"] += 1
                result["errors"].append({"code": code, "day": day, "error": error})
    return result


def history(code, days=90):
    """Inclusive calendar window ending today; missing days are absent, not zeroes.

    Return {code,city,days,from_day,to_day,series,change,errors}. change has price
    and sellers objects {absolute,percent}, from first to last non-null observation
    inside the window (minimum two values; zero baseline => percent=None).
    """
    code = _code(code)
    days = _limit(days, "days")
    if not 1 <= days <= 36500:
        raise ValueError("days должен быть от 1 до 36500.")
    today = _now().date()
    start, end = (today - timedelta(days=days - 1)).isoformat(), today.isoformat()
    with _connect() as conn:
        rows = [dict(row) for row in conn.execute(
            "SELECT code,day,price,sellers,reviews,checked_at FROM snapshots "
            "WHERE code=? AND day BETWEEN ? AND ? ORDER BY day", (code, start, end))]
        errors = [dict(row) for row in conn.execute(
            "SELECT day,checked_at,status,error FROM watch_attempts "
            "WHERE code=? AND day BETWEEN ? AND ? AND status!='ok' ORDER BY day", (code, start, end))]
    change = {}
    for key in ("price", "sellers"):
        values = [row[key] for row in rows if row[key] is not None]
        delta = values[-1] - values[0] if len(values) >= 2 else None
        change[key] = {"absolute": delta,
                       "percent": round(delta / values[0] * 100, 2) if delta is not None and values[0] else None}
    return {"code": code, "city": CITY, "days": days, "from_day": start, "to_day": end,
            "series": rows, "change": change, "errors": errors}
