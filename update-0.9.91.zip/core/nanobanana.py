import urllib.request
import urllib.error
import urllib.parse
import socket
import ipaddress
import http.client
import tempfile
import json
import ssl
import time
import os

CTX = ssl.create_default_context()
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

def _urlopen(req, timeout):
    try:
        return urllib.request.urlopen(req, context=CTX, timeout=timeout)
    except (urllib.error.URLError, ssl.SSLError) as e:
        if isinstance(getattr(e, "reason", e), ssl.SSLError):
            raise RuntimeError("Не удалось проверить сертификат TLS. Проверьте системное хранилище доверенных сертификатов.") from None
        raise

def check_account(api_key: str) -> dict:
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
        'User-Agent': USER_AGENT
    }
    req = urllib.request.Request('https://api.royaltechno.cc/v1/account', headers=headers)
    with _urlopen(req, timeout=12) as resp:
        return json.loads(resp.read().decode('utf-8'))

def is_valid_image_url(url: str) -> bool:
    conn = None
    try:
        host, path, address = _image_address(url)
        conn = _ImageConnection(host, address)
        conn.request("HEAD", path, headers={"User-Agent": USER_AGENT})
        return conn.getresponse().status == 200
    except Exception:
        return False
    finally:
        if conn is not None:
            conn.close()

def generate_product_photo(api_key: str, reference_image_url: str = None, prompt_text: str = None, aspect_ratio: str = "portrait") -> dict:
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
        'User-Agent': USER_AGENT
    }
    
    if not prompt_text:
        prompt_text = (
            "Professional commercial product photography of the exact item shown in the reference image. "
            "Isolated on an ultra-clean warm-white minimalist studio podium, soft diffuse morning sunlight with delicate realistic shadow, "
            "crisp sharp focus on textures and fine details, 8k resolution, Apple commercial catalog standard, luxury aesthetic"
        )
        
    ref_urls = []
    if reference_image_url:
        _image_address(reference_image_url)
        if not is_valid_image_url(reference_image_url):
            raise ValueError("Исходное фото недоступно или не прошло проверку безопасности")
        ref_urls.append(reference_image_url)
        
    payload = {
        "model": "nano-banana-pro",
        "input": {
            "prompt": prompt_text,
            "reference_image_urls": ref_urls,
            "aspect_ratio": aspect_ratio
        }
    }
    
    req = urllib.request.Request(
        'https://api.royaltechno.cc/v1/jobs',
        data=json.dumps(payload).encode('utf-8'),
        headers=headers,
        method='POST'
    )
    
    with _urlopen(req, timeout=15) as resp:
        job_data = json.loads(resp.read().decode('utf-8'))
        job_id = job_data.get('id')
        
    if not job_id:
        raise Exception("Failed to get job ID from RoyalTech API")
        
    # Poll status
    for _ in range(35):
        time.sleep(4)
        poll_req = urllib.request.Request(
            f'https://api.royaltechno.cc/v1/jobs/{job_id}',
            headers=headers,
            method='GET'
        )
        try:
            with _urlopen(poll_req, timeout=15) as resp:
                poll_data = json.loads(resp.read().decode('utf-8'))
                status = poll_data.get('status')
                if status == 'succeeded':
                    output_url = poll_data.get('output', {}).get('url')
                    return {
                        "success": True,
                        "job_id": job_id,
                        "url": output_url
                    }
                elif status in ['failed', 'error']:
                    return {
                        "success": False,
                        "error": poll_data.get('error', 'Job failed')
                    }
        except RuntimeError:
            raise
        except Exception:
            continue
            
    return {"success": False, "error": "Generation timed out"}

# Exact host allowlist: no suffix matching, credentials, redirects or private addresses.
IMAGE_HOSTS = frozenset({"resources.cdn-kaspi.kz"})
MAX_IMAGE_BYTES = 8 * 1024 * 1024

def _image_address(url):
    try:
        u = urllib.parse.urlsplit(url)
        if (u.scheme != "https" or u.hostname not in IMAGE_HOSTS or u.username or u.password
                or u.port not in (None, 443) or "\\" in url or any(ord(c) < 33 for c in url)):
            raise ValueError()
        addresses = socket.getaddrinfo(u.hostname, 443, type=socket.SOCK_STREAM)
        if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
            raise ValueError()
        return u.hostname, urllib.parse.urlunsplit(("", "", u.path or "/", u.query, "")), addresses[0][4][0]
    except (ValueError, TypeError):
        raise ValueError("Фото разрешено загружать только по HTTPS с публичного Kaspi CDN") from None

class _ImageConnection(http.client.HTTPSConnection):
    def __init__(self, host, address):
        super().__init__(host, timeout=25, context=CTX)
        self._address = address

    def connect(self):
        # Pin the validated address; TLS still verifies the original hostname.
        sock = socket.create_connection((self._address, 443), self.timeout)
        try:
            self.sock = CTX.wrap_socket(sock, server_hostname=self.host)
        except Exception:
            sock.close()
            raise

def download_file(url: str, save_path: str):
    host, path, address = _image_address(url)
    conn = _ImageConnection(host, address)
    temp_path = None
    try:
        conn.request("GET", path, headers={"User-Agent": USER_AGENT, "Accept": "image/*"})
        resp = conn.getresponse()
        if resp.status != 200:
            raise ValueError("Фото недоступно; перенаправления запрещены")
        mime = resp.getheader("Content-Type", "").split(";", 1)[0].lower()
        if mime not in {"image/jpeg", "image/png", "image/webp"}:
            raise ValueError("Ответ не является поддерживаемым изображением")
        length = resp.getheader("Content-Length")
        if length is not None and (int(length) < 0 or int(length) > MAX_IMAGE_BYTES):
            raise ValueError("Фото превышает лимит 8 MiB")
        folder = os.path.dirname(os.path.abspath(save_path))
        os.makedirs(folder, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=folder, delete=False) as f:
            temp_path = f.name
            total = 0
            while True:
                chunk = resp.read(min(65536, MAX_IMAGE_BYTES + 1 - total))
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_IMAGE_BYTES:
                    raise ValueError("Фото превышает лимит 8 MiB")
                f.write(chunk)
        # Verify the actual file, not just the server-supplied MIME type.
        from PIL import Image
        with Image.open(temp_path) as image:
            if image.format not in {"JPEG", "PNG", "WEBP"}:
                raise ValueError("Неподдерживаемый формат фото")
            image.verify()
        os.replace(temp_path, save_path)
        temp_path = None
        return save_path
    except ssl.SSLError:
        raise RuntimeError("Не удалось проверить сертификат TLS изображения") from None
    finally:
        conn.close()
        if temp_path is not None:
            os.remove(temp_path)
