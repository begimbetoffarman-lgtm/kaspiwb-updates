"""Поиск карточек Kaspi с малым числом продавцов («где пусто, а спрос есть»).

Берёт публичную выдачу Kaspi по вашему запросу и у каждой карточки смотрит число продавцов в вашем городе.
Только чтение публичных страниц, ничего не меняет ни в Kaspi, ни в вашем магазине. Скорость ограничена:
не больше MAX_CARDS карточек за проверку, пауза между запросами, одна проверка за раз."""
import re
import threading
import time
import urllib.parse

import requests

from core import margin_calc as mc

MAX_CARDS = 60          # сколько карточек просматриваем за одну проверку
LIST_PAGE = 12          # столько карточек отдаёт одна страница выдачи
MAX_PAGES = 8
PAUSE = 0.5             # секунд между запросами к Kaspi
FAIL_STOP = 5           # столько ошибок подряд — останавливаемся
CACHE_TTL = 600         # одинаковый запрос в течение 10 минут не повторяем
MAX_SELLERS_LIMIT = 5
CACHE_MAX = 50

_LOCK = threading.Lock()
_STATE = {"running": False}
_CACHE = {}             # (запрос, город, порог) -> (время, готовое состояние)


def _empty():
    return {"running": False, "query": "", "max_sellers": 2, "city": "", "checked": 0, "total": 0, "scanned_pages": 0,
            "found": [], "error": "", "skipped": 0, "started_at": None, "finished_at": None, "cached": False}


def clean_query(value):
    q = re.sub(r"\s+", " ", str(value or "")).strip()
    return q if 2 <= len(q) <= 80 else ""


def _listing(query, page, city):
    q = ":availableInZones:Magnum_ZONE1"
    url = ("https://kaspi.kz/yml/product-view/pl/results?page=%d&q=%s&text=%s&sort=relevance&qs=&ui=d&i=-1&c=%s"
           % (page, urllib.parse.quote(q), urllib.parse.quote(query), city))
    r = requests.get(url, headers={"User-Agent": mc.UA, "Referer": "https://kaspi.kz/shop/"}, timeout=25)
    r.raise_for_status()
    data = r.json().get("data")
    if not isinstance(data, list):
        raise ValueError("Kaspi не вернул список карточек.")
    return data


def _num(v):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if x == x and abs(x) != float("inf") else None


def _card(item, sellers):
    code = str(item.get("id") or "")
    price = _num(item.get("unitPrice"))
    reviews = _num(item.get("reviewsQuantity"))
    rating = _num(item.get("rating"))
    return {"code": code, "title": str(item.get("title") or "")[:200], "brand": str(item.get("brand") or "")[:80],
            "price": int(price) if price is not None else None, "sellers": sellers,
            "reviews": int(reviews) if reviews is not None else None, "rating": rating,
            "url": "https://kaspi.kz/shop/p/-%s/" % code if re.fullmatch(r"\d{5,15}", code) else ""}


def _count(code, city):
    """Число продавцов карточки; ошибки Kaspi не превращаем в «0 продавцов»."""
    total, offs = mc._offers(code, city, live=True)
    if total is None:   # общее число неизвестно: по оставшимся после разбора предложениям его не считаем
        raise ValueError("Kaspi не назвал число продавцов.")
    return total, offs


def start(query, max_sellers=2, city="750000000", pages=5):
    """Запускает проверку в фоне. Возвращает текущее состояние; если проверка уже идёт, новая не запускается."""
    q = clean_query(query)
    if not q:
        raise ValueError("Введите запрос от 2 до 80 символов, например «органайзер для обуви».")
    try:
        ms = int(max_sellers)
    except (TypeError, ValueError):
        ms = 2
    ms = max(0, min(ms, MAX_SELLERS_LIMIT))
    city = str(city or "")
    if not re.fullmatch(r"\d{9}", city):
        raise ValueError("Не удалось определить город магазина для проверки.")
    pages = max(1, min(int(pages or 5), MAX_PAGES))
    key = (q.lower(), city, ms)
    with _LOCK:
        if _STATE.get("running"):
            return dict(_STATE)
        now = time.time()
        for k in [k for k, v in _CACHE.items() if now - v[0] >= CACHE_TTL]:
            del _CACHE[k]
        hit = _CACHE.get(key)
        if hit and time.time() - hit[0] < CACHE_TTL:
            _STATE.clear()
            _STATE.update(hit[1], cached=True)
            return dict(_STATE)
        _STATE.clear()
        _STATE.update(_empty(), running=True, query=q, max_sellers=ms, city=city,
                      started_at=time.strftime("%Y-%m-%d %H:%M:%S"))
    threading.Thread(target=_run, args=(q, ms, city, pages, key), name="low-sellers", daemon=True).start()
    return status()


def status():
    with _LOCK:
        out = dict(_STATE)
        out["found"] = [dict(x) for x in _STATE.get("found", [])]
    return out


def _run(query, max_sellers, city, pages, key, listing=None, offers=None, sleep=time.sleep):
    listing = listing or _listing
    offers = offers or _count
    fails, seen, cards = 0, set(), []
    error = ""
    try:
        for page in range(pages):
            try:
                data = listing(query, page, city)
                fails = 0
            except Exception:
                fails += 1
                if fails >= FAIL_STOP or page == 0:
                    raise RuntimeError("Kaspi сейчас не отвечает. Повторите проверку позже.")
                continue
            if not data:
                break
            for it in data:
                code = str(it.get("id") or "")
                if code and code not in seen and len(cards) < MAX_CARDS:
                    seen.add(code)
                    cards.append(it)
            with _LOCK:
                _STATE["scanned_pages"] = page + 1
                _STATE["total"] = len(cards)
            if len(cards) >= MAX_CARDS:
                break
            sleep(PAUSE)
        fails = 0
        for it in cards:
            code = str(it.get("id") or "")
            try:
                n, _ = offers(code, city)
                fails = 0
            except Exception:
                n = None
                fails += 1
                with _LOCK:
                    _STATE["skipped"] += 1
                if fails >= FAIL_STOP:
                    error = "Kaspi перестал отвечать на половине проверки. Показано то, что успели проверить."
                    break
            with _LOCK:
                if n is not None:
                    _STATE["checked"] += 1
                if isinstance(n, int) and 0 < n <= max_sellers:
                    _STATE["found"].append(_card(it, n))
                    _STATE["found"].sort(key=lambda x: (x["sellers"], -(x["reviews"] or 0)))
            sleep(PAUSE)
    except Exception as exc:
        error = str(exc) if isinstance(exc, RuntimeError) else "Не удалось выполнить проверку."
    finally:
        with _LOCK:
            if not error and _STATE.get("skipped"):
                error = "Не удалось проверить карточек: %d. Результат неполный, повторите проверку позже." % _STATE["skipped"]
            _STATE.update(running=False, error=error, finished_at=time.strftime("%Y-%m-%d %H:%M:%S"))
            if not error:   # неполную проверку не кэшируем
                if len(_CACHE) >= CACHE_MAX:
                    del _CACHE[min(_CACHE, key=lambda k: _CACHE[k][0])]
                _CACHE[key] = (time.time(), {k: v for k, v in _STATE.items() if k != "cached"})
