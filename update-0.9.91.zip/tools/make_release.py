"""Чистая сборка для другого продавца: без data/, config.json, паролей, токенов, ваших накладных и резервных копий.
Запуск (из папки проекта):  runtime\\python.exe tools\\make_release.py [версия] [mac]
Результат: D:\\kaspi-arbitrage-release\\KaspiWB-<версия>.zip (Windows) или KaspiWB-Mac-<версия>.zip (с аргументом mac:
без Windows-Python runtime и start.bat, с start.command). В конце: проверка, что в архиве нет ваших секретов."""
import json
import os
import sys
import tarfile
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = r"D:\kaspi-arbitrage-release"
_args = [a for a in sys.argv[1:] if a != "mac"]
MAC = "mac" in sys.argv[1:]
VERSION = _args[0] if _args else open(os.path.join(ROOT, "version.txt")).read().strip()
SKIP_DIRS = {".venv", "data", "obsidian", "_wb_test", "_render", "_upload", "backups", "__pycache__", ".git", "tools_private", ".claude"}
SKIP_FILES = {"config.json", "extract_live_kaspi_products.py", "inspect_kaspi_html.py", "check_xml_preorder.py", "ДЛЯ-ANTIGRAVITY.md", "ПЛАН-РАЗВИТИЯ.md", "AGENTS.md", "CLAUDE.md", "build_0933.log"}
# исходный код источника данных и инструменты выгрузки у клиентов не нужны; данные рынка идут файлом (см. ниже) и заглушкой core/redstat.py
SKIP_FILES |= {"market_analytics.py", "market_docs.py", "redstat.py", "import_market.py", "index_market_docs.py", "redstat_pull.py"}
# данные рынка (аналитика по базе) в обычный релиз не входят; клиентская сборка с пакетом данных: KWB_WITH_MARKET=1
WITH_MARKET = os.environ.get("KWB_WITH_MARKET") == "1"
if not WITH_MARKET:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import release_filter
    SKIP_FILES |= release_filter.FILES
SKIP_EXT ={".pyc", ".pkl", ".log"}


def secrets():
    """Значения из вашего config.json, которых не должно быть в сборке (токен, пароли, логин, номер магазина)."""
    try:
        sys.path.insert(0, ROOT)
        from core import secrets as _sec
        c = dict(_sec._raw(os.path.join(ROOT, "config.json")))
        c.update(_sec._load_store())          # секреты теперь в защищённом хранилище; файл не меняем
    except Exception:
        return []
    keys = ("kaspi_api_token", "kaspi_cab_password", "kaspi_cab_login", "gmail_app_password", "gmail_address",
            "royaltech_api_key", "kaspi_merchant_id", "feed_token")
    return [str(c[k]) for k in keys if c.get(k) and len(str(c[k])) >= 5]


def main():
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, f"KaspiWB-Mac-{VERSION}.zip" if MAC else f"KaspiWB-{VERSION}.zip")
    files = []
    for base, dirs, names in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not (MAC and d == "runtime" and base == ROOT)]
        for n in names:
            if n in SKIP_FILES or os.path.splitext(n)[1] in SKIP_EXT:
                continue
            if base == ROOT and ((MAC and n == "start.bat") or (not MAC and n == "start.command")):
                continue
            files.append(os.path.join(base, n))
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            arc = os.path.join("KaspiWB", os.path.relpath(f, ROOT))
            if os.path.basename(f) == "start.command":
                zi = zipfile.ZipInfo(arc.replace("\\", "/"))
                zi.external_attr = 0o100755 << 16          # право на запуск, иначе Mac не откроет двойным щелчком
                zi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(zi, open(f, "rb").read())
            elif not WITH_MARKET and arc.replace("\\", "/") == "KaspiWB/static/index.html":
                z.writestr(arc.replace("\\", "/"), release_filter.strip_index(open(f, encoding="utf-8", newline="").read()).encode("utf-8"))
            else:
                z.write(f, arc)
        # данные рынка для клиента: файл из вашей базы и заглушка вместо внешнего источника (настоящий core/redstat.py не входит)
        stub = os.path.join(ROOT, "tools_private", "client_stubs", "redstat.py")
        pack = os.path.join(ROOT, "tools_private", "out", "market_pack.db")
        if WITH_MARKET:
            z.write(stub, "KaspiWB/core/redstat.py")
        if WITH_MARKET and os.path.isfile(pack):
            z.write(pack, "KaspiWB/core/market_data/market_pack.db")
        elif WITH_MARKET:
            print("ВНИМАНИЕ: нет tools_private/out/market_pack.db, в сборку не попадут данные рынка (запустите tools_private/make_market_pack.py)")
    if MAC:   # свой Python для Apple Silicon и Intel (python-build-standalone), чтобы на Mac ничего не ставить
        PYDIR = os.path.join(OUT, "mac-python")
        with zipfile.ZipFile(path, "a", zipfile.ZIP_DEFLATED) as z:
            for arch in ("arm64", "x86_64"):
                tp = os.path.join(PYDIR, arch + ".tar.gz")
                if not os.path.exists(tp):
                    print("НЕТ", tp, "- архив без встроенного Python для", arch)
                    continue
                with tarfile.open(tp) as t:
                    mem = {m.name: m for m in t.getmembers()}
                    for m in mem.values():
                        src = m
                        while src.issym():                 # ссылки превращаем в обычные файлы (zip на Windows без символьных ссылок)
                            tgt = os.path.normpath(os.path.join(os.path.dirname(src.name), src.linkname)).replace("\\", "/")
                            src = mem.get(tgt)
                            if src is None:
                                break
                        if src is None or not src.isfile():
                            continue
                        zi = zipfile.ZipInfo("KaspiWB/runtime-mac/" + arch + "/" + m.name)
                        zi.external_attr = 0o100755 << 16
                        zi.compress_type = zipfile.ZIP_DEFLATED
                        z.writestr(zi, t.extractfile(src).read())
    # проверка на утечки: ищем значения ваших секретов во всех текстовых файлах архива
    bad = []
    sec = secrets()
    with zipfile.ZipFile(path) as z:
        for info in z.infolist():
            if os.path.splitext(info.filename)[1].lower() in (".py", ".js", ".html", ".json", ".md", ".bat", ".command", ".txt", ".css"):
                data = z.read(info).decode("utf-8", "ignore")
                for s in sec:
                    if s in data:
                        bad.append((info.filename, s[:2] + "…"))
    print("файлов:", len(files), "размер МБ:", round(os.path.getsize(path) / 1e6, 1))
    print("УТЕЧКИ:", bad if bad else "нет")
    print(path)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
