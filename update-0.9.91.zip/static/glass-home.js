/* Переключатель «стеклянный вид» главной. Выбор хранится на этом компьютере. */
(function () {
  var K = 'kwb_glass', root = document.documentElement;
  function get() { try { return localStorage.getItem(K) !== '0'; } catch (e) { return true; } }
  function apply(on) { root.classList.toggle('no-glass', !on); var b = document.getElementById('glassToggle'); if (b) { b.setAttribute('aria-pressed', on ? 'true' : 'false'); b.textContent = on ? 'Новый вид: вкл' : 'Новый вид: выкл'; } }
  function init() {
    var pane = document.getElementById('tab-home');
    if (pane && !document.getElementById('glassToggle')) {
      var b = document.createElement('button');
      b.type = 'button'; b.id = 'glassToggle'; b.className = 'glass-toggle';
      b.title = 'Выключите, если программа тормозит: вернётся прежний вид';
      b.addEventListener('click', function () { var on = !get(); try { localStorage.setItem(K, on ? '1' : '0'); } catch (e) {} apply(on); });
      pane.insertBefore(b, pane.firstChild);
    }
    apply(get());
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
