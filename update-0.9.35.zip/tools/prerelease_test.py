"""Проверка Windows-сборки перед отправкой знакомым: делает то же, что сделает пользователь.
Запуск:  runtime\\python.exe -I tools\\prerelease_test.py [путь_к_zip]     (по умолчанию D:\\kaspi-arbitrage-release\\KaspiWB-<версия>.zip)
Что проверяет:
  1. состав архива: нет data/, config.json, backups, ваших ключей; start.bat с переносами CRLF; есть runtime, инструкция, оферта;
  2. все .py файлы компилируются;
  3. архив распаковывается в папку с пробелами и русскими буквами (как у многих пользователей), start.bat запускается,
     сервер поднимается (HTTP 200), в окне нет «not recognized» и «unexpected»;
  4. запуск start.bat из папки без run.py (сценарий «из архива») показывает понятное сообщение, а не ошибки.
Код возврата 0 = всё хорошо. При любой ошибке сборку отдавать нельзя."""
import os
import py_compile
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT =r"D:\kaspi-arbitrage-release"
ver = open(os.path.join(ROOT, "version.txt"), encoding="utf-8").read().strip()
ZIP = sys.argv[1] if len(sys.argv) > 1 else os.path.join(OUT, f"KaspiWB-{ver}.zip")
fails = []


def ok(cond, label, extra=""):
    print(("  ✅ " if cond else "  ❌ ") + label + (f" ({extra})" if extra and not cond else ""))
    if not cond:
        fails.append(label)


def kill_tree(proc):
    subprocess.call(["taskkill", "/PID", str(proc.pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run_bat(folder, wait=40):
    """Запускает start.bat, ждёт строку «Сервер запущен», возвращает (вывод, порт или None)."""
    log = os.path.join(tempfile.gettempdir(), "kwb_pre_out.txt")
    # свой порт, чтобы тест не зависел от того, запущена ли у вас сама программа на 8790
    with open(os.path.join(folder, "config.json"), "w", encoding="utf-8") as cf:
        cf.write('{"port": 18790}')
    env = dict(os.environ, KWB_NO_BROWSER="1")
    with open(log, "wb") as fh:
        p = subprocess.Popen(["cmd.exe", "/c", "call .\\start.bat"], cwd=folder, stdout=fh, stderr=subprocess.STDOUT,
                             stdin=subprocess.DEVNULL, creationflags=0x08000000, env=env)
        port = None
        t0 = time.time()
        text = ""
        while time.time() - t0 < wait:
            time.sleep(1)
            text = open(log, "rb").read().decode("utf-8", "replace")
            m = re.search(r"Сервер запущен: http://127\.0\.0\.1:(\d+)", text)
            if m:
                port = int(m.group(1))
                break
            if p.poll() is not None:
                break
        code = None
        if port:
            try:
                time.sleep(1)
                code = urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=10).status
            except Exception as e:
                code = str(e)[:60]
        kill_tree(p)
        time.sleep(1)
        text = open(log, "rb").read().decode("utf-8", "replace")
    return text, port, code


def main():
    print("Проверяю:", ZIP)
    if not os.path.exists(ZIP):
        print("Архив не найден. Сначала tools\\make_release.py.")
        return 2
    z = zipfile.ZipFile(ZIP)
    names = z.namelist()
    print("1. Состав архива")
    ok(not any(re.search(r"/(data|backups)/", n) for n in names), "нет data/ и backups/")
    ok(not any(n.endswith("config.json") for n in names), "нет config.json")
    ok(not any("private" in n.lower() or n.endswith(".key") for n in names), "нет приватных ключей")
    ok("KaspiWB/runtime/python.exe" in names, "есть встроенный Python (runtime)")
    ok("KaspiWB/ИНСТРУКЦИЯ.md" in names and "KaspiWB/ОФЕРТА.md" in names, "есть инструкция и оферта")
    bat = z.read("KaspiWB/start.bat") if "KaspiWB/start.bat" in names else b""
    ok(bool(bat) and bat.count(b"\r\n") == bat.count(b"\n"), "start.bat с переносами CRLF")
    ok(b"(Extract All)" not in bat, "в start.bat нет скобок внутри блоков")
    ok(not any(n.startswith("KaspiWB/start.command") for n in names), "в Windows-сборке нет start.command")

    tmp = tempfile.mkdtemp(prefix="kwb ")
    work = os.path.join(tmp, "Тест папка 1", "Мой магазин")        # пробелы и кириллица в пути
    try:
        z.extractall(work)
        app = os.path.join(work, "KaspiWB")
        print("2. Компиляция .py")
        bad = []
        for base, _d, files in os.walk(app):
            if os.sep + "runtime" in base or os.sep + "vendor" in base:
                continue
            for f in files:
                if f.endswith(".py"):
                    try:
                        with open(os.path.join(base, f), "rb") as fh:
                            compile(fh.read(), f, "exec")
                    except Exception as e:
                        bad.append(f"{f}: {str(e)[:80]}")
        ok(not bad, "все .py компилируются", "; ".join(bad))
        print("3. Запуск start.bat из чистой папки (кириллица и пробелы в пути)")
        text, port, code = run_bat(app)
        ok(port is not None, "сервер запустился", text[-300:].replace("\n", " "))
        ok(code == 200, "страница программы отдаётся (HTTP 200)", str(code))
        ok("not recognized" not in text and "unexpected" not in text and "Traceback" not in text, "в окне нет ошибок",
           re.sub(r"\s+", " ", text[-300:]))
        ok("Тест-драйв" in text, "пробный период показан в окне")
        print("4. Запуск «из архива» (нет run.py)")
        only = os.path.join(tmp, "only bat")
        os.makedirs(only)
        shutil.copy(os.path.join(app, "start.bat"), only)
        r = subprocess.run(["cmd.exe", "/c", "call .\\start.bat"], cwd=only, capture_output=True, stdin=subprocess.DEVNULL,
                           timeout=30, creationflags=0x08000000)
        out = r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")
        ok("not recognized" not in out and "unexpected" not in out, "сообщение показано без ошибок cmd")
        ok("АРХИВА" in out, "понятное сообщение «запуск из архива»")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    if fails:
        print("ПРОВЕРКА НЕ ПРОЙДЕНА:", "; ".join(fails))
        return 1
    print("ПРОВЕРКА ПРОЙДЕНА: сборку можно отдавать.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
