"""Собирает ИНСТРУКЦИЯ.md в красивый HTML, а затем через Chrome/Edge печатает PDF.
Запуск:  runtime\\python.exe tools\\md_to_pdf.py [вход.md] [выход.pdf]
По умолчанию: ИНСТРУКЦИЯ.md -> D:\\kaspi-arbitrage-release\\ИНСТРУКЦИЯ.pdf"""
import html
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_OUT = r"D:\kaspi-arbitrage-release\ИНСТРУКЦИЯ.pdf"

CHROME = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]

CSS = """
@page { size: A4; margin: 16mm 14mm 18mm 14mm; }
* { box-sizing: border-box; }
body { font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif; color: #1c2333;
       font-size: 11.5pt; line-height: 1.62; margin: 0; }
h1 { font-size: 24pt; color: #0f1c3f; border-bottom: 3px solid #f4b393;
     padding-bottom: 10px; margin: 0 0 22px; }
h2 { font-size: 16pt; color: #0f1c3f; margin: 30px 0 12px;
     padding: 8px 0 8px 0; border-bottom: 1px solid #dde3ee; page-break-after: avoid; }
h3 { font-size: 13pt; color: #1f2a44; margin: 22px 0 10px;
     padding-left: 10px; border-left: 4px solid #f4b393; page-break-after: avoid; }
p { margin: 9px 0; }
ul, ol { margin: 9px 0 9px 4px; padding-left: 22px; }
li { margin: 5px 0; }
strong { color: #0f1c3f; }
code { background: #f1f4fa; padding: 2px 5px; border-radius: 4px;
       font-family: "Consolas", monospace; font-size: 10.5pt; color: #b03a2e; }
hr { border: none; border-top: 1px dashed #cfd8e8; margin: 24px 0; }
table { width: 100%; border-collapse: collapse; margin: 14px 0; page-break-inside: avoid; }
th { background: #1f2a44; color: #fff; text-align: left; padding: 9px 11px;
     font-size: 10.5pt; font-weight: 600; }
td { padding: 8px 11px; border-bottom: 1px solid #e4e9f2; vertical-align: top; font-size: 10.5pt; }
tr:nth-child(even) td { background: #f8fafd; }
blockquote { margin: 14px 0; padding: 11px 15px; background: #fff7f0;
             border-left: 5px solid #f4b393; border-radius: 0 6px 6px 0; }
blockquote p { margin: 4px 0; }
a { color: #2b5db8; text-decoration: none; }
"""


def md_to_html(md):
    """Мини-Markdown: заголовки, таблицы, списки, выделения, код, цитаты, hr."""
    lines = md.split("\n")
    out = []
    i = 0
    in_ul = in_ol = in_tbl = False

    def close_lists():
        nonlocal in_ul, in_ol, in_tbl
        if in_ul:
            out.append("</ul>"); in_ul = False
        if in_ol:
            out.append("</ol>"); in_ol = False
        if in_tbl:
            out.append("</table>"); in_tbl = False

    def inline(t):
        t = html.escape(t, quote=False)
        t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
        t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
        t = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", t)
        t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', t)
        return t

    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if not s:
            close_lists(); i += 1; continue

        # таблица
        if s.startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:\-|]+\|$", lines[i + 1].strip()):
            close_lists()
            cells = [c.strip() for c in s.strip("|").split("|")]
            out.append("<table><thead><tr>" + "".join(f"<th>{inline(c)}</th>" for c in cells) + "</tr></thead><tbody>")
            i += 2
            while i < len(lines) and lines[i].strip().startswith("|"):
                cs = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                out.append("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in cs) + "</tr>")
                i += 1
            out.append("</tbody></table>")
            continue

        if s.startswith("```"):
            close_lists()
            i += 1
            buf = []
            while i < len(lines) and not lines[i].strip().startswith("```"):
                buf.append(html.escape(lines[i])); i += 1
            i += 1
            out.append("<pre><code>" + "\n".join(buf) + "</code></pre>")
            continue

        if re.match(r"^---+$", s) or re.match(r"^\*\*\*+$", s):
            close_lists(); out.append("<hr>"); i += 1; continue

        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            close_lists()
            lvl = len(m.group(1))
            out.append(f"<h{lvl}>{inline(m.group(2))}</h{lvl}>")
            i += 1; continue

        if s.startswith(">"):
            close_lists()
            buf = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                buf.append(inline(lines[i].strip()[1:].strip())); i += 1
            out.append("<blockquote>" + "".join(f"<p>{b}</p>" for b in buf) + "</blockquote>")
            continue

        m = re.match(r"^[-*]\s+(.*)$", s)
        if m:
            if not in_ul:
                close_lists(); out.append("<ul>"); in_ul = True
            out.append(f"<li>{inline(m.group(1))}</li>"); i += 1; continue

        m = re.match(r"^\d+[.)]\s+(.*)$", s)
        if m:
            if not in_ol:
                close_lists(); out.append("<ol>"); in_ol = True
            out.append(f"<li>{inline(m.group(1))}</li>"); i += 1; continue

        close_lists()
        out.append(f"<p>{inline(s)}</p>")
        i += 1

    close_lists()
    return "\n".join(out)


def find_browser():
    for p in CHROME:
        if os.path.exists(p):
            return p
    for name in ("chrome", "msedge", "chromium"):
        p = shutil.which(name)
        if p:
            return p
    return None


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "ИНСТРУКЦИЯ.md")
    dst = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_OUT
    md = io.open(src, encoding="utf-8").read()
    page = ("<!doctype html><html><head><meta charset='utf-8'>"
            "<title>Kaspi WB — инструкция</title><style>" + CSS + "</style></head><body>"
            + md_to_html(md) + "</body></html>")

    tmpdir = tempfile.mkdtemp(prefix="kwbmd_")
    html_path = os.path.join(tmpdir, "doc.html")
    io.open(html_path, "w", encoding="utf-8").write(page)

    br = find_browser()
    if not br:
        sys.exit("Не найден Chrome или Edge — PDF собрать нечем.")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.exists(dst):
        os.remove(dst)
    args = [br, "--headless=new", "--disable-gpu", "--no-sandbox", "--no-pdf-header-footer",
            f"--print-to-pdf={dst}", "file:///" + html_path.replace("\\", "/")]
    rc = subprocess.call(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if rc != 0 or not os.path.exists(dst):
        # старый синтаксис headless
        subprocess.call([br, "--headless", "--disable-gpu", "--no-pdf-header-footer",
                         f"--print-to-pdf={dst}", "file:///" + html_path.replace("\\", "/")],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    shutil.rmtree(tmpdir, ignore_errors=True)
    if not os.path.exists(dst):
        sys.exit("PDF не создался.")
    print("PDF:", dst, round(os.path.getsize(dst) / 1024), "КБ")


if __name__ == "__main__":
    main()
