# Установщик Kaspi WB: ставит программу в папку пользователя и создаёт ярлыки. Права администратора не нужны.
# Для проверок: KWB_TARGET (папка), KWB_SHORTCUT_DIR (куда положить ярлык), KWB_SILENT=1 (без окон).
$ErrorActionPreference = 'Stop'
try { Start-Transcript -Path (Join-Path $env:TEMP 'kaspiwb_install.log') -Force | Out-Null } catch {}
Add-Type -AssemblyName System.Windows.Forms
function Say($t, $icon = 'Information') { if (-not $env:KWB_SILENT) { [void][System.Windows.Forms.MessageBox]::Show($t, 'Kaspi WB', 'OK', $icon) } else { Write-Host $t } }
try {
    $Target = if ($env:KWB_TARGET) { $env:KWB_TARGET } else { Join-Path $env:LOCALAPPDATA 'KaspiWB' }
    $zip = Join-Path $PSScriptRoot 'KaspiWB.zip'
    $tmp = Join-Path $env:TEMP ('kwb_' + [guid]::NewGuid().ToString('N'))
    Expand-Archive -Path $zip -DestinationPath $tmp -Force
    $src = Join-Path $tmp 'KaspiWB'
    $upgrade = Test-Path (Join-Path $Target 'run.py')
    New-Item -ItemType Directory -Force -Path $Target | Out-Null
    # data и config.json пользователя не трогаем (при переустановке сохраняются все его данные)
    & robocopy $src $Target /E /XD data backups /XF config.json /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "Не удалось скопировать файлы (код $LASTEXITCODE)" }
    try { [System.IO.Directory]::Delete($tmp, $true) } catch {}      # уборка временной папки не должна ломать установку
    $ws = New-Object -ComObject WScript.Shell
    function Link($dir, $name) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
        $l = $ws.CreateShortcut((Join-Path $dir ($name + '.lnk')))
        $l.TargetPath = Join-Path $Target 'start.bat'
        $l.WorkingDirectory = $Target
        $l.IconLocation = "$env:SystemRoot\System32\shell32.dll,13"
        $l.Description = 'Kaspi WB'
        $l.Save()
    }
    $desk = if ($env:KWB_SHORTCUT_DIR) { $env:KWB_SHORTCUT_DIR } else { [Environment]::GetFolderPath('Desktop') }
    Link $desk 'Kaspi WB'
    if (-not $env:KWB_SHORTCUT_DIR) { Link (Join-Path ([Environment]::GetFolderPath('Programs')) 'Kaspi WB') 'Kaspi WB' }
    $msg = if ($upgrade) { "Программа обновлена. Ваши данные и настройки сохранены.`nЗапустите её ярлыком «Kaspi WB» на рабочем столе." } else { "Программа установлена в:`n$Target`n`nЗапустите её ярлыком «Kaspi WB» на рабочем столе." }
    Say $msg
    if (-not $env:KWB_SILENT) {
        $a = [System.Windows.Forms.MessageBox]::Show('Запустить программу сейчас?', 'Kaspi WB', 'YesNo', 'Question')
        if ($a -eq 'Yes') { Start-Process -FilePath (Join-Path $Target 'start.bat') -WorkingDirectory $Target }
    }
} catch {
    Say ("Ошибка установки: " + $_.Exception.Message) 'Error'
    exit 1
}
