"""Собирает установщик KaspiWB-Setup.exe (встроенный в Windows IExpress): внутри архив программы и install.ps1.
Запуск:  runtime\\python.exe tools\\make_installer.py     (результат: D:\\kaspi-arbitrage-release\\KaspiWB-Setup.exe)
Установщик не подписан цифровой подписью, поэтому Windows может показать предупреждение SmartScreen."""
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = r"D:\kaspi-arbitrage-release"
STAGE = os.path.join(OUT, "installer_build")


def main():
    ver = open(os.path.join(ROOT, "version.txt"), encoding="utf-8").read().strip()
    rc = subprocess.call([sys.executable, "-I", os.path.join(ROOT, "tools", "make_release.py"), ver], cwd=ROOT)
    if rc:
        sys.exit("Сборка остановлена: в архиве нашлись ваши секреты.")
    rc = subprocess.call([sys.executable, "-I", os.path.join(ROOT, "tools", "prerelease_test.py"), os.path.join(OUT, f"KaspiWB-{ver}.zip")], cwd=ROOT)
    if rc:
        sys.exit("Сборка остановлена: проверка на чистой распаковке не пройдена (tools\\prerelease_test.py).")
    os.makedirs(STAGE, exist_ok=True)
    shutil.copy2(os.path.join(OUT, f"KaspiWB-{ver}.zip"), os.path.join(STAGE, "KaspiWB.zip"))
    ps = open(os.path.join(ROOT, "tools", "installer", "install.ps1"), encoding="utf-8").read()
    open(os.path.join(STAGE, "install.ps1"), "w", encoding="utf-8-sig").write(ps)     # BOM: иначе PowerShell 5 ломает кириллицу
    exe = os.path.join(OUT, "KaspiWB-Setup.exe")
    if os.path.exists(exe):
        os.remove(exe)
    sed = f"""[Version]
Class=IEXPRESS
SEDVersion=3
[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=1
HideExtractAnimation=1
UseLongFileName=1
InsideCompressed=0
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=
DisplayLicense=
FinishMessage=
TargetName={exe}
FriendlyName=Kaspi WB
AppLaunched=powershell.exe -NoProfile -ExecutionPolicy Bypass -File install.ps1
PostInstallCmd=<None>
AdminQuietInstCmd=
UserQuietInstCmd=
SourceFiles=SourceFiles
[Strings]
FILE0="install.ps1"
FILE1="KaspiWB.zip"
[SourceFiles]
SourceFiles0={STAGE}\\
[SourceFiles0]
%FILE0%=
%FILE1%=
"""
    sed_path = os.path.join(STAGE, "setup.sed")
    open(sed_path, "w", encoding="cp1251", errors="replace").write(sed)
    subprocess.check_call(["iexpress.exe", "/N", "/Q", sed_path])
    print("готово:", exe, round(os.path.getsize(exe) / 1e6, 1), "МБ")


main()
