#!/bin/bash
# Запуск Kaspi WB на Mac. Двойной клик (первый раз: правая кнопка → «Открыть», на macOS 15 - см. ИНСТРУКЦИЯ.md).
# Все ошибки пишутся в data/error.log (без паролей и токенов: туда попадают только сообщения установки и программы).
cd "$(dirname "$0")" || exit 1
export PYTHONUTF8=1
export PYTHONDONTWRITEBYTECODE=1
export PIP_DISABLE_PIP_VERSION_CHECK=1
LANG=${LANG:-ru_RU.UTF-8}; export LANG
mkdir -p data 2>/dev/null
LOG="data/error.log"

pause() { echo; read -r -p "Нажмите Enter, чтобы закрыть окно"; }
log() { { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; } >>"$LOG" 2>/dev/null; }
fail() {   # fail "что случилось" "что делать"
  echo
  echo "========================================================"
  echo " ОШИБКА: $1"
  [ -n "$2" ] && echo " Что делать: $2"
  echo " Сделайте скриншот этого окна и пришлите Арману."
  echo "========================================================"
  log "FAIL: $1"
  pause; exit 1
}

if [ ! -f run.py ]; then
  fail "рядом нет файла run.py. Вы запустили файл из архива или не из той папки." "Дважды щёлкните по zip, дождитесь папки KaspiWB, перенесите её в «Документы» и запустите start.command из неё."
fi

# Файлы из интернета помечены карантином: снимаем метку со всей папки (без неё macOS не ругается на каждый файл).
xattr -dr com.apple.quarantine . 2>/dev/null
chmod +x start.command 2>/dev/null

case "$PWD" in
  *AppTranslocation*|/Volumes/*)
    fail "папка запущена прямо из архива или с флешки (путь: $PWD)." "Перенесите папку KaspiWB в «Документы» (мышкой в Finder) и запустите start.command оттуда." ;;
esac
if ! touch data/.write_test 2>/dev/null; then
  fail "нет права записи в папку программы ($PWD)." "Перенесите папку KaspiWB в «Документы» и запустите оттуда."
fi
rm -f data/.write_test

# ---------- Поиск подходящего Python (нужен 3.9+) ----------
ok_py() { [ -x "$1" ] && "$1" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1; }
PY=""
CANDS=""
# Свой Python из папки программы (если он есть в архиве) - самый надёжный вариант, ставить ничего не нужно.
case "$(uname -m)" in arm64) ARCH_ORDER="arm64 x86_64" ;; *) ARCH_ORDER="x86_64 arm64" ;; esac
if [ -d runtime-mac ]; then
  chmod -R u+x runtime-mac/*/python/bin 2>/dev/null
  for a in $ARCH_ORDER; do CANDS="$CANDS $PWD/runtime-mac/$a/python/bin/python3"; done
fi
for v in 3.13 3.12 3.11 3.10 3.9; do CANDS="$CANDS /opt/homebrew/bin/python$v /usr/local/bin/python$v /Library/Frameworks/Python.framework/Versions/$v/bin/python3"; done
CANDS="$CANDS /opt/homebrew/bin/python3 /usr/local/bin/python3 /Library/Frameworks/Python.framework/Versions/Current/bin/python3"
for c in $CANDS; do ok_py "$c" && { PY="$c"; break; }; done
if [ -z "$PY" ]; then
  P=$(command -v python3 2>/dev/null)
  # /usr/bin/python3 без «средств командной строки» - заглушка, которая лишь вызывает окно установки. Берём её, только если средства есть.
  if [ -n "$P" ] && { [ "$P" != "/usr/bin/python3" ] || xcode-select -p >/dev/null 2>&1; }; then
    ok_py "$P" && PY="$P"
  fi
fi
if [ -z "$PY" ]; then
  echo "========================================================"
  echo " На Mac нужен бесплатный Python 3.9 или новее - он не найден."
  echo " Сейчас откроется страница python.org. Скачайте «macOS 64-bit universal2 installer»,"
  echo " установите (кнопки «Продолжить»), потом запустите start.command снова."
  echo "========================================================"
  log "python 3.9+ not found; macOS $(sw_vers -productVersion 2>/dev/null) $(uname -m)"
  open "https://www.python.org/downloads/macos/"
  pause; exit 1
fi

echo "Диагностика: macOS $(sw_vers -productVersion 2>/dev/null), $(uname -m), $("$PY" -V 2>&1), версия программы $(cat version.txt 2>/dev/null)"
log "start: macOS $(sw_vers -productVersion 2>/dev/null) $(uname -m) $("$PY" -V 2>&1) py=$PY ver=$(cat version.txt 2>/dev/null)"

# ---------- Окружение .venv ----------
if [ -d .venv ] && ! .venv/bin/python -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1; then
  echo "Окружение повреждено, создаю заново..."
  mv .venv ".venv.old.$(date +%s)" 2>/dev/null
fi
if [ ! -d .venv ]; then
  echo "Первый запуск: готовлю окружение (нужен интернет, 1-3 минуты, окно не закрывайте)..."
  if ! "$PY" -m venv .venv >data/venv.log 2>&1; then
    cat data/venv.log >>"$LOG"; tail -n 8 data/venv.log
    rm -rf .venv
    fail "не удалось создать окружение Python." "Установите Python с python.org (universal2) и запустите снова."
  fi
fi
# shellcheck disable=SC1091
source .venv/bin/activate || fail "не удалось включить окружение .venv." "Удалите папку .venv внутри KaspiWB и запустите снова."

# ---------- Библиотеки ----------
if ! python -c "import flask, openpyxl, PIL, requests, certifi" >/dev/null 2>&1; then
  echo "Устанавливаю библиотеки (нужен интернет)..."
  python -m pip install --quiet --upgrade pip >data/pip.log 2>&1
  if ! python -m pip install --quiet -r requirements.txt >>data/pip.log 2>&1; then
    { echo "--- pip install failed ---"; tail -n 40 data/pip.log; } >>"$LOG"
    if grep -qiE "Temporary failure|Connection|NameResolution|getaddrinfo|nodename|timed out|No matching distribution|Could not find a version|offline|Max retries" data/pip.log; then
      fail "не удалось скачать библиотеки: похоже, нет интернета или он блокирует pypi.org." "Проверьте Wi-Fi (откройте сайт в браузере), отключите VPN/прокси и запустите снова."
    elif grep -qiE "SSL|CERTIFICATE" data/pip.log; then
      fail "ошибка сертификатов при скачивании библиотек." "Откройте Finder → Программы → Python 3.x → дважды щёлкните «Install Certificates.command», потом запустите снова."
    else
      tail -n 8 data/pip.log
      fail "не удалось установить библиотеки (последние строки выше)." "Пришлите скриншот: нужна более новая версия Python с python.org."
    fi
  fi
fi

# Сертификаты: системный Python с python.org не видит корневые сертификаты, берём набор из certifi.
CA=$(python -c 'import certifi; print(certifi.where())' 2>/dev/null)
if [ -n "$CA" ] && [ -f "$CA" ]; then
  export SSL_CERT_FILE="$CA" REQUESTS_CA_BUNDLE="$CA"
fi

# ---------- Запуск ----------
echo
echo "Kaspi WB: запускаю локальный сервер. Окно не закрывайте, пока работаете."
echo "Браузер откроется сам. Если нет - откройте http://127.0.0.1:8790 вручную."
echo "Если на экране появится вопрос «принимать входящие подключения» - нажмите «Не разрешать» или «Разрешить», оба варианта подходят."
echo
RUNLOG="data/last_run.log"
python run.py 2> >(tee "$RUNLOG" >&2)
CODE=$?
sleep 0.3
if [ "$CODE" -ne 0 ]; then
  { echo "--- run.py exit code $CODE ---"; grep -v ' - - \[' "$RUNLOG" 2>/dev/null | tail -n 40; } >>"$LOG"
  echo
  echo "========================================================"
  echo " Программа остановилась с ошибкой (код $CODE). Последние строки:"
  grep -v ' - - \[' "$RUNLOG" 2>/dev/null | tail -n 10
  echo " Сделайте скриншот этого окна и пришлите Арману (подробности в data/error.log)."
  echo "========================================================"
else
  echo "Программа остановлена."
fi
pause
