"""Адреса владельца программы. Заполните после создания бесплатных сервисов (см. README в папке лицензий).
UPDATE_URL — ссылка на version.json (например https://raw.githubusercontent.com/<вы>/<репозиторий>/main/version.json).
REPORT_URL — адрес веб-приложения Google Apps Script, которое записывает активации в вашу таблицу."""
UPDATE_URL = "https://raw.githubusercontent.com/begimbetoffarman-lgtm/kaspiwb-updates/main/version.json"
REPORT_URL = "https://script.google.com/macros/s/AKfycbyCaJwuLBxJqyKGMb5nDMdVzflS7EHy-txF4xDYzh-utGhDXSzjW25D34i_davwgy7UEw/exec"
