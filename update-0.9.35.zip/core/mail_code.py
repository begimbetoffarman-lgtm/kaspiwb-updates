"""Автоматическое чтение кода входа Kaspi из Gmail (IMAP, пароль приложения).
Читаются ТОЛЬКО письма, где отправитель содержит «kaspi». Код и пароль нигде не логируются."""
import email
import email.utils
import imaplib
import json
import os
import re
import time
from email.header import decode_header, make_header

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _cfg():
    from core import secrets as _sec
    c = _sec.read_config()
    return (c.get("gmail_address") or "").strip(), (c.get("gmail_app_password") or "").replace(" ", "")


SERVERS = {"gmail.com": "imap.gmail.com", "googlemail.com": "imap.gmail.com",
           "mail.ru": "imap.mail.ru", "bk.ru": "imap.mail.ru", "inbox.ru": "imap.mail.ru", "list.ru": "imap.mail.ru",
           "yandex.ru": "imap.yandex.ru", "yandex.kz": "imap.yandex.ru", "ya.ru": "imap.yandex.ru",
           "outlook.com": "outlook.office365.com", "hotmail.com": "outlook.office365.com",
           "live.com": "outlook.office365.com", "icloud.com": "imap.mail.me.com", "yahoo.com": "imap.mail.yahoo.com"}


def _server(addr):
    """Свой сервер из настроек или по домену почты; иначе imap.<домен>."""
    from core import secrets as _sec
    custom = (_sec.read_config().get("mail_server") or "").strip()
    return custom or SERVERS.get(addr.split("@")[-1].lower(), "imap." + addr.split("@")[-1].lower())


def configured():
    a, p = _cfg()
    return bool(a and p)


def _text(msg):
    parts = []
    for part in (msg.walk() if msg.is_multipart() else [msg]):
        if part.get_content_type() in ("text/plain", "text/html"):
            try:
                parts.append(part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", "ignore"))
            except Exception:
                pass
    return re.sub(r"<[^>]+>", " ", " ".join(parts))


def _code_from(msg):
    subj = str(make_header(decode_header(msg.get("Subject", ""))))
    body = _text(msg)
    for src in (subj, body):          # сначала число рядом со словом «код»/code
        m = re.search(r"(?:код|code)\D{0,25}(?<!\d)(\d{4,6})(?!\d)", src, re.I)
        if m:
            return m.group(1)
    for src in (subj, body):
        m = re.search(r"(?<!\d)(\d{4,6})(?!\d)", src)
        if m:
            return m.group(1)
    return None


def _connect():
    addr, pwd = _cfg()
    if not (addr and pwd):
        raise RuntimeError("Почта не настроена (адрес и пароль приложения).")
    box = imaplib.IMAP4_SSL(_server(addr), 993, timeout=30)
    box.login(addr, pwd)
    box.select("INBOX", readonly=True)
    return box


def _kaspi_mails(box, since_ts):
    """[(время, письмо)] от Kaspi новее since_ts, свежие первыми."""
    day = time.strftime("%d-%b-%Y", time.gmtime(since_ts - 86400))
    typ, ids = box.search(None, "SINCE", day, "FROM", "kaspi")
    out = []
    for i in (ids[0].split() if typ == "OK" else [])[-15:]:
        typ, data = box.fetch(i, "(RFC822)")
        if typ != "OK":
            continue
        msg = email.message_from_bytes(data[0][1])
        ts = email.utils.mktime_tz(email.utils.parsedate_tz(msg.get("Date"))) if msg.get("Date") else 0
        if ts >= since_ts:
            out.append((ts, msg))
    return sorted(out, key=lambda x: x[0], reverse=True)


def fetch_code(since_ts, wait=90):
    """Ждёт письмо Kaspi с кодом (не старше since_ts). Возвращает код или None."""
    end = time.time() + wait
    while True:
        box = _connect()
        try:
            for ts, msg in _kaspi_mails(box, since_ts):
                c = _code_from(msg)
                if c:
                    return c
        finally:
            try:
                box.logout()
            except Exception:
                pass
        if time.time() > end:
            return None
        time.sleep(5)


def test():
    """Проверка подключения: сколько писем Kaspi за 7 дней и нашёлся ли код в последнем. Сам код не возвращается."""
    box = _connect()
    try:
        mails = _kaspi_mails(box, time.time() - 7 * 86400)
        return {"ok": True, "kaspi_mails_7d": len(mails), "code_found_in_latest": bool(mails and _code_from(mails[0][1]))}
    finally:
        try:
            box.logout()
        except Exception:
            pass
