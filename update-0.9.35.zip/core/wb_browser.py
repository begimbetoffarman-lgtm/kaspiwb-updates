"""Поиск на Wildberries через настоящий браузер (Edge/Chrome).

Wildberries блокирует обычные запросы из программ (403/498), но пускает браузер после короткой проверки.
Поэтому мы запускаем установленный на компьютере Edge или Chrome в отдельном профиле, открываем страницу поиска,
ждём, пока пройдёт проверка, и читаем карточки со страницы. Только стандартная библиотека Python.
"""
import base64
import json
import os
import re
import socket
import struct
import subprocess
import time
import urllib.parse
import urllib.request

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROFILE_DIR = os.path.join(BASE_DIR, "data", "wb_browser_profile")
PORT = 9339

BROWSER_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    # macOS
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
    os.path.expanduser("~/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
    # Linux
    "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser", "/usr/bin/microsoft-edge",
]


def find_browser():
    for p in BROWSER_PATHS:
        if os.path.exists(p):
            return p
    return None


class _WS:
    """Минимальный WebSocket-клиент (RFC 6455) для протокола DevTools."""

    def __init__(self, url, timeout=30):
        u = urllib.parse.urlparse(url)
        self.sock = socket.create_connection((u.hostname, u.port), timeout=timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (f"GET {u.path} HTTP/1.1\r\nHost: {u.hostname}:{u.port}\r\nUpgrade: websocket\r\n"
               f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n")
        self.sock.sendall(req.encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("DevTools: соединение закрыто")
            buf += chunk
        if b" 101 " not in buf.split(b"\r\n")[0]:
            raise ConnectionError("DevTools: рукопожатие отклонено")
        self._rest = buf.split(b"\r\n\r\n", 1)[1]
        self._id = 0

    def _read(self, n):
        while len(self._rest) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ConnectionError("DevTools: соединение закрыто")
            self._rest += chunk
        out, self._rest = self._rest[:n], self._rest[n:]
        return out

    def _send(self, text):
        data = text.encode("utf-8")
        head = bytearray([0x81])
        n = len(data)
        if n < 126:
            head.append(0x80 | n)
        elif n < 65536:
            head.append(0x80 | 126)
            head += struct.pack(">H", n)
        else:
            head.append(0x80 | 127)
            head += struct.pack(">Q", n)
        mask = os.urandom(4)
        head += mask
        self.sock.sendall(bytes(head) + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def _recv(self):
        payload = b""
        while True:
            b1, b2 = self._read(2)
            fin, op = b1 & 0x80, b1 & 0x0F
            n = b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._read(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._read(8))[0]
            data = self._read(n)
            if op == 0x8:
                raise ConnectionError("DevTools: закрыто браузером")
            if op in (0x9, 0xA):
                continue
            payload += data
            if fin:
                return payload.decode("utf-8", "replace")

    def call(self, method, params=None, timeout=30):
        self._id += 1
        mid = self._id
        self._send(json.dumps({"id": mid, "method": method, "params": params or {}}))
        self.sock.settimeout(timeout)
        while True:
            msg = json.loads(self._recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError(msg["error"].get("message", "ошибка DevTools"))
                return msg.get("result", {})

    def eval(self, expr, timeout=30):
        r = self.call("Runtime.evaluate", {"expression": expr, "returnByValue": True, "awaitPromise": True}, timeout)
        return r.get("result", {}).get("value")

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


def _http_json(url, method="GET", timeout=5):
    req = urllib.request.Request(url, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _ensure_browser():
    """Запускает браузер с отладочным портом (если ещё не запущен) и возвращает True/сообщение об ошибке."""
    try:
        _http_json(f"http://127.0.0.1:{PORT}/json/version", timeout=2)
        return None
    except Exception:
        pass
    exe = find_browser()
    if not exe:
        return "Не найден Microsoft Edge или Google Chrome. Установите один из них."
    os.makedirs(PROFILE_DIR, exist_ok=True)
    args = [exe, f"--remote-debugging-port={PORT}", f"--user-data-dir={PROFILE_DIR}", "--no-first-run",
            "--no-default-browser-check", "--disable-extensions", "--window-size=1200,900",
            "--lang=ru-RU", "about:blank"]
    try:
        subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        return f"Не удалось запустить браузер: {e}"
    for _ in range(40):
        time.sleep(0.5)
        try:
            _http_json(f"http://127.0.0.1:{PORT}/json/version", timeout=2)
            return None
        except Exception:
            continue
    return "Браузер не ответил. Закройте окна Edge/Chrome и повторите."


_EXTRACT_JS = r"""
(() => {
  const out = [];
  document.querySelectorAll('article.product-card').forEach(c => {
    const id = c.getAttribute('data-nm-id');
    if (!id) return;
    const link = c.querySelector('a[aria-label]');
    const name = (link && link.getAttribute('aria-label') || '').trim();
    const lines = c.innerText.split('\n').map(s => s.trim()).filter(Boolean);
    let brand = '';
    const si = lines.indexOf('/');
    if (si > 0) brand = lines[si - 1];
    const ins = c.querySelector('ins');
    const priceTxt = ins ? ins.textContent : '';
    const price = parseInt(priceTxt.replace(/[^0-9]/g, ''), 10) || 0;
    const txt = c.innerText;
    const rm = txt.match(/(\d[,.]\d)\s*[·•]\s*([\d\s\u00a0]+)\s*оцен/);
    const rating = rm ? parseFloat(rm[1].replace(',', '.')) : 0;
    const feedbacks = rm ? parseInt(rm[2].replace(/\D/g, ''), 10) : 0;
    const img = c.querySelector('img');
    out.push({id: parseInt(id, 10), name, brand, price_rub: price, rating, feedbacks, img: img ? img.src : ''});
  });
  return JSON.stringify({count: out.length, items: out, title: document.title, body: document.body ? document.body.innerText.slice(0, 300) : ''});
})()
"""


def search_wb(query, limit=50, status=None):
    """Возвращает (список карточек, текст ошибки). Карточка: id, name, brand, price_rub, rating, feedbacks."""
    err = _ensure_browser()
    if err:
        return [], err
    ws = None
    target_id = None
    items = {}
    try:
        page = 1
        while len(items) < limit and page <= 4:
            url = "https://www.wildberries.ru/catalog/0/search.aspx?" + urllib.parse.urlencode(
                {"search": query, "page": page, "sort": "popular"})
            if ws is None:
                tgt = _http_json("http://127.0.0.1:%d/json/new?%s" % (PORT, urllib.parse.quote(url, safe=":/?=&%")), method="PUT")
                target_id = tgt["id"]
                ws = _WS(tgt["webSocketDebuggerUrl"])
                ws.call("Page.enable")
            else:
                ws.call("Page.navigate", {"url": url})
            # ждём прохождения проверки браузера и появления карточек (до ~45 сек)
            got = None
            for _ in range(45):
                time.sleep(1)
                try:
                    raw = ws.eval(_EXTRACT_JS)
                    data = json.loads(raw) if raw else {}
                except Exception:
                    continue
                if data.get("count", 0) >= 8:
                    got = data
                    break
            if not got:
                if items:
                    break
                return [], "Wildberries не показал выдачу (проверка браузера не пройдена). Откройте окно браузера, пройдите проверку и повторите."
            # прокрутка, чтобы подгрузились все карточки страницы
            last = got["count"]
            for _ in range(8):
                ws.eval("window.scrollBy(0, document.body.scrollHeight)")
                time.sleep(1.2)
                data = json.loads(ws.eval(_EXTRACT_JS))
                if data["count"] <= last and data["count"] >= 40:
                    got = data
                    break
                last = data["count"]
                got = data
            for it in got["items"]:
                if it["price_rub"] > 0 and it["name"]:
                    items.setdefault(it["id"], it)
            page += 1
        return list(items.values())[: max(limit, 1) * 2], ""
    except Exception as e:
        return [], f"Ошибка работы с браузером: {e}"
    finally:
        if ws:
            ws.close()
        if target_id:
            try:
                _http_json(f"http://127.0.0.1:{PORT}/json/close/{target_id}", timeout=3)
            except Exception:
                pass
