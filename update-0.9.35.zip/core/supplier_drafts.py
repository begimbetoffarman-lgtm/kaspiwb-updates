"""Prepare all supplier variants locally for the existing Kaspi review workflow."""
import hashlib
import time
from core import kaspi_content as cards
from core import suppliers


def make(product, preorder_days, variant_ids=None):
    source = suppliers.source_name(product.get('source'))
    suppliers.product_url(source, product.get('url'))
    if source=='1688' and (isinstance(preorder_days, bool) or not isinstance(preorder_days, int) or not 1 <= preorder_days <= 30):
        raise ValueError('Предзаказ — от 1 до 30 календарных дней.')
    variants = product.get('variants')
    if not isinstance(variants, list) or not variants or len(variants) > 1000:
        raise ValueError('Не удалось получить полный список вариантов (от 1 до 1000).')
    if variant_ids is not None:
        if not isinstance(variant_ids,list) or not variant_ids:
            raise ValueError('Выберите варианты товара.')
        requested={str(i) for i in variant_ids}
        variants=[v for v in variants if str(v.get('id')) in requested]
        if {str(v.get('id')) for v in variants}!=requested:
            raise ValueError('Варианты не найдены в загруженном товаре.')
    prepared = []
    for variant in variants:
        days=preorder_days
        if source=='ozon':
            delivery=variant.get('delivery') or {}
            if not delivery.get('verified') or not isinstance(delivery.get('preorder_days'),int):
                raise ValueError(delivery.get('error') or 'Сначала проверьте срок доставки каждого выбранного варианта Ozon.')
            days=delivery['preorder_days']
            if not 1<=days<=30:raise ValueError('Срок Ozon должен укладываться в 30 дней.')
        identifier = str(variant.get('id') or '')
        if not identifier:
            raise ValueError('У варианта нет кода. Загрузите товар повторно.')
        # Ozon sku identifies a variant across every aspect page of that product.
        identity = source + '|' + identifier if source == 'ozon' else source + '|' + str(product['id']) + '|' + identifier
        digest = hashlib.sha256(identity.encode()).hexdigest()[:20]
        sku = ('CN' if source == '1688' else 'OZ') + digest
        image_list = list(dict.fromkeys([variant.get('image')] + product.get('images', [])))
        images = [u for u in image_list if isinstance(u, str) and u.startswith(('https://','http://'))]
        title = str(variant.get('name') or product.get('name') or '')
        if source == '1688' and product.get('name'):
            title += ' — ' + str(product['name'])
        d = {'sku': sku, 'source': source, 'source_url': variant.get('url') or product['url'],
             'source_product_id': str(product['id']), 'source_variant_id': identifier,
             'source_title': product.get('name'), 'source_variant': variant,
             'source_currency': product.get('currency'), 'source_checked_at': product.get('checked_at'),
             'source_attributes': product.get('attributes', []), 'source_images': images,
             'title': title.strip()[:200], 'brand': '', 'category': '', 'category_title': '',
             'category_suggestions': [], 'description': '', 'attributes': [], 'images': images[:10],
             'price': 0, 'cost': 0, 'preorder_days': days, 'status': 'draft',
             'created_at': time.strftime('%Y-%m-%d %H:%M:%S')}
        d['problems'], d['risks'] = cards.validate(d), cards.risks(d)
        prepared.append(d)
    if len({d['sku'] for d in prepared}) != len(prepared):
        raise ValueError('В вариантах повторяются коды. Загрузите товар повторно.')
    with cards._lock:
        drafts = cards.load_drafts()
        # Keep already issued 0.9.30 SKUs and manual edits, including sent cards.
        ozon_existing = {}
        for old in drafts:
            if old.get('source') == 'ozon' and old.get('source_variant_id'):
                ozon_existing.setdefault(str(old['source_variant_id']), old['sku'])
        for fresh in prepared:
            if source == 'ozon' and fresh['source_variant_id'] in ozon_existing:
                fresh['sku'] = ozon_existing[fresh['source_variant_id']]
        known = {d['sku'] for d in drafts}
        incoming = {d['sku']: d for d in prepared}
        for old in drafts:
            if old['sku'] in incoming:
                fresh = incoming[old['sku']]
                for key in ('source_variant', 'source_checked_at', 'source_attributes', 'source_images', 'source_url'):
                    old[key] = fresh[key]
                if source == 'ozon':
                    old['preorder_days'] = fresh['preorder_days']
                old['problems'], old['risks'] = cards.validate(old), cards.risks(old)
        added = [d for d in prepared if d['sku'] not in known]
        # Repeating import preserves manual edits and every moderation/sale state.
        cards.save_drafts(added + drafts)
    return {'success': True, 'created': len(added), 'existing': len(prepared)-len(added),
            'total_variants': len(prepared), 'skus': [d['sku'] for d in prepared]}
