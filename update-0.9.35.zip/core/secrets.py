"""Защищённое хранилище секретов (токен Kaspi API, пароль сотрудника, пароль почты, ключ RoyalTech).

Раньше всё это лежало в config.json открытым текстом. Теперь:
  Windows: шифрование DPAPI (привязано к учётной записи Windows) -> data/.secrets.bin
  Mac:     связка ключей macOS (команда security)
  запасной вариант: data/.secrets.json с правами только владельцу
Во всём коде читайте настройки ТОЛЬКО через read_config() и пишите через write_config(): секреты сами
уходят в хранилище, а в config.json остаются обычные настройки. Старые открытые значения переносятся
автоматически при первом чтении и удаляются из config.json."""
import base64
import json
import os
import subprocess
import sys
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE = os.path.join(ROOT, "config.json")
DATA_DIR = os.path.join(ROOT, "data")
DPAPI_FILE = os.path.join(DATA_DIR, ".secrets.bin")
PLAIN_FILE = os.path.join(DATA_DIR, ".secrets.json")
KC_SERVICE, KC_ACCOUNT = "KaspiWB-secrets", "KaspiWB"
_ENTROPY = b"KaspiWB-v1"

SECRET_KEYS = ("kaspi_api_token", "kaspi_cab_password", "gmail_app_password", "royaltech_api_key")

_lock = threading.RLock()
_cache = {"key": None, "data": None}


# ---------------------------------------------------------------- Windows DPAPI
def _dpapi(data, protect):
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    def mk(b):
        buf = ctypes.create_string_buffer(b, len(b))
        return BLOB(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    crypt32.CryptProtectData.argtypes = crypt32.CryptUnprotectData.argtypes = [
        ctypes.POINTER(BLOB), ctypes.c_void_p, ctypes.POINTER(BLOB), ctypes.c_void_p, ctypes.c_void_p,
        wintypes.DWORD, ctypes.POINTER(BLOB)]
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    bin_, keep1 = mk(data)
    ent, keep2 = mk(_ENTROPY)
    out = BLOB()
    fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    if not fn(ctypes.byref(bin_), None, ctypes.byref(ent), None, None, 0, ctypes.byref(out)):
        raise OSError("DPAPI error %d" % ctypes.GetLastError())
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


# ---------------------------------------------------------------- бэкенды
def _backend():
    if sys.platform == "win32":
        return "dpapi"
    if sys.platform == "darwin":
        return "keychain"
    return "plain"


def _restrict(path):
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass


def _read_backend(name):
    if name == "dpapi":
        if not os.path.exists(DPAPI_FILE):
            return None
        with open(DPAPI_FILE, "rb") as f:
            return json.loads(_dpapi(f.read(), False).decode("utf-8"))
    if name == "keychain":
        r = subprocess.run(["security", "find-generic-password", "-a", KC_ACCOUNT, "-s", KC_SERVICE, "-w"],
                           capture_output=True, text=True, timeout=20)
        if r.returncode != 0:
            return None
        return json.loads(base64.b64decode(r.stdout.strip()).decode("utf-8"))
    if os.path.exists(PLAIN_FILE):
        with open(PLAIN_FILE, encoding="utf-8") as f:
            return json.load(f)
    return None


def _write_backend(name, d):
    raw = json.dumps(d, ensure_ascii=True).encode("utf-8")
    os.makedirs(DATA_DIR, exist_ok=True)
    if name == "dpapi":
        tmp = DPAPI_FILE + ".tmp"
        with open(tmp, "wb") as f:
            f.write(_dpapi(raw, True))
        os.replace(tmp, DPAPI_FILE)
    elif name == "keychain":
        r = subprocess.run(["security", "add-generic-password", "-U", "-a", KC_ACCOUNT, "-s", KC_SERVICE,
                            "-w", base64.b64encode(raw).decode("ascii")], capture_output=True, text=True, timeout=20)
        if r.returncode != 0:
            raise OSError("keychain: " + (r.stderr or "")[:80])
    else:
        with open(PLAIN_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f)
        _restrict(PLAIN_FILE)


def _file_key():
    out = []
    for p in (DPAPI_FILE, PLAIN_FILE):
        try:
            s = os.stat(p)
            out.append((s.st_mtime_ns, s.st_size))
        except OSError:
            out.append(None)
    return tuple(out)


def _load_store():
    """Все секреты из хранилища (словарь). Не бросает исключений."""
    with _lock:
        key = _file_key()
        if _backend() != "keychain" and _cache["key"] == key and _cache["data"] is not None:
            return dict(_cache["data"])
        if _backend() == "keychain" and _cache["data"] is not None and _cache["key"] == key:
            return dict(_cache["data"])
        data = {}
        for name in dict.fromkeys([_backend(), "plain"]):          # основное, затем запасное
            try:
                d = _read_backend(name)
                if d:
                    for k, v in d.items():
                        data.setdefault(k, v)
            except Exception:
                continue
        _cache["key"], _cache["data"] = key, dict(data)
        return data


def _save_store(d):
    """Записывает секреты; возвращает True, если записали и прочитали обратно то же самое."""
    with _lock:
        d = {k: v for k, v in d.items() if v not in (None, "")}
        ok = False
        try:
            _write_backend(_backend(), d)
            if _backend() == "dpapi" or _backend() == "keychain":
                try:
                    os.remove(PLAIN_FILE)           # запасной файл больше не нужен
                except OSError:
                    pass
            ok = _read_backend(_backend()) == d or (not d)
        except Exception:
            ok = False
        if not ok and _backend() != "plain":         # основное недоступно: запасной вариант с ограниченными правами
            try:
                _write_backend("plain", d)
                ok = _read_backend("plain") == d
            except Exception:
                ok = False
        _cache["key"], _cache["data"] = None, None
        return ok


# ---------------------------------------------------------------- единый доступ к настройкам
def _raw(path=None):
    try:
        with open(path or CONFIG_FILE, encoding="utf-8-sig") as f:
            c = json.load(f)
            return c if isinstance(c, dict) else {}
    except Exception:
        return {}


def _write_raw(cfg, path=None):
    p = path or CONFIG_FILE
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
    _restrict(p)


def migrate(path=None):
    """Переносит открытые секреты из config.json в хранилище и удаляет их из файла. Возвращает список перенесённых ключей."""
    with _lock:
        raw = _raw(path)
        plain = {k: raw[k] for k in SECRET_KEYS if k in raw}
        if not plain:
            return []
        store = _load_store()
        for k, v in plain.items():
            if v not in (None, ""):
                store[k] = v          # открытое значение в файле появилось позже (запись старой версией или сбой хранилища): оно новее
        if not _save_store(store):
            return []                                 # не удалось сохранить: открытые копии остаются, ничего не теряем
        if _load_store() != {k: v for k, v in store.items() if v not in (None, "")}:
            return []
        for k in plain:
            raw.pop(k, None)
        _write_raw(raw, path)
        return list(plain)


def read_config(path=None):
    """config.json + секреты из хранилища одним словарём. Старые открытые значения переносятся автоматически."""
    with _lock:
        raw = _raw(path)
        if any(k in raw for k in SECRET_KEYS):
            try:
                migrate(path)
                raw = _raw(path)
            except Exception:
                pass
        if path in (None, CONFIG_FILE) or os.path.abspath(path) == os.path.abspath(CONFIG_FILE):
            raw.update({k: v for k, v in _load_store().items() if k in SECRET_KEYS})
        # если перенос не удался, открытые значения в raw остаются и работа не ломается
        return raw


def write_config(cfg, path=None):
    """Записывает настройки: секреты в хранилище, остальное в config.json. Ключ секрета, которого нет в cfg или он пустой, удаляется."""
    with _lock:
        cfg = dict(cfg)
        store = _load_store()
        changed = False
        for k in SECRET_KEYS:
            v = cfg.pop(k, None)
            if (v in (None, "")) != (store.get(k) in (None, "")) or (v not in (None, "") and store.get(k) != v):
                changed = True
                if v in (None, ""):
                    store.pop(k, None)
                else:
                    store[k] = v
        if changed and not _save_store(store):
            # хранилище недоступно: не теряем значения, оставляем их в файле
            for k in SECRET_KEYS:
                if store.get(k):
                    cfg[k] = store[k]
        _write_raw(cfg, path)


def get(key, default=""):
    v = read_config().get(key)
    return default if v in (None, "") else v


def has(key):
    return bool(str(get(key, "")).strip())


def backend_name():
    return {"dpapi": "Windows DPAPI", "keychain": "Связка ключей macOS", "plain": "файл с ограниченными правами"}[_backend()]


# ---------------------------------------------------------------- «Удалить мои данные»
KEEP_CONFIG = ("port", "update_url", "allowed_hosts", "report_url")


def wipe_all():
    """Стирает секреты, настройки магазина и папку data/. Файл лицензии и скрытые служебные файлы лицензии остаются
    (иначе удаление данных обнуляло бы пробный период). Возвращает {"removed": число объектов, "errors": [...]}."""
    import shutil
    removed, errors = 0, []
    with _lock:
        for name in dict.fromkeys([_backend(), "plain"]):
            try:
                if name == "keychain":
                    subprocess.run(["security", "delete-generic-password", "-a", KC_ACCOUNT, "-s", KC_SERVICE],
                                   capture_output=True, timeout=20)
                elif name == "dpapi":
                    if os.path.exists(DPAPI_FILE):
                        os.remove(DPAPI_FILE); removed += 1
                elif os.path.exists(PLAIN_FILE):
                    os.remove(PLAIN_FILE); removed += 1
            except Exception as e:
                errors.append(str(e)[:80])
        raw = _raw()
        keep = {k: v for k, v in raw.items() if k in KEEP_CONFIG}
        try:
            _write_raw(keep)
        except Exception as e:
            errors.append(str(e)[:80])
        if os.path.isdir(DATA_DIR):
            for n in os.listdir(DATA_DIR):
                if n.startswith("."):            # .license.json, .blocked.json и др. служебные файлы лицензии
                    continue
                p = os.path.join(DATA_DIR, n)
                try:
                    if os.path.isdir(p):
                        shutil.rmtree(p)
                    else:
                        os.remove(p)
                    removed += 1
                except Exception as e:
                    errors.append(n + ": " + str(e)[:60])
        _cache["key"], _cache["data"] = None, None
    return {"removed": removed, "errors": errors}
