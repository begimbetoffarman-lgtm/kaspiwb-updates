import urllib.request
import json
import ssl
import time
import os

CTX = ssl._create_unverified_context()
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

def check_account(api_key: str) -> dict:
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
        'User-Agent': USER_AGENT
    }
    req = urllib.request.Request('https://api.royaltechno.cc/v1/account', headers=headers)
    with urllib.request.urlopen(req, context=CTX, timeout=12) as resp:
        return json.loads(resp.read().decode('utf-8'))

def is_valid_image_url(url: str) -> bool:
    if not url:
        return False
    try:
        req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT}, method='HEAD')
        with urllib.request.urlopen(req, context=CTX, timeout=2.5) as r:
            return r.status == 200
    except Exception:
        return False

def generate_product_photo(api_key: str, reference_image_url: str = None, prompt_text: str = None, aspect_ratio: str = "portrait") -> dict:
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
        'User-Agent': USER_AGENT
    }
    
    if not prompt_text:
        prompt_text = (
            "Professional commercial product photography of the exact item shown in the reference image. "
            "Isolated on an ultra-clean warm-white minimalist studio podium, soft diffuse morning sunlight with delicate realistic shadow, "
            "crisp sharp focus on textures and fine details, 8k resolution, Apple commercial catalog standard, luxury aesthetic"
        )
        
    ref_urls = []
    if reference_image_url and is_valid_image_url(reference_image_url):
        ref_urls.append(reference_image_url)
        
    payload = {
        "model": "nano-banana-pro",
        "input": {
            "prompt": prompt_text,
            "reference_image_urls": ref_urls,
            "aspect_ratio": aspect_ratio
        }
    }
    
    req = urllib.request.Request(
        'https://api.royaltechno.cc/v1/jobs',
        data=json.dumps(payload).encode('utf-8'),
        headers=headers,
        method='POST'
    )
    
    with urllib.request.urlopen(req, context=CTX, timeout=15) as resp:
        job_data = json.loads(resp.read().decode('utf-8'))
        job_id = job_data.get('id')
        
    if not job_id:
        raise Exception("Failed to get job ID from RoyalTech API")
        
    # Poll status
    for _ in range(35):
        time.sleep(4)
        poll_req = urllib.request.Request(
            f'https://api.royaltechno.cc/v1/jobs/{job_id}',
            headers=headers,
            method='GET'
        )
        try:
            with urllib.request.urlopen(poll_req, context=CTX, timeout=15) as resp:
                poll_data = json.loads(resp.read().decode('utf-8'))
                status = poll_data.get('status')
                if status == 'succeeded':
                    output_url = poll_data.get('output', {}).get('url')
                    return {
                        "success": True,
                        "job_id": job_id,
                        "url": output_url
                    }
                elif status in ['failed', 'error']:
                    return {
                        "success": False,
                        "error": poll_data.get('error', 'Job failed')
                    }
        except Exception:
            continue
            
    return {"success": False, "error": "Generation timed out"}

def download_file(url: str, save_path: str):
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    with urllib.request.urlopen(req, context=CTX, timeout=25) as resp:
        with open(save_path, 'wb') as f:
            f.write(resp.read())
    return save_path
