"""Сравнение фото по «отпечатку» (dHash): находит карточки Kaspi с той же картинкой, что у товара на WB,
даже если название другое. Отпечаток устойчив к смене размера и сжатию, но не к сильной обрезке и надписям поверх."""
import io
import ssl
import urllib.request
from concurrent.futures import ThreadPoolExecutor

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
SAME_MAX_DIST = 10          # из 64 бит: до 10 отличий считаем той же картинкой


def dhash_bytes(data, size=8):
    """64-битный отпечаток картинки (целое число) или None, если картинку не прочитать."""
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(data)).convert("L").resize((size + 1, size), Image.LANCZOS)
        px = list(im.getdata())
        bits = 0
        for row in range(size):
            for col in range(size):
                bits = (bits << 1) | (1 if px[row * (size + 1) + col] > px[row * (size + 1) + col + 1] else 0)
        return bits
    except Exception:
        return None


def hamming(a, b):
    return bin(a ^ b).count("1")


def fetch(url, timeout=6):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "image/*"})
        # открытые картинки без секретов; у CDN Wildberries бывает самоподписанный сертификат, как и в остальном коде программы
        with urllib.request.urlopen(req, timeout=timeout, context=ssl._create_unverified_context()) as r:
            return r.read(2_000_000)
    except Exception:
        return None


def hash_url(url):
    data = fetch(url) if url else None
    return dhash_bytes(data) if data else None


def hash_urls(urls, workers=8):
    """Отпечатки для списка ссылок (параллельно), в том же порядке; None там, где не вышло."""
    if not urls:
        return []
    with ThreadPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(hash_url, urls))


def same_photo(h, ref_hashes):
    """Минимальное расстояние между отпечатком h и любым из ref_hashes (None, если сравнивать не с чем)."""
    if h is None:
        return None
    ds = [hamming(h, r) for r in ref_hashes if r is not None]
    return min(ds) if ds else None
