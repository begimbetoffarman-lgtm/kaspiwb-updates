"""
Создание карточек Kaspi из товаров Wildberries через ОФИЦИАЛЬНЫЙ API Kaspi
(https://kaspi.kz/shop/api/products/...), токен — тот же, что в настройках (kaspi_api_token).

Поток: товар WB -> card.json с WB (фото, описание, характеристики, предмет)
       -> черновик карточки (категория Kaspi, обязательные характеристики, фото)
       -> проверка -> POST /products/import -> статус/результат модерации.
После успешной отправки товар добавляется в прайс (свой магазин) с ценой и предзаказом.
"""
import hashlib
import json
import math
import os
import re
import threading
import time
import urllib.parse
import urllib.request

from core import kaspi_store as ks

API = "https://kaspi.kz/shop/api/products"
DRAFTS_FILE = os.path.join(ks.DATA_DIR, "kaspi_card_drafts.json")
CATS_FILE = os.path.join(ks.DATA_DIR, "kaspi_categories.json")
ATTR_DIR = os.path.join(ks.DATA_DIR, "kaspi_attr_cache")
UA = ks.USER_AGENT
_lock = threading.RLock()
_basket_by_vol = {}


# ---------------------------------------------------------------- Kaspi API
def _token():
    t = ks._config_value("kaspi_api_token", "").strip()
    if not t:
        raise RuntimeError("Не указан Kaspi API токен (Настройки & API).")
    return t


def _kaspi(path, method="GET", body=None, timeout=40):
    headers = {"X-Auth-Token": _token(), "Accept": "application/json", "User-Agent": UA}
    data = None
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "text/plain"   # так требует документация Kaspi
    req = urllib.request.Request(API + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        msg = e.read().decode("utf-8", "replace")[:800]
        raise RuntimeError(f"Kaspi API {e.code}: {msg}")
    return json.loads(raw) if raw.strip() else {}


def categories(force=False):
    if not force and os.path.exists(CATS_FILE) and time.time() - os.path.getmtime(CATS_FILE) < 7 * 86400:
        with open(CATS_FILE, encoding="utf-8") as f:
            return json.load(f)
    cats = _kaspi("/classification/categories")
    ks._atomic_json_write(CATS_FILE, cats)
    return cats


def _attr_cache_path(cat):
    return os.path.join(ATTR_DIR, hashlib.md5(cat.encode("utf-8")).hexdigest() + ".json")


def attributes(cat):
    """Характеристики категории + допустимые значения для enum (кэш 7 дней)."""
    p = _attr_cache_path(cat)
    if os.path.exists(p) and time.time() - os.path.getmtime(p) < 7 * 86400:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    q = urllib.parse.quote(cat)
    attrs = _kaspi(f"/classification/attributes?c={q}")
    for a in attrs:
        if a.get("type") == "enum":
            try:
                a["values"] = _kaspi(f"/classification/attribute/values?c={q}&a={urllib.parse.quote(a['code'])}")
            except Exception as e:
                a["values"] = []
                a["values_error"] = str(e)
    os.makedirs(ATTR_DIR, exist_ok=True)
    ks._atomic_json_write(p, attrs)
    return attrs


# ---------------------------------------------------------------- WB card
def _basket_guess(vol):
    from core.wb_parser import get_basket_number
    return get_basket_number(vol)


def wb_card(wb_id):
    wb_id = int(wb_id)
    vol, part = wb_id // 100000, wb_id // 1000
    tried = []
    order = [_basket_by_vol.get(vol), _basket_guess(vol)] + list(range(1, 61))
    for b in order:
        if not b or b in tried:
            continue
        tried.append(b)
        host = f"https://basket-{b:02d}.wbbasket.ru/vol{vol}/part{part}/{wb_id}"
        try:
            req = urllib.request.Request(host + "/info/ru/card.json", headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=6) as r:
                card = json.loads(r.read().decode("utf-8"))
        except Exception:
            continue
        _basket_by_vol[vol] = b
        n = int((card.get("media") or {}).get("photo_count") or 1)
        card["_images"] = [f"{host}/images/big/{i}.webp" for i in range(1, min(n, 10) + 1)]
        return card
    raise RuntimeError(f"Карточка WB {wb_id} не найдена (WB не отдал card.json)")


# ---------------------------------------------------------------- matching
def _words(s):
    return [w for w in re.findall(r"[a-zа-яё0-9]+", (s or "").lower()) if len(w) >= 3]


def _stem(w):
    return w[:5] if len(w) > 5 else w


def suggest_categories(text_main, text_extra="", limit=8):
    """Подсказка категорий: совпадение слов из предмета/названия WB с названием категории Kaspi.
    Это только подсказка — категорию всегда подтверждает человек."""
    main = {_stem(w) for w in _words(text_main)}
    extra = {_stem(w) for w in _words(text_extra)} - main
    scored = []
    for c in categories():
        tw = {_stem(w) for w in _words(c.get("title"))}
        if not tw:
            continue
        hit_main, hit_extra = len(tw & main), len(tw & extra)
        if not hit_main:
            continue
        precision = (hit_main + 0.5 * hit_extra) / len(tw)
        scored.append((3 * hit_main + hit_extra + 4 * precision, c))
    scored.sort(key=lambda x: -x[0])
    return [c for _, c in scored[:limit]]


def search_categories(q, limit=30):
    q = (q or "").lower().strip()
    if not q:
        return []
    return [c for c in categories() if q in c["title"].lower() or q in c["code"].lower()][:limit]


def _contains(hay, value):
    """Совпадение только целыми словами: 'one x' не найдётся внутри 'iphone xs'."""
    v = value.lower().strip()
    tail = r"[а-яё]{0,4}" if (len(v) >= 5 and " " not in v and re.fullmatch(r"[а-яё]+", v)) else ""
    return re.search(r"(?<![a-zа-яё0-9])" + re.escape(v) + tail + r"(?![a-zа-яё0-9])", hay) is not None


def _wb_opts(card):
    return {o.get("name", "").lower(): str(o.get("value", "")) for o in (card.get("options") or [])}


def model_from_title(title):
    """Kaspi сам собирает название карточки: «Тип + Бренд + Модель + …». Поэтому в «Модель» кладём
    смысловую часть названия без первого слова (типа товара) и без количества/цвета после запятой."""
    t = re.split(r",|\s\d+\s?шт", title or "")[0].strip()
    words = t.split()
    m = " ".join(words[1:]) if len(words) > 1 else t
    return (m or title or "")[:60].strip()


_GENERIC = {"нет", "да", "другой", "другое", "прочее", "прочие", "иное"}
_NUM_MAP = {  # характеристика Kaspi -> поля WB (в тех же единицах, что обычно у Kaspi: см, кг, шт)
    # только размеры самого товара: размеры упаковки WB — не размеры товара
    "length": ("длина предмета", "глубина предмета"),
    "depth": ("глубина предмета", "длина предмета"),
    "width": ("ширина предмета",),
    "height": ("высота предмета",),
    "weight": ("вес товара без упаковки (г)", "вес с упаковкой (кг)"),
    "amount in a package": ("количество предметов в упаковке (шт.)", "количество предметов в упаковке"),
    "quantity": ("количество предметов в упаковке (шт.)", "количество предметов в упаковке"),
    "volume": ("объем", "объем (л)", "объем (мл)"),
}


def autofill(attrs, card, title):
    """Заполняет то, что можно честно вывести из данных WB. Остальное — пусто (решает человек)."""
    opts = _wb_opts(card)
    colors = (card.get("nm_colors_names") or "").lower()
    hay_title = (title + " " + (card.get("imt_name") or "") + " " + (card.get("subj_name") or "")).lower()
    hay_all = hay_title + " " + " ".join(f"{k} {v}" for k, v in opts.items()).lower()
    out = []
    for a in attrs:
        code, typ = a["code"], a.get("type")
        val, src = None, ""
        leaf = code.split("*")[-1].lower()
        if typ == "enum" and a.get("values"):
            names = [v["name"] for v in a["values"] if v.get("name")]
            pool = colors if "color" in leaf else hay_all
            hits = [n for n in names if n.lower() not in _GENERIC and not re.fullmatch(r"[\d\s.,/x×-]+", n)
                    and _contains(pool, n)]
            if not hits and "color" not in leaf:
                hits = [n for n in names if _contains(hay_title, n)]
            hits.sort(key=len, reverse=True)
            # 'iPhone X' внутри уже найденного 'iPhone Xs Max' — не отдельное значение
            hits = [h for i, h in enumerate(hits) if not any(_contains(o.lower(), h) for o in hits[:i])]
            if hits:
                val = hits if a.get("multiValued") else hits[0]
                if a.get("multiValued"):
                    val = list(dict.fromkeys(val))[:5]
                src = "WB"
        elif typ == "string":
            if leaf in ("code", "vendor code", "article", "manufacturers code", "manufacturer code") and card.get("vendor_code"):
                val, src = str(card["vendor_code"])[:256], "WB артикул продавца"
            elif leaf == "model":
                val, src = model_from_title(title), "из названия"
            elif "manufacturer" in leaf and card.get("vendor_code"):
                val, src = str(card["vendor_code"])[:256], "WB артикул продавца"
            elif leaf in ("size", "dimensions", "размер"):
                dims = [opts.get(k, "") for k in ("ширина предмета", "глубина предмета", "высота предмета")]
                dims = [re.sub(r"[^\d.,]", "", d) for d in dims if d]
                if len(dims) >= 2:
                    val, src = "x".join(dims) + " см", "WB габариты"
            elif "additional" in leaf and card.get("contents"):
                val, src = ("Комплектация: " + card["contents"])[:256], "WB комплектация"
        elif typ == "number":
            keys = _NUM_MAP.get(leaf, ())
            for k in keys:
                if opts.get(k):
                    m = re.search(r"[\d]+(?:[.,]\d+)?", opts[k])
                    if m:
                        val, src = float(m.group(0).replace(",", ".")), "WB: " + k
                        if val.is_integer():
                            val = int(val)
                        break
        out.append({"code": code, "type": typ, "mandatory": bool(a.get("mandatory")),
                    "multiValued": bool(a.get("multiValued")), "value": val, "source": src})
    return out


_WB_JUNK = re.compile(r"(wildberries|вайлдберриз|валдберис|\bwb\b|\bвб\b|https?://\S+|#\S+)", re.I)


def clean_description(card):
    d = _WB_JUNK.sub("", card.get("description") or "")
    d = re.sub(r"[ \t]+", " ", d).strip()
    specs = []
    for o in (card.get("options") or [])[:25]:
        n, v = o.get("name"), o.get("value")
        if n and v and not _WB_JUNK.search(f"{n} {v}"):
            specs.append(f"- {n}: {v}")
    txt = d
    if specs:
        txt += "\n\nХарактеристики:\n" + "\n".join(specs)
    return txt[:7000].strip() or (card.get("imt_name") or "")


# ---------------------------------------------------------------- drafts
def load_drafts():
    with _lock:
        if not os.path.exists(DRAFTS_FILE):
            return []
        with open(DRAFTS_FILE, encoding="utf-8") as f:
            return json.load(f)


def save_drafts(drafts):
    with _lock:
        ks._atomic_json_write(DRAFTS_FILE, drafts)


def _find(drafts, sku):
    for d in drafts:
        if d["sku"] == sku:
            return d
    return None


def make_draft(wb_item):
    """wb_item — элемент из каталога радара (id, name, brand, kaspi_price, cost_total, ai_cdn_url...)."""
    wb_id = int(wb_item.get("id") or wb_item.get("wb_id"))
    card = wb_card(wb_id)
    brand = ((card.get("selling") or {}).get("brand_name") or wb_item.get("brand") or "").strip()
    base = card.get("imt_name") or wb_item.get("name") or ""
    color = (card.get("nm_colors_names") or "").split(",")[0].strip()
    title = " ".join(x for x in [brand, base, color] if x)[:200]
    extra = " ".join([card.get("subj_root_name", ""), card.get("contents", ""), (card.get("description") or "")[:600]])
    sugg = suggest_categories(f"{card.get('subj_name','')} {base}", extra)
    cat = sugg[0]["code"] if sugg else ""
    attrs = autofill(attributes(cat), card, title) if cat else []
    images = []
    if wb_item.get("ai_cdn_url"):
        images.append(wb_item["ai_cdn_url"])
    images += card["_images"]
    d = {
        "sku": f"WB{wb_id}",
        "wb_id": wb_id,
        "wb_url": f"https://www.wildberries.ru/catalog/{wb_id}/detail.aspx",
        "wb_subject": card.get("subj_name", ""),
        "title": title,
        "brand": brand,
        "category": cat,
        "category_title": sugg[0]["title"] if sugg else "",
        "category_suggestions": sugg,
        "description": clean_description(card),
        "attributes": attrs,
        "images": images[:10],
        "price": int(wb_item.get("kaspi_price") or 0),
        "cost": int(wb_item.get("cost_total") or wb_item.get("total_cost") or 0),
        "preorder_days": int(ks._config_value("preorder_days", 7) or 7),
        "status": "draft",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    d["problems"] = validate(d)
    d["risks"] = risks(d)
    with _lock:
        drafts = load_drafts()
        old = _find(drafts, d["sku"])
        if old and old.get("status") in ("sent", "accepted"):
            return old                       # не перетираем уже отправленную
        drafts = [x for x in drafts if x["sku"] != d["sku"]]
        drafts.insert(0, d)
        save_drafts(drafts)
    return d


def set_category(sku, cat):
    with _lock:
        drafts = load_drafts()
        d = _find(drafts, sku)
        if not d:
            raise RuntimeError("Черновик не найден")
        title = next((c["title"] for c in categories() if c["code"] == cat), "")
        if not title:
            raise RuntimeError("Такой категории Kaspi нет")
        card = wb_card(d["wb_id"]) if d.get("wb_id") else {}
        d["category"], d["category_title"] = cat, title
        d["attributes"] = autofill(attributes(cat), card, d["title"])
        d["problems"] = validate(d)
        d["risks"] = risks(d)
        save_drafts(drafts)
        return d


def update_draft(sku, fields):
    allowed = {"title", "brand", "description", "images", "price", "cost", "preorder_days"}
    with _lock:
        drafts = load_drafts()
        d = _find(drafts, sku)
        if not d:
            raise RuntimeError("Черновик не найден")
        for k, v in fields.items():
            if k in allowed:
                if k == 'preorder_days' and d.get('source') == 'ozon':
                    continue
                d[k] = v
        if "attributes" in fields:                     # {code: value}
            for a in d["attributes"]:
                if a["code"] in fields["attributes"]:
                    v = fields["attributes"][a["code"]]
                    if a["type"] == "boolean" and isinstance(v, str):
                        v = {"true": True, "false": False}.get(v.lower(), None)
                    if a["type"] == "number" and isinstance(v, str):
                        try:
                            v = float(v.replace(",", "."))
                        except ValueError:
                            v = None
                    if v in ("", [], None):
                        v = None
                    a["value"], a["source"] = v, ("вручную" if v is not None else "")
        if d.get("status") in ("error", "rejected"):
            d["status"] = "draft"
        d["problems"] = validate(d)
        d["risks"] = risks(d)
        save_drafts(drafts)
        return d


def delete_draft(sku):
    with _lock:
        save_drafts([d for d in load_drafts() if d["sku"] != sku])


def validate(d):
    p = []
    if d.get('source') in ('1688', 'ozon'):
        if re.search(r'[\u3400-\u9fff]', str(d.get('title') or '') + str(d.get('description') or '')):
            p.append('Переведите название и описание на русский')
        try:
            cost = float(d.get('cost') or 0)
            if not math.isfinite(cost) or cost <= 0:
                p.append('Укажите себестоимость с доставкой')
            days = float(d.get('preorder_days') or 0)
            if not days.is_integer() or not 1 <= days <= 30:
                p.append('Предзаказ должен быть от 1 до 30 дней')
        except (ValueError, TypeError):
            p.append('Проверьте себестоимость и срок предзаказа')
        variant = d.get('source_variant') or {}
        if d.get('source') == 'ozon':
            delivery = variant.get('delivery') or {}
            if not delivery.get('verified') or d.get('preorder_days') != delivery.get('preorder_days'):
                p.append('Повторно загрузите вариант Ozon для автоматического срока доставки')
        if variant.get('stock') == 0 or variant.get('availability') == 'outOfStock':
            p.append('Этот вариант отсутствовал у поставщика при загрузке')
    if not d.get("category"):
        p.append("Не выбрана категория Kaspi")
    if not (d.get("title") or "").strip():
        p.append("Пустое название")
    if not (d.get("brand") or "").strip():
        p.append("Не указан бренд")
    if not d.get("images"):
        p.append("Нет фото")
    if not (d.get("description") or "").strip():
        p.append("Нет описания")
    if int(d.get("price") or 0) <= 0:
        p.append("Не указана цена продажи")
    for a in d.get("attributes", []):
        if a["mandatory"] and a["value"] in (None, "", []):
            p.append("Не заполнена характеристика: " + a["code"].split("*")[-1])
    return p


def kaspi_image_url(u):
    """Kaspi принимает только JPG/JPEG/PNG. Фото WB — .webp, поэтому отдаём их Kaspi через
    публичный конвертер wsrv.nl (возвращает настоящий JPEG). Kaspi скачивает фото один раз при загрузке."""
    if re.search(r"\.webp(\?|$)", u, re.I) or "wbbasket.ru" in u:
        return "https://wsrv.nl/?url=" + urllib.parse.quote(u, safe="") + "&output=jpg&q=90"
    return u


def risks(d):
    """Не блокирует отправку, но предупреждает о частых причинах отказа модерации Kaspi."""
    r = []
    if d.get('source') in ('1688', 'ozon'):
        v = d.get('source_variant') or {}
        r.append('Проверьте наличие, минимальную партию, цену за единицу, упаковку и срок доставки поставщика.')
        if v.get('min_quantity') and v['min_quantity'] > 1:
            r.append('Минимальный заказ у поставщика: ' + str(v['min_quantity']) + '.')
    text = f"{d.get('title','')} {d.get('category_title','')}".lower()
    if re.search(r"набор|комплект из|подар", text) or "наборы" in text:
        r.append("Слова «набор/подарок» или категория «Наборы…»: Kaspi запрещает наборы, собранные не производителем "
                 "или из несвязанных товаров. Лучше обычная категория товара и название без «набор».")
    # Реальный отказ Kaspi «Такой набор запрещен»: в названии не было слова «набор», но было «7 шт».
    m = re.search(r"(?<![\d.,xх×])(\d{1,3})\s*(?:шт|штук|предмет|элемент|пар|в\s*1)\b", text)
    if (m and int(m.group(1)) >= 2) or re.search(r"\bсет\b|\bкомплект\b", text):
        r.append("В названии несколько штук («7 шт», «комплект», «сет»): Kaspi часто отклоняет такое как запрещённый набор. "
                 "Продавайте одну штуку: уберите количество из названия и поставьте цену за 1 шт.")
    if re.search(r"подарок|в подарок|акция|скидк|хит продаж|лучший", (d.get("description") or "").lower()):
        r.append("В описании есть рекламные слова (подарок/акция/лучший) — Kaspi их не любит, уберите.")
    b = (d.get("brand") or "").strip().lower()
    if b and b not in ("без бренда", "noname", "no name"):
        r.append(f"Бренд «{d.get('brand')}» — бренд поставщика. Если это не ваш товар этого бренда, Kaspi может запросить документы.")
    return r


def payload(d):
    attrs = [{"code": a["code"], "value": a["value"]} for a in d["attributes"] if a["value"] not in (None, "", [])]
    return {
        "sku": d["sku"],
        "title": d["title"].strip()[:1024],
        "brand": d["brand"].strip()[:256],
        "category": d["category"],
        "description": d["description"][:7000],
        "attributes": attrs,
        "images": [{"url": kaspi_image_url(u)} for u in dict.fromkeys(d["images"]) if u.startswith("http")][:10],
    }


def send(skus):
    """Отправляет готовые (без проблем) черновики одним запросом. Возвращает код загрузки Kaspi."""
    with _lock:
        drafts = load_drafts()
        ready, blocked = [], []
        for s in skus:
            d = _find(drafts, s)
            if not d:
                continue
            d["problems"] = validate(d)
            (blocked if d["problems"] else ready).append(d)
        if not ready:
            save_drafts(drafts)
            return {"success": False, "error": "Нет готовых карточек: у выбранных есть незаполненные поля.",
                    "blocked": [b["sku"] for b in blocked]}
        resp = _kaspi("/import", method="POST", body=[payload(d) for d in ready])
        code = resp.get("code") if isinstance(resp, dict) else None
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for d in ready:
            d.update({"status": "sent", "import_code": code, "sent_at": now, "kaspi_response": resp})
        save_drafts(drafts)
    # в прайс: цена + предзаказ (Kaspi покажет оффер, когда карточка пройдёт модерацию)
    for d in ready:
        if d.get('source') in ('1688', 'ozon'):
            ks.add_product_from_supplier(d)
            continue
        ks.add_product_from_wb({"id": d["wb_id"], "kaspi_name": d["title"], "brand": d.get("brand"), "cost_total": d.get("cost") or 0,
                                "kaspi_price": d["price"], "category": d.get("category_title"),
                                "img_main": d["images"][0] if d["images"] else ""},
                               preorder_days=int(d.get("preorder_days") or 7))
    return {"success": True, "import_code": code, "sent": [d["sku"] for d in ready],
            "blocked": [b["sku"] for b in blocked], "kaspi_response": resp}


def refresh_status():
    """Опрашивает Kaspi по всем отправленным загрузкам."""
    drafts = load_drafts()
    codes = {d.get("import_code") for d in drafts if d.get("status") == "sent" and d.get("import_code")}
    report = {}
    for code in codes:
        q = urllib.parse.quote(str(code))
        try:
            st = _kaspi(f"/import?i={q}")
            res = _kaspi(f"/import/result?i={q}")
        except Exception as e:
            report[code] = {"error": str(e)}
            continue
        report[code] = {"status": st, "result": res}
        finished = str((st or {}).get("status") or "").upper() == "FINISHED"
        per_sku = (res or {}).get("result") or {}
        with _lock:
            fresh = load_drafts()
            for d in fresh:
                if d.get("import_code") != code:
                    continue
                d["kaspi_status"], d["checked_at"] = st, time.strftime("%Y-%m-%d %H:%M:%S")
                r = per_sku.get(d["sku"]) or {}
                d["kaspi_result"] = r or res
                if r.get("errors") or str(r.get("state", "")).upper() == "ERRORS":
                    d["status"], d["kaspi_errors"] = "error", (r.get("errors") or []) + (r.get("warnings") or [])
                elif finished and str(r.get("state", "")).upper() == "FINISHED":
                    d["status"], d["kaspi_errors"] = "accepted", []
            save_drafts(fresh)
    return report


# ---------------------------------------------------------------- после модерации: сразу в продажу
def autosale(manual=True):
    """Карточки, загруженные в Kaspi, проверяются в кабинете (через сотрудника). Как только Kaspi создал
    товар (появился код карточки) — выставляем его в продажу с ценой и предзаказом из черновика.
    Возвращает отчёт. Без подключённого сотрудника ничего не делает."""
    from core import kaspi_cabinet as kcab
    rep = {"checked": 0, "put_on_sale": [], "waiting": [], "on_sale": [], "errors": []}
    drafts = load_drafts()
    todo = [d for d in drafts if d.get("status") in ("accepted", "selling")]
    if not todo:
        return rep
    if not kcab.status().get("connected"):
        try:
            kcab._ensure(allow_login=manual)
        except Exception as e:
            rep["errors"].append(f"Кабинет не подключён: {e}")
            return rep
    for d in todo:
        rep["checked"] += 1
        sku = d["sku"]
        try:
            o = kcab.get_offer(sku)
        except Exception as e:
            rep["waiting"].append(sku)
            d["sale_note"] = f"Kaspi ещё не создал товар (модерация): {e}"[:200]
            continue
        d["card_code"] = o.get("card_code") or d.get("card_code")
        d["kaspi_title"] = o.get("title") or d.get("kaspi_title")
        if d["status"] == "accepted":
            if not o.get("card_code"):
                rep["waiting"].append(sku)
                d["sale_note"] = "Ждём модерацию Kaspi"
                continue
            try:
                from core import wb_tracker
                wd = wb_tracker.wb_preorder_days(d.get("wb_id")) if d.get("wb_id") else None
                if wd:
                    d["preorder_days"] = wd
                kcab.set_offer(sku, price=int(d.get("price") or 0), preorder_days=int(d.get("preorder_days") or 7),
                               available=True, stock=1 if d.get('source') in ('1688', 'ozon') else 10, model=o.get("title") or d["title"])
                d["status"], d["sale_sent_at"] = "selling", time.strftime("%Y-%m-%d %H:%M:%S")
                d["sale_note"] = "Отправлено в продажу, Kaspi применит в течение часа"
                rep["put_on_sale"].append(sku)
            except Exception as e:
                d["sale_note"] = f"Не удалось выставить: {e}"[:300]
                rep["errors"].append(f"{sku}: {e}")
        else:  # selling — проверяем, что покупатель видит товар
            pub = kcab.public_offer(o["card_code"]) if o.get("card_code") else None
            if pub and not o.get("pending"):
                d["status"] = "on_sale"
                d["shop"] = pub
                d["shop_url"] = f"https://kaspi.kz/shop/p/-{o['card_code']}/"
                d["sale_note"] = f"В продаже: {pub['price']} ₸" + (f", предзаказ {pub['preorder']} дн" if pub.get("preorder") else "")
                rep["on_sale"].append(sku)
            else:
                rep["waiting"].append(sku)
    with _lock:
        fresh = load_drafts()
        by = {d["sku"]: d for d in drafts}
        fresh = [by.get(x["sku"], x) if x["sku"] in {d["sku"] for d in todo} else x for x in fresh]
        save_drafts(fresh)
    return rep


_watch_started = False


def start_watcher(interval_sec=600):
    """Фоновая проверка модерации раз в 10 минут, пока запущена программа."""
    global _watch_started
    if _watch_started:
        return
    _watch_started = True

    def loop():
        time.sleep(90)
        while True:
            try:
                from core import license as _lic
                if not _lic.is_active():
                    time.sleep(interval_sec)
                    continue
                if any(d.get("status") == "sent" for d in load_drafts()):
                    refresh_status()              # загрузка обработана? -> «на модерации»
                if any(d.get("status") in ("accepted", "selling") for d in load_drafts()):
                    if ks._config_value("kaspi_cab_login", "") and ks._config_value("kaspi_cab_password", ""):
                        autosale(manual=False)
            except Exception as e:
                print("cards watcher:", e)
            time.sleep(interval_sec)
    threading.Thread(target=loop, daemon=True, name="cards-watcher").start()


def ai_photo(sku):
    """Студийное ИИ-фото по первому фото товара (RoyalTech). Возвращает публичную ссылку и ставит фото главным."""
    from core.nanobanana import generate_product_photo
    key = str(ks._config_value("royaltech_api_key", "")).strip()
    if not key:
        raise RuntimeError("Нет ключа RoyalTech (Настройки → NanoBanana) — ИИ-фото недоступно.")
    drafts = load_drafts()
    d = _find(drafts, sku)
    if not d or not d.get("images"):
        raise RuntimeError("Нет исходного фото")
    ref = d["images"][0]                    # исходная ссылка (RoyalTech не скачивает через конвертер wsrv)
    prompt = ("Professional e-commerce product photo of the exact item from the reference image, same shape, color and "
              "material, no text, no logos, no watermarks, clean light neutral background, soft studio light, sharp focus")
    res = generate_product_photo(key, reference_image_url=ref, prompt_text=prompt, aspect_ratio="portrait")
    if not res.get("success") or not res.get("url"):
        raise RuntimeError("ИИ-фото не получилось: " + str(res.get("error")))
    return update_draft(sku, {"images": [res["url"]] + [u for u in d["images"] if u != res["url"]][:9]})
