"""Калькулятор маржинальности: данные карточки Kaspi по ссылке (только чтение публичной витрины).
Берём: название, фото, рейтинг и число отзывов, цены топ-5 продавцов, место карточки в своей категории,
возраст карточки и число отзывов за 30 дней (по датам отзывов). Расчёт денег делает экран (static/margin.js).
Ничего не пишет в Kaspi, кабинет не нужен."""
import datetime
import json
import math
import re
import time
import urllib.parse

import requests

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0.0.0 Safari/537.36")
_CACHE = {}
_TTL = 1800
POS_PAGES = 10          # 10 страниц по 12 карточек = первые 120 мест


def parse_code(text):
    s = str(text or "").strip()
    m = re.search(r"-(\d{5,})/?(?:[?#].*)?$", s) or re.search(r"/p/[^?#]*?(\d{7,12})", s) or re.fullmatch(r"(\d{5,})", s)
    if not m:
        raise RuntimeError("Не нашёл код карточки. Вставьте ссылку на товар Kaspi (оканчивается на число) или сам код.")
    return m.group(1)


def cny_rate():
    """Официальный курс юаня НБ РК (тенге за 1 ¥). Только подсказка: рабочий курс задаёт продавец."""
    r = requests.get("https://www.nationalbank.kz/rss/get_rates.cfm?fdate=" + time.strftime("%d.%m.%Y"), timeout=20)
    t = r.content.decode("utf-8", "replace")
    m = re.search(r"<title>CNY</title>.*?<description>([\d.]+)</description>", t, re.S)
    if not m:
        raise RuntimeError("НБ РК не отдал курс юаня.")
    return float(m.group(1))


def _page(code, city):
    r = requests.get(f"https://kaspi.kz/shop/p/-{code}/?c={city}", headers={"User-Agent": UA, "Accept-Language": "ru"}, timeout=25)
    if r.status_code != 200:
        raise RuntimeError(f"Kaspi не открыл карточку ({r.status_code}).")
    t = r.content.decode("utf-8", "replace")
    out = {"title": None, "img": None, "category": None, "leaf": None, "rating": None, "reviews": 0}
    for m in re.finditer(r'<script type="application/ld\+json">(.*?)</script>', t, re.S):
        try:
            j = json.loads(m.group(1))
        except Exception:
            continue
        if isinstance(j, dict) and j.get("@type") == "Product":
            out["title"], out["img"], out["category"] = j.get("name"), j.get("image"), j.get("category")
            break
    m = re.search(r'"categoryCodes":\["([^"]+)"', t)
    out["leaf"] = m.group(1) if m else None
    m = re.search(r'"rating":([\d.]+),"reviewsQuantity":(\d+)', t)
    if m:
        out["rating"], out["reviews"] = float(m.group(1)), int(m.group(2))
    return out


def _offers(code, city):
    body = {"cityId": city, "id": code, "merchantUID": [], "limit": 64, "page": 0, "sort": True}
    r = requests.post(f"https://kaspi.kz/yml/offer-view/offers/{code}", json=body, timeout=20,
                      headers={"User-Agent": UA, "Referer": f"https://kaspi.kz/shop/p/-{code}/", "Origin": "https://kaspi.kz"})
    if r.status_code != 200:
        return 0, []
    j = r.json()
    offs = []
    for o in j.get("offers", []):
        try:
            opts = o.get("deliveryOptions") or {}
            opt = opts.get(o.get("deliveryType")) or (next(iter(opts.values())) if opts else {})
            offs.append({"merchant": o.get("merchantName") or "", "price": int(float(o.get("price"))),
                         "rating": o.get("merchantRating"), "reviews": o.get("merchantReviewsQuantity"),
                         "kaspi_delivery": bool(o.get("kaspiDelivery")), "preorder": int(o.get("preorder") or 0),
                         "delivery": (o.get("delivery") or "")[:10], "days": opt.get("deliveryDays"),
                         "inter_city": opt.get("interCity"), "delivery_type": o.get("deliveryType")})
        except Exception:
            continue
    offs.sort(key=lambda x: x["price"])
    return int(j.get("offersCount") or len(offs)), offs


def _position(code, leaf, city):
    """Место карточки в выдаче своей категории (сортировка «по популярности»). None — дальше первых 120."""
    if not leaf:
        return None, 0
    seen = 0
    for page in range(POS_PAGES):
        q = f":category:{leaf}:availableInZones:Magnum_ZONE1"
        u = (f"https://kaspi.kz/yml/product-view/pl/results?page={page}&q={urllib.parse.quote(q)}"
             f"&text=&sort=relevance&qs=&ui=d&i=-1&c={city}")
        try:
            r = requests.get(u, headers={"User-Agent": UA, "Referer": "https://kaspi.kz/shop/"}, timeout=25)
            data = r.json().get("data") or []
        except Exception:
            break
        if not data:
            break
        for i, it in enumerate(data):
            if str(it.get("id")) == code or str(it.get("configSku")) == code:
                return seen + i + 1, seen + len(data)
        seen += len(data)
        time.sleep(0.5)
    return None, seen


def _parse_date(s):
    try:
        return datetime.datetime.strptime(s, "%d.%m.%Y").date()
    except Exception:
        return None


def _reviews_info(code, total):
    """Возраст карточки (по самому старому отзыву) и число отзывов за последние 30 дней."""
    if not total:
        return None, 0
    base = f"https://kaspi.kz/yml/review-view/api/v1/reviews/product/{code}"
    H = {"User-Agent": UA, "Referer": f"https://kaspi.kz/shop/p/-{code}/", "Accept": "application/json"}

    def get(page):
        r = requests.get(base + f"?limit=20&page={page}&orderBy=DATE&asc=true", headers=H, timeout=20)
        return [_parse_date(d.get("date")) for d in (r.json().get("data") or [])] if r.status_code == 200 else []
    today = datetime.date.today()
    recent, oldest = 0, None
    pages = max(1, math.ceil(total / 20))
    for p in range(min(pages, 3)):               # свежие отзывы идут первыми
        ds = [d for d in get(p) if d]
        recent += sum(1 for d in ds if (today - d).days <= 30)
        if ds and (today - ds[-1]).days > 30:
            break
    last = [d for d in get(pages - 1) if d]
    if last:
        oldest = min(last)
    age_days = (today - oldest).days if oldest else None
    return age_days, recent


_COMM = []


def commission_for(category):
    """Комиссия Kaspi «с НДС» по названию категории из таблицы core/kaspi_commissions.json (таблица Kaspi по категориям)."""
    global _COMM
    if not category:
        return None
    if not _COMM:
        import os
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "kaspi_commissions.json"), encoding="utf-8") as f:
            _COMM = json.load(f)
    q = str(category).strip().lower()
    hits = [r for r in _COMM if q in r[0]]
    strong = [r for r in hits if r[0].endswith(q)]
    use = strong or hits
    if not use:
        return None
    rates = {}
    for _, r in use:
        rates[r] = rates.get(r, 0) + 1
    rate = sorted(rates.items(), key=lambda kv: (-kv[1], -kv[0]))[0][0]
    return {"rate": rate, "ambiguous": len(rates) > 1, "matches": len(use)}


def inspect(link, city="750000000"):
    code = parse_code(link)
    hit = _CACHE.get(code)
    if hit and time.time() - hit[0] < _TTL:
        return hit[1]
    pg = _page(code, city)
    count, offs = _offers(code, city)
    pos, scanned = _position(code, pg["leaf"], city)
    age_days, recent = _reviews_info(code, pg["reviews"])
    res = {"code": code, "link": f"https://kaspi.kz/shop/p/-{code}/", "title": pg["title"], "img": pg["img"],
           "category": pg["category"], "category_code": pg["leaf"], "rating": pg["rating"], "reviews": pg["reviews"],
           "reviews_30d": recent, "age_days": age_days, "sellers": count, "top": offs[:5],
           "position": pos, "position_scanned": scanned, "commission": commission_for(pg["category"])}
    _CACHE[code] = (time.time(), res)
    return res
