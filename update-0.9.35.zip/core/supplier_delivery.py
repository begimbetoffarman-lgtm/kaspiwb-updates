"""Ozon delivery dates for the selected city; never infer a date from another city."""
import datetime as dt
import re

MONTHS={'января':1,'февраля':2,'марта':3,'апреля':4,'мая':5,'июня':6,'июля':7,'августа':8,'сентября':9,'октября':10,'ноября':11,'декабря':12}

def delivery_info(raw, expected_city, buffer_days=3, today=None):
    today=today or dt.datetime.now(dt.timezone(dt.timedelta(hours=5))).date()
    city=str((raw or {}).get('city') or '').strip()
    text=str((raw or {}).get('text') or '').strip()
    result={'city':city,'expected_city':expected_city,'text':text,'verified':False,'preorder_days':None}
    norm=lambda value:re.sub(r'[^а-яa-z0-9]','',str(value).lower().replace('ё','е'))
    if not expected_city or not city or norm(city)!=norm(expected_city):
        result['error']='Для срока Ozon выберите в его окне тот же город, что в программе: '+str(expected_city or 'город не задан в Первом запуске')+'. Затем повторите загрузку.'
        return result
    dates=[]
    for first,last,month in re.findall(r'(\d{1,2})(?:\s*[-–—]\s*(\d{1,2}))?\s+('+'|'.join(MONTHS)+')',text.lower()):
        try:
            month=MONTHS[month];year=today.year+(1 if today.month==12 and month==1 else 0)
            date=dt.date(year,month,int(last or first))
            if date>=today:dates.append(date)
        except ValueError:pass
    if not dates:
        for phrase,offset in [('послезавтра',2),('завтра',1),('сегодня',0)]:
            if phrase in text.lower():dates=[today+dt.timedelta(days=offset)];break
    if not dates:
        result['error']='Ozon не показал дату доставки для этого варианта. Выберите адрес или пункт выдачи в его окне и повторите загрузку.'
        return result
    date=max(dates);days=max(1,(date-today).days+max(0,int(buffer_days)))
    if days>30:
        result['error']='Доставка Ozon с запасом превышает 30 дней. Такой срок предзаказа нельзя выставить в Kaspi.'
        return result
    result.update(verified=True,preorder_days=days,date=date.isoformat(),buffer_days=max(0,int(buffer_days)))
    return result
