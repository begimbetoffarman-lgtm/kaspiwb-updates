"""
Автопилот репрайсера: фоновый цикл, который сам, без нажатия кнопки,
1) обновляет цены конкурентов по товарам, которые можно демпинговать,
2) пересчитывает цены (run_auto_repricer_cycle, с защитой маржи),
3) пересобирает XML-прайс, который Kaspi забирает по постоянной ссылке.

Работает, пока запущена программа. Состояние пишется в data/autopilot_status.json.
"""
import json
import os
import threading
import time
import traceback

from core import kaspi_store as ks

STATUS_FILE = os.path.join(ks.DATA_DIR, "autopilot_status.json")
FEED_FILE = os.path.join(ks.DATA_DIR, "feed.xml")
MIN_INTERVAL_MIN = 10
DEFAULT_INTERVAL_MIN = 30

_lock = threading.Lock()   # не даёт двум циклам идти одновременно
_feed_lock = threading.Lock()
_started = False


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def load_status():
    try:
        with open(STATUS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_status(st):
    os.makedirs(ks.DATA_DIR, exist_ok=True)
    tmp = STATUS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=2)
    os.replace(tmp, STATUS_FILE)


def interval_min(cfg=None):
    cfg = cfg or ks.load_repricer_config()
    try:
        v = int(cfg.get("interval_min", DEFAULT_INTERVAL_MIN))
    except Exception:
        v = DEFAULT_INTERVAL_MIN
    return max(MIN_INTERVAL_MIN, v)


def rebuild_feed():
    """Пересобирает XML-прайс атомарно (Kaspi никогда не увидит недописанный файл)."""
    with _feed_lock:
        tmp = FEED_FILE + ".tmp"
        ks.export_kaspi_xml_feed(tmp)
        os.replace(tmp, FEED_FILE)
    return FEED_FILE


def feed_path(max_age_sec=120):
    """Путь к свежему фиду: если файл старше max_age_sec, пересобирает (чтобы ручные правки цен тоже попадали)."""
    if not os.path.exists(FEED_FILE) or time.time() - os.path.getmtime(FEED_FILE) > max_age_sec:
        rebuild_feed()
    return FEED_FILE


def targets():
    """Товары, которые робот реально может вести: есть код карточки Kaspi и ваша себестоимость."""
    data = ks.fetch_kaspi_store_data()
    return [p for p in data.get("products", []) if p.get("card_code", "").isdigit() and (p.get("cost_real") or p.get("min_price"))]


def run_once(reason="manual"):
    """Один полный цикл. Возвращает итог; при уже идущем цикле — {'busy': True}."""
    if not _lock.acquire(blocking=False):
        return {"success": False, "busy": True, "error": "Цикл уже идёт"}
    st = load_status()
    st.update({"running": True, "started_at": _now(), "reason": reason})
    _save_status(st)
    try:
        cfg = ks.load_repricer_config()
        max_age = max(60, interval_min(cfg) * 60 - 60)
        tg = targets()
        fetched, errors = 0, []
        for p in tg:
            r = ks.fetch_competitor_prices(p["card_code"], max_age_sec=max_age)
            if r.get("ok"):
                fetched += 1
            else:
                errors.append(f'{p["sku"]}: {r.get("error")}')
                if "429" in str(r.get("error")):
                    errors.append("Kaspi ограничил частоту запросов — цикл остановлен, продолжит в следующий раз.")
                    break
        cycle = ks.run_auto_repricer_cycle()
        rebuild_feed()
        st = load_status()
        st.update({
            "running": False,
            "last_run": _now(),
            "last_ok": True,
            "targets": len(tg),
            "competitors_fetched": fetched,
            "repriced": cycle.get("repriced_count", 0),
            "shielded": cycle.get("shielded_count", 0),
            "unchanged": cycle.get("unchanged_count", 0),
            "skipped": cycle.get("skipped", {}),
            "errors": errors[:10],
            "feed_built_at": _now(),
        })
        _save_status(st)
        return {"success": True, "status": st, "cycle": cycle}
    except Exception as e:
        st = load_status()
        st.update({"running": False, "last_run": _now(), "last_ok": False,
                   "errors": [f"{type(e).__name__}: {e}"]})
        _save_status(st)
        traceback.print_exc()
        return {"success": False, "error": str(e), "status": st}
    finally:
        _lock.release()


def _loop():
    # после старта программы ждём минуту, чтобы интерфейс успел загрузиться
    time.sleep(60)
    while True:
        try:
            from core import license as _lic
            if not _lic.is_active():
                time.sleep(60)
                continue
            cfg = ks.load_repricer_config()
            if cfg.get("enabled"):
                st = load_status()
                last = st.get("last_run_ts", 0)
                if time.time() - last >= interval_min(cfg) * 60:
                    st["last_run_ts"] = time.time()
                    _save_status(st)
                    run_once(reason="auto")
        except Exception:
            traceback.print_exc()
        time.sleep(30)


def start():
    global _started
    if _started:
        return
    _started = True
    st = load_status()
    st["running"] = False   # если прошлый запуск оборвался посреди цикла
    _save_status(st)
    threading.Thread(target=_loop, daemon=True, name="autopilot").start()
