// Баннеры лицензии: пробный период заканчивается или закончился. Сервер сам закрывает функции (код 402).
(function () {
  const ban = () => {
    let b = document.getElementById('licBanner');
    if (!b) {
      b = document.createElement('div'); b.id = 'licBanner'; b.style.display = 'none';
      const mc = document.querySelector('.main-content'); if (mc) mc.insertBefore(b, mc.firstChild);
    }
    return b;
  };
  async function check() {
    let s; try { s = await (await fetch('/api/license')).json(); } catch (e) { return; }
    const b = ban(); if (!b) return;
    const contact = ' Связь: +7 700 394 00 94 (WhatsApp / Telegram).';
    if (!s.is_active) {
      b.className = 'lic-banner bad';
      b.innerHTML = '<b>Пробный период закончился.</b> Доступны заказы и накладные, настройки и обновления; защита (снятие с продажи товара, которого нет на WB) продолжает работать. Остальное откроется после активации: <a href="#" id="licOpen">Активировать PRO</a>.' + contact;
    } else if (s.status === 'TRIAL' && s.days_left <= 2) {
      b.className = 'lic-banner warn';
      b.innerHTML = '<b>Пробный период заканчивается через ' + s.days_left + ' дн.</b> Чтобы продолжить, <a href="#" id="licOpen">активируйте PRO</a>.' + contact;
    } else if (s.status === 'PRO' && s.days_left <= 3) {
      b.className = 'lic-banner warn';
      b.innerHTML = '<b>Лицензия заканчивается через ' + s.days_left + ' дн.</b> Продлите ключ.' + contact;
    } else { b.style.display = 'none'; return; }
    b.style.display = '';
    const l = document.getElementById('licOpen');
    if (l) l.onclick = e => { e.preventDefault(); const a = document.getElementById('btnSidebarActivate'); if (a) a.click(); };
  }
  // сервер отвечает 402, когда функция закрыта: показываем причину и обновляем баннер
  const of = window.fetch; let last = 0;
  window.fetch = async function (...a) {
    const r = await of.apply(this, a);
    if (r.status === 402) {
      try { const d = await r.clone().json(); if (d.license_expired && Date.now() - last > 3000) { last = Date.now(); if (typeof showToast === 'function') showToast(d.error); check(); } } catch (e) { }
    }
    return r;
  };
  // после обновления старый код ещё работает в памяти: просим перезапустить программу
  async function vcheck() {
    let v; try { v = await (await fetch('/api/version')).json(); } catch (e) { return; }
    let b = document.getElementById('restartBanner');
    if (!v || !v.restart_needed) { if (b) b.style.display = 'none'; return; }
    if (!b) {
      b = document.createElement('div'); b.id = 'restartBanner'; b.className = 'lic-banner warn';
      const mc = document.querySelector('.main-content'); if (mc) mc.insertBefore(b, mc.firstChild);
    }
    b.innerHTML = '<b>Программа обновлена до версии ' + v.disk + ', но ещё работает старая (' + v.running + ').</b> Закройте чёрное окно программы и запустите её заново (start.bat), иначе часть функций, например код из почты и сохранение паролей, будет работать неверно.';
    b.style.display = '';
  }
  document.addEventListener('DOMContentLoaded', () => { setTimeout(check, 800); setTimeout(vcheck, 1500); });
  setInterval(vcheck, 120000);
  setInterval(check, 300000);
  window.checkLicenseBanner = check;
})();
