// Окно оплаты подписки: Kaspi QR, кнопка «Я оплатил» (заявка автору + сообщение в WhatsApp с номером компьютера).
(function () {
  const $ = id => document.getElementById(id);
  const WA = '77003940094';          // WhatsApp автора
  const PRICE = '9 900';
  function init() {
    const b = $('btnPayDone'); if (!b) return;
    b.addEventListener('click', async () => {
      const machine = ($('modalMachineId') && $('modalMachineId').textContent || '').trim();
      const contact = ($('payContact').value || '').trim();
      b.disabled = true; $('payMsg').textContent = 'Отправляю заявку…';
      let sent = false;
      try {
        const r = await fetch('/api/payment/claim', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contact }) });
        const d = await r.json(); sent = d.success === true;
        if (!sent && d.error) $('payMsg').textContent = d.error;
      } catch (e) { sent = false; }
      const text = 'Здравствуйте! Оплатил Kaspi QR ' + PRICE + ' ₸ за программу Kaspi WB. Номер компьютера: ' + machine + (contact ? '. Контакт: ' + contact : '') + '.';
      $('payMsg').innerHTML = (sent ? '✅ Заявка отправлена автору. ' : '') + 'Чтобы ключ пришёл быстрее, напишите в WhatsApp: <a href="https://wa.me/' + WA + '?text=' + encodeURIComponent(text) + '" target="_blank" rel="noopener">открыть чат</a>. Ключ вставьте в поле ниже и нажмите «Активировать PRO».';
      b.disabled = false;
    });
  }
  let tries = 0; const iv = setInterval(() => { if ($('btnPayDone') || ++tries > 30) { clearInterval(iv); init(); } }, 500);
})();
