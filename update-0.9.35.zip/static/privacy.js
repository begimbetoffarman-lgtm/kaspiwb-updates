// Кнопка «Удалить мои данные с этого компьютера» (Настройки).
(function () {
  const $ = id => document.getElementById(id);
  async function init() {
    const b = $('btnWipeData'); if (!b) return;
    try { const d = await (await fetch('/api/data/info')).json(); if (d.backend) $('wipeBackend').textContent = d.backend; } catch (e) {}
    b.addEventListener('click', async () => {
      const q = 'Удалить ВСЕ данные программы с этого компьютера?\n\nБудут стёрты: токен и пароли, настройки магазина, карточки, цены, накладные, вход в кабинет.\nЛицензия и пробный период сохранятся.\nОтменить нельзя.';
      if (!confirm(q)) return;
      const t = prompt('Для подтверждения введите слово УДАЛИТЬ');
      if (!t || t.trim().toUpperCase() !== 'УДАЛИТЬ') { $('wipeMsg').textContent = 'Отменено: слово не совпало.'; return; }
      b.disabled = true;
      try {
        const d = await (await fetch('/api/data/wipe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ confirm: 'УДАЛИТЬ' }) })).json();
        $('wipeMsg').textContent = d.success ? 'Готово: данные удалены. Закройте программу и запустите её заново.' : (d.error || 'Не удалось удалить.');
      } catch (e) { $('wipeMsg').textContent = 'Ошибка связи с программой.'; }
      b.disabled = false;
    });
  }
  // блок настроек может появиться позже загрузки страницы: ждём кнопку до 15 секунд
  let tries = 0; const iv = setInterval(() => { if ($('btnWipeData') || ++tries > 30) { clearInterval(iv); init(); } }, 500);
})();
