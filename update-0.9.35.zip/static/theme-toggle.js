// Переключатель «День / Ночь». Выбор запоминается; пока не выбирали, тема берётся из настроек системы.
(function () {
  const KEY = 'kwTheme';
  const sys = () => (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
  const saved = () => { try { return localStorage.getItem(KEY); } catch (e) { return null; } };
  const store = m => { try { localStorage.setItem(KEY, m); } catch (e) { } };
  function paint(m) {
    document.documentElement.setAttribute('data-theme', m);
    document.querySelectorAll('#themeSwitch button').forEach(b => {
      const on = b.dataset.mode === m;
      b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }
  function init() {
    paint(saved() || sys());
    document.querySelectorAll('#themeSwitch button').forEach(b => b.addEventListener('click', () => { store(b.dataset.mode); paint(b.dataset.mode); }));
    if (window.matchMedia) {
      const mq = window.matchMedia('(prefers-color-scheme: dark)');
      const h = () => { if (!saved()) paint(sys()); };
      if (mq.addEventListener) mq.addEventListener('change', h); else if (mq.addListener) mq.addListener(h);
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
