// Если программу перезапустили, а вкладка осталась старой: сервер отвечает 403 session_expired, страница обновляется сама один раз.
(function () {
  const of = window.fetch;
  window.fetch = async function () {
    const r = await of.apply(this, arguments);
    if (r.status === 403) {
      try {
        const j = await r.clone().json();
        if (j && j.session_expired) {
          let n = 0; try { n = +sessionStorage.getItem('kwbReload') || 0; } catch (e) {}
          if (n < 1) { try { sessionStorage.setItem('kwbReload', '1'); } catch (e) {} location.reload(); }
        }
      } catch (e) {}
    } else { try { sessionStorage.removeItem('kwbReload'); } catch (e) {} }
    return r;
  };
})();
